-- =============================================
-- Author:      <Prathik>
-- Version:     <3.2.2.28>
-- Description:	<generic query for report. this will create record with report name if exists it will update same>
-- =============================================
declare @count int
set @count= (select count(*) from [dbo].[OCMCustomReport] where [ReportName]='OCMAgentLoginLogoutReport')

if(@count>=1)
begin
   UPDATE [dbo].[OCMCustomReport]
    SET [ReportQuery] = 'SELECT M.[AgentID],A.[AgentName],[StationID],[SkillList],[SkillNameList],[LoginDateTime],[LogoutDateTime],[LogoutReasonCode],
	[LogoutReason],[ReportDateTime],A.TeamName,A.SupervisorName FROM [OCM_AgentLoginLogoutReport] M WITH(NOLOCK) 
	INNER JOIN fn_AgentHierarchy(ReportFilterType,TeamFilter,UserIdFilter) A ON  A.AgentId=M.AgentID
	WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime]<= ExportToDate',
    [LastChangedOn] = replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':','')
    WHERE [ReportName]='OCMAgentLoginLogoutReport'

end
else
begin
	 
	INSERT [dbo].[OCMCustomReport] ([ReportName], [ReportQuery], [ReportCreatedBy], [ReportCreatedOn], [LastChangedBy], [LastChangedOn], [ReportType])
    VALUES ( N'OCMAgentLoginLogoutReport', N'SELECT M.[AgentID],A.[AgentName],[StationID],[SkillList],[SkillNameList],[LoginDateTime],[LogoutDateTime],[LogoutReasonCode],
	[LogoutReason],[ReportDateTime],A.TeamName,A.SupervisorName FROM [OCM_AgentLoginLogoutReport] M WITH(NOLOCK) 
	INNER JOIN fn_AgentHierarchy(ReportFilterType,TeamFilter,UserIdFilter) A  ON  A.AgentId=M.AgentID
	WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime]<= ExportToDate', 
	N'Admin',replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Admin', 
    replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Generic')
end




