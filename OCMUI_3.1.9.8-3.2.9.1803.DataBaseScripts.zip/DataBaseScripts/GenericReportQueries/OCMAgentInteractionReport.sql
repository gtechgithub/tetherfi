-- =============================================
-- Author:      <Prathik>
-- Version:     <3.2.2.28>
-- Description:	<generic query for report. this will create record with report name if exists it will update same>
-- =============================================
declare @count int
set @count= (select count(*) from [dbo].[OCMCustomReport] where [ReportName]='OCMAgentInteractionReport')

if(@count>=1)
begin
   UPDATE [dbo].[OCMCustomReport]
   SET [ReportQuery] = 'SELECT M.[AgentID],A.[AgentName],[Channel],[Direction],[DNIS],[ConnectedDateTime],[CreatedDateTime],[Ani],
	[ActiveTime],[SessionID],[HoldTime],[IsConferenced],[IsTransfered],[TPINTransferReconnected],[SubChannel],
	[SubSessionID],[InteractionID],[Skill],[SkillName],[DNISName],[TransferedTo],[ConferencedTo],[ConferenceToAgentList],
	[TransferToAgent],[TransferConferenceFromAgent],[TransferConferenceFromInteraction],[OtherData],[ClosedDateTime],
	[DisconnectedDateTime],[ClosedReason],[QueueTime],[ACWTime] ,[HandleTime],[ReportDateTime],
	A.TeamName,A.SupervisorName,[CIF],[RegisteredMobileNo] FROM [OCM_AgentInteractionReport] M WITH(NOLOCK) 
	INNER JOIN  fn_AgentHierarchy(ReportFilterType,TeamFilter,UserIdFilter) A  ON A.AgentId=M.AgentID
	WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime] <= ExportToDate'
    ,[LastChangedOn] = replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':','')
    WHERE [ReportName]='OCMAgentInteractionReport'

end
else
begin
	INSERT [dbo].[OCMCustomReport] ( [ReportName], [ReportQuery], [ReportCreatedBy], [ReportCreatedOn], [LastChangedBy], [LastChangedOn], [ReportType]) 
	VALUES ( N'OCMAgentInteractionReport', N'SELECT M.[AgentID],A.[AgentName],[Channel],[Direction],[DNIS],[ConnectedDateTime],[CreatedDateTime],[Ani],
	[ActiveTime],[SessionID],[HoldTime],[IsConferenced],[IsTransfered],[TPINTransferReconnected],[SubChannel],
	[SubSessionID],[InteractionID],[Skill],[SkillName],[DNISName],[TransferedTo],[ConferencedTo],[ConferenceToAgentList],
	[TransferToAgent],[TransferConferenceFromAgent],[TransferConferenceFromInteraction],[OtherData],[ClosedDateTime],
	[DisconnectedDateTime],[ClosedReason],[QueueTime],[ACWTime],[HandleTime] ,[ReportDateTime],
	A.TeamName,A.SupervisorName,[CIF],[RegisteredMobileNo] FROM [OCM_AgentInteractionReport] M WITH(NOLOCK) 
	INNER JOIN  fn_AgentHierarchy(ReportFilterType,TeamFilter,UserIdFilter) A  ON A.AgentId=M.AgentID
	WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime] <= ExportToDate', N'Admin', 
	replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Admin', 
	replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Generic')
end




