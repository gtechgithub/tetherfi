-- =============================================
-- Author:      <Prathik>
-- Version:     <3.1.11.30>
-- Description:	<generic query for report. this will create record with report name if exists it will update same>
-- =============================================
declare @count int
set @count= (select count(*) from [dbo].[OCMCustomReport] where [ReportName]='OCMAgentSummaryLoginLogoutReport')

if(@count>=1)
begin
   UPDATE [dbo].[OCMCustomReport]
   SET [ReportQuery] = 'SELECT [AgentID],[AgentName],[LoginDateTime],[LogoutDateTime],[SkillList],[StationID],[TotalInteraction],[TotalVoice],
	[TotalChat],[TotalSM],[TotalSMS],isnull([TotalFax],0) [TotalFax],[TotalEmail],[TotalAudioIP],[TotalVideoIP],[TotalStaffedTime],[TotalInteractionTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalInteractionTime]) * 3600 +DATEPART(mi, [TotalInteractionTime]) * 60 + DATEPART(ss,[TotalInteractionTime])/nullif([TotalInteraction],0)),0),0),108) as [AvgInteractionTime],[TotalVoiceTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalVoiceTime]) * 3600 +DATEPART(mi, [TotalVoiceTime]) * 60 + DATEPART(ss,[TotalVoiceTime])/nullif([TotalVoice],0)),0),0),108) as [AvgVoiceTime],[TotalChatTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalChatTime]) * 3600 +DATEPART(mi, [TotalChatTime]) * 60 + DATEPART(ss,[TotalChatTime])/nullif([TotalChat],0)),0),0),108) as [AvgChatTime],[TotalSMTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalSMTime]) * 3600 +DATEPART(mi, [TotalSMTime]) * 60 + DATEPART(ss,[TotalSMTime])/nullif([TotalSM],0)),0),0),108) as [AvgSMTime],[TotalSMSTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalSMSTime]) * 3600 +DATEPART(mi, [TotalSMSTime]) * 60 + DATEPART(ss,[TotalSMSTime])/nullif([TotalSMS],0)),0),0),108) as [AvgSMSTime],[TotalFaxTime] ,
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalFaxTime]) * 3600 +DATEPART(mi, [TotalFaxTime]) * 60 + DATEPART(ss,[TotalFaxTime])/nullif([TotalFax],0)),0),0),108) as [AvgFaxTime],[TotalEmailTime] ,
	CONVERT(char(8),DATEADD(second,isnull(( DATEPART(hh,[TotalEmailTime]) * 3600 +DATEPART(mi, [TotalEmailTime]) * 60 + DATEPART(ss,[TotalEmailTime])/nullif([TotalEmail],0)),0),0),108) as [AvgEmailTime],[TotalAudioIPTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalAudioIPTime]) * 3600 +DATEPART(mi, [TotalAudioIPTime]) * 60 + DATEPART(ss,[TotalAudioIPTime])/nullif([TotalAudioIP],0)),0),0),108) as [AvgAudioIPTime],[TotalVideoIPTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalVideoIPTime]) * 3600 +DATEPART(mi, [TotalVideoIPTime]) * 60 + DATEPART(ss,[TotalVideoIPTime])/nullif([TotalVideoIP],0)),0),0),108) as[AvgVideoIPTime],
	[TotalACWTime],[TotalAuxTime],[TotalExtIn],[TotalExtOut],[TotalTransferIn],[TotalTransferOut],[TotalConferenceIn],[TotalConferenceOut],[ReportDateTime] 
	FROM [dbo].[OCM_AgentSummaryReport] WITH(NOLOCK) WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime]<= ExportToDate AND [AgentID] like DetailReportParameter',
   [LastChangedOn] = replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':','')
    WHERE [ReportName]='OCMAgentSummaryLoginLogoutReport'

end
else
begin
		
	INSERT [dbo].[OCMCustomReport] ( [ReportName], [ReportQuery], [ReportCreatedBy], [ReportCreatedOn], [LastChangedBy], [LastChangedOn], [ReportType]) 
	VALUES ( N'OCMAgentSummaryLoginLogoutReport', N'SELECT [AgentID],[AgentName],[LoginDateTime],[LogoutDateTime],[SkillList],[StationID],[TotalInteraction],[TotalVoice],
	[TotalChat],[TotalSM],[TotalSMS],isnull([TotalFax],0) [TotalFax],[TotalEmail],[TotalAudioIP],[TotalVideoIP],[TotalStaffedTime],[TotalInteractionTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalInteractionTime]) * 3600 +DATEPART(mi, [TotalInteractionTime]) * 60 + DATEPART(ss,[TotalInteractionTime])/nullif([TotalInteraction],0)),0),0),108) as [AvgInteractionTime],[TotalVoiceTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalVoiceTime]) * 3600 +DATEPART(mi, [TotalVoiceTime]) * 60 + DATEPART(ss,[TotalVoiceTime])/nullif([TotalVoice],0)),0),0),108) as [AvgVoiceTime],[TotalChatTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalChatTime]) * 3600 +DATEPART(mi, [TotalChatTime]) * 60 + DATEPART(ss,[TotalChatTime])/nullif([TotalChat],0)),0),0),108) as [AvgChatTime],[TotalSMTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalSMTime]) * 3600 +DATEPART(mi, [TotalSMTime]) * 60 + DATEPART(ss,[TotalSMTime])/nullif([TotalSM],0)),0),0),108) as [AvgSMTime],[TotalSMSTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalSMSTime]) * 3600 +DATEPART(mi, [TotalSMSTime]) * 60 + DATEPART(ss,[TotalSMSTime])/nullif([TotalSMS],0)),0),0),108) as [AvgSMSTime],[TotalFaxTime] ,
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalFaxTime]) * 3600 +DATEPART(mi, [TotalFaxTime]) * 60 + DATEPART(ss,[TotalFaxTime])/nullif([TotalFax],0)),0),0),108) as [AvgFaxTime],[TotalEmailTime] ,
	CONVERT(char(8),DATEADD(second,isnull(( DATEPART(hh,[TotalEmailTime]) * 3600 +DATEPART(mi, [TotalEmailTime]) * 60 + DATEPART(ss,[TotalEmailTime])/nullif([TotalEmail],0)),0),0),108) as [AvgEmailTime],[TotalAudioIPTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalAudioIPTime]) * 3600 +DATEPART(mi, [TotalAudioIPTime]) * 60 + DATEPART(ss,[TotalAudioIPTime])/nullif([TotalAudioIP],0)),0),0),108) as [AvgAudioIPTime],[TotalVideoIPTime],
	CONVERT(char(8),DATEADD(second, isnull((DATEPART(hh,[TotalVideoIPTime]) * 3600 +DATEPART(mi, [TotalVideoIPTime]) * 60 + DATEPART(ss,[TotalVideoIPTime])/nullif([TotalVideoIP],0)),0),0),108) as[AvgVideoIPTime],
	[TotalACWTime],[TotalAuxTime],[TotalExtIn],[TotalExtOut],[TotalTransferIn],[TotalTransferOut],[TotalConferenceIn],[TotalConferenceOut],[ReportDateTime] 
	FROM [dbo].[OCM_AgentSummaryReport] WITH(NOLOCK) WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime]<= ExportToDate AND [AgentID] like DetailReportParameter', N'Admin',
	replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Admin', 
	replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Generic')
end

