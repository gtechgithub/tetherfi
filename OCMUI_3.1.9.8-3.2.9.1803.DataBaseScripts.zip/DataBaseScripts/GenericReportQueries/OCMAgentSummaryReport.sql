-- =============================================
-- Author:      <Prathik>
-- Version:     <3.1.12.28>
-- Description:	<generic query for report. this will create record with report name if exists it will update same>
-- =============================================
declare @count int
set @count= (select count(*) from [dbo].[OCMCustomReport] where [ReportName]='OCMAgentSummaryReport')

if(@count>=1)
begin
   UPDATE [dbo].[OCMCustomReport]
   SET [ReportQuery] = 'SELECT M.[AgentID] ,A.[AgentName],SUM([TotalInteraction]) [TotalInteraction],SUM(TotalVoice) TotalVoice,SUM(TotalChat) TotalChat,SUM(TotalSM) TotalSM ,
	SUM([TotalAudioIP]) [TotalAudioIP],SUM([TotalVideoIP]) [TotalVideoIP],SUM(TotalSMS) TotalSMS,SUM(isnull(TotalFax,0)) TotalFax,SUM(TotalEmail) TotalEmail,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalStaffedTime) * 3600 +DATEPART(mi, TotalStaffedTime) * 60 + DATEPART(ss,TotalStaffedTime))) as [TotalStaffedTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalInteractionTime) * 3600 +DATEPART(mi, TotalInteractionTime) * 60 + DATEPART(ss,TotalInteractionTime)))as [TotalInteractionTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,TotalInteractionTime) * 3600 +DATEPART(mi, TotalInteractionTime) * 60 + DATEPART(ss,TotalInteractionTime))/nullif(SUM([TotalInteraction]),0),0))as [AvgInteractionTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalACWTime) * 3600 +DATEPART(mi, TotalACWTime) * 60 + DATEPART(ss,TotalACWTime)))as [TotalACWTime] , 
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalAuxTime) * 3600 +DATEPART(mi, TotalAuxTime) * 60 + DATEPART(ss,TotalAuxTime))) AS [TotalAuxTime],   
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalVoiceTime]) * 3600 +DATEPART(mi, [TotalVoiceTime]) * 60 + DATEPART(ss,[TotalVoiceTime])))as [TotalVoiceTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalVoiceTime]) * 3600 +DATEPART(mi, [TotalVoiceTime]) * 60 + DATEPART(ss,[TotalVoiceTime]))/nullif(SUM(TotalVoice),0),0))as [AvgVoiceTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalChatTime]) * 3600 +DATEPART(mi, [TotalChatTime]) * 60 + DATEPART(ss,[TotalChatTime])))as [TotalChatTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalChatTime]) * 3600 +DATEPART(mi, [TotalChatTime]) * 60 + DATEPART(ss,[TotalChatTime]))/nullif(SUM(TotalChat),0),0))as [AvgChatTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalSMTime]) * 3600 +DATEPART(mi, [TotalSMTime]) * 60 + DATEPART(ss,[TotalSMTime])))as [TotalSMTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalSMTime]) * 3600 +DATEPART(mi, [TotalSMTime]) * 60 + DATEPART(ss,[TotalSMTime]))/nullif(SUM(TotalSM),0),0))as [AvgSMTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalSMSTime]) * 3600 +DATEPART(mi, [TotalSMSTime]) * 60 + DATEPART(ss,[TotalSMSTime])))as [TotalSMSTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalFaxTime]) * 3600 +DATEPART(mi, [TotalFaxTime]) * 60 + DATEPART(ss,[TotalFaxTime])))as [TotalFaxTime] ,
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalSMSTime]) * 3600 +DATEPART(mi, [TotalSMSTime]) * 60 + DATEPART(ss,[TotalSMSTime]))/nullif(SUM(TotalSMS),0),0))as [AvgSMSTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalFaxTime]) * 3600 +DATEPART(mi, [TotalFaxTime]) * 60 + DATEPART(ss,[TotalFaxTime]))/nullif(SUM(TotalFax),0),0))as [AvgFaxTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalEmailTime]) * 3600 +DATEPART(mi, [TotalEmailTime]) * 60 + DATEPART(ss,[TotalEmailTime])))as [TotalEmailTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalEmailTime]) * 3600 +DATEPART(mi, [TotalEmailTime]) * 60 + DATEPART(ss,[TotalEmailTime]))/nullif(SUM(TotalEmail),0),0))as [AvgEmailTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalAudioIPTime]) * 3600 +DATEPART(mi, [TotalAudioIPTime]) * 60 + DATEPART(ss,[TotalAudioIPTime])))as [TotalAudioIPTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalAudioIPTime]) * 3600 +DATEPART(mi, [TotalAudioIPTime]) * 60 + DATEPART(ss,[TotalAudioIPTime]))/nullif(SUM([TotalAudioIP]),0),0))as [AvgAudioIPTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalVideoIPTime]) * 3600 +DATEPART(mi, [TotalVideoIPTime]) * 60 + DATEPART(ss,[TotalVideoIPTime])))as [TotalVideoIPTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalVideoIPTime]) * 3600 +DATEPART(mi, [TotalVideoIPTime]) * 60 + DATEPART(ss,[TotalVideoIPTime]))/nullif(SUM([TotalVideoIP]),0),0))as [AvgVideoIPTime] ,  
	SUM(TotalExtIn)as [TotalExtIn] ,SUM(TotalExtOut) as [TotalExtOut] ,SUM(TotalTransferIn) as [TotalTransferIn] ,SUM(TotalTransferOut) as [TotalTransferOut] ,SUM(TotalConferenceIn) as [TotalConferenceIn] ,  SUM(TotalConferenceOut) as [TotalConferenceOut] ,
	A.TeamName,A.SupervisorName FROM [dbo].[OCM_AgentSummaryReport] M WITH(NOLOCK)
	INNER JOIN fn_AgentHierarchy(ReportFilterType,TeamFilter,UserIdFilter) A  ON A.AgentId=M.[AgentID]
	WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime]<= ExportToDate   
	GROUP BY M.[AgentID],A.[AgentName],A.TeamName,A.SupervisorName',
   [LastChangedOn] = replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':','')
    WHERE [ReportName]='OCMAgentSummaryReport'

end
else
begin
		
	INSERT [dbo].[OCMCustomReport] ([ReportName], [ReportQuery], [ReportCreatedBy], [ReportCreatedOn], [LastChangedBy], [LastChangedOn], [ReportType]) 
	VALUES ( N'OCMAgentSummaryReport', N'SELECT M.[AgentID] ,A.[AgentName],SUM([TotalInteraction]) [TotalInteraction],SUM(TotalVoice) TotalVoice,SUM(TotalChat) TotalChat,SUM(TotalSM) TotalSM ,
	SUM([TotalAudioIP]) [TotalAudioIP],SUM([TotalVideoIP]) [TotalVideoIP],SUM(TotalSMS) TotalSMS,SUM(isnull(TotalFax,0)) TotalFax,SUM(TotalEmail) TotalEmail,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalStaffedTime) * 3600 +DATEPART(mi, TotalStaffedTime) * 60 + DATEPART(ss,TotalStaffedTime))) as [TotalStaffedTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalInteractionTime) * 3600 +DATEPART(mi, TotalInteractionTime) * 60 + DATEPART(ss,TotalInteractionTime)))as [TotalInteractionTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,TotalInteractionTime) * 3600 +DATEPART(mi, TotalInteractionTime) * 60 + DATEPART(ss,TotalInteractionTime))/nullif(SUM([TotalInteraction]),0),0))as [AvgInteractionTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalACWTime) * 3600 +DATEPART(mi, TotalACWTime) * 60 + DATEPART(ss,TotalACWTime)))as [TotalACWTime] , 
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,TotalAuxTime) * 3600 +DATEPART(mi, TotalAuxTime) * 60 + DATEPART(ss,TotalAuxTime))) AS [TotalAuxTime],   
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalVoiceTime]) * 3600 +DATEPART(mi, [TotalVoiceTime]) * 60 + DATEPART(ss,[TotalVoiceTime])))as [TotalVoiceTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalVoiceTime]) * 3600 +DATEPART(mi, [TotalVoiceTime]) * 60 + DATEPART(ss,[TotalVoiceTime]))/nullif(SUM(TotalVoice),0),0))as [AvgVoiceTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalChatTime]) * 3600 +DATEPART(mi, [TotalChatTime]) * 60 + DATEPART(ss,[TotalChatTime])))as [TotalChatTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalChatTime]) * 3600 +DATEPART(mi, [TotalChatTime]) * 60 + DATEPART(ss,[TotalChatTime]))/nullif(SUM(TotalChat),0),0))as [AvgChatTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalSMTime]) * 3600 +DATEPART(mi, [TotalSMTime]) * 60 + DATEPART(ss,[TotalSMTime])))as [TotalSMTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalSMTime]) * 3600 +DATEPART(mi, [TotalSMTime]) * 60 + DATEPART(ss,[TotalSMTime]))/nullif(SUM(TotalSM),0),0))as [AvgSMTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalSMSTime]) * 3600 +DATEPART(mi, [TotalSMSTime]) * 60 + DATEPART(ss,[TotalSMSTime])))as [TotalSMSTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalFaxTime]) * 3600 +DATEPART(mi, [TotalFaxTime]) * 60 + DATEPART(ss,[TotalFaxTime])))as [TotalFaxTime] ,
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalSMSTime]) * 3600 +DATEPART(mi, [TotalSMSTime]) * 60 + DATEPART(ss,[TotalSMSTime]))/nullif(SUM(TotalSMS),0),0))as [AvgSMSTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalFaxTime]) * 3600 +DATEPART(mi, [TotalFaxTime]) * 60 + DATEPART(ss,[TotalFaxTime]))/nullif(SUM(TotalFax),0),0))as [AvgFaxTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalEmailTime]) * 3600 +DATEPART(mi, [TotalEmailTime]) * 60 + DATEPART(ss,[TotalEmailTime])))as [TotalEmailTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalEmailTime]) * 3600 +DATEPART(mi, [TotalEmailTime]) * 60 + DATEPART(ss,[TotalEmailTime]))/nullif(SUM(TotalEmail),0),0))as [AvgEmailTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalAudioIPTime]) * 3600 +DATEPART(mi, [TotalAudioIPTime]) * 60 + DATEPART(ss,[TotalAudioIPTime])))as [TotalAudioIPTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalAudioIPTime]) * 3600 +DATEPART(mi, [TotalAudioIPTime]) * 60 + DATEPART(ss,[TotalAudioIPTime]))/nullif(SUM([TotalAudioIP]),0),0))as [AvgAudioIPTime] ,  
	[dbo].[SECONDSTOhhmmss](SUM ( DATEPART(hh,[TotalVideoIPTime]) * 3600 +DATEPART(mi, [TotalVideoIPTime]) * 60 + DATEPART(ss,[TotalVideoIPTime])))as [TotalVideoIPTime] ,  
	[dbo].[SECONDSTOhhmmss](ISNULL(SUM ( DATEPART(hh,[TotalVideoIPTime]) * 3600 +DATEPART(mi, [TotalVideoIPTime]) * 60 + DATEPART(ss,[TotalVideoIPTime]))/nullif(SUM([TotalVideoIP]),0),0))as [AvgVideoIPTime] ,  
	SUM(TotalExtIn)as [TotalExtIn] ,SUM(TotalExtOut) as [TotalExtOut] ,SUM(TotalTransferIn) as [TotalTransferIn] ,SUM(TotalTransferOut) as [TotalTransferOut] ,SUM(TotalConferenceIn) as [TotalConferenceIn] ,  SUM(TotalConferenceOut) as [TotalConferenceOut] ,
	A.TeamName,A.SupervisorName FROM [dbo].[OCM_AgentSummaryReport] M WITH(NOLOCK)
	INNER JOIN fn_AgentHierarchy(ReportFilterType,TeamFilter,UserIdFilter) A  ON A.AgentId=M.[AgentID]
	WHERE [ReportDateTime] >= ExportFromDate AND [ReportDateTime]<= ExportToDate   
	GROUP BY M.[AgentID],A.[AgentName],A.TeamName,A.SupervisorName', N'Admin',
	replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Admin', 
	replace(convert(varchar(8), getdate(), 112)+' '+convert(varchar(8), getdate(), 114), ':',''), N'Generic')
end



