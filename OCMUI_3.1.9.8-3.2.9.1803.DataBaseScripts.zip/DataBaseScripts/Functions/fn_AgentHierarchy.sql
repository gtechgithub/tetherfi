
/****** Object:  UserDefinedFunction [dbo].[fn_AgentHierarchy]    Script Date: 04/10/2018 12:23:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:<Prathik>
-- Version:<3.1.12.28>
--Description:<This function is used to filter reports based of team,teamsupervisor and na.> 
--------------<reports will be filtered based on the ReportFilterType configured in ocm application>
-- =============================================
alter FUNCTION [dbo].[fn_AgentHierarchy](@type varchar(50), @teamid varchar(10),@supervisorid varchar(10))
RETURNS  @Result TABLE (AgentId varchar(50),AgentName varchar(200),SupervisorName varchar(200),TeamName varchar(200))
AS 
BEGIN
	 IF(@type='team')
	 BEGIN
			WITH Team AS(
			SELECT [TeamID] FROM [AGT_Teams] WHERE [TeamID] = @teamid
			UNION ALL
			SELECT t.[TeamID] FROM [AGT_Teams] t INNER JOIN Team r ON t.ParentId = r.TeamID)

			INSERT INTO @Result(AgentId,AgentName,SupervisorName,TeamName)
			SELECT DISTINCT A.AvayaLoginID,ISNULL(A.FirstName,'')+' '+ ISNULL(A.LastName,'') AgentName,
			ISNULL(B.FirstName,'NA')+' '+ ISNULL(B.LastName,'')  SupervisorName ,
			ISNULL(C.TeamName,' ') AS TeamName 
			FROM [AGT_Agent] A 
			LEFT JOIN [AGT_Agent] B WITH(NOLOCK)  ON A.[PrimarySupervisorID] = B.ID 
			LEFT JOIN [AGT_Agent] S WITH(NOLOCK)  ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN [AGT_Teams] C WITH(NOLOCK) ON C.TeamID = A.TeamID
			LEFT JOIN [AGT_Teams] P WITH(NOLOCK) ON C.ParentID  = P.TeamID
			LEFT JOIN [AGT_Teams] PC WITH(NOLOCK) ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN (SELECT TeamID FROM Team)  
	 END
	 ELSE IF (@type='teamsupervisor')
	 BEGIN
			WITH Team AS(
			SELECT [TeamID] FROM [AGT_Teams] WHERE [TeamID] = @teamid
			UNION ALL
			SELECT T.[TeamID] FROM [AGT_Teams] t INNER JOIN Team r ON t.ParentId = r.TeamID),
			Supervisor AS ( 
			SELECT ID FROM [AGT_Agent]  WHERE ID=@supervisorid
			UNION ALL
			SELECT A.ID FROM [AGT_Agent] A INNER JOIN Supervisor B   ON A.[PrimarySupervisorID] = B.ID)

			INSERT INTO @Result(AgentId,AgentName,SupervisorName,TeamName)
			SELECT DISTINCT  A.AvayaLoginID AgentId,ISNULL(A.FirstName,'')+' '+ ISNULL(A.LastName,'') AgentName,
			ISNULL(B.FirstName,'NA')+' '+ ISNULL(B.LastName,'')  SupervisorName ,ISNULL(C.TeamName,' ') AS TeamName FROM [AGT_Agent] A 
			LEFT JOIN [AGT_Agent] B WITH(NOLOCK)  ON A.[PrimarySupervisorID] = B.ID 
			LEFT JOIN [AGT_Agent] S WITH(NOLOCK)  ON S.AvayaLoginID = A.AvayaLoginID
			LEFT JOIN [AGT_Teams] C WITH(NOLOCK) ON C.TeamID = A.TeamID
			LEFT JOIN [AGT_Teams] P WITH(NOLOCK) ON C.ParentID  = P.TeamID
			LEFT JOIN [AGT_Teams] PC WITH(NOLOCK) ON PC.ParentID  = B.TeamID 
			WHERE  C.TeamID IN ( SELECT TeamID FROM Team )  AND A.ID IN ( SELECT ID FROM Supervisor)
	 END
	 ELSE
	 BEGIN
	        INSERT INTO @Result(AgentId,AgentName,SupervisorName,TeamName)
	        SELECT DISTINCT  A.AvayaLoginID AgentId,ISNULL(A.FirstName,'')+' '+ ISNULL(A.LastName,'') AgentName,
			ISNULL(B.FirstName,'NA')+' '+ ISNULL(B.LastName,'')  SupervisorName ,ISNULL(C.TeamName,' ') AS TeamName FROM [AGT_Agent] A 
			LEFT JOIN [AGT_Agent] B WITH(NOLOCK)  ON A.[PrimarySupervisorID] = B.ID 
			LEFT JOIN [AGT_Teams] C WITH(NOLOCK) ON C.TeamID = A.TeamID


			IF OBJECT_ID('OCM_AgentInteractionReport') IS Not NULL 
			BEGIN
				INSERT INTO @Result(AgentId,AgentName,SupervisorName,TeamName)
				SELECT distinct AgentId,'' AgentName, '' SupervisorName, '' TeamName FROM OCM_AgentInteractionReport where AgentId not in (select AgentID from @Result)
			END
	 END
	 RETURN 
END
GO


