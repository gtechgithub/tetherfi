
/****** Object:  StoredProcedure [dbo].[Get_Chat_DashboardData]    Script Date: 22/06/2018 12:10:09 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:<Prathik>
-- Version:<3.1.9.8>
-- =============================================
alter PROCEDURE [dbo].[Get_Chat_DashboardData] 
(
	@Type as varchar(20), @startdate as varchar(20), @enddate as varchar(20), @dnis as varchar(1000)
)
AS
IF(@type='summarydata')
BEGIN

	Declare @ChatCallback AS INT
	Declare @TotalChat AS INT
	Declare @ChatCount AS INT
	Declare @ChatToAudio AS INT
	Declare @ChatToVideo AS INT
	Declare @AudioIP AS INT
	Declare @AudioToVideo AS INT
	Declare @AudioToChat AS INT
	Declare @VideoIP AS INT
	Declare @VideoToAudio AS INT
	Declare @VideoToChat AS INT
	Declare @TransferedChat AS INT
	Declare @TransferedAudio AS INT
	Declare @TransferedVideo AS INT
	Declare @ConferencedChat AS INT
	Declare @ConferencedAudio AS INT
	Declare @ConferencedVideo AS INT
	Declare @AverageHandleTime AS FLOAT
	Declare @AverageHandleAudioTime AS FLOAT
	Declare @AverageHandleVideoTime AS FLOAT

   IF(@dnis !='')
   BEGIN

    SELECT @ChatCallback=(ISNULL(( SELECT COUNT(1)  FROM IVR_CALLBACK_REQUESTS R WITH(NOLOCK)  INNER JOIN TMAC_Interactions T WITH(NOLOCK)  on T.SubSessionId  = R.UCID 
	WHERE  (T.Channel='Chat' OR T.Channel='TextChat' OR T.Channel='AudioChat' OR T.Channel='VideoChat') AND T.CALLCONNECTEDTIME !='00010101000000'AND T.CreatedDateTime>=(@startdate+'000000') AND 
	T.CreatedDateTime<=(@enddate+'235959') AND T.Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0)),

	@TotalChat=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@ChatCount=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@ChatToAudio=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@ChatToVideo=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@AudioIP=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@AudioToVideo=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='AudioChat') AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@AudioToChat=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='AudioChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@VideoIP=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@VideoToAudio=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='VideoChat') AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),

	@VideoToChat=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='VideoChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0),
	

	@TransferedChat=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsTransfered='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis)) ),0)),

	@TransferedAudio=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsTransfered='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis)) ),0)),

	@TransferedVideo=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsTransfered='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis)) ),0)),

	@ConferencedChat=(ISNULL((SELECT COUNT(IsConferenced) as Conferenced from TMAC_Interactions WITH(NOLOCK)
	WHERE IsConferenced='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0)),

	@ConferencedAudio=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsConferenced='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis)) ),0)),

	@ConferencedVideo=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsConferenced='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis)) ),0)),

	@AverageHandleTime=(ISNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  WITH(NOLOCK) 
	WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0)),

	@AverageHandleAudioTime=(ISNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  WITH(NOLOCK) 
	WHERE (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0)),

	@AverageHandleVideoTime=(ISNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  WITH(NOLOCK) 
	WHERE (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959') AND Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis))),0))


	Select @ChatCallback as ChatCallback, 0 as AudioCallback, 0 as VideoCallback,@ChatCount as ChatCount,@ChatToAudio as ChatToAudio,@ChatToVideo as ChatToVideo,
	@AudioIP as AudioIP,@AudioToVideo as AudioToVideo,@AudioToChat as AudioToChat,@VideoIP as VideoIP,@VideoToAudio as VideoToAudio,@VideoToChat as VideoToChat,
	@TransferedChat as TransferedChat,@TransferedAudio as TransferedAudio,@TransferedVideo as TransferedVideo,@ConferencedChat as ConferencedChat,
	@ConferencedAudio as ConferencedAudio,@ConferencedVideo as ConferencedVideo, @AverageHandleTime as AverageHandleTime,@AverageHandleAudioTime as AverageHandleAudioTime, @AverageHandleVideoTime as AverageHandleVideoTime,
	convert(decimal(5,2),isnull(((convert(float,@TotalChat) - (convert(float,@TransferedChat) +convert(float, @ConferencedChat) ))/convert(float,nullif(@TotalChat,0))),0)) as FirstCallResolution,
	convert(decimal(5,2),isnull(((convert(float,@AudioIP) - (convert(float,@TransferedAudio) +convert(float, @ConferencedAudio) ))/convert(float,nullif(@AudioIP,0))),0)) as FirstCallResolutionAudio,
	convert(decimal(5,2),isnull(((convert(float,@VideoIP) - (convert(float,@TransferedVideo) +convert(float, @ConferencedVideo) ))/convert(float,nullif(@VideoIP,0))),0)) as FirstCallResolutionVideo

   END
   ELSE
   BEGIN

	SELECT @ChatCallback=(ISNULL(( SELECT COUNT(1)  FROM IVR_CALLBACK_REQUESTS R WITH(NOLOCK)  INNER JOIN TMAC_Interactions T WITH(NOLOCK)  on T.SubSessionId  = R.UCID 
	WHERE  (T.Channel='Chat' OR T.Channel='TextChat' OR T.Channel='AudioChat' OR T.Channel='VideoChat') AND T.CALLCONNECTEDTIME !='00010101000000'AND T.CreatedDateTime>=(@startdate+'000000') AND 
	T.CreatedDateTime<=(@enddate+'235959')),0)),

	@TotalChat=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@ChatCount=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@ChatToAudio=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@ChatToVideo=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='Chat' OR Channel='TextChat' ) AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@AudioIP=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@AudioToVideo=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='AudioChat') AND SubChannel='video' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@AudioToChat=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='AudioChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@VideoIP=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@VideoToAudio=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='VideoChat') AND SubChannel='audio' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),

	@VideoToChat=ISNULL((SELECT COUNT(1) from TMAC_Interactions T WITH(NOLOCK)  
	WHERE  (Channel='VideoChat') AND SubChannel='text' AND CALLCONNECTEDTIME !='00010101000000' AND IsConferenced='0' AND IsTransfered='0'
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0),
	

	@TransferedChat=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsTransfered='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@TransferedAudio=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsTransfered='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@TransferedVideo=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsTransfered='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@ConferencedChat=(ISNULL((SELECT COUNT(IsConferenced) as Conferenced from TMAC_Interactions WITH(NOLOCK)
	WHERE IsConferenced='1' AND (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@ConferencedAudio=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsConferenced='1' AND (Channel='AudioChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@ConferencedVideo=(ISNULL((SELECT COUNT(IsTransfered) as Transfered from  TMAC_Interactions WITH(NOLOCK)   
	WHERE IsConferenced='1' AND (Channel='VideoChat') AND  CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@AverageHandleTime=(ISNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  WITH(NOLOCK) 
	WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@AverageHandleAudioTime=(ISNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  WITH(NOLOCK) 
	WHERE (Channel='AudioChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0)),

	@AverageHandleVideoTime=(ISNULL((SELECT (Sum(ActiveTime)+Sum(HoldTime))/count(SessionID) from TMAC_Interactions  WITH(NOLOCK) 
	WHERE (Channel='VideoChat') AND CALLCONNECTEDTIME !='00010101000000' 
	AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')),0))


	Select @ChatCallback as ChatCallback, 0 as AudioCallback, 0 as VideoCallback,@ChatCount as ChatCount,@ChatToAudio as ChatToAudio,@ChatToVideo as ChatToVideo,
	@AudioIP as AudioIP,@AudioToVideo as AudioToVideo,@AudioToChat as AudioToChat,@VideoIP as VideoIP,@VideoToAudio as VideoToAudio,@VideoToChat as VideoToChat,
	@TransferedChat as TransferedChat,@TransferedAudio as TransferedAudio,@TransferedVideo as TransferedVideo,@ConferencedChat as ConferencedChat,
	@ConferencedAudio as ConferencedAudio,@ConferencedVideo as ConferencedVideo, @AverageHandleTime as AverageHandleTime,@AverageHandleAudioTime as AverageHandleAudioTime, @AverageHandleVideoTime as AverageHandleVideoTime,
	convert(decimal(5,2),isnull(((convert(float,@TotalChat) - (convert(float,@TransferedChat) +convert(float, @ConferencedChat) ))/convert(float,nullif(@TotalChat,0))),0)) as FirstCallResolution,
	convert(decimal(5,2),isnull(((convert(float,@AudioIP) - (convert(float,@TransferedAudio) +convert(float, @ConferencedAudio) ))/convert(float,nullif(@AudioIP,0))),0)) as FirstCallResolutionAudio,
	convert(decimal(5,2),isnull(((convert(float,@VideoIP) - (convert(float,@TransferedVideo) +convert(float, @ConferencedVideo) ))/convert(float,nullif(@VideoIP,0))),0)) as FirstCallResolutionVideo

   END
END
IF(@type='chartintentdata')
BEGIN
   IF(@dnis !='')
   BEGIN
		--SELECT DISTINCT TOP 10 IM.IntentName,count(I.SessionId ) as ChatCount from [GBL_IntentMapping] IM WITH(NOLOCK) INNER JOIN [TMAC_Interactions] I
		--WITH(NOLOCK) ON IM.SessionID=I.SessionId where (IM.Channel='TextChat' OR IM.Channel='Chat' OR IM.Channel='AudioChat' OR IM.Channel='VideoChat') 
		--AND (I.Channel='TextChat' OR I.Channel='Chat' OR I.Channel='AudioChat' OR I.Channel='VideoChat') AND  
		--I.CALLCONNECTEDTIME !='00010101000000' and IM.ClosedDate >= @startdate and IM.ClosedDate <= @enddate and
		--I.CreatedDateTime>=(@startdate+'000000') AND I.CreatedDateTime<=(@enddate+'235959') 
		--AND I.Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis)) 
		--GROUP BY IM.IntentName ORDER BY count(I.SessionId ) desc, IM.IntentName asc	

		SELECT DISTINCT TOP 10 Intent as IntentName,count(SessionId) as ChatCount FROM [TMAC_Interactions] 
		WITH(NOLOCK) WHERE (Channel='TextChat' OR Channel='Chat' OR Channel='AudioChat' OR Channel='VideoChat') AND  
		CALLCONNECTEDTIME !='00010101000000' AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')  AND
		Skill IN (Select Id from [dbo].BreakStringIntoRows (@dnis)) AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY Intent ORDER BY count(SessionId ) DESC, Intent ASC	
   END
   ELSE
   BEGIN
        --SELECT DISTINCT TOP 10 IM.IntentName,count(I.SessionId ) as ChatCount from [GBL_IntentMapping] IM WITH(NOLOCK) INNER JOIN [TMAC_Interactions] I
		--WITH(NOLOCK) ON IM.SessionID=I.SessionId where (IM.Channel='TextChat' OR IM.Channel='Chat' OR IM.Channel='AudioChat' OR IM.Channel='VideoChat') 
		--AND (I.Channel='TextChat' OR I.Channel='Chat' OR I.Channel='AudioChat' OR I.Channel='VideoChat') AND  
		--I.CALLCONNECTEDTIME !='00010101000000' and IM.ClosedDate >= @startdate and IM.ClosedDate <= @enddate and
		--I.CreatedDateTime>=(@startdate+'000000') AND I.CreatedDateTime<=(@enddate+'235959') 
		--GROUP BY IM.IntentName ORDER BY count(I.SessionId ) desc, IM.IntentName asc	

		SELECT DISTINCT TOP 10 Intent as IntentName ,count(SessionId) as ChatCount FROM [TMAC_Interactions] 
		WITH(NOLOCK) WHERE (Channel='TextChat' OR Channel='Chat' OR Channel='AudioChat' OR Channel='VideoChat') AND  
		CALLCONNECTEDTIME !='00010101000000' AND CreatedDateTime>=(@startdate+'000000') AND CreatedDateTime<=(@enddate+'235959')  AND 
		IsConferenced='0' AND IsTransfered='0'
		GROUP BY Intent ORDER BY count(SessionId ) DESC, Intent ASC	
   END
END
ELSE
IF (@type='chartskilldata')
BEGIN
   IF(@dnis !='')
   BEGIN
		SELECT DISTINCT TOP 10   CASE WHEN S.SKILLNAME !='' THEN S.SKILLNAME ELSE T.SKILL END AS Skill, COUNT(SESSIONID) AS ChatCount  FROM TMAC_INTERACTIONS T WITH(NOLOCK)
		LEFT JOIN TMAC_SKILLS S WITH(NOLOCK) ON T.SKILL=S.SKILLEXTENSION WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
		AND CALLCONNECTEDTIME !='00010101000000'AND CREATEDDATETIME>=(@startdate+'000000') AND CREATEDDATETIME<=(@enddate+'235959')
		AND T.SKILL IN (SELECT ID FROM [DBO].BREAKSTRINGINTOROWS (@dnis)) AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY SKILL,SKILLNAME ORDER BY count(SESSIONID ) DESC,  SKILL ASC
   END
   ELSE
   BEGIN
   		SELECT DISTINCT TOP 10   CASE WHEN S.SKILLNAME !='' THEN S.SKILLNAME ELSE T.SKILL END AS Skill, COUNT(SESSIONID) AS ChatCount  FROM TMAC_INTERACTIONS T WITH(NOLOCK)
		LEFT JOIN TMAC_SKILLS S WITH(NOLOCK) ON T.SKILL=S.SKILLEXTENSION WHERE (Channel='Chat' OR Channel='TextChat' OR Channel='AudioChat' OR Channel='VideoChat') 
		AND CALLCONNECTEDTIME !='00010101000000' AND CREATEDDATETIME>=(@startdate+'000000') AND CREATEDDATETIME<=(@enddate+'235959') AND IsConferenced='0' AND IsTransfered='0'
		GROUP BY SKILL,SKILLNAME ORDER BY count(SESSIONID ) DESC,  SKILL ASC
   END
	
END

