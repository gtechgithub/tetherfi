
/****** Object:  StoredProcedure [dbo].[Get_AuditTrailOCMReport]    Script Date: 03-07-2017 12:20:29 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Adhip,Shruthi>
-- Version:		<3.2.8.2>
-- Create date: <Create Date,,>
-- Description:	<Stored Procedure for Outbound Calls Report with Call Duration calculation>
-- =============================================
ALTER PROCEDURE [dbo].[Get_AuditTrailOCMReport]
	@startdate as varchar(20),
	@enddate as varchar(20),
	@SearchString AS VARCHAR(MAX),
	@SortString AS VARCHAR(1000),
	@PageNo INT = 1,
	@PageSize INT = 10,
	@TotalPageSize INT OUTPUT
AS
DECLARE @DataFromDate VARCHAR(50)
DECLARE @DataToDate VARCHAR(50)
BEGIN
Declare
	@lPageNbr INT,
	@lPageSize INT,
	@lFirstRec INT,
	@lLastRec INT,
	@lTotalRows INT,
    @CombineQuery VARCHAR(MAX),
    @MAIN VARCHAR(MAX),
	@DRILL VARCHAR(MAX),
    @ToatlCount NVARCHAR(MAX)
		
	SET @TotalPageSize = 0
		SET @lPageNbr = @PageNo
		SET @lPageSize = @PageSize
		SET @DataFromDate = @startdate
		SET @DataToDate = @enddate
		--used to calcuate the apge size
		SET @lFirstRec = ( @lPageNbr - 1 ) * @lPageSize
		SET @lLastRec = ( @lPageNbr * @lPageSize + 1 )
				SELECT @MAIN='SELECT TXN_DATE,TRANSACTION_NAME AS [Transaction],FUNCTIONNAME AS [Function],(TXN_DATE+'' ''+TXN_TIME) AS [DateTime],OLD_VALUES AS OldValues,NEW_VALUES as NewValues,USER_ID as UserID,CHANGEREASON AS ChangeReason,[ModuleName] FROM AUDITTRAIL_REPORT with(nolock) WHERE (TXN_DATE+'' ''+TXN_TIME) >='''+@DataFromDate+''' AND (TXN_DATE+'' ''+TXN_TIME) <= '''+@DataToDate +''''
	        --this query Sorts and filtes
			SELECT @CombineQuery=' SELECT * FROM  ( SELECT ROW_NUMBER() OVER(ORDER BY [DateTime] ASC) RowNumber, * FROM  ('+@MAIN+'
			) AS table1  WHERE 1=1'+@SearchString+'
			)As tabl1 WHERE 1=1 AND RowNumber > '+CONVERT(VARCHAR,@lFirstRec)+' AND RowNumber < '+CONVERT(VARCHAR,@lLastRec)+' '+@SortString
            --query is used to get the total count
			SET @ToatlCount = 'SELECT @x = COUNT(*) FROM('+@MAIN+')AS table1 Where 1=1  AND ([DateTime] >= '''+@DataFromDate+''' AND [DateTime] <='''+@DataToDate+''') '+@SearchString --+' '+@SortString
			--print @ToatlCount
			--Executed the sting as query
			EXEC(@CombineQuery)
			print @CombineQuery
			print @ToatlCount
			--Executes the total count 
			exec sp_executesql @ToatlCount, N'@x int out', @TotalPageSize out
			SELECT	@TotalPageSize as N'TotalPageSize'
END
