ALTER TABLE CMM_Report_Logs 
ALTER COLUMN [ReportName] varchar(200)