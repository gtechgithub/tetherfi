
/****** Object:  Index [PK_IX_C_AGT_Agent_TimeTrack_ID]    Script Date: 11/21/2018 15:23:34 ******/
ALTER TABLE [dbo].[AGT_Agent_TimeTrack] ADD  CONSTRAINT [PK_IX_C_AGT_Agent_TimeTrack_ID] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_N_AGT_Agent_TimeTrack_AgentID]    Script Date: 11/21/2018 15:23:53 ******/
CREATE NONCLUSTERED INDEX [IX_N_AGT_Agent_TimeTrack_AgentID] ON [dbo].[AGT_Agent_TimeTrack]
(
	[AgentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_N_AGT_Agent_TimeTrack_LoginDateTime]    Script Date: 11/21/2018 15:24:11 ******/
CREATE NONCLUSTERED INDEX [IX_N_AGT_Agent_TimeTrack_LoginDateTime] ON [dbo].[AGT_Agent_TimeTrack]
(
	[LoginDate] ASC,
	[LoginTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [IX_N_AGT_Agent_TimeTrack_LogoutDateTime]    Script Date: 11/21/2018 15:24:29 ******/
CREATE NONCLUSTERED INDEX [IX_N_AGT_Agent_TimeTrack_LogoutDateTime] ON [dbo].[AGT_Agent_TimeTrack]
(
	[LogoutDate] ASC,
	[LogoutTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


