alter table [dbo].[CMM_Report_Scheduler] add StartTime varchar(20)

EXEC sp_rename 'CMM_Report_Scheduler.Time', 'EndTime', 'COLUMN';