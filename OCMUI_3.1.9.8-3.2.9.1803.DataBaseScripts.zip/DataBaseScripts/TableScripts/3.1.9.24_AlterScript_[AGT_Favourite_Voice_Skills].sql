
ALTER TABLE [AGT_Favourite_Voice_Skills] ADD  ID INT IDENTITY (1,1)

