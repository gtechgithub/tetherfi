--version 3.2.8.2
----------------------------------------------------------------------------
ALTER TABLE [CHECKER_AUDITTRAIL_REPORT] ADD [ModuleName] VARCHAR(255)

UPDATE [CHECKER_AUDITTRAIL_REPORT] SET [ModuleName] = [FUNCTIONNAME] WHERE [ModuleName] IS NULL

