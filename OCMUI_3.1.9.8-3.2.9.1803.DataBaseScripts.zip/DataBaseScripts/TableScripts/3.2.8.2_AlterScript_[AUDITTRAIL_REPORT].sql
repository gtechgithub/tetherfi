----------------------------------------------------------------------------------------
--version 3.2.8.2
----------------------------------------------------------------------------
ALTER TABLE [AUDITTRAIL_REPORT] ADD [ModuleName] VARCHAR(255)

UPDATE [AUDITTRAIL_REPORT] SET [ModuleName] = [FUNCTIONNAME] WHERE [ModuleName] IS NULL