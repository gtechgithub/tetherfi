ALTER TABLE [dbo].[AGT_Favourite_Voice_Skills]
ADD [Channel] VARCHAR(20)