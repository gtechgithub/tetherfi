
Update [CMM_USER_MANAGEMENT] SET FUNCTIONALITY='ChatIntentSkillMapping' WHERE  FUNCTIONALITY ='SoiIntentmapping'

Update [CMM_Role_Pages] SET PAGENAME ='ChatIntentSkillMapping' WHERE  PAGENAME ='SoiIntentmapping'