Alter table CMM_Report_Scheduler
Add ReportTitle varchar(4000)