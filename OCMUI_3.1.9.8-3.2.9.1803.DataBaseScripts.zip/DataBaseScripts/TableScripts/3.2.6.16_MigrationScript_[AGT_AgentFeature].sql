--Execute both maker and checker db
--**********************************************************************************************
--Migration from [AGT_TMACAgentProfile] 
--**********************************************************************************************
INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsHoldVoiceCallOnChatCall',[IsHoldVoiceCallOnChatCall]  FROM [AGT_TMACAgentProfile]
    
INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsSecondTextChatAutoAnswer',[IsSecondTextChatAutoAnswer]  FROM [AGT_TMACAgentProfile]

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsTextChatAutoAnswer',[IsTextChatAutoAnswer]  FROM [AGT_TMACAgentProfile]

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsCRMEnabled',[IsCRMEnabled]  FROM [AGT_TMACAgentProfile]

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsManualInEnabled',[IsManualInEnabled]  FROM [AGT_TMACAgentProfile]

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsVoiceACDAutoAnswerEnabled',[IsVoiceACDAutoAnswerEnabled]  FROM [AGT_TMACAgentProfile]

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsVoiceACDAutoACWEnabled',[IsVoiceACDAutoACWEnabled]  FROM [AGT_TMACAgentProfile]

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsTextChatAutoACWEnabled',[IsTextChatAutoACWEnabled]  FROM [AGT_TMACAgentProfile]

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsVoiceAllAutoACWEnabled',[IsVoiceAllAutoACWEnabled]  FROM [AGT_TMACAgentProfile]

--**********************************************************************************************
--Migration from [AGT_ChannelCount] 
--**********************************************************************************************
INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsSMSOutEnabled', [Enable] FROM [AGT_ChannelCount] WHERE
[Channel] ='smsout'

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsFaxOutEnabled', [Enable] FROM [AGT_ChannelCount] WHERE
[Channel] ='faxout'

INSERT INTO [dbo].[AGT_AgentFeature]
([AgentID],[Feature],[Enable])
SELECT  [AgentID],'IsFaxInternationalEnabled', [Enable] FROM [AGT_ChannelCount] WHERE
[Channel] ='faxinternational'
