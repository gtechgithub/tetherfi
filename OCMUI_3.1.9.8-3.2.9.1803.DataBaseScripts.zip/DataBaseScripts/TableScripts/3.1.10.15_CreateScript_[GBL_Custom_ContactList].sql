USE [OCM]
GO

/****** Object:  Table [dbo].[GBL_Custom_ContactList]    Script Date: 12/10/2018 10:47:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[GBL_Custom_ContactList](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CallerID] [varchar](20) NULL,
	[Email] [varchar](50) NULL,
	[FBHandle] [varchar](50) NULL,
	[MessengerID] [varchar](20) NULL,
	[CustomerIDType] [varchar](20) NOT NULL,
	[CustomerIDNo] [varchar](50) NOT NULL,
	[Country] [varchar](20) NULL,
	[ContactType] [varchar](20) NULL,
	[InclusionFlag] [char](1) NULL,
	[ExclusionFlag] [char](1) NULL,
	[OtherData] [varchar](max) NULL,
	[LastChangedBy] [varchar](50) NULL,
	[LastChangedOn] [varchar](50) NULL,
 CONSTRAINT [PK_GBL_Custom_ContactList_ID] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UK_GBL_Custom_ContactList_CallerID] UNIQUE NONCLUSTERED 
(
	[CallerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


