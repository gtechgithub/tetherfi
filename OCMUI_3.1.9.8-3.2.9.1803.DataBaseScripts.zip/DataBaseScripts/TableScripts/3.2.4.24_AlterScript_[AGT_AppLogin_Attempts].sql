
 ALTER TABLE [AGT_AppLogin_Attempts] ADD UserHostAddress VARCHAR(50), [Page] VARCHAR(50), [Reason] VARCHAR(50)
