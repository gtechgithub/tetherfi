
--Execute both maker and checker db
/****** Object:  Table [dbo].[AGT_AgentFeature]    Script Date: 16/06/2019 10:01:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AGT_AgentFeature](
	[AgentID] [varchar](20) NOT NULL,
	[Feature] [varchar](50) NOT NULL,
	[Enable] [bit] NOT NULL,
 CONSTRAINT [PK_AGT_AgentFeature_AgentIDFeature] PRIMARY KEY CLUSTERED 
(
	[AgentID] ASC,
	[Feature] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AGT_AgentFeature] ADD  CONSTRAINT [DF_AGT_AgentFeature_Enable]  DEFAULT ((0)) FOR [Enable]
GO


