﻿var global_AssemblyVersion = "TMAC :3.1.08.0806";
//  --------------------------------------------------------------------------
// All Application UI level Settings goes here
//  --------------------------------------------------------------------------
var isCloseLoginPage = true;
var isTmacWindowFocus = false;
var isApplication_window_size_type_pixel = false;  //true if the application window size is to be set in pixel
var Application_window_width = 40; //percentage - [42 - voice bio | 28 - dbs sg live chat | 40 - uob]
var Application_window_height = 95; //percentage - [28 - voice bio | 100 - dbs sg live chat | 100 - uob]
//is tmac full screen
var isFullTMAC = false;
//is tmac tour
var isTour = false;
//show/hide the left panel after login
var openLeftSidePanel = false;
//is the main tab is custom
var isCustomMainTab = false;
//display station id
var agentStationOnMain = false;
//agent status on main
var agentStatusOnMain = false;
//agent profile on main
var agentProfileOnMain = true;
//is agent chat
var isAgentChat = false;
//is customer chat
var isCustomerChat = false;
//dummy chat list
var dummyCustomerList = [];
//s wallbaord
var isWallboard = true;
//is remiders
var isReminder = false;
//initially isReminderThreadStarted is false
var isReminderThreadStarted = false;
//store the reminder list in this variable for the thread loop
var globalReminderList;
//interaction history
var isInteractionHistory = true;
//is custom customer journey
var isCustomerJourney = false;
//customer journey iframe
var ih_iframe_url = "https://indialab.tetherfi.com:55443/TMAC_Agent_Utils/UI/InteractionHistory.html";
var quotesList = [
    "Your most unhappy customers are your source of learning...",
    "Make every interaction count, even the small ones, They are all relevant...",
    "Go the extra mile. It's never crowded...",
    "We rise by lifting others...",
    "The customer's perception is your reality..."];
// Below two variables are used for to store current window width and Height
//  based on these variables, we can set the CRM window width and position.
var Application_Window_Current_Width = 0;
var Application_Window_Current_Height = 0;
// Store all the incoming call details here, will set flag to indicate whether we need to send to iserve
var global_ConnectedCalls = [];
// Set the active tab id to this variable
var global_activeTabId;
// Temporary array for ucid
var global_temporaryUCID = [];
// Connect array for ucid
var global_connectUCID = [];
//added by sirajuddin for CBG integration
var global_connectedProxy = "";
//open tabs array
var global_openTabs = [];
//open tabs ucid array
var global_openTabsUCID = [];
var global_tabCount = 0;
var global_QueueTimeColor = [];
var global_UCID = [];
var global_OutboundUCID;
var global_isTPINTransfer = false;
var global_isTPINTrasnferOutbound = false;
var global_isFeewaiverTrasnferOutbound = false;
var global_ConnectionHandle;
//Global Variable to check if the voice call received has a callback already registered
var global_voiceCallHasCallback = false;
var global_TextChatScheduleCallbackID;
var global_ExistingCallbackForCustomerTabId = 2000; // global variable for interaction id when a customer has a callback tab when he initiates a chat
var global_AgentForcedLogoffEventFlag = false;
var global_InteractionTabs = [];
//Set the flag if TPIN transfer is done in order that, not to start the ACW start time during TPIN transfer
var global_isTPINTransferDone = false;
//dialog width pixel/percentage
var kendo_window_width = {};
kendo_window_width.add_reminder = isFullTMAC ? "525px" : "90%";
kendo_window_width.barge_in_dialog = isFullTMAC ? "525px" : "90%";
kendo_window_width.make_call_dialog = isFullTMAC ? "525px" : "90%";
kendo_window_width.transfer_dialog = isFullTMAC ? "525px" : "90%";
kendo_window_width.conference_dialog = isFullTMAC ? "525px" : "90%";;
kendo_window_width.confirm_dialog = isFullTMAC ? "525px" : "90%";
kendo_window_width.callback_dialog = isFullTMAC ? "225px" : "90%";
kendo_window_width.pob_callback_dialog = isFullTMAC ? "800px" : "90%";
kendo_window_width.va_history = isFullTMAC ? "400px" : "90%";
kendo_window_width.chat_template_dialog = isFullTMAC ? "525px" : "90%";
kendo_window_width.start_chat = isFullTMAC ? "525px" : "90%";
//extra configs
//tmac header and footer height - note: no px only digit
var tmac_header_footer_height = "30px";
//aux status to enable logout
var logoutAux = "7 - Project";
//blink the status on call
var isBlinkStatus = false;
//disable status on call
var isDisableStatusOnCall = false;
//to show push notification
var isPushNotification = true;
//disabled window resize
var isDisableResize = false;
//recent alerts
var recentAlerts = [];
//notify timeout
var notifyTimeout = 3000;
//agent forced logoff
var isLoggingOff = false;
//if the agent logged out
var isLogoutDone = false;
//flag to close all tabs on tmac ui status change, TSC - Tmac Status Change
var isCloseTabsOnTSC = true;
//flag set to check if all tabs to be closed based on hardphone status change ,PSC - PhoneStatusChange
//NOTE: this is not a config key, this is initializing place of this key, so do not change at all
//if close tab is required/not on status change please make isCloseTabsOnTSC - true/false
var isCloseTabsOnPSC = false;
//flag set to check if the status is changed from server or from ui/Dashboard
var isStatusManagerChange = false;
//to skip close tab on these tab types for status change
var skipCloseTabType = [];
//to skip close tab on these staus for status change
var skipCloseTabStatus = [];
//text chat transfer tmac server
var destTmacServerName = "";
//favorite list on transfer
var favListGridItemSelect = "";
//text chat transfer favorite list
var favListGridItemSelectForChat = "";
//tmac disconnect by handle type
var disconnectByHandleType = "";
//tmac agent to agent chat obj
var tmacAgentChatObj = [];
var ApplicationConfigurationSettings = {
    EnableRemoteLogging: {
        Success: true,
        Info: true,
        Warning: true,
        Error: true
    }
}
var favionIcon = "favicon";
//enable/disable agent id for invalid lan id
var isAgentIdOnInvalidLanId = false;
//dummy station use lanid
var isStationAvailable = true;
//show domain list
var isDomainList = false;
//show login with password
var isLoginWithPassword = false;
//aux based on team
var isLoadAgentAux = false;
//label on title
var labelOnTitle = false;
var titleName = "TMAC";
var signalRVersion;
var global_AUXCodes;
var global_Intents;
var global_AgentList = [];
var global_FavouriteSkills;
var global_SpeedDial;
var global_WorkCodeList;
var global_TeamID;
var global_AgentName;
var global_UserProfileForAgent;
var global_Password;
var global_CallType = "";
var global_transferIntID;
var global_conferenceIntID;
//to allow transfer/conference/make call in specified status
var allowedStatus = {
    "Voice": ["Available"],
    "TextChat": ["Available"]
};
//active tab interaction id
var global_activeTabInteractionID;
//agent status timer counter
var statusTimeCounter = 0;
//agent status obj
var global_LastAgentStat;
var global_agentCamera;
//tmac reload flag
var global_ReloadDone;
//timeout function
var global_timeoutFunctions = [];
var global_LoginRedisplay;
//marquee text reference
var marqueeText = "";
//active tab id for tabstrip select/active event
var active_tab_id = "";
//main tabtrip element
var tabstrip;
//make call tabstrip element
var tabstrip_call;
//trasnfer call tabstrip element
var tabstrip_transfer;
var logout_button_clicked = false;
var call_log_out = false;
//support doc url
var supportDocUrl = "docs/pdf.pdf";
//barge-in enabled
var isBargeIn = true;
//supervisor enabled
var isSupervisor = false;
//supervisor link
var supervisorLink = "https://indialab.tetherfi.com:55443/UOB_SupervisorModule"; //https://demo.tetherfi.com:55443/Tetherfi_SupervisorModule, https://indialab.tetherfi.com:55443/UOB_SupervisorModule
//toggle tmac screen
var isTmacScreenToggle = false;
//auto timer for time taken
var autoTimerForTimeTaken = false;
//enable/disable blind transfer button
var isBlindTransfer = true;
//favourite skill list in call transfer window
var isFavouriteSkillTab = true;
//favouriteskill list grid tab name
var favouriteSkillTabName = "Skill List"; //Blind Transfer, Skill List
//speed dial list tab in call transfer window
var isSpeedDialTab = true;   //true
//speeddial list grid tab name
var speedDialTabName = "Speed Dial List"; //Consult Transfer, Speed Dial List
//to show/hide speed dial for textchat
var isSpeedDialOnTextChat = false;
//calls in queue threshold value for blinking for wallboard
var ciqThresholdValue = 50;
//modal on dialog
var modalOnDialog = true;
//initial status on load
var initialStatus = "Default";
//workbench configuration
var isWorkbench = false;
//workbench link
var workbenchLink = "http://localhost:6091/";
//to print etra logs in console and UI log
var extraLogs = {
    "TMACEventNames": true,
    "TMACEventObjects": false,
    "VoiceBioEvents": false
};
//type of agent logged in
var agentType = "";
//expand/collapse on iframes
var isExpandCollapseOnIframes = {
    "Supervisor": true,
    "Workbench": true
};
//Enable close tab on disconnect for realtime channel
var isEnableCloseTabOnDisconnect = {
    "Voice": false,
    "TextChat": true
};
//logout agent on close window
var isLogoutOnClose = false;
var changeStatusTimeOut = 3000;
//  --------------------------------------------------------------------------

//-------------------------------CHANNEL CONFIGURATIONS-----------------------
var isFbEnabled = false;
var isChatEnabled = true;
var isFaxEnabled = false;
//  --------------------------------------------------------------------------

//---------------------------------------FAX----------------------------------
var global_FaxReference = [];
var faxLineNumbers = [];
var faxInteractionId;
var isPrintFax = false;
//  --------------------------------------------------------------------------


//----------------------------------------CRM---------------------------------
var isIServe = true;
var isDynamicCRM = true;
var isNiceIntegration = true;
var global_IsCRMEnabled;
var global_CRMName;
var global_MSDChatAcceptPopUpURL;
var global_MSDChatClosePopUpURL;
var global_MSDCallbackAcceptPopUpURL;
var global_MSDCallbackClosePopUpURL;
var global_MSDInboundVoicePopUpURL;
var global_MSDOutboundVoicePopUpURL;
//  --------------------------------------------------------------------------


//----------------------------------------VOICE-------------------------------
//name of outbound in db
var global_outboundName = "8 - Call Outbound";
//is voice authentication panel enabled
var isVoiceAuthenticationPanel = true;
//authentication label names
var voiceAuthenticationLabels = {
    label1: "Verified Status",
    label2: "TPIN lock status"
};
//show/hide IVR transfer button
var ivrTransferEnabled = true;
//show/hide IVR menus
var isIvrMenuEnabled = true;
//dynamic voice data obj
var voiceObj = {
    //Customer Intent is default
    "Customer Intent": "ddlIntent, custom-width-50",
    //CallerID is default
    "Caller ID": "txtCallerID, custom-width-50"
};
//is voice service data window
var isVoiceDataWindow = false;
//type of voice data window
var voiceDataWindowType = "campaign";
//campaign manager selector url
var campSelectorUrl = "https://localhost:55443/TetherfiCampaignManagerClient/ui/campaign_selector.html?fromAddr=";
//campaign manger servic url for campui.js
var campServiceUrl = "https://localhost:55443/TetherfiCampaignManagerClient/CampaignManager.asmx";
//workcode config key
var isWorkCode = false;
//enable voice if a single chat going on
var isEnableVoiceOnSingleChat = true;
//  --------------------------------------------------------------------------


//----------------------------------------TEXT CHAT/AUDIO-VIDEO CHAT---------------------------
//CSAT survey
var isCSATSurvey = false;
//Sanitize Html
var isSanitizeHtml = false;
//is grammer check
var isGrammerCheck = false;
//chat session reference
var global_ChatReference = []; //intid, isAgent, isCustomer, isTyping, isBlink, isActive isDisconnected, hyperLinks[]
//is PWeb Chat
var isPWebChat = true;

//dynamic chat data obj
var chatObj = {
    "Name": "textChatName",
    "Segment Code": "textChatSegment, custom-width-50",
    "Sub Segment Code": "textChatSubSegment, custom-width-50",
	"CIF": "textChatCIF, custom-width-50",
	"Language": "textChatLang, custom-width-50",
    "Queue Time": "textChatQueueTime, custom-width-50",
    "Reg Mobile": "textChatRegPhone1, custom-width-50",
	"Intent": "textChatIntent, custom-width-50",
};

//is chat authentication panel enabled
var isChatAuthenticationPanel = true;
//authentication label names
var chatAuthenticationLabels = {
    label1: "Authentication Status",
    label2: "Authentication Level"
};
//temp intid for chat template
var tempIntIdForChatTemplate;
//chat templates array
var allChatTemplates = [];
//text chat greeting text
var global_TextChatGreetingText;
//text chat callback id
var global_TextChatCallbackID;
//immedialte callback button
var isImmediateCallbackBtn = true;
//scheduled callback button
var isScheduledCallbackBtn = true;
//Request Callback Button
var isRequestCallbackBtn = true;

//video call enabled
var isVideoCall = false;
//video call on tab/window
var videoCallType = "tab";
//audio escalate button
var isAudioEscalate = false;
//video escalate button
var isVideoEscalate = false;
//text chat transfer
var isChatTransfer = true;
//conference button
var isConference = false;
//chat history name
var chatHistoryName = "VA Chat History";
//va chat history
var isVaChatHistoryBtn = true;
//va chat history accordion
var isVaChatHistoryAccordion = true;
//chat attachment
var isAttachement = false;
//is user/customer name label on chatbox
var isUserLabel = true;
//chat whiteboard
var isWhiteboard = false;
//whiteboard url
var whiteboardUrl = "https://demo.tetherfi.com:55443/tmac_client/ui/whiteboard.htm";
//open camera button
var isCamera = false;
//voice note
var isVoiceNote = false;
//pdf editor required
var isPdfEditor = false;
//is hyperlink in tag to customer
var isHyperlinkWithTag = true;
//to send all links to customer at the end of chat
var sendAllLinksToCustomer = true;
global_endTextChatNotification = [];
//send messages as app message
var isAppMessage = false;
//is reply button on chat box
var isReplyOnChat = false;
//for uploaded files
var files = {};
//facebook reference
var global_FbReference = [];
//image formats for text chat
var imageFormats = [".JPEG", ".JPG", ".PNG", ".TIFF", ".BMP", ".GIF"];
//audio formats for text chat
var audioFormats = [".AAC", ".MP3", ".OGG", ".WMA", ".WAV", ".M4A"];
//video formats for text chat
var videoFormats = [".MP4", ".3GP"];
//file formats for text chat
var fileFormats = [".TXT", ".CSV", ".EXCEL", ".XLS", ".WORD", ".DOC", ".DOCX", ".MDB", ".PPT", ".PDF", ".PSD", ".FLASH", ".CONFIG", ".BAC", ".ZIP"];
//attachement max size
var maxAttachFileSize = "10";
//Used to check if the image has been edited and saved by the user
var isEditedImage = false;
//Used to check if the image is currently being edited for canvas resizing
var editingImage = false;
//image or pdf edit
var editFileType = "";
//draw stroke style
var drawStrokeStyle = "#000";
//draw stroke size
var drawStrokeSize = "12";
//is form filling
var isFormFilling = false;
//co browsing pages
var forms = [
    { name: "CreditCardForm", url: "https://demo.tetherfi.com:8443/cobrowse/creditcard.html" },
    { name: "TestPageForm", url: "https://demo.tetherfi.com:8443/wx" }
];
var vConn = null;
//expand/collapse on video chat
var isExpandCollapseOnVideoChat = false;
//is uuid enabled for chatid
var isUuidEnabled = false;
//filter type for auto complete chat template
var chatTemplateFilter = "startswith"; //startswith, endswith and contains
//To provide comment on textchat transfer/conference accept/reject
var isCommentOnConfirmaion = false;
//chatbox type
var chatBoxType = "inline"; //inline, outline
//filter template based on time stamp
var isTemplateTimeFilter = false;
//disconnect chat label
var disconnectChatLabel = "Chat";
//  --------------------------------------------------------------------------


//----------------------------------------CALLBACK----------------------------
var isCallback = true;
var global_CallbackPopUpURL;
var global_QMSPopUpURL;
var global_ACWPopUpURL;
var global_hasgetDataEventDetails = false;
var global_isTextChatCallback = false;
//trim before makecall
var global_trimDigitsBeforeMakeCall = "";
//callback vdn list
var global_TextChatVDNList;
//dbs ibg dnis list
var global_IBGDNISList;
//  --------------------------------------------------------------------------


//----------------------------------------DASHBOARD---------------------------
//dashboard connect interval
var loadMyDashboard;
//is dashboard enabled
var isDashboardEnabled = false;
//channel list for dashboard
var globalChannelList = ["Voice", "Textchat"];
//dashboard interval 
var dashboardInterval = [{
    text: "12Hrs",
    value: "12"
},
{
    text: "24Hrs",
    value: "24"
},
{
    text: "36Hrs",
    value: "36"
},
{
    text: "48Hrs",
    value: "48"
},
{
    text: "60Hrs",
    value: "60"
},
{
    text: "72Hrs",
    value: "72"
}
];
//default dashboard interval
var defaultDashboardInterval = "72";
//dashboard connect url
var dashboardSignalRUrl1 = "http://indialab.tetherfi.com:55004";
var dashboardSignalRUrl2 = "http://indialab.tetherfi.com:55006";
//dashboard reconnect interval
var dashboardUrl = "http://indialab.tetherfi.com:55080/TMAC_Agent_Utils/ui/dashboard.html";
//global agent list dashboard
var globalAgentList = [];
//  --------------------------------------------------------------------------


//----------------------------------------VTM---------------------------------
var isVTM = false;

//  --------------------------------------------------------------------------


//----------------------------------------Voice Bio---------------------------
var isVoiceBio = false;
//retry login flag
var retryLogin = true;
//retry interval
var retryInterval = 5000;
//enter manual lan id
var isManualLanId = true;
var voiceBioStationId = "autodiscover";
//voice bio reference
var global_VBReference = [];
//voice bio notification limit
var voiceBioNoficationLimit = {
    notEnrolled: 0,
    enrolled: 0,
    enoughAudio: 0,
    authenticated: 0,
    notAuthenticated: 0,
    rejectedTwice: 0
};
var isDummyVBData = false;
var dummyCLI = "92386588";
var dummyNRIC = "S1234567A";
//  --------------------------------------------------------------------------


//---------------------------------------POM----------------------------------
var isPOM = false;
var global_POMReference = [];
var pomActiveCallInteractionID = "";
var pomLastAgentState = "";