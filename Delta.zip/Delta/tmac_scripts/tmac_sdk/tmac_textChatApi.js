﻿//Tetherfi Multimedia Agent Client 
//JavaScript SDK
//DBS chat API
//Author - Weerathungage Sumudu Saman
//Last updated date - 2019/02/05

var version_tmac_chat_sdk = "3.1.08.0806";

//text chat events
function TextChatAgentMessageForBargeinEvent(event) {
    // string Message 
    // string AgentID  
    tmacevent_TextChatAgentMessageForBargeinEvent(event);
}

function TextChatDisconnectedEvent(event) {
    //string Reason { get; set; }
    //string SessionId
    tmacevent_TextChatDisconnectedEvent(event);
}

function TextChatDisconnectForBargeinEvent(event) {
    // string AgentID  
    // string Reason 
    tmacevent_TextChatDisconnectForBargeinEvent(event);
}

function TextChatFailureEvent(event) {
    // string ErrorType  
    // string ErrorCode  
    // string ErrorDescription 
    tmacevent_TextChatFailureEvent(event);
}

function TextChatIncomingEvent(event) {

    // bool IsManualAnswer  -Is manual answer required
    // string UCID  -call UCID
    // string PhoneNumber -ANI (TextChatServer SIP from address)
    // string VDNName -CalledDevice name
    // string CalledDevice -Called device number
    // string Queue -Queue number
    // string QueueName -Queue name
    // bool IsAgentTransferedChat -Is this a transfered chat
    // bool IsDeflected -Event received for a deflected call. (IsManualAnswer is always true when IsDeflected is true)

    // InteractionRecoveryDataModel RecoveryData 

    //save recovery data
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    tmacevent_TextChatIncomingEvent(event);
}

function TextChatMessageReceivedEvent(event) {
    // string Message 

    tmacevent_TextChatMessageReceivedEvent(event);
}

function TextChatMessageSentEvent(event) {
    // string Message
    // bool IsAppMessage
    // string ConferenceType
    // bool IsRelayMessage
    // bool IsOfflineMessage
    // string ChatIntId
    // string DateTime
    // bool Result
    tmacevent_TextChatMessageSentEvent(event);
}

function AVControlMessageReceivedEvent(event) {
    // string Type 
    // string Message 
    tmacevent_AVControlMessageReceivedEvent(event);
}

function TextChatRemoteUserConnectedEvent(event) {
    //string Name 
    //string ScreenName 
    //string Other 
    //string UID 
    //string AuthType 
    //string CallStatus 
    //string CIF 
    //string CustSeg 
    //string CustSubSeg 
    //string Lang 
    //string Intent 
    //string NRIC 
    //string RegNo1 
    //string RegNo2 
    //string salutation 
    //string screenName 
    //string VAChatSessionID 
    //string ChatHistoryData 
    //string QueueTime 
    //string TextChatServerSessionID 
    //string TextChatSessionID 
    //string CustEntType 
    //string JsonData 
    //TextChatIncomingEvent TextChatIncomingEvent


    tmacevent_TextChatRemoteUserConnectedEvent(event);
}

function TextChatTranscriptForTransferEvent(event) {

    //List < TextChatTranscriptMessageForTransfer > Transcript;
    /*
    class TextChatTranscriptMessageForTransfer { }
    class TextChatTranscriptAgentMessageForTransfer : TextChatTranscriptMessageForTransfer
    {
        
        string Type  = "Agent"
        string DateTime  //dd/mm/yyyy HH:mm:ss
        string AgentName  
        string AgentID  
        string Message  
    }
    class TextChatTranscriptUserMessageForTransfer : TextChatTranscriptMessageForTransfer
    {
        string Type =  "User"
        string DateTime  //dd/mm/yyyy HH:mm:ss
        string Message  
    }*/

    tmacevent_TextChatTranscriptForTransferEvent(event);
}

function TextChatTransferNotificationEvent(event) {
    // string FromAgentID 
    // string FromAgentName  
    // string Comment 
    // string Data 
    // string FromTmacServer { get; set; }
    // string FromInteractionID { get; set; }
    tmacevent_TextChatTransferNotificationEvent(event);
}

function TextChatTransferNotificationResponseEvent(event) {
    // string Response 
    // string FromAgentID 
    // string FromAgentName 
    // string Comment 
    // string Data 
    tmacevent_TextChatTransferNotificationResponseEvent(event);
}

function TextChatTypingStateChangedEvent(event) {
    // int Status  
    try {
        tmacevent_TextChatTypingStateChangedEvent(event);
    } catch (e) {

    }
}

function TextChatUserMessageForBargeinEvent(event) {
    // string Message 
    // string AgentID 
    try {
        tmacevent_TextChatUserMessageForBargeinEvent(event);
    } catch (e) {

    }
}

function TextChatUserRequestedCallbackEvent(event) {
    // bool Status { get; set; }    
    try {
        tmacevent_TextChatUserRequestedCallbackEvent(event);
    } catch (e) {

    }
}

function TextChatAgentConnectedEvent(event) {
    try {
        tmac_TextChatAgentConnectedEvent(event);
    } catch (e) {

    }
}

function TextChatAgentDisconnectedEvent(event) {
    try {
        tmac_TextChatAgentDisconnectedEvent(event);
        if (event.ConferenceType == "silent") {
            tmac_EndTextChatWithReason(null, null, global_DeviceID, event.InteractionID, "AgentChatDisconnected");
        }
    } catch (e) {

    }
}

function TextChatAgentMessageReceivedEvent(event) {
    try {
        tmac_TextChatAgentMessageReceivedEvent(event);
    } catch (e) {

    }
}

//Text chat methods
function tmac_EndTextChat(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "EndTextChat");
}

function tmac_EndTextChatDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_EndTextChatWithReason(callbackfunction, userobject, deviceid, interactionid, reason) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.reason = reason;  //String
    tmac_command(callbackfunction, userobject, data, "EndTextChatWithReason");
}

function tmac_EndTextChatWithReasonDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendTextChat(callbackfunction, userobject, deviceid, interactionid, text) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.text = text;  //String
    tmac_command(callbackfunction, userobject, data, "SendTextChat");
}

function tmac_SendTextChatDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendTextChatFromTemplate(callbackfunction, userobject, deviceid, interactionid, text, templateid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.text = text;  //String
    data.tid = templateid;
    tmac_command(callbackfunction, userobject, data, "SendTextChatFromTemplate");
}

function tmac_SendTextChatFromTemplateDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
		 try {
			 if (typeof callbackfunction === "function") {
					callbackfunction(resultdata, userobject);
				}
			else {
					window[callbackfunction](resultdata, userobject);
			}
         }
    catch (e) {
       }
}

function tmac_SendAppMessage(callbackfunction, userobject, deviceid, interactionid, text) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.text = text;  //String
    tmac_command(callbackfunction, userobject, data, "SendAppMessage");
}

function tmac_SendAppMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendAVControlMessage(callbackfunction, userobject, deviceid, interactionid, message, type) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.type = type;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "SendAVControlMessage");
}

function tmac_SendAVControlMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendAppMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_RegisterTextChatCallback(callbackfunction, userobject, deviceid, interactionid, preferrednumber, preferredtime) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.preferrednumber = preferrednumber;  //String
    data.preferredtime = preferredtime;  //String
    tmac_command(callbackfunction, userobject, data, "RegisterTextChatCallback");
}

function tmac_RegisterTextChatCallbackDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendTextChatTransferNotification(callbackfunction, userobject, deviceid, interactionid, remoteAgentId, comment, otherdata) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.remoteAgentId = remoteAgentId;  //String
    data.comment = comment;  //String
    data.data = otherdata;  //String
    tmac_command(callbackfunction, userobject, data, "SendTextChatTransferNotification");
}

function tmac_SendTextChatTransferNotificationDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendTextChatTransferNotificationRespond(callbackfunction, userobject, deviceid, originatedAgentId, originatedInteractionID, response, comment, otherdata) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.originatedAgentId = originatedAgentId;  //String
    data.originatedInteractionID = originatedInteractionID;  //String
    data.response = response;  //String
    data.comment = comment;  //String
    data.data = otherdata;  //String
    tmac_command(callbackfunction, userobject, data, "SendTextChatTransferNotificationRespond");
}

function tmac_SendTextChatTransferNotificationRespondDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TransferTextChatToQueue(callbackfunction, userobject, deviceid, interactionId, skillNumber, isBlind, chatMode) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionId = interactionId;  //String
    data.skillNumber = skillNumber;  //String
    data.isBlind = isBlind;  //Boolean
    data.chatMode = chatMode; //String
    tmac_command(callbackfunction, userobject, data, "TransferTextChatToQueue");
}

function tmac_TransferTextChatToQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TransferTextChatToServer(callbackfunction, userobject, deviceid, chatSessionId, sourceagentId, interactionId, number, comment, agentid, lineid, toAgentTmacServer, confType, chatMode) {
    let data = {};
    data.sourcedeviceid = deviceid;
    data.chatsessionid = chatSessionId;
    data.sourceagentid = sourceagentId;
    data.sourceinteractionid = interactionId;
    data.destnumber = number;
    data.comment = comment;
    data.destagentid = agentid;
    data.lineid = lineid;
    data.toAgentTmacServer = toAgentTmacServer;
    data.confType = confType;
    data.chatMode = chatMode;
    tmac_command(callbackfunction, userobject, data, "TransferTextChatToServer");
}

function tmac_TransferTextChatToServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TextChatBargeinToServer(callbackfunction, userobject, agentid, interactionid, supervisoravayaloginid, tmacServer) {
    var data = {};
    data.agentid = agentid;  //String
    data.interactionid = interactionid;  //String
    data.supervisoravayaloginid = supervisoravayaloginid;  //String
    data.agentTmacServer = tmacServer;
    data.supervisorTmacServer = _tmacServer;
    tmac_command(callbackfunction, userobject, data, "TextChatBargeinToServer");
}

function tmac_TextChatBargeinToServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TextChatStopBargeinTo(callbackfunction, userobject, agentid, interactionid, supervisoravayaloginid) {
    var data = {};
    data.agentid = agentid;  //String
    data.interactionid = interactionid;  //String
    data.supervisoravayaloginid = supervisoravayaloginid;  //String
    tmac_command(callbackfunction, userobject, data, "TextChatStopBargeinTo");
}

function tmac_TextChatStopBargeinToDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TextChatNotifyTypingStateChange(callbackfunction, userobject, deviceid, interactionId, stat) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionId = interactionId;  //String
    data.stat = stat;  //Int32
    tmac_command(callbackfunction, userobject, data, "TextChatNotifyTypingStateChange");
}

function tmac_TextChatNotifyTypingStateChangeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetTextChatAgentListForBargein(callbackfunction, userobject, teamId, supervisoravayaloginid) {
    var data = {};
    data.teamId = teamId;  //String
    data.supervisoravayaloginid = supervisoravayaloginid;  //String
    tmac_command(callbackfunction, userobject, data, "GetTextChatAgentListForBargein");
}

function tmac_GetTextChatAgentListForBargeinDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetTextChatAgentListForBargeinAll(callbackfunction, userobject, teamId, supervisoravayaloginid) {
    var data = {};
    data.teamId = teamId;  //String
    data.supervisoravayaloginid = supervisoravayaloginid;  //String
    data.tmacServer = _tmacServer;
    tmac_command(callbackfunction, userobject, data, "GetTextChatAgentListForBargeinAll");
}

function tmac_GetTextChatAgentListForBargeinAllDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendTextChatTransferNotificationResponseToServer(callbackfunction, userobject, toTmacServer, toAgentId, toInteractionId, response, comment, otherdata) {

    var data = {};
    data.fromTmacServer = _tmacServer;  //String
    data.fromAgentId = global_AgentID;  //String
    data.fromAgentName = global_AgentName;  //String
    data.toTmacServer = toTmacServer;  //String
    data.toAgentId = toAgentId;  //String
    data.toInteractionId = toInteractionId;  //String
    data.response = response;  //String
    data.comment = comment;  //String
    data.data = otherdata;  //String

    tmac_command(callbackfunction, userobject, data, "SendTextChatTransferNotificationResponseToServer");
}

function tmac_SendTextChatTransferNotificationResponseToServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent (ResultCode,ResultMessage)
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendTextChatTransferNotificationToServer(callbackfunction, userobject, intid, toAgent, toTmacServer, comment, otherdata) {
    var data = {};
    data.fromTmacServer = _tmacServer;  //String
    data.fromAgentId = global_AgentID;  //String
    data.fromAgentName = global_AgentName;  //String
    data.fromInteraction = intid;  //String
    data.toAgent = toAgent;  //String
    data.toTmacServer = toTmacServer;  //String
    data.comment = comment;  //String
    data.data = otherdata;  //String

    tmac_command(callbackfunction, userobject, data, "SendTextChatTransferNotificationToServer");
}

function tmac_SendTextChatTransferNotificationToServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent (ResultCode,ResultMessage)
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}