﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TmacTextChatUI.js";
var file_version = "3.1.08.0806";
var changedBy = "Kavya Nayak";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
var isRMCallbackbtm;
// ----------------------------------------------------------------------------------
$(function () {
    //load chat templates once this file is loaded
		 LoadAllChatTempaltes();
		 //get features from ocm
		 if (global_AgentFeatures && global_AgentFeatures.length > 0) {
				  let getRMFeature = global_AgentFeatures.filter(function (f) {
						   return f.Feature === "RMCallbackEnabled" && f.IsEnabled;
				  });
				  isRequestCallbackBtn = getRMFeature.length > 0;
		 }
		
});

function TextChatNewChatReceived(data) {
    try {
        //current interaction id
        let intid = data.InteractionID;
        //save the chat reference for session timer
        SaveChatReference(intid);
        //update the chat routing type. If IsNonVoiceRouting is true then WQ else CM
        GetChatReferenceObj(intid).isNonVoiceRouting = data.IsNonVoiceRouting;
        //add chat tab
        AddChatTab(data);
        //Initialize the UIKit accordion for the created tab
        let accordion = UIkit.accordion($('#chat_accordion' + intid), {
            collapse: false,
            showfirst: false
        }),
            wrapper1 = accordion.find('[data-wrapper]').get(0), //0 as index of the content
            wrapper2 = accordion.find('[data-wrapper]').get(1); //1 as index of the content
        accordion.toggleItem(UIkit.$(wrapper1), true, false); // animated true and collapse true
        accordion.toggleItem(UIkit.$(wrapper2), true, false); // animated true and collapse true
        ChangeChatColorInit("divTxtChatTranscript" + intid, "chat_colors" + intid);
        //blink the chat accordion header on incoming chat
        $("#chat_transcript_accordion" + intid).addClass("blink_chat");
        global_UCID[intid] = data.UCID;
        if (!isChatAuthenticationPanel)
            $("#div_authentication" + intid).remove();
        else {
            $("#auth_st_label" + intid).text(chatAuthenticationLabels.label1);
            $("#auth_lv_label" + intid).text(chatAuthenticationLabels.label2);
        }
        //set va chat history accordion name
        $("#va_history_accordion" + intid).text(chatHistoryName);
        if (!isVaChatHistoryAccordion) {
            $("#va_history_accordion" + intid).addClass("uk-display-none");
        }
        if (isCamera)
            $("#spanOpenCamera" + intid).css("display", "table-cell");
        if (isWhiteboard)
            $("#spanTextChatWhiteboard" + intid).css("display", "table-cell");
        if (isAttachement)
            $("#spanTextChatAttach" + intid).css("display", "table-cell");
        if (isVoiceNote)
            $("#spanTextChatSendVoice" + intid).css("display", "table-cell");
        //show notification on !window focus
        ShowNotification("You have new", "Incoming Chat");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatNewChatReceived()", ex, false);
    }
}

function AddChatTab(data) {
    try {
        //current interaction id
        let intid = data.InteractionID;
        //incoming phone number
        let phonenumber = data.PhoneNumber;
        //save the tab reference
        SaveTabReference('chat', intid, 'new');
        //add chat dynamic fields
        AddDynamicFields("chat");
        //tab header content
        let headerTemplate = GetTabHtml("tab_header_template", intid, { icon: "chat" });
        //tab body content
        let bodyTemplate = document.getElementById("chat_tab_body").innerHTML;
        //let bodyTemplate = GetTabHtml("chat_body_template", intid, "");
        //variable chat active initially true
        let tabActive = true;
        //add a kendo tab
        AddTab(bodyTemplate, headerTemplate, intid, phonenumber, tabActive, false, true);
        //create the initial interaction history grid
        if (data.ConferenceType != "silent") {
            //load chat template grid
            CreateChatTemplateGrid("");
				 //set the controls
				 SetTextChatControlVisibility(intid, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false);
            //Initialize the auto complete for the #textChatMessage text area
            $("#textChatMessage" + intid).kendoAutoComplete({
                dataSource: allChatTemplates,
                filter: chatTemplateFilter,
                noDataTemplate: false,
                dataTextField: "Text",
                dataValueField: "ID",
                select: textChatMessageOnSelect
            });
            //initialise event lister for the message textarea
            AddTypingEventListener(intid);
            // if shift + enter is pressed, goes to new line [Since Alt+Enter will maximize the browser window, so we replaced with shift + Enter]
            $("#textChatMessage" + intid).keypress(function (e) {
                if (e.keyCode == 13 && !e.shiftKey) {
                    SendChat(intid);
                    // Remove the unnecessary character
                    return false;
                }
                //append . and space event for grammer check
                if (isGrammerCheck && (e.keyCode === 46 || e.keyCode === 32 || (e.keyCode == 13 && e.shiftKey))) {
                    GrammerCheck(intid);
                }
            });
            //focus the textbox when clicking on chatbox area
            $("#div_chat_box_wrapper" + intid).click(function () {
                $("#textChatMessage" + intid).focus();
            });
            //store the chat interaction id in hidden variable
            $("#textChatInteractionID").val(intid);
            //variable set for chat disconnect message dialog display based on customer or agent disconnect
            global_endTextChatNotification[intid] = false;
            //add a call timer/session timer  
            AddCallTimer(intid, "chat", "#hdn_text_chat_starttime" + intid, "#text_chat_starttime" + intid,
                "#text_chat_time_taken" + intid, "#text_chat_span_starttime" + intid, "#agent_time_taken" + intid,
                "#agent_time_taken_span" + intid, "#hdn_agent_time_taken_start" + intid, "#hdn_agent_time_taken_end" + intid, "#btnTextChat_FreezeAutoResponse" + intid, data.ConferenceType);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddChatTab()", ex, false);
    }
}

function textChatMessageOnSelect(e) {
    try {
        var dataItem = this.dataItem(e.item.index());
        GetChatReferenceObj(global_activeTabInteractionID).selectedTemplateId = dataItem.ID;
    } catch (e) {
        log.LogDetails("Error", "TmacTextChatUI.textChatMessageOnSelect()", ex, false);
    }
}

function AddTypingEventListener(intid) {
    try {
        //chat input textarea element
        var element = $("#textChatMessage" + intid);
        //on change of element
        element.keyup(function () {
            if (element.val() !== "") {
                //typing...
                TextChatNotifyTypingStatusChange(global_DeviceID, intid, 0);
            } else {
                //not typing...
                TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
            }
        });
        //on blur send not typing
        element.blur(function () {
            //not typing...
            TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
        });

        $("#chat_submit_box" + intid + " span.k-icon.k-clear-value.k-i-close").click(function () {
            //not typing...
            TextChatNotifyTypingStatusChange(global_DeviceID, intid, 1);
            if (isGrammerCheck) ClearHighlightTextarea(intid);
        });

    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddTypingEventListener()", ex, false);
    }
}

function GrammerCheck(intid) {
    try {
        var text = $("#textChatMessage" + intid).val();
        var data = {};
        data.intid = intid;
        data.originalText = text;
        if ($.trim(text) != "")
            if (isSanitizeHtml) text = sanitizeHtml(text);
        if (text != "")
            CheckGrammer(text, data);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GrammerCheck()", ex, false);
    }
}

function GrammerCheckDone(data, obj) {
    try {
        var message = "";
        if (!GetChatReferenceObj(obj.intid).isDisconnected) {
            if (data !== null) {
                ClearHighlightTextarea(obj.intid);
                $('#textChatMessage' + obj.intid).highlightTextarea({
                    ranges: [{
                        color: '#FFFF00',
                        ranges: data
                    }]
                });
                $("#textChatMessage" + obj.intid).focus();
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GrammerCheckDone()", ex, false);
    }
}

function ClearHighlightTextarea(intid) {
    try {
        $('#textChatMessage' + intid).highlightTextarea('destroy');
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ClearHighlightTextarea()", ex, false);
    }
}

function SetSelectionRange(input, selectionStart, selectionEnd) {
    try {
        if (input.setSelectionRange) {
            input.focus();
            input.setSelectionRange(selectionStart, selectionEnd);
        } else if (input.createTextRange) {
            var range = input.createTextRange();
            range.collapse(true);
            range.moveEnd('character', selectionEnd);
            range.moveStart('character', selectionStart);
            range.select();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SetSelectionRange()", ex, false);
    }
}

function SetCareToPos(input, values) {
    try {
        //var input = document.getElementById("textChatMessage" + intid);
        SetSelectionRange(input, values, values);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SetCareToPos()", ex, false);
    }
}

function TextchatRemoteUserConnected(data) {
    try {
        let intid = data.InteractionID;
        //remove the chat accordion blink once the chat is connected
        $("#chat_transcript_accordion" + intid).removeClass("blink_chat");
        //set control visibility
        if (data.ConferenceType == "silent")
            SetTextChatControlVisibility(intid, false, false, true, false, false, false, false, false, false, false, false, false, false, false,false);
        else if (data.ConferenceType == "whisper")
            SetTextChatControlVisibility(intid, false, true, true, false, false, false, false, false, true, false, false, false, false, false,false);
        else
				 SetTextChatControlVisibility(intid, false, true, true, isChatTransfer, isConference,
						  isAudioEscalate, isVideoEscalate, false, true, isImmediateCallbackBtn, isVaChatHistoryBtn, false, false, false, isRequestCallbackBtn);

        //CSAT Survey Request
        if (isCSATSurvey)
            InitiateCsatSurvey(data);

        if (isPWebChat) {
            AssignDynamicValues(data, "chat");
            //set the chat mode
            try {
                let chatMode = data.ChatMode;
                GetChatReferenceObj(intid).chatMode = chatMode;
                if (isVideoCall && chatMode != "text") {
                    //if this is transfer chat or conference chat
                    if (data.TextChatIncomingEvent.IsAgentConferenceChat) {
                        let isAudioOnly = false;
                        //check is this a audio ip chat then isAudioOnly true
                        if (chatMode == "audio")
                            isAudioOnly = true;
                        //create a audio channel connection
                        vConn = new AVChannel(intid, global_AgentID, global_DeviceID, isAudioOnly, "remoteVideo" + intid);
                        //join the call
                        vConn.call();
                    }
                    //if this is a new chat
                    else {
                        let msg = {};
                        msg.type = "avtstatus";
                        msg.param = chatMode;
                        msg = JSON.stringify(msg);
                        SendAVControlMessage(global_DeviceID, intid, msg, "avtstatus");
                    }
                }

            } catch (ex) {
                log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected() - ChatMode", ex, false);
            }
        }
        else {
            var jsonData = JSON.parse(data.JsonData);
            GetChatReferenceObj(intid).customerName = jsonData.eCustName;
            $('#divTabHeader' + intid).text(jsonData.eCustName);
            $("#textChatName" + intid).val(jsonData.eCustName);
            $("#textChatNRIC" + intid).val(jsonData.eKCIN);
            $("#textChatRegPhone" + intid).val(jsonData.eMobileNo);
            $("#textChatEmail" + intid).val(jsonData.eEmail);
        }

        try {
            var historyData = JSON.parse(data.ChatHistoryData);
            if (historyData.length !== 0) {
                $("#chat_divider" + intid).remove();
                $("#queueHistoryChatBox" + intid).show();
                CreateQueueHistoryChatBox(intid, historyData);
            }
        } catch (ex) {
            log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected() - Inside", ex, false);
        }

        //send greetings if this is a new chat not a transferred chat
        if (!data.TextChatIncomingEvent.IsAgentTransferedChat) {
            SendtextChatGreeting(intid);
        }

        //check if any active AV going on then disable AV buttons if enabled
        if (isAudioEscalate || isVideoEscalate) {
            CheckForActiveAV();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextchatRemoteUserConnected()", ex, false);
    }
}

function TextChatAgentConnected(event) {
    try {
        let intid = event.InteractionID;
        //get conference agent info
        let agentInfo = JSON.parse(event.AgentInfoJson);
        //extra parameter for agent info
        let extraParam = JSON.parse(agentInfo.extraparam);
        if (extraParam.conferenceType == "conf" || extraParam.conferenceType == "whisper") {
            ShowNotify(event.AgentName + " connected to the chat", "info", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatAgentConnected()", ex, false);
    }
}

function CreateQueueHistoryChatBox(intid, data) {
    try {
        $.each(data, function (i, val) {
            let msgDateTime = val.timestamp;
            let msgid = uuid();
            if ((val.customer_input != "") && (val.customer_input != undefined)) {
                AddMessageToChatbox(intid, msgid, val.customer_input, "customer", msgDateTime, "queueHistoryChatBox", "", false, "", GetChatReferenceObj(intid).customerName);
            }
            else if ((val.reply != "") && (val.reply != undefined))
                AddMessageToChatbox(intid, msgid, val.reply, "agent", msgDateTime, "queueHistoryChatBox", "", false, "", "Chatbot");
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CreateQueueHistoryChatBox()", ex, false);
    }
}

function LoadVAChatHistoryDialog(deviceid, intid) {
    try {
        $("#vaHistoryAccordion").hide();
        $("#vaHistoryNoData").show();
        $("#va_history_request_dialog").data("kendoWindow").center().open();
        custom_LoadVAChatHistory(deviceid, intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.LoadVAChatHistoryDialog()", ex, false);
    }
}

function LoadVAChatHistoryChatBox(event) {
    try {
        $("#vaHistoryAccordion").html("");
        var parse = JSON.parse(event.JsonData);
        var sessionList = [];
        if (parse.history.length !== 0) {
            $("#vaHistoryNoData").hide();
            $("#vaHistoryAccordion").show();
            $.each(parse.history, function (i, val) {
                let sessionId = val.SessionID;
                let appendId = sessionId.length >= 30 ? sessionId.substr(sessionId.length - 30, 30) : sessionId;
                let heading = '<h3 class="uk-accordion-title">...' + appendId + '</h3>';
                let content = '<div class="uk-accordion-content no-padding" id="div_' + sessionId + '"></div>';
                let chatBox = '<div class="chat_box touchscroll chat_box_colors_a va_chat_box" id="vaChatBox_' + sessionId + '"></div>';
                let msgid = uuid();
                let msg = "";
                let msgDateTime = "";
                if (sessionList.indexOf(sessionId) < 0) {
                    sessionList.push(sessionId);
                    $("#vaHistoryAccordion").append(heading);
                    $("#vaHistoryAccordion").append(content);
                    $("#div_" + sessionId).append(chatBox);
                    if (val.RequestMessage != "") {
                        msg = val.RequestMessage;
                        msgDateTime = val.ReponseMessageDateTime;
                        AddMessageToChatbox("", msgid, msg, "customer", msgDateTime, "vaChatBox_" + sessionId, "", false, "", GetChatReferenceObj(global_activeTabInteractionID).customerName);
                    }
                    if (val.ReponseMessage != "") {
                        msg = val.ReponseMessage;
                        msgDateTime = val.ReponseMessageDateTime;
                        AddMessageToChatbox("", msgid, msg, "agent", msgDateTime, "vaChatBox_" + sessionId, "", false, "", "Chatbot");
                    }
                } else {
                    if (val.RequestMessage != "") {
                        msg = val.RequestMessage;
                        msgDateTime = val.RequestMessageDateTime;
                        AddMessageToChatbox("", msgid, msg, "customer", msgDateTime, "vaChatBox_" + sessionId, "", false, "", GetChatReferenceObj(global_activeTabInteractionID).customerName);
                    }
                    if (val.ReponseMessage != "") {
                        msg = val.ReponseMessage;
                        msgDateTime = val.ReponseMessageDateTime;
                        AddMessageToChatbox("", msgid, msg, "agent", msgDateTime, "vaChatBox_" + sessionId, "", false, "", "Chatbot");
                    }
                }
            });
        }
        UIkit.accordion($("#vaHistoryAccordion"));
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.LoadVAChatHistoryChatBox()", ex, false);
    }
}

function TextChatDisconnected(intid, reason) {
    //chat ended
    try {
        //if chat is disconnected and the tab is blinking, stop the blinking of tab
        if (GetChatReferenceObj(intid).isBlink) {
            $("#li_" + intid).removeClass("blink_chattab");
            GetChatReferenceObj(intid).isBlink = false;
        }
        //if customer is typing and chat disconnect the remove typing div
        if (GetChatReferenceObj(intid).isTyping)
            RemoveTypingDiv(intid);
        //trigger the end on chat disconnect - otherwise timer will be running even after the chat disconnect
        if ($("#hdn_agent_time_taken_end" + intid).val() === "") {
            $("#hdn_agent_time_taken_end" + intid).val(new Date());
        }
        //if auto timer then clear the timer to stop
        if (autoTimerForTimeTaken) {
            clearInterval(GetChatReferenceObj(intid).timeTakenToReply);
            clearInterval(GetTabReferenceObj(intid).tabTimer);
        }
        //if the chat is disconnected before answering remove the chat accordion header blink
        $("#chat_transcript_accordion" + intid).removeClass("blink_chat");
        //if chatCallbackScheduleEnabled is false then don't show callback schedule button 
        //disable the ui controls
			 SetTextChatControlVisibility(intid, false, false, false, false, false, false, false, false, false, false, false, isScheduledCallbackBtn, true, isEnableCloseTabOnDisconnect.TextChat, false);
        //remove active tab color
        $("#li_" + intid).removeClass("li-on-call");
        //enable tab close button
        EnableTabCloseButton(intid);
        HideConfirmDialog();
        //if video/audio call is enabled and is going on then close the session
        if (isVideoCall && GetChatReferenceObj(intid).chatMode != "text")
            CloseAVConnection(intid, "remote");
        //check for other chat and active AV buttons if enabled
        if (isAudioEscalate || isVideoEscalate) {
            CheckForActiveAV();
        }
        //close all the dialogs opened for chat
        CloseAllChatDialogs();
        ChangeTabReferenceStatus(intid, 'CallDisconnected');
        //add chat reference for the interaction isDisconnected true
        GetChatReferenceObj(intid).isDisconnected = true;
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatDisconnected()", ex, false);
    }
}

function TextChatAgentDisconnected(event) {
    try {
        if (event.ConferenceType == "" || event.ConferenceType == "conf" || event.ConferenceType == "whisper")
            ShowNotify(event.AgentName + " disconnected the chat", "info", null, "top-center");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatAgentDisconnected()", ex, false);
    }
}

function SendtextChatGreeting(intid) {
    try {
        //message
        if ((global_TextChatGreetingText === "") || (global_TextChatGreetingText === "undefined") || (global_TextChatGreetingText === 0)) {
            return;
        }
        //set the greeting mesage to the textarea
        $("#textChatMessage" + intid).val(global_TextChatGreetingText);
        //send the greeting to chatbox and the server
        SendChat(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendtextChatGreeting()", ex, false);
    }
}

function SendChat(intid) {
    try {
        //if message is empty return
        let msg = $("#textChatMessage" + intid).val();
        let custMsg = "";
        let msgid = uuid();
        let agentName = global_AgentName.split(' ')[0];;
        if ((msg === "") || (msg === null)) {
            return;
        }
        if (isSanitizeHtml) {
            msg = sanitizeHtml(msg);
            if (msg == "") {
                log.LogDetails("Warning", "TmacTextChatUI.EndChat()", "Invalid text is not allowed!", true);
                return;
            }
        }
        //if agent send chat while the customer is typing remove the customer typing div and add it after agent text
        if (GetChatReferenceObj(intid).isTyping)
            RemoveTypingDiv(intid);

        if (!GetChatReferenceObj(intid).isAgent) {
            //trigger the time agent replied to customer to know total time taken to reply to the customer
            $("#hdn_agent_time_taken_end" + intid).val(new Date());
            //if auto timer then clear the timer to stop
            if (autoTimerForTimeTaken) clearInterval(GetChatReferenceObj(intid).timeTakenToReply);
            GetChatReferenceObj(intid).isCustomer = false;
            GetChatReferenceObj(intid).isAgent = true;
        }
        if (isHyperlinkWithTag) {
            custMsg = CheckForHyperlinks(intid, msg, true);
            custMsg = msg.replace(/\b((?:[a-z][\w-]+:(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.-]+[.][a-z]{2,4}\/)(?:(?:[^\s()<>.]+[.]?)+|((?:[^\s()<>]+|(?:([^\s()<>]+)))))+(?:((?:[^\s()<>]+|(?:([^\s()<>]+))))|[^\s`!()[]{};:'".,<>?«»“”‘’]))/gi, "<a target=_blank href=https://$1>$1</a>");
        }
        else {
            custMsg = msg;
        }
        //to send msg as an app message
        if (isAppMessage) {
            //check for co-browsing
            custMsg = isFormFilling === true ? CheckForForms(custMsg, intid) : custMsg;
            msg = custMsg;
            let isReply = false;
            GetChatReferenceObj(intid).replyText != "" ? isReply = true : isReply = false;
            let obj = {};
            obj.id = msgid;
            obj.message = custMsg;
            obj.messageType = "text";
            if (isReply) {
                obj.type = "reply";
                obj.replyIdTextType = GetChatReferenceObj(intid).replyTextId + "|" + GetChatReferenceObj(intid).replyText + "|" + GetChatReferenceObj(intid).replyType;
            }
            else
                obj.type = "new";
            custMsg = JSON.stringify(obj);

            //send the message to server
            SendTextChat(global_DeviceID, intid, custMsg);
            let replyJson = {};
            replyJson.replyType = GetChatReferenceObj(intid).replyType;
            replyJson.replyTextId = GetChatReferenceObj(intid).replyTextId;
            replyJson.replyText = GetChatReferenceObj(intid).replyText;
            replyJson.replyUser = GetChatReferenceObj(intid).replyUser;
            //add the message to the chatbox
            AddMessageToChatbox(intid, msgid, msg, "agent", "", "divTxtChatTranscript", "", isReply, replyJson, agentName);
        }
        else {
            //send the message to server
            msg = custMsg;
            SendTextChat(global_DeviceID, intid, custMsg);
            AddMessageToChatbox(intid, msgid, msg, "agent", "", "divTxtChatTranscript", "", false, "", agentName);
        }
        GetChatReferenceObj(intid).selectedTemplateId = "";
        if (isGrammerCheck) {
            ClearHighlightTextarea(intid);
            GrammerCheck(intid);
        }
        //clear the textarea
        $("#textChatMessage" + intid).val("");
        //set focus to the textbox after sending the chat
        $("#textChatMessage" + intid).focus();
        //add the customer typing div
        if (GetChatReferenceObj(intid).isTyping)
            AddTypingDiv(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendChat()", ex, false);
    }
}

function TextChatMessageSent(event, displayMessage) {
    try {
        //show the message only for recovery event
        if ((event.RecoveryEvent && !event.IsAppMessage) || displayMessage) {
            let intid = event.InteractionID;
            let msgid = event.EventId;
            let msg = event.Message;
            let agentName = global_AgentName.split(" ")[0];
            AddMessageToChatbox(intid, msgid, msg, "agent", "", "divTxtChatTranscript", "", false, "", agentName);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendChat()", ex, false);
    }
}

function TextChatMessageReceived(confType, appMessage, message, msgid, intid, user) {
    try {
        let labelName = "";
        let userType = "";
        //check for html sanitize if appMessage then check only the text and if not appMessage just check the text
        if (isSanitizeHtml && ((appMessage !== undefined && appMessage && JSON.parse(message).messageType == "text") || !appMessage)) message = sanitizeHtml(message);
        if (message != "") {
            //if customer send chat sometimes i wont get not typing after typing so i need to hide and show again later if still typing
            if (GetChatReferenceObj(intid).isTyping)
                RemoveTypingDiv(intid);

            if (!GetChatReferenceObj(intid).isActive) {
                $("#li_" + intid).addClass("blink_chattab");
                GetChatReferenceObj(intid).isBlink = true;
            }

            if (!GetChatReferenceObj(intid).isCustomer) {
                //trigger customer message received time
                $("#hdn_agent_time_taken_start" + intid).val(new Date());
                //set the vlaue to null to start timer until agent replies 
                $("#hdn_agent_time_taken_end" + intid).val("");
                //if auto timer then clear the counter and start the timer
                if (autoTimerForTimeTaken) {
                    GetChatReferenceObj(intid).timeTakenCounter = 0;
                    clearInterval(GetChatReferenceObj(intid).timeTakenToReply);
                    StartChatTimeTakenTimer(intid, "#agent_time_taken_span" + intid);
                }
                GetChatReferenceObj(intid).isCustomer = true;
                GetChatReferenceObj(intid).isAgent = false;
            }

            //add the customer name for conference/barge-in
            if (user != "") {
                labelName = user;
                if (confType == "silent") {
                    userType = "agent";
                }
                else
                    userType = "conferenceAgent";
            }
            else {
                labelName = GetChatReferenceObj(intid).customerName;
                userType = "customer";
            }
            if (appMessage !== undefined && appMessage) {
                log.LogDetails(log.logType.Info, "TmacTextChatUI.OnCustomerMessageReceived", "video message:[" + message + "]", false);
                //parse the received json
                let jsonMessage = JSON.parse(message);
                //if the type is bye then close the video poup

                if (jsonMessage.messageType !== undefined && jsonMessage.messageType == "whiteboard") {
                    OpenWhiteBoard(jsonMessage.message);
                }
                else if (jsonMessage.messageType !== undefined) {
                    let replyJson = {};
                    let isReply = false;
                    if (jsonMessage.type == "reply") {
                        isReply = true;
                        replyJson.replyTextId = jsonMessage.replyIdTextType.split('|')[0];
                        replyJson.replyText = jsonMessage.replyIdTextType.split('|')[1];
                        replyJson.replyType = jsonMessage.replyIdTextType.split('|')[2];

                        if (jsonMessage.replyIdTextType.split('|')[0].split('_')[1] == "customer")
                            replyJson.replyUser = "Customer";
                        else
                            replyJson.replyUser = "You";
                    }
                    msgid = jsonMessage.id;
                    if (jsonMessage.messageType == "image") {
                        AddMessageToChatbox(intid, msgid, jsonMessage.message, userType, "", "divTxtChatTranscript", "image", isReply, replyJson, labelName);
                    }
                    else if (jsonMessage.messageType == "audio") {
                        AddMessageToChatbox(intid, msgid, jsonMessage.message, userType, "", "divTxtChatTranscript", "audio", isReply, replyJson, labelName);
                    }
                    else if (jsonMessage.messageType == "video") {
                        AddMessageToChatbox(intid, msgid, jsonMessage.message, userType, "", "divTxtChatTranscript", "video", isReply, replyJson, labelName);
                    }
                    else if (jsonMessage.messageType == "file") {
                        var fileType = GetFileExtension(jsonMessage.message.split('|')[1]);
                        if (fileType == "doc" || fileType == "docx" || fileType == "pdf")
                            AddMessageToChatbox(intid, msgid, jsonMessage.message, userType, "", "divTxtChatTranscript", "file", isReply, replyJson, labelName);
                        else
                            AddMessageToChatbox(intid, msgid, jsonMessage.message, userType, "", "divTxtChatTranscript", "others", isReply, replyJson, labelName);
                    }
                    else if (jsonMessage.messageType == "text") {
                        //add the message to the chatbox
                        let msg = jsonMessage.message;
                        if (isHyperlinkWithTag)
                            msg = msg.replace(/\b((?:[a-z][\w-]+:(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.-]+[.][a-z]{2,4}\/)(?:(?:[^\s()<>.]+[.]?)+|((?:[^\s()<>]+|(?:([^\s()<>]+)))))+(?:((?:[^\s()<>]+|(?:([^\s()<>]+))))|[^\s`!()[]{};:'".,<>?«»“”‘’]))/gi, "<a target=_blank href=https://$1>$1</a>")
                        AddMessageToChatbox(intid, msgid, msg, userType, "", "divTxtChatTranscript", "", isReply, replyJson, labelName);
                    }
                    //show notifications for app message
                    ShowNotification("You have new text message", jsonMessage.message);
                }
            } else {
                //show unread divider if the tab is inactive
                //let activeTabId = tabstrip.select()[0].id.split('_')[1];
                //if (activeTabId != intid) {
                //    if ($("#divTxtChatTranscript" + intid).find(".unread").length == 0) {
                //        AddMessageToChatbox(intid, msgid, "Unread Messages", "unread", "", "divTxtChatTranscript", "", false, "", labelName);
                //    }
                //}
                if (isHyperlinkWithTag)
                    message = message.replace(/\b((?:[a-z][\w-]+:(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.-]+[.][a-z]{2,4}\/)(?:(?:[^\s()<>.]+[.]?)+|((?:[^\s()<>]+|(?:([^\s()<>]+)))))+(?:((?:[^\s()<>]+|(?:([^\s()<>]+))))|[^\s`!()[]{};:'".,<>?«»“”‘’]))/gi, "<a target=_blank href=https://$1>$1</a>")
                //add the message to the chatbox
                AddMessageToChatbox(intid, msgid, message, userType, "", "divTxtChatTranscript", "", false, "", labelName);
                //show notifications for not app message
                ShowNotification("You have new text message", message);
            }
            //hide the freeze button if enabled
            $("#btnTextChat_FreezeAutoResponse" + intid).hide();

            //add the customer typing div if i have same typing event
            if (GetChatReferenceObj(intid).isTyping)
                AddTypingDiv(intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatMessageReceived()", ex, false);
    }
}

function AVControlMessageReceived(event) {
    try {
        let intid = event.InteractionID;
        let jsonMessage = JSON.parse(event.Message);
        if (event.Type == "avtstatus") {
            switch (jsonMessage.param) {
                case "audio":
                    AudioEscalate(intid);
                    FreezeTextChatAutoResponse(global_DeviceID, intid);
                    break;
                case "video":
                    VideoEscalate(intid);
                    FreezeTextChatAutoResponse(global_DeviceID, intid);
                    break;
                case false:
                    if (isAudioEscalate)
                        FadeInButton("#btnTextChat_AudioEscalate" + intid);
                    if (isVideoEscalate)
                        FadeInButton("#btnTextChat_VideoEscalate" + intid);
                    log.LogDetails("Error", "TmacTextChatUI.AVControlMessageReceived()", "Customer has declined your request", true);
                    break;
            }
        }
        else if (event.Type == "bye") {
            DisableAV(intid);
        }
        else if (event.Type == "offer") {
            let isAudioOnly = false;
            if (GetChatReferenceObj(intid).chatMode == "audio") {
                isAudioOnly = true;
                SetTextChatControlVisibility(intid, false, true, true, isChatTransfer, isConference, false, false, true, true,
                    isImmediateCallbackBtn, isVaChatHistoryBtn, false, false, false,false);
                CheckForActiveAV();
                $("#divCustomerName" + intid + " i").html("phone");
            }
            else if (GetChatReferenceObj(intid).chatMode == "video") {
                isAudioOnly = false;
                ShowVideoWindow(intid);
            }
            //create a video channel connection
            vConn = new AVChannel(intid, global_AgentID, global_DeviceID, isAudioOnly, "remoteVideo" + intid);
            //proccess the offer
            vConn.onCommMessage(event.Message);
        }
        else {
            //process video messages [answers, candidates etc.]
            vConn.onCommMessage(event.Message);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AVControlMessageReceived()", ex, false);
    }
}

function AddMessageToChatbox(intid, messageid, message, type, datetime, chatBoxDiv, attachType, isReply, replyJson, labelName) {
    try {
        //check if the message id is empty then create new id
        messageid = messageid == "" ? uuid() : messageid;
        //li tag
        let li = "";
        //html to append
        let html = "";
        //dateTime for the message
        let dateTime = (datetime == "") ? FormatDate(new Date()) : datetime;
        let loader = '<span class="md-preloader" id="loader_' + messageid + '"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="96" width="96" viewBox="0 0 75 75"><circle cx="37.5" cy="37.5" r="33.5" stroke-width="4"></circle></svg></span>';
        //reply icon for every message
        let replyIcon = "";
        //is user/customer name required with the message
        let labelTag = "";
        //generate the agent message div
        if (type == "agent") {
            let li1 = "";
            let li2 = "";
            let chatReplyBox1 = "";
            let chatReplyBox2 = "";
            let replyHighlightDiv = "";
            if (isUserLabel) {
                if (chatBoxType == "outline")
                    labelTag = '<div class="uk-text-bold uk-text-agent-label uk-text-muted">' + labelName + '</div>';
                else
                    labelTag = '<div class="uk-text-bold uk-text-agent-label">' + labelName + '</div>';
            }
            if (isReplyOnChat)
                replyIcon = '<i class="uk-icon-mail-reply reply-icon" onclick="AddReplyBox(\'' + messageid + '\',\'' + intid + '\',\'You\',\'' + chatBoxDiv + '\',\'' + attachType + '\');"></i>';
            switch (attachType) {
                case "image":
                    var imageTag = '<img onclick="PreviewAttachment(\'' + message + '\');" id="img_' + messageid + '" class="attach_img uk-display-none" src="' + message + '"/>';
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_image_' + messageid + '" class="attach_li">' + replyIcon;
                    li2 = '<div class="img-container">' + loader + imageTag + '</div><span class="chat_message_time attach_time_span">' + dateTime + '</span></li>';
                    break;
                case "audio":
                    var audioTag = "<audio preload='true' id='aud_" + messageid + "' controls src='" + message + "'></audio>";
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_audio_' + messageid + '" class="audio_li">' + replyIcon;
                    li2 = '<span>' + audioTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "video":
                    var videoTag = "<video id='vid_" + messageid + "' class='videoTag' controls src='" + message + "'></video>";
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_video_' + messageid + '" class="attach_li">' + replyIcon;
                    li2 = '<span>' + videoTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "others":
                    var splitMessage = message.split('|');//0-name, 1-src
                    var name = splitMessage[0];
                    var src = splitMessage[1];
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_file_' + messageid + '" class="file_li">' + replyIcon;
                    li2 = '<div class="document-body"><a id="file_' + messageid + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a>' +
                        '</div><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "file":
                    var splitMessage = message.split('|');//0-name, 1-src
                    var name = splitMessage[0];
                    var src = splitMessage[1];
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_file_' + messageid + '" class="file_li">' + replyIcon;
                    li2 = '<div class="document-body"><a id="file_' + messageid + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a>' +
                        '</div><span class="chat_message_time">' + dateTime + '</span><i class="uk-icon-expand expand-icon-agent" onclick="PreviewFile(\'' + src + '\')"></i></li>';
                    break;
                default:
                    let tag = "";
                    if (message.indexOf("\\ud83d\\") > -1) {
                        tag = '<img src="../assets/img/glyph/' + message.split('\\')[2] + '.png" width="39" height="39" valign="middle" id="emoji_' + messageid + '">';
                    }
                    else {
                        tag = '<span class="chat-text-span" id="text_' + messageid + '">' + message + '</span>';
                    }
                    li1 = '<li user="agent" username="' + labelName + '" id="li_agent_text_' + messageid + '">' + replyIcon;
                    li2 = tag + '<span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
            }

            if (isReply) {
                chatReplyBox1 = '<div class="chat-reply-box" onclick="GotoThisDiv(\'' + replyJson.replyTextId + '\');"><span class="uk-text-bold uk-text-primary">' + replyJson.replyUser + '</span><br/><span class="uk-text-small-10">';
                chatReplyBox2 = '</span></div>';
                switch (replyJson.replyType) {
                    case "text":
                        replyHighlightDiv = replyJson.replyText;
                        break;
                    case "image":
                        replyHighlightDiv = '<i class="material-icons md-color-white">photo_camera</i> Photo </span><span class="span-reply-img"><img class="reply-img-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "video":
                        replyHighlightDiv = '<i class="material-icons md-color-white">videocam</i> Video </span><span class="span-reply-img"><video class="reply-vid-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "audio":
                        replyHighlightDiv = '<i class="material-icons md-color-white">keyboard_voice</i> ' + replyJson.replyText;
                        break;
                    case "file":
                        replyHighlightDiv = '<i class="material-icons md-color-white">insert_drive_file</i> ' + replyJson.replyText;
                        break;
                }
                replyHighlightDiv = chatReplyBox1 + replyHighlightDiv + chatReplyBox2;
                li = li1 + replyHighlightDiv + li2;
            }
            else
                li = li1 + li2;
            if ($("#" + chatBoxDiv + intid).find("li:last").attr("user") == "agent" && $("#" + chatBoxDiv + intid).find("li:last").attr("username") == labelName) {
                $("#" + chatBoxDiv + intid).find("ul:last").append(li);
                if (chatBoxType == "outline") $("#" + chatBoxDiv + intid).find("ul:last").find(".uk-text-agent-label").addClass("uk-margin-right-15");
            }
            else {
                html = '<div class="chat_message_wrapper chat_message_right uk-animation-fade"><ul class="chat_message' + (chatBoxType == "outline" ? " outline" : "") + '" > ' + li + '</ul ></div > ';
            }
        }
        //generate the customer message div
        else if (type == "customer" || type == "conferenceAgent") {
            let li1 = "";
            let li2 = "";
            let chatReplyBox1 = "";
            let chatReplyBox2 = "";
            let replyHighlightDiv = "";
            if (isUserLabel) {
                if (chatBoxType == "outline")
                    labelTag = '<div class="uk-text-bold uk-text-customer-label ' + (type == "customer" ? "uk-text-muted" : "uk-text-facebook") + '">' + labelName + '</div>';
                else
                    labelTag = '<div class="uk-text-bold uk-text-customer-label ' + type + '">' + labelName + '</div>';
            }
            if (isReplyOnChat)
                replyIcon = '<i class="uk-icon-mail-reply reply-icon" onclick="AddReplyBox(\'' + messageid + '\',\'' + intid + '\',\'Customer\',\'' + chatBoxDiv + '\',\'' + attachType + '\');"></i>';
            switch (attachType) {
                case "image":
                    var imageTag = '<img onclick="PreviewAttachment(\'' + message + '\');" id="img_' + messageid + '" class="attach_img uk-display-none" src="' + message + '"/>';
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_image_' + messageid + '" class="attach_li">' + replyIcon;
                    li2 = '<div class="img-container">' + loader + imageTag + '</div><span class="chat_message_time attach_time_span">' + dateTime + '</span></li>';
                    break;
                case "audio":
                    var audioTag = "<audio preload='true' id='aud_" + messageid + "' controls src='" + message + "'></audio>";
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_audio_' + messageid + '" class="audio_li">' + replyIcon;
                    li2 = '<span>' + audioTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "video":
                    var videoTag = "<video id='vid_" + messageid + "' class='videoTag' controls src='" + message + "'></video>";
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_video_' + messageid + '" class="attach_li">' + replyIcon;
                    li2 = '<span>' + videoTag + '</span><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "others":
                    var splitMessage = message.split('|');//0-name, 1-src
                    var name = splitMessage[0];
                    var src = splitMessage[1];
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_file_' + messageid + '" class="file_li">' + replyIcon;
                    li2 = '<div class="document-body"><a id="file_' + messageid + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a>' +
                        '</div><span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
                case "file":
                    var splitMessage = message.split('|');//0-name, 1-src
                    var name = splitMessage[0];
                    var src = splitMessage[1];
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_file_' + messageid + '" class="file_li">' + replyIcon;
                    li2 = '<div class="document-body"><a id="file_' + messageid + '" class="document-filename" download="' + name + '" href="' + src + '">' + name + '</a>' +
                        '</div><span class="chat_message_time">' + dateTime + '</span><i class="uk-icon-expand expand-icon-customer" onclick="PreviewFile(\'' + src + '\')"></i></li>';
                    break;
                default:
                    let tag = "";
                    if (message.indexOf("\\ud83d\\") > -1) {
                        tag = '<img src="../assets/img/glyph/' + message.split('\\')[2] + '.png" width="39" height="39" valign="middle" id="emoji_' + messageid + '">';
                    }
                    else {
                        tag = '<span class="chat-text-span" id="text_' + messageid + '">' + message + '</span>';
                    }
                    li1 = '<li user="' + type + '" username="' + labelName + '" id="li_customer_text_' + messageid + '">' + replyIcon;
                    li2 = tag + '<span class="chat_message_time">' + dateTime + '</span></li>';
                    break;
            }

            if (isReply) {
                chatReplyBox1 = '<div class="chat-reply-box" onclick="GotoThisDiv(\'' + replyJson.replyTextId + '\');"><span class="uk-text-bold uk-text-primary">' + replyJson.replyUser + '</span><br/><span class="uk-text-small-10">';
                chatReplyBox2 = '</span></div>';
                switch (replyJson.replyType) {
                    case "text":
                        replyHighlightDiv = replyJson.replyText;
                        break;
                    case "image":
                        replyHighlightDiv = '<i class="material-icons md-color-white">photo_camera</i> Photo </span><span class="span-reply-img"><img class="reply-img-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "video":
                        replyHighlightDiv = '<i class="material-icons md-color-white">videocam</i> Video </span><span class="span-reply-img"><video class="reply-vid-tag" src="' + replyJson.replyText + '"/>';
                        break;
                    case "audio":
                        replyHighlightDiv = '<i class="material-icons md-color-white">keyboard_voice</i> ' + replyJson.replyText;
                        break;
                    case "file":
                        replyHighlightDiv = '<i class="material-icons md-color-white">insert_drive_file</i> ' + replyJson.replyText;
                        break;
                }
                replyHighlightDiv = chatReplyBox1 + replyHighlightDiv + chatReplyBox2;
                li = li1 + replyHighlightDiv + li2;
            }
            else
                li = li1 + li2;

            if ($("#" + chatBoxDiv + intid).find("li:last").attr("user") == type && $("#" + chatBoxDiv + intid).find("li:last").attr("username") == labelName) {
                $("#" + chatBoxDiv + intid).find("ul:last").append(li);
                if (chatBoxType == "outline") $("#" + chatBoxDiv + intid).find("ul:last").find(".uk-text-customer-label").addClass("uk-margin-left-15");
            }
            else {
                html = '<div class="chat_message_wrapper uk-animation-fade"><ul class="chat_message' + (chatBoxType == "outline" ? " outline" : "") + '">' + li + '</ul></div>';
            }
        }
        //generate the typing message div
        else if (type === "typing") {
            if (chatBoxType == "outline") {
                let userType = GetChatReferenceObj(intid).typingUser == GetChatReferenceObj(intid).customerName ? "customer" : "agent";
                labelTag = '<div class="uk-text-bold uk-typing-label ' + (userType == "customer" ? "uk-text-muted" : "uk-text-facebook") + '">' + GetChatReferenceObj(intid).typingUser + " typing..." + '</div>';
            }
            html =
                '<div class="chat_message_wrapper uk-animation-fade" id="typing_indicator' + intid + '">' +
                '<ul class="chat_message' + (chatBoxType == "outline" ? " outline" : "") + '">' +
                '<li user="typing" typing="' + GetChatReferenceObj(intid).typingUser + '" id="li_typing_' + messageid + '" class="typing">' +
                '<div class="typing-css"><span></span><span></span><span></span><span></span><span></span></div>' +
                '</li>' +
                '</ul>' +
                '</div>';
        }
        //generate the divider for transfer chat
        else if (type === "divider") {
            html = "<div class='chat_divider uk-animation-fade'><li user='divider'><span class='uk-text-muted'>" + message + "</span></li></div>";
        }
        //generate the divider for transfered chat
        else if (type == "transconf") {
            html = "<div class='chat_divider transconf uk-animation-fade'><li user='divider'><span class='uk-text-facebook'>" + message + "</span></li></div>";
        }
        //generate the divider for transfered chat
        else if (type == "unread") {
            html = "<div class='chat_divider unread uk-margin uk-animation-fade' id='unread_divider" + intid + "'>" +
                "<li user='divider'><span class='uk-text-muted uk-text-bold'>" + message + "</span></li></div>";
        }

        //append the div to chat box
        if (html != "") {
            $("#" + chatBoxDiv + intid).append(html);
            //add agent/customer name on chat box
            if (isUserLabel) {
                if (type == "agent") {
                    if (chatBoxType == "outline")
                        $(labelTag).insertBefore("#li_agent_text_" + messageid);
                    else
                        $("#li_agent_text_" + messageid).prepend(labelTag);
                }
                else if (type == "customer" || type == "conferenceAgent") {
                    if (chatBoxType == "outline")
                        $(labelTag).insertBefore("#li_customer_text_" + messageid);
                    else
                        $("#li_customer_text_" + messageid).prepend(labelTag);
                }
                else if (type == "typing" && chatBoxType == "outline") {
                    $(labelTag).insertBefore("#li_typing_" + messageid);
                }
            }
        }

        //add animation to the li
        if (type == "agent")
            $("#li_agent_text_" + messageid).addClass("uk-animation-scale-up");
        else if (type == "customer" || type == "conferenceAgent")
            $("#li_customer_text_" + messageid).addClass("uk-animation-scale-up");

        //chat box div element
        let elem = document.getElementById(chatBoxDiv + intid);
        //scroll to top after appening the message div
        elem.scrollTop = elem.scrollHeight;
        //show the image after the image is loaded by removing the loader
        if (attachType == "image")
            // main image loaded ?
            $('#img_' + messageid).on('load', function () {
                // hide/remove the loading image
                $('#loader_' + messageid).hide();
                $('#img_' + messageid).show();
                let elem = document.getElementById(chatBoxDiv + intid);
                //scroll to top after appening the message div
                elem.scrollTop = elem.scrollHeight;
            });
        //close reply box if is reply
        if (isReply && type == "agent")
            CloseReplyBox(intid);
        //some margin issue for reply fixed
        if (isReply && attachType != "" && attachType != "audio") {
            $("#" + chatBoxDiv + intid).find(".chat-reply-box:last").css("margin", "0 0 5px 0");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddMessageToChatbox()", ex, false);
    }
}

function AddReplyBox(msgid, intid, who, chatBoxDiv, attachType) {
    try {
        if (!GetChatReferenceObj(intid).isDisconnected) {
            $("#attachPrev" + intid).css("display", "none");
            if (attachType == "") {
                GetChatReferenceObj(intid).replyType = "text";
                GetChatReferenceObj(intid).replyText = $("#text_" + msgid).text();
                GetChatReferenceObj(intid).replyTextId = "#" + $("#text_" + msgid).closest("li")[0].id;
                $("#chat_reply_text" + intid).text(GetChatReferenceObj(intid).replyText);
            }
            else if (attachType == "image") {
                $("#attachPrev" + intid).css("display", "table-cell");
                GetChatReferenceObj(intid).replyType = "image";
                GetChatReferenceObj(intid).replyText = $("#img_" + msgid)[0].src;
                GetChatReferenceObj(intid).replyTextId = "#" + $("#img_" + msgid).closest("li")[0].id;
                $("#chat_reply_text" + intid).html('<i class="material-icons">photo_camera</i> Photo');
                $("#attachPrev" + intid).html("<img class='reply-preview-img' src='" + GetChatReferenceObj(intid).replyText + "'/>");
            }
            else if (attachType == "video") {
                $("#attachPrev" + intid).css("display", "table-cell");
                GetChatReferenceObj(intid).replyType = "video";
                GetChatReferenceObj(intid).replyText = $("#vid_" + msgid)[0].src;
                GetChatReferenceObj(intid).replyTextId = "#" + $("#vid_" + msgid).closest("li")[0].id;
                $("#chat_reply_text" + intid).html('<i class="material-icons">videocam</i> ' + moment(document.getElementById("vid_" + msgid).duration, "ss.SS").format("mm:ss") + ' Video ');
                $("#attachPrev" + intid).html("<video class='reply-preview-vid' src='" + GetChatReferenceObj(intid).replyText + "'/>");
            }
            else if (attachType == "audio") {
                GetChatReferenceObj(intid).replyType = "audio";
                GetChatReferenceObj(intid).replyText = moment(document.getElementById("aud_" + msgid).duration, "ss.SS").format("mm:ss");
                GetChatReferenceObj(intid).replyTextId = "#" + $("#aud_" + msgid).closest("li")[0].id;
                $("#chat_reply_text" + intid).html('<i class="material-icons">keyboard_voice</i> ' + moment(document.getElementById("aud_" + msgid).duration, "ss.SS").format("mm:ss"));
            }
            else if (attachType == "others") {
                GetChatReferenceObj(intid).replyType = "file";
                GetChatReferenceObj(intid).replyText = $("#file_" + msgid).text();
                GetChatReferenceObj(intid).replyTextId = "#" + $("#file_" + msgid).closest("li")[0].id;
                $("#chat_reply_text" + intid).html('<i class="material-icons">insert_drive_file</i> ' + GetChatReferenceObj(intid).replyText);
            }
            $("#chat_reply_head" + intid).text(who);
            GetChatReferenceObj(intid).replyUser = who;
            $("#div_chat_box_wrapper" + intid).addClass("chat_box_wrapper_reply");
            $("#chat_reply_box" + intid).removeClass("uk-display-none");

            $("#textChatMessage" + intid).focus();
            $("#textChatMessage" + intid).focus();
        }
    } catch (ex) {

    }
}

function CloseReplyBox(intid) {
    GetChatReferenceObj(intid).replyText = "";
    GetChatReferenceObj(intid).replyUser = "";
    GetChatReferenceObj(intid).replyType = "";
    GetChatReferenceObj(intid).replyTextId = "";
    $("#div_chat_box_wrapper" + intid).removeClass("chat_box_wrapper_reply");
    $("#chat_reply_box" + intid).addClass("uk-display-none");
    $("#attachPrev" + intid).css("display", "none");
}

function GotoThisDiv(id) {
    // Scroll
    var offSetTop = $(id).height() + 10;
    $("#divTxtChatTranscript" + global_activeTabInteractionID).scrollTo(id, 500, { offset: { top: -offSetTop } });
    setTimeout(function () {
        $(id).addClass("uk-animation-shake");
        setTimeout(function () {
            $(id).removeClass("uk-animation-shake");
        }, 1000);
    }, 500);
}

function AddTypingDiv(intid) {
    try {
        if ($("#typing_indicator" + intid).length == 0) {
            //add typing div to the chat box
            AddMessageToChatbox(intid, uuid(), "", "typing", "", "divTxtChatTranscript", "", false, "", "");
            $("#typing_span" + intid).text(GetChatReferenceObj(intid).typingUser + " typing...");
        }
        else {
            if (chatBoxType == "outline" && $("#divTxtChatTranscript" + intid).find("li:last").attr("typing") != GetChatReferenceObj(intid).typingUser) {
                let userType = GetChatReferenceObj(intid).typingUser == GetChatReferenceObj(intid).customerName ? "customer" : "agent";
                $("#divTxtChatTranscript" + intid).find("ul:last").find(".uk-typing-label").text(GetChatReferenceObj(intid).typingUser + " typing...");
                //$("#divTxtChatTranscript" + intid).find("ul:last").find(".uk-typing-label").removeClass();
                //$("#divTxtChatTranscript" + intid).find("ul:last").find(".uk-typing-label").addClass("uk-text-bold uk-typing-label " + (userType == "customer" ? "uk-text-muted" : "uk-text-facebook"));
            }
            $("#typing_span" + intid).text(GetChatReferenceObj(intid).typingUser + " typing...");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddTypingDiv()", ex, false);
    }
}

function RemoveTypingDiv(intid) {
    try {
        //remove the typing div
        $("#typing_indicator" + intid).remove();
        $("#typing_span" + intid).text("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.RemoveTypingDiv()", ex, false);
    }
}

function CheckForHyperlinks(intid, message, flag) {
    try {
        //initialise http and www variable
        var http, www, hyperLink, returnMessage = "";
        //new message array
        var newMessageArray = [];
        //split the message on 'space'
        var splitMessage = message.split(/ |\n/);
        //foreach split message
        $.each(splitMessage, function (i, val) {
            //clear hyperLink
            hyperLink = "";
            //if text in split text is not blank
            if (val !== "") {
                //check for http in the text
                http = val.indexOf("http");
                //if http is not there in the text
                if (http < 0) {
                    //check for www. in the text
                    www = val.indexOf("www.");
                    //www. is there in the text
                    if (www >= 0) {
                        //text has hyperlink starts with www. and push it to hyperlink array
                        hyperLink = '<a href="https://' + val + '" target="_blank">' + val + '</a>\n';
                        if (flag) AddLinkToArray(intid, hyperLink);
                    }
                    //http is there in text
                } else {
                    //text has hyperlink starts with http and push it to hyperlink array
                    hyperLink = '<a href="' + val + '" target="_blank">' + val + '</a>\n';
                    if (flag) AddLinkToArray(intid, hyperLink);
                }
            }
            hyperLink == "" ? newMessageArray.push(val) : newMessageArray.push(hyperLink);
        });
        $.each(newMessageArray, function (i, val) {
            returnMessage += val + " ";
        });
        return $.trim(returnMessage);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CheckForHyperlinks()", ex, false);
    }
    return message;
}

function AddLinkToArray(intid, val) {
    try {
        GetChatReferenceObj(intid).hyperLinks.push(val);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AddLinkToArray()", ex, false);
    }
}

function TextChatWaitTimerEvent(event) {
    try {
        let intid = event.InteractionID;
        //check if this current chat is disconnected
        if (!GetChatReferenceObj(intid).isDisconnected && GetChatReferenceObj(intid).chatMode == "text") {
            GetChatReferenceObj(intid).isAgent = true;
            //get the message template to be sent to customer
            let message = event.AutoResponseTemplate;
            let msgid = uuid();
            if (isAppMessage) {
                let obj = {};
                obj.id = msgid;
                obj.message = message;
                obj.messageType = "text";
                obj.type = "new";
                message = JSON.stringify(obj);
            }
            //send the message to the server
            SendTextChat(global_DeviceID, intid, message);
            //if agent send chat while the customer is typing remove the customer typing div and add it after agent text
            if (GetChatReferenceObj(intid).isTyping)
                RemoveTypingDiv(intid);
            //add the message div to the chatbox
            AddMessageToChatbox(intid, msgid, message, "agent", "", "divTxtChatTranscript", "", false, "", global_AgentName.split(' ')[0]);
            //if this is the final auto response then disconnect the chat
            if (event.IsFinal) {
                EndChat(intid, "Auto response timeout");
            }
            else {
                //add the customer typing div
                if (GetChatReferenceObj(intid).isTyping)
                    AddTypingDiv(intid);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.TextChatWaitTimerEvent()", ex, false);
    }
}

function EndChat(intid, reason) {
    try {
        var message = "";
        //hyperlinks to server
        $.each(GetChatReferenceObj(intid).hyperLinks, function (i, val) {
            message += val + "\n";
        });
        //if message not empty
        if (message !== "" && sendAllLinksToCustomer) {
            console.log("Hyperlinks");
            console.log(GetChatReferenceObj(intid).hyperLinks);
            let msgid = uuid();
            if (isAppMessage) {
                var obj = {};
                obj.id = msgid;
                obj.message = message;
                obj.messageType = "text";
                obj.type = "new";
                message = JSON.stringify(obj);
            }
            //send the message to server
            SendTextChat(global_DeviceID, intid, "Below are the links shared during conversation \n" + message);
        }
        global_endTextChatNotification[intid] = true;
        DisableButton("#btnTextChat_Disconnect" + intid);
        //if video/audio call is enabled and is going on then close the session
        if (isVideoCall && GetChatReferenceObj(intid).chatMode != "text")
            CloseAVConnection(intid, "local");
        EndTextChat(global_DeviceID, intid, false, reason == undefined ? "AgentChatDisconnected" : reason);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.EndChat()", ex, false);
    }
}

function CloseAVConnection(intid, type) {
    try {
        DisableAV(intid);
        //if (type == "local")
        vConn.close();
        //else
        //    vConn.handleBye();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CloseAVConnection()", ex, false);
    }
}

function submitTextChatCallbackRequest() {
    try {
        var number = $.trim($("#textChatPreferredNumber").val());
        if (number === "") {
            ShowNotify("Number cannot be empty", "danger", null, "top-center");
            return false;
        }

        var hasWhiteSpaces = /\s/.test(number);
        var regex = /[^\w\s]/gi;
        var regexChars = /^[a-zA-Z]/;
        var hasSpecialChars = regex.test(number);
        var hasChars = regexChars.test(number);
        var isNotANumber = isNaN(number);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid Number, Please provide a valid number", "danger", null, "top-center");
            return;
        }
        //end current chat
        //EndTextChat(global_DeviceID, global_TextChatCallbackID, true);

        RegisterTextChatCallback(global_DeviceID, global_TextChatCallbackID, number, "");
        $("#callback_dialog").data("kendoWindow").close();
        //close the chat tab
        //CloseUITab(global_TextChatCallbackID, "");
        //CloseTab(global_DeviceID,global_TextChatCallbackID);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.submitTextChatCallbackRequest()", ex, false);
    }
}

function SubmitTextChatScheduleCallbackRequest() {
    try {
        var number = $.trim($("#textScheduleChatPreferredNumber").val());

        if (number === "") {
            ShowNotify("Number cannot be empty", "danger", null, "top-center");
            return false;
        }
        if ($.trim($("#chatcallbackScheduleRequestDate").val()) === "") {
            ShowNotify("Callback date cannot be empty", "danger", null, "top-center");
            return false;
        }
        if ($.trim($("#chatcallbackScheduleRequestTime").val()) === "") {
            ShowNotify("Callback time cannot be empty", "danger", null, "top-center");
            return false;
        }

        var re = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;

        if (!re.test($("#chatcallbackScheduleRequestTime").val())) {
            ShowNotify("Please enter a valid time", "danger", null, "top-center");
            return false;
        }

        var hasWhiteSpaces = /\s/.test(number);
        var regex = /[^\w\s]/gi;
        var regexChars = /^[a-zA-Z]/;
        var hasSpecialChars = regex.test(number);
        var hasChars = regexChars.test(number);
        var isNotANumber = isNaN(number);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }

        //commandManager.js
        var intid = global_TextChatScheduleCallbackID;
        var startDate = $("#chatcallbackScheduleRequestDate").val();
        var yearone = startDate.substring(0, 4);
        var monthone = startDate.substring(5, 7);
        var dayone = startDate.substring(8, 10);
        var time = $("#chatcallbackScheduleRequestTime").val();
        var hour = time.split(":")[0];
        var min = time.split(":")[1];
        var newstartdate = new Date(yearone, monthone - 1, dayone, hour, min, "00");
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();

        var callbackDate = yearone + monthone + dayone;

        if (newstartdate < today) {
            ShowNotify("Callback datetime should be greater than today", "danger", null, "top-center");
            return false;
        }
        //removed from the new UI
        var lang = "EN";
        var segment = $("#textChatSegment" + intid).val();
        var subsegment = $("#textChatSubSegment" + intid).val();
        var intent = $("#textChatIntent" + intid).val();
        var custEntType = $("#hfTextChatCustEntType" + intid).val();

        //commandManager.js
        custom_submit('Callback',
            $("#hfTextChatUCID" + intid).val(),
            "",
            "",
            startDate,
            hour,
            min,
            lang + ":" + segment + ":" + subsegment + ":" + intent + ":" + custEntType,
            intid,
            $("#textScheduleChatPreferredNumber").val(),
            global_AgentID,
            $("#hfTextChatCIF" + intid).val(),
            callbackDate,
            hour + min + "00",
            globalConfig_DigibankCallbackType,
            "");

        $("#schedule_callback_dialog").data("kendoWindow").close();

        // Reset the Value back to Empty;
        $("#textScheduleChatPreferredNumber").val("");
        $("#textChatPreferredNumber").val("");
        $("#chatcallbackScheduleRequestDate").val("");
        $("#chatcallbackScheduleRequestTime").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SubmitTextChatScheduleCallbackRequest()", ex, false);
    }
}

function OpenTextChatCallbackDialog(intid) {
    try {
        global_TextChatCallbackID = intid;
        $("#callback_dialog").data("kendoWindow").center().open();
        var prefNumber = $("#hfRegPhone" + intid).val();
        $("#textChatPreferredNumber").val(prefNumber);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatCallbackDialog()", ex, false);
    }
}

function OpenTextChatScheduleCallbackDialog(intid) {
    try {
        global_TextChatScheduleCallbackID = intid;
        var prefNumber = $("#hfRegPhone" + intid).val();
        $("#textScheduleChatPreferredNumber").val(prefNumber);
        $("#schedule_callback_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatScheduleCallbackDialog()", ex, false);
    }
}

function TextcChatFailure(data) {
    //alert the error
    ShowNotify(data.ErrorDescription, "danger", null, "top-center");
}

function SetTextChatControlVisibility(intid, answer, send, drop, transfer, conference, audioEscalate,
    videoEscalate, muteAudio, chatTemplate, callback, vaHistory, chatCallbackSchedule, chatbox, tabClose, requestCallback) {
    try {
        $('#btnTextChat_Answer' + intid).toggle(answer);
        $('#btnTextChat_Disconnect' + intid).toggle(drop);
        $('#btnTextChat_Transfer' + intid).toggle(transfer);
        $('#btnTextChat_Conference' + intid).toggle(conference);
        $('#btnTextChat_LoadVAChatHistory' + intid).toggle(vaHistory);
        $('#btnTextChat_ChatTemplate' + intid).toggle(chatTemplate);
        $('#btnTextChat_AudioEscalate' + intid).toggle(audioEscalate);
        $('#btnTextChat_AudioMute' + intid).toggle(muteAudio);
        $('#btnTextChat_VideoEscalate' + intid).toggle(videoEscalate);
        $('#btnTextChat_Callback' + intid).toggle(callback);
        $("#btnTextChat_CallbackSchedule" + intid).toggle(chatCallbackSchedule);
		$("#btnTextChat_FreezeAutoResponse" + intid).toggle(false);
		$("#btnTextChat_RMCallback" + intid).toggle(requestCallback);
        if (!send) {
            $('#chat_submit_box' + intid).parent().css("pointer-events", "none");
            $('#chat_submit_box' + intid).css("opacity", "0.5");
        }
        else {
            setTimeout(function () {
                $("#textChatMessage" + intid).focus();
                $("#textChatMessage" + intid).focus();
            }, 500);
            $('#chat_submit_box' + intid).parent().css("pointer-events", "all");
            $('#chat_submit_box' + intid).css("opacity", "1");
        }
        if (tabClose === true) {
            EnableTabCloseButton(intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SetTextChatControlVisibility()", ex, false);
    }
}

function OpenTextChatTransferDialog(intid) {
    try {
        EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
        EnableButton("#btndialogblindtransfercall", "BT", "tag");
        GetTmacWallboardSkills();
        DisableButton("#btnTextChat_Transfer" + intid);
        GetAgentListStaffed(intid, "transferCall", "#btnTextChat_Transfer" + intid, "forward");
        global_transferIntID = intid;
        //transfer type is changed to textchat
        global_CallType = "TextChatTransfer";
        //disable transfer number textbox for chat as we need to select agent from grid
        $("#txtNumberTrans").attr("readonly", "readonly");
        //select the first agent list tab
        $("#tabstrip_transfer").data("kendoTabStrip").select(0);
        $("#transfer_dialog").data("kendoWindow").title("Transfer Chat List");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatTransferDialog()", ex, false);
    }
}

function OpenTextChatConfDialog(intid) {
    try {
        EnableButton("#btnConfMCall", "call_split", "icon");
        GetAgentListStaffed(intid, "conferenceCall", "#btnTextChat_Conference" + intid, "group");
        DisableButton("#btnTextChat_Conference" + intid);
        global_conferenceIntID = intid;
        global_CallType = "TextChatConference";
        //disable conference number textbox for chat as we need to select agent from grid
        $("#txtNumberConf").attr("readonly", "readonly");
        $("#conference_dialog").data("kendoWindow").title("Conference Chat List");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatTransferDialog()", ex, false);
    }
}

function GetResponseFromAgent(event) {
    try {
        let otherData = JSON.parse(event.Data);
        let comment = "",
            s = $("#notification_confirm_template").html(),
            t = Handlebars.compile(s),
            context = {
                agent: event.FromAgentName,
                type: (otherData.type == "conf" ? "conference" : "transfer"),
                mode: otherData.mode,
                deviceid: global_DeviceID,
                isComment: event.Comment != "" ? true : false,
                comment: event.Comment,
                showComment: isCommentOnConfirmaion
            },
            html = t(context);

        UIkit.modal.confirm(html,
            function () {
                if (isCommentOnConfirmaion)
                    comment = $("#comment_on_confirmation").val().trim();
                SendTextChatTransferNotificationRespond(event.FromTmacServer, event.FromAgentID, event.FromInteractionID, "Accept", comment, event.Data);
            },
            function oncancel() {
                if (isCommentOnConfirmaion)
                    comment = $("#comment_on_confirmation").val().trim();
                SendTextChatTransferNotificationRespond(event.FromTmacServer, event.FromAgentID, event.FromInteractionID, "Reject", comment, event.Data);
            });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetResponseFromAgent()", ex, false);
    }
}

function OpenTextChatChatTemplatesDialog(intid) {
    try {
        //$("#ChatTemplatesDialog").dialog("open");
        //custom_LoadChatTemplates(intid);
        OpenChatTemplate(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenTextChatChatTemplatesDialog()", ex, false);
    }
}

function GetTextChatCallbackDetails(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        //get details based on the session id from the table
        custom_getdetailsforUCID(parse.srno, parse.sessionid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetTextChatCallbackDetails()", ex, false);
    }
}

function OpenBargeInDialog() {
    try {
        $("#barge_in_dialog").data("kendoWindow").center().open();
        GetTextChatAgentListForBargein("", "");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenBargeInDialog()", ex, false);
    }
}

function BargeInDisplay(txt, intid, AgentID, isCustomer) {
    try {
        let msgid = uuid();
        let msgDateTime = FormatDate(new Date());
        if (isCustomer) {
            AddMessageToChatbox("", msgid, txt, "customer", msgDateTime, "bargeinchatTranscript", "", false, "", "Customer");
        } else {
            AddMessageToChatbox("", msgid, txt, "agent", msgDateTime, "bargeinchatTranscript", "", false, "", "Agent");
        }
        var elem = document.getElementById('bargeinchatTranscript');
        elem.scrollTop = elem.scrollHeight;
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.BargeInDisplay()", ex, false);
    }
}

function DisplayTextTranscript(event) {
    try {
        var intid = event.InteractionID;
        for (var i = 0; i < event.Transcript.length; i++) {
            let msgid = event.Transcript[i].Id;
            let msg = event.Transcript[i].Message;
            let agentName = event.Transcript[i].AgentName.split(' ')[0];
            let agentid = event.Transcript[i].AgentID;
            let customerName = GetChatReferenceObj(intid).customerName;
            let msgDateTime = moment(event.Transcript[i].DateTime,"DD/MM/YYYY HH:mm:ss").add(-2,"hours").add(-30,"minutes").format("DD/MM/YYYY hh:mma");
            if (event.Transcript[i].Type.toLowerCase() == "agent") {
                AddMessageToChatbox(intid, msgid, msg, "agent", msgDateTime, "divTxtChatTranscript", "", false, "", agentName);
            }
            else if (event.Transcript[i].Type.toLowerCase() == "user") {
                AddMessageToChatbox(intid, msgid, msg, "customer", msgDateTime, "divTxtChatTranscript", "", false, "", customerName);
            }
            else {
                AddMessageToChatbox(intid, msgid, msg + " <b>" + agentName + " : " + agentid + "</b>", "transconf", "", "divTxtChatTranscript", "", false, "", "");
            }
        }
        AddMessageToChatbox(intid, "", "Previous agent's conversation", "divider", "", "divTxtChatTranscript", "", false, "", "");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.DisplayTextTranscript()", ex, false);
    }
}

function LoadCIF(intid, ucid) {
    //customCommands.js
    custom_LoadCIF(intid, ucid);
}

function loadCIFValue(event) {
    var parse = JSON.parse(event.JsonData);
    //custom_UpdateInteractionHistory(parse.sessionid, "", "", "", "", parse.detail, "Callback-Start", "In", "Chat", parse.sessionid, "Callback", global_AgentID);
}

function loadUCIDChatToCallback(event) {
    var parse = JSON.parse(event.JsonData);
    custom_UpdateChatToCallback(event.InteractionID, parse.detail, parse.sessionid);

}

function updateUCIDChatToCallback(event) {
    //do nothing

}

function GetTextChatData(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        var callbackExist = parse.detail;
        if (callbackExist) {
            global_hasgetDataEventDetails = true;
            global_voiceCallHasCallback = true;
            global_ExistingCallbackForCustomerTabId = global_ExistingCallbackForCustomerTabId + 1;
            custom_getdetailsforCIF(global_ExistingCallbackForCustomerTabId, parse.srno);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetTextChatData()", ex, false);
    }
}

function SubmitMultipleTextChatCallbackSchedule() {
    try {
        var number = $.trim($("#multipleCallbackSchedulePrefNumber").val());
        if (number === "") {
            ShowNotify("Number cannot be empty", "danger", null, "top-center");
            return false;
        }
        if ($.trim($("#multipleCallbackScheduleDate").val()) === "") {
            ShowNotify("Callback date cannot be empty", "danger", null, "top-center");
            return false;
        }

        if ($("#multipleCallbackScheduleTime").val() === "") {
            ShowNotify("Callback time cannot be empty", "danger", null, "top-center");
            return false;
        }

        var re = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;

        if (!re.test($("#multipleCallbackScheduleTime").val())) {
            ShowNotify("Please enter a valid time", "danger", null, "top-center");
            return false;
        }

        //commandManager.js
        var hasWhiteSpaces = /\s/.test(number);
        var regex = /[^\w\s]/gi;
        var regexChars = /^[a-zA-Z]/;
        var hasSpecialChars = regex.test(number);
        var hasChars = regexChars.test(number);
        var isNotANumber = isNaN(number);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid Number, Please provide a valid number", "danger", null, "top-center");
            return;
        }

        var intid = global_activeTabInteractionID;
        var startDate = $("#multipleCallbackScheduleDate").val();
        var yearone = startDate.substring(0, 4);
        var monthone = startDate.substring(5, 7);
        var dayone = startDate.substring(8, 10);
        var time = $("#multipleCallbackScheduleTime").val().split(':');
        var hour = time[0];
        var min = time[1];
        var newstartdate = new Date(yearone, monthone - 1, dayone, hour, min, "00");
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();

        if (newstartdate < today) {
            ShowNotify("Callback datetime should be greater than today", "danger", null, "top-center");
            return false;
        }

        var callbackDate = yearone + monthone + dayone;
        var comments = $('#txtComments' + intid).val();
        //commandManager.js
        custom_submitMultipleScheduleCallback('Callback', $("#hfmultipleCallbackScheduleRequestSrno").val(), startDate, hour, min, intid,
            callbackDate, hour + min + "00", $("#hfmultipleCallbackScheduleRequestType").val(), $("#multipleCallbackSchedulePrefNumber").val(),
            $("#hfmultipleCallbackScheduleRowId").val(), comments);
        $("#schedule_multiple_callback_dialog").data("kendoWindow").close();
        // Reset the Value back to Empty;
        $("#multipleCallbackSchedulePrefNumber").val("");
        $("#hfmultipleCallbackScheduleRequestSrno").val("");
        $("#hfmultipleCallbackScheduleRequestType").val("");
        $("#hfmultipleCallbackScheduleRowId").val("");
        $("#textChatPreferredNumber").val("");
        $("#multipleCallbackScheduleDate").val("");
        $("#multipleCallbackScheduleTime").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SubmitMultipleTextChatCallbackSchedule()", ex, false);
    }
}

function OpenChatTemplate(intId) {
    try {
        CreateChatTemplateGrid("");
        tempIntIdForChatTemplate = intId;
        GetChatTemplateDepartments();
        $("#chat_template_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenChatTemplate()", ex, false);
    }
}

function CloseAllChatDialogs() {
    try {
        $("#chat_template_dialog").data("kendoWindow").close();
        $("#close_callback_dialog").data("kendoWindow").close();
        $("#callback_detail_dialog").data("kendoWindow").close();
        $("#callback_dialog").data("kendoWindow").close();
        $("#va_history_request_dialog").data("kendoWindow").close();
        $("#schedule_multiple_callback_dialog").data("kendoWindow").close();
        $("#schedule_callback_dialog").data("kendoWindow").close();
        $("#confirm_dialog").data("kendoWindow").close();
        $("#conference_dialog").data("kendoWindow").close();
        $("#transfer_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CloseAllChatDialogs()", ex, false);
    }
}

function ChatTemplateDialogClose(arg) {
    try {
        var $kendoComboBox1 = $('#chat_dept_combobox').data('kendoComboBox');
        $kendoComboBox1.enable(false);
        $kendoComboBox1.value("");
        $kendoComboBox1.dataSource.data("");

        var $kendoComboBox2 = $('#chat_grp_combobox').data('kendoComboBox');
        $kendoComboBox2.enable(false);
        $kendoComboBox2.value("");
        $kendoComboBox2.dataSource.data("");

        $('#chat_template_grid').data('kendoGrid').dataSource.data([]);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ChatTemplateDialogClose()", ex, false);
    }
}

function LoadAllChatTempaltes() {
    try {
        tmac_SMS_GetSMSTemplateDepartments("GetAllChatTemplateDepartmentsDone", null);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.LoadAllChatTempaltes()", ex, false);
    }
}

function GetChatTemplateDepartments() {
    tmac_SMS_GetSMSTemplateDepartments("GetChatTemplateDepartmentsDone", null);
}

function GetChatTemplateDepartmentsDone(data) {
    try {
        var $kendoComboBox = $('#chat_dept_combobox').data('kendoComboBox');
        $kendoComboBox.enable();
        $kendoComboBox.dataSource.data(data);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetChatTemplateDepartmentsDone()", ex, false);
    }
}

function CreateGridComboBoxes(data) {
    try {
        //chat template department dropdown
        $("#chat_dept_combobox").kendoComboBox({
            dataTextField: "Name",
            dataValueField: "ID",
            placeholder: "Departments",
            filter: "contains",
            suggest: true,
            index: 1,
            enable: false,
            change: OnChatDeptChange,
            select: OnChatDeptSelect
        });

        $("#chat_grp_combobox").kendoComboBox({
            dataTextField: "Name",
            dataValueField: "ID",
            placeholder: "Groups",
            filter: "contains",
            suggest: true,
            index: 1,
            enable: false,
            change: OnChatGrpChange,
            select: OnChatGrpSelect
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CreateGridComboBoxes()", ex, false);
    }
}

function OnChatDeptChange() {
    try {
        var $kendoComboBox = $('#chat_grp_combobox').data('kendoComboBox');
        $kendoComboBox.enable(false);
        $kendoComboBox.value("");
        $kendoComboBox.dataSource.data("");

        $('#chat_template_grid').data('kendoGrid').dataSource.data([]);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OnChatDeptChange()", ex, false);
    }
}

function OnChatDeptSelect(arg) {
    try {
        var dataItem = this.dataItem(arg.item);
        var deptId = dataItem.ID;
        tmac_SMS_GetSMSTemplateGroups("GetChatTemplateGroupsDone", null, deptId);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OnChatDeptSelect()", ex, false);
    }
}

function GetChatTemplateGroupsDone(data) {
    try {
        setTimeout(function () {
            var $kendoComboBox = $('#chat_grp_combobox').data('kendoComboBox');
            $kendoComboBox.enable();
            $kendoComboBox.dataSource.data(data);
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetChatTemplateGroupsDone()", ex, false);
    }
}

function OnChatGrpChange() {
    try {
        $('#chat_template_grid').data('kendoGrid').dataSource.data([]);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OnChatGrpChange()", ex, false);
    }
}

function OnChatGrpSelect(arg) {
    try {
        var dataItem = this.dataItem(arg.item);
        var grpId = dataItem.ID;
        if (grpId !== "Groups")
            tmac_SMS_GetSMSTemplates("GetChatTemplatesDone", null, grpId);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OnChatGrpSelect()", ex, false);
    }
}

function GetChatTemplatesDone(data) {
    try {
        let templates = [];
        $.each(data, function (i, val) {
            if (isTemplateTimeFilter && val.StartTime != "" && val.StartTime != null && val.EndTime != "" && val.EndTime != null) {
                let format = "HH:mm:ss",
                    time = moment(new Date(), format),
                    beforeTime = moment(val.StartTime, format),
                    afterTime = moment(val.EndTime, format);
                if (time.isBetween(beforeTime, afterTime))
                    templates.push({ ID: val.ID, Text: val.Text });
            }
            else
                templates.push({ ID: val.ID, Text: val.Text });
        });
        setTimeout(function () {
            $('#chat_template_grid').data('kendoGrid').dataSource.data(templates);
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetChatTemplatesDone()", ex, false);
    }
}

function GetAllChatTemplateDepartmentsDone(data) {
    try {
        $.each(data, function (i, val) {
            tmac_SMS_GetSMSTemplateGroups("GetAllChatTemplateGroupsDone", null, val.ID);
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetAllChatTemplateDepartmentsDone()", ex, false);
    }
}

function GetAllChatTemplateGroupsDone(data) {
    try {
        $.each(data, function (i, val) {
            tmac_SMS_GetSMSTemplates("GetAllChatTemplatesDone", null, val.ID);
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetAllChatTemplateGroupsDone()", ex, false);
    }
}

function GetAllChatTemplatesDone(data) {
    try {
        $.each(data, function (i, val) {
            if (isTemplateTimeFilter && val.StartTime != "" && val.StartTime != null && val.EndTime != "" && val.EndTime != null) {
                let format = "HH:mm:ss",
                    time = moment(new Date(), format),
                    beforeTime = moment(val.StartTime, format),
                    afterTime = moment(val.EndTime, format);
                if (time.isBetween(beforeTime, afterTime))
                    allChatTemplates.push({ ID: val.ID, Text: val.Text });
            }
            else
                allChatTemplates.push({ ID: val.ID, Text: val.Text });
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetAllChatTemplatesDone()", ex, false);
    }
}

function TextChatCSATSurvey(event) {
    var parse = JSON.parse(event.JsonData);
    $("#hfCsatUrl" + event.InteractionID).val(parse.SurveyMsg);
}

function InitiateCsatSurvey(data) {
    try {
        var parse = JSON.parse(data.JsonData);
        var value = parse.eCin;
        var arr = [];
        arr = value.split('/');
        var cin = arr[0]; // Customer CIN
        var cinSuffix = arr[1]; // Customer CIN Suffix
        value = parse.eCustSeg;
        arr = value.split('/');
        var custSeg = arr[0]; // Customer segment
        var intent = parse.pTopic;
        var channel = parse.pChannel;
        var brand = parse.pBranding;
        custom_TextChatCsatSurvey(data.InteractionID, data.TextChatSessionID, custSeg, global_LanID, cin, cinSuffix, intent, channel, brand);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.InitiateCsatSurvey()", ex, false);
    }
}

function OpenNewChatWindow() {
    try {
        $("#start_chat_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenNewChatWindow()", ex, false);
    }
}

function InitNewChat() {
    try {
        var obj = {};
        obj.nric = $.trim($("#txtChatNRIC").val());
        obj.salute = $.trim($("#txtChatSalutation").val());
        obj.name = $.trim($("#txtChatName").val());
        obj.phone = $.trim($("#txtChatPhone").val());
        obj.email = $.trim($("#txtChatEmail").val());

        if (obj.name == "") {
            ShowNotify("Please provide customer name", "danger", null, "top-center");
            return;
        }
        else if (obj.name == "") {
            ShowNotify("Please provide customer name", "danger", null, "top-center");
            return;
        }

        tmac_StartTextChatFromAgent("InitNewChatDone", null, obj.nric, global_AgentID, obj.salute, obj.name, obj.phone, obj.email);
        let isExist = false;
        $.each(dummyCustomerList, function (i, val) {
            if (obj.nric === val.nric && obj.name === val.name) {
                isExist = true;
                return;
            }
        });
        if (!isExist) {
            dummyCustomerList.push(obj);
            customer_chat.get_customerlist();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.InitNewChat()", ex, false);
    }
}

function InitNewChatDone(data, obj) {
    try {
        $("#start_chat_dialog").data("kendoWindow").close();
        $("#txtChatNRIC").val("");
        $("#txtChatSalutation").val("");
        $("#txtChatName").val("");
        $("#txtChatPhone").val("");
        $("#txtChatEmail").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.InitNewChatDone()", ex, false);
    }
}

function SendAVRequest(intid, type) {
    try {
        let data = {};
        data.type = "requestav";
        data.param = type;
        let msg = JSON.stringify(data);
        SendAVControlMessage(global_DeviceID, intid, msg, "requestav");
        if (data.param == "audio")
            FadeOutButton("#btnTextChat_AudioEscalate" + intid);
        else
            FadeOutButton("#btnTextChat_VideoEscalate" + intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.SendAVRequest()", ex, false);
    }
}

function AudioEscalate(intid) {
    try {
        //create a audio channel connection
        vConn = new AVChannel(intid, global_AgentID, global_DeviceID, true, "remoteVideo" + intid);
        //set chat mode
        GetChatReferenceObj(intid).chatMode = "audio";
        //change the icon to phone
        $("#divCustomerName" + intid + " i").html("phone");
			 SetTextChatControlVisibility(intid, false, true, true, isChatTransfer, isConference,
					  false, false, true, true, isImmediateCallbackBtn, isVaChatHistoryBtn, false, false, false, isRequestCallbackBtn);
        CheckForActiveAV();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AudioEscalate()", ex, false);
    }
}

function VideoEscalate(intid) {
    try {
        //create a video channel connection
        vConn = new AVChannel(intid, global_AgentID, global_DeviceID, false, "remoteVideo" + intid);
        //show agent/customer video window
        ShowVideoWindow(intid);
        //set text chat controls
			 SetTextChatControlVisibility(intid, false, true, true, isChatTransfer, isConference,
					  false, false, false, true, isImmediateCallbackBtn, isVaChatHistoryBtn, false, false, false, isRequestCallbackBtn);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.AudioEscalate()", ex, false);
    }
}

function ShowVideoWindow(intid) {
    try {
        //expand tmac on config
        if (isExpandCollapseOnVideoChat)
            window.resizeTo(screen.width, screen.height);
        $("#chatDetailsDiv" + intid).removeClass("uk-width-large-1-1 uk-width-medium-1-1");
        $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-2 uk-width-medium-1-1");
        $("#videoCallDiv" + intid).removeClass("uk-display-none");
        //change the icon to phone
        $("#divCustomerName" + intid + " i").html("video_call");
        GetChatReferenceObj(intid).chatMode = "video";
        CheckForActiveAV();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.ShowVideoWindow()", ex, false);
    }
}

function MuteIPAudio(intid, type) {
    try {
        let btn = "";
        let msg = {};
        let value = "";
        if (type == "av")
            btn = "#btnMuteAudio";
        else
            btn = "#btnTextChat_AudioMute";
        if ($(btn + intid).hasClass("muted")) {
            $(btn + intid).removeClass("muted");
            $(btn + intid).removeClass("md-btn-success");
            $(btn + intid).addClass("md-btn-danger");
            $(btn + intid).attr("title", "Mute Audio");
            vConn.unMute(true, false);
            value = "unmuteaudio";
        }
        else {
            $(btn + intid).addClass("muted");
            $(btn + intid).removeClass("md-btn-danger");
            $(btn + intid).addClass("md-btn-success");
            $(btn + intid).attr("title", "UnMute Audio");
            vConn.mute(true, false);
            value = "muteaudio";
        }
        msg.type = "avcontrol";
        msg.value = value;
        msg = JSON.stringify(msg);
        SendAVControlMessage(global_DeviceID, intid, msg, "avcontrol");
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.MuteIPAudio()", ex, false);
    }
}

function MuteIPVideo(intid) {
    try {
        if ($("#btnMuteVideo" + intid).hasClass("muted")) {
            $("#btnMuteVideo" + intid).removeClass("muted");
            $("#btnMuteVideo" + intid).removeClass("md-btn-success");
            $("#btnMuteVideo" + intid).addClass("md-btn-danger");
            $("#btnMuteVideo" + intid).attr("title", "Mute Video");
            vConn.unMute(false, true);
        }
        else {
            $("#btnMuteVideo" + intid).addClass("muted");
            $("#btnMuteVideo" + intid).removeClass("md-btn-danger");
            $("#btnMuteVideo" + intid).addClass("md-btn-success");
            $("#btnMuteVideo" + intid).attr("title", "UnMute Video");
            vConn.mute(false, true);
        }
        //TODO::call avcontrol for video mute/unmute
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.MuteIPVideo()", ex, false);
    }
}

function DisableAV(intid) {
    try {
        if (GetChatReferenceObj(intid).chatMode == "audio") {
            GetChatReferenceObj(intid).chatMode = "text";
        }
        else if (GetChatReferenceObj(intid).chatMode == "video") {
            GetChatReferenceObj(intid).chatMode = "text";
            $("#btnMuteAudio" + intid).addClass("disabled");
            $("#btnMuteVideo" + intid).addClass("disabled");
        }
        //make the tmac ibar and remove the video tags
        $("#chatDetailsDiv" + intid).removeClass("uk-width-large-1-2 uk-width-medium-1-1");
        $("#chatDetailsDiv" + intid).addClass("uk-width-large-1-1 uk-width-medium-1-1");
        $("#videoCallDiv" + intid).remove();
        //collapse tmac on config
        if (isExpandCollapseOnVideoChat)
            ResizeWindow(false);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.DisableAV()", ex, false);
    }
}

function CheckForActiveAV() {
    try {
        let disabledButton = false;
        let activeChatCount = 0;
        $.each(global_ChatReference, function (i, val) {
            if (!val.isDisconnected) {
                activeChatCount++;
                if (val.chatMode != "text" || activeChatCount > 1)
                    disabledButton = true;
            }
        });

        $.each(global_ChatReference, function (i, val) {
            if (disabledButton) {
                $("#btnTextChat_AudioEscalate" + val.intid).addClass("disabled");
                $("#btnTextChat_VideoEscalate" + val.intid).addClass("disabled");
            }
            else {
                $("#btnTextChat_AudioEscalate" + val.intid).removeClass("disabled");
                $("#btnTextChat_VideoEscalate" + val.intid).removeClass("disabled");
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CheckForActiveAV()", ex, false);
    }
}


// send textmesg to textchat
function SendCallbackRequestToRM(intid) {
		 try {
				  
			 FadeOutButton("#btnTextChat_RMCallback" + intid);
			tmac_SendTextChatFromTemplate(function (result, obj) {
				 if (result === 1) {
					// success
					}
				 else {
				    log.LogDetails("Error", "TmacTextChatUI.SendCallbackRequestToRM()", "Callback request failed", true);
					FadeInButton("#btnTextChat_RMCallback" + obj.intid);
				 }
			}, { intid: intid }, global_DeviceID, intid, "RMCallbackRequest", "");
		 } catch (ex) {
				  log.LogDetails("Error", "TmacTextChatUI.SendCallbackRequestToRM()", ex, false);
		 }
}