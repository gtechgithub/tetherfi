﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "POMUI.js";
var file_version = "3.1.08.06";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

//--------------------------------------------------------------------------------------------
$(function () {
    //let obj1 = {};
    //obj1.Name = "Meeting";
    //obj1.Value = "3";
    //obj1.Display = 1;

    //let obj2 = {};
    //obj2.Name = "Logout";
    //obj2.Value = "4";
    //obj2.Display = 1;

    //global_AUXCodes.push(obj1);
    //global_AUXCodes.push(obj2);

    //LoadAuxDiv(global_AUXCodes, "NotReady");

    LoadPOMAgentListGrid();

    FadeOutButton("#btn_change_status");
});

//----------------------------------AGENT CALL EVENTS-----------------------------------------
function POMIncomingVoiceCall(event) {
    try {
        let intid = event.InteractionID;
        let transferFrom = event.UUI.split("|")[1];
        let jsonData = JSON.parse(event.UUI.split("|")[2]);
        pomActiveCallInteractionID = intid;
        CreatePOMCallbackTab(intid, (transferFrom == "" ? false : true));
        IncomingCallUUIData(intid, jsonData, transferFrom);
        GetPOMReferenceObj(intid).closeTab = true;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMIncomingVoiceCall()", ex, false);
    }
}

function POMVoiceCallConnectedEvent(event) {
    try {
        let intid = event.InteractionID;
        POMSetCallControlStatus(intid, false, false, false, true, true, false, true, true, false, false, false);
        ChangeTabReferenceStatus(intid, "CallConnected");
        GetPOMReferenceObj(intid).closeTab = false;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallConnectedEvent()", ex, false);
    }
}

function POMVoiceCallDisconnectedEvent(event) {
    try {
        let intid = event.InteractionID;
        $("#li_" + intid).removeClass("li-on-call");
        POMSetCallControlStatus(intid, false, false, false, false, false, false, false, false, false, false, false);
        ChangeTabReferenceStatus(intid, "CallDisconnected");
        global_CallType = "";
        //if this is a transferred call we dont have WrapUp mode to close the tab
        //so close the tab here
        if (GetPOMReferenceObj(intid).closeTab) {
            CloseTab(intid);
            RemovePOMReference(intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallDisconnectedEvent()", ex, false);
    }
}

function POMVoiceCallInitiating(event) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallInitiating()", ex, false);
    }
}

function POMVoiceOutgoingCallEvent(event) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceOutgoingCallEvent()", ex, false);
    }
}

function POMVoiceCallTransferInitiatedEvent(event) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallTransferInitiatedEvent()", ex, false);
    }
}

function POMVoiceCallTransferRemoteConnected(event) {
    try {
        //enable complete, cancel buttons on transfer window
        $('#btnDone').removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallTransferRemoteConnected()", ex, false);
    }
}

function POMVoiceCallTransferLineDisconnectEvent(event) {
    try {
        let intid = event.InteractionID;
        //hide the confirm window
        HideConfirmDialog();
        //disable answer button
        if (event.IsMainLine) //in connected state
            POMSetCallControlStatus(intid, false, false, false, true, true, false, true, true, false, false, false);
        else //in hold state
            POMSetCallControlStatus(intid, false, false, false, false, false, true, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallTransferLineDisconnectEvent()", ex, false);
    }
}

function POMConferenceInitiated(event) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceInitiated()", ex, false);
    }
}

function POMConferenceRemoteConnected(event) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceRemoteConnected()", ex, false);
    }
}

function POMConferenceCompleted(event) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceCompleted()", ex, false);
    }
}

function POMConferenceLineDisconnected(event) {
    try {
        //hide the transfer window
        HideConfirmDialog();
        //disable answer button
        POMSetCallControlStatus(event.InteractionID, false, false, false, true, true, false, true, true, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceLineDisconnected()", ex, false);
    }
}

function POMVoiceCallHoldEvent(event) {
    try {
        POMSetCallControlStatus(event.InteractionID, false, false, false, false, false, true, false, false, false, false, false);
        ChangeTabReferenceStatus(event.InteractionID, "CallHold");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallHoldEvent()", ex, false);
    }
}

function POMVoiceCallHoldReconnectEvent(event) {
    try {
        POMSetCallControlStatus(event.InteractionID, false, false, false, true, true, false, true, true, false, false, false);
        ChangeTabReferenceStatus(event.InteractionID, "CallConnected");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMVoiceCallHoldReconnectEvent()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------


//----------------------------------GENERIC CTI EVENTS----------------------------------------

function CallStateChangeNotify(event) {
    try {
        let jsonData = JSON.parse(event.JsonData);
        let deviceId = jsonData.Device;
        let callState = jsonData.CallState;
        switch (callState.toLocaleLowerCase()) {
            case "preview":
                break;
            case "conferenceowner":
                GetPOMReferenceObj(pomActiveCallInteractionID).isConference = true;
                break;
            case "conferencepassive":
                GetPOMReferenceObj(pomActiveCallInteractionID).isConference = true;
                break;
        }
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CallStateChangeNotify()", ex, false);
    }
}

function OnPOMLoginSuccess(event) {
    try {
        log.LogDetails("Info", "POMUI.OnPOMLoginSuccess()", "You are loggedIn as POM Agent", true);
        $("#div_pom_dashboard").removeClass("uk-display-none");
        $("#div_pom_dashboard").removeClass("uk-width-large-1-1");
        $("#div_pom_dashboard").addClass("uk-width-large-1-2");
        $("#div_agent_info").removeClass("uk-width-large-1-1");
        $("#div_agent_info").addClass("uk-width-large-1-2");
        TriggerResize();
        FadeInButton("#btn_change_status");
        $("#agentType").text("AutoDialer Agent - Outbound");
        //agentType = "AutoDialer";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPOMLoginSuccess()", ex, false);
    }
}

function OnPOMLoginFailed(event) {
    try {
        log.LogDetails("Info", "POMUI.OnPOMLoginFailed()", "You are loggedIn as ACD Agent", true);
        FadeInButton("#btn_change_status");
        $("#agentType").text("ACD Agent");
        //agentType = "ACD";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPOMLoginFailed()", ex, false);
    }
}

function OnBlendToInbound(event) {
    try {
        log.LogDetails("Info", "POMUI.OnBlendToOutbound()", "Agent Blend to Inbound", true);
        $("#agentType").text("AutoDialer Agent - Inbound");
        //agentType = "AutoDialer";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnBlendToInbound()", ex, false);
    }
}

function OnBlendToOutbound(event) {
    try {
        log.LogDetails("Info", "POMUI.OnBlendToOutbound()", "Agent Blend to Outbound", true);
        $("#agentType").text("AutoDialer Agent - Outbound");
        //agentType = "AutoDialer";
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnBlendToOutbound()", ex, false);
    }
}

function OnCallWrapUpDataEvent(event) {
    try {
        let eventJsonData = JSON.parse(event.JsonData);
        let jsonArrayString = eventJsonData.JsonData.replace(/'/g, '"');
        let jsonArray = JSON.parse(jsonArrayString);
        let intid = pomActiveCallInteractionID;
        if (intid != "") {
            $("#wrapupCodeDropDown" + intid).data("kendoDropDownList").dataSource.data(jsonArray);
            $("#div_wrapup" + intid).removeClass("uk-display-none");
        }
        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnCallWrapUpDataEvent()", ex, false);
    }
}

function OnConsultDestinationAgentsList(event) {
    try {
        let eventJsonData = JSON.parse(JSON.parse(event.JsonData).JsonData);
        $("#pomAgentList").data("kendoGrid").dataSource.data(eventJsonData);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnConsultDestinationAgentsList()", ex, false);
    }
}

function OnPendingConsultComplete(event) {
    try {
        POMVoiceCallTransferRemoteConnected();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnPendingConsultComplete()", ex, false);
    }
}

function OnConferenceEnded(event) {
    try {
        GetPOMReferenceObj(pomActiveCallInteractionID).isConference = false;
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnConferenceEnded()", ex, false);
    }
}
//--------------------------------------------------------------------------------------------


//----------------------------------DATA BINDING----------------------------------------------
function CreatePOMCallbackTab(intid, isTransfer) {
    try {
        //get the tab header and body template 
        let headerTemplate = GetTabHtml("tab_header_template", intid, { icon: "phone_callback" });
        let bodyTemplate = GetTabHtml("pom_tab_template", intid, null);
        //save tab and POM reference
        SaveTabReference("pom", intid, "new");
        SavePOMReference(intid);
        //add the tab
        AddTab(bodyTemplate, headerTemplate, intid, intid, true, false, true);
        //initialise the accordion
        UIkit.accordion($('#pom_accordion' + intid), {
            collapse: false,
            showfirst: true
        });
        //initialise completionCode dropdown
        $("#wrapupCodeDropDown" + intid).kendoDropDownList({
            dataTextField: "codeValue",
            dataValueField: "codeID",
            index: 0
        });
        //set call control status for incoming call
        if (isTransfer)
            POMSetCallControlStatus(intid, false, false, true, false, false, false, false, false, false, false, false);
        else
            POMSetCallControlStatus(intid, true, true, false, false, false, false, false, false, false, false, false);
        // When call comes, store the start time in the hidden field
        AddCallTimer(intid, "voice", "#hdn_voice_call_starttime" + intid, "#voice_call_starttime" + intid,
            "#voice_call_time_taken" + intid, "#voice_call_span_starttime" + intid, "", "", "", "", "", "");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CreatePOMCallbackTab()", ex, false);
    }
}

function IncomingCallUUIData(intid, jsonData, transferFrom) {
    try {
        let callbackNotes = jsonData.CallbackNotes;
        let campaignName = jsonData.CampaignName;
        let canCancel = jsonData.CanCancel;
        let canCancelSpecified = jsonData.CanCancelSpecified;
        let canDial = jsonData.CanDial;
        let canDialSpecified = jsonData.CanDialSpecified;
        let canEnterFreeFormNumber = jsonData.CanEnterFreeFormNumber;
        let canEnterFreeFormNumberSpecified = jsonData.CanEnterFreeFormNumberSpecified;
        let canReschedule = jsonData.CanReschedule;
        let canRescheduleSpecified = jsonData.CanRescheduleSpecified;
        let contactCapabilities = jsonData.ContactCapabilities;
        let contactID = jsonData.ContactID;
        let contactNumbers = jsonData.ContactNumbers;
        let contactType = jsonData.ContactType;
        let contactTypeSpecified = jsonData.ContactTypeSpecified;
        let defaultNumber = jsonData.DefaultNumber;
        let expiryTime = jsonData.ExpiryTime;
        let scriptFailoverURL = jsonData.ScriptFailoverURL;
        let scriptURL = jsonData.ScriptURL;
        let skillsetID = jsonData.SkillsetID;
        let skillsetName = jsonData.SkillsetName;
        let timed = jsonData.Timed;
        let timedSpecified = jsonData.TimedSpecified;
        let timeout = jsonData.Timeout;
        let timeoutSpecified = jsonData.TimeoutSpecified;
        let callType = "";
        switch (contactType) {
            case 0:
                callType = (transferFrom == "" ? "Preview" : "Preview - " + transferFrom);
                break;
            case 0:
                callType = (transferFrom == "" ? "Progressive" : "Progressive - " + transferFrom);
                break;
            case 0:
                callType = (transferFrom == "" ? "Predictive" : "Predictive - " + transferFrom);
                break;
            case 0:
                callType = (transferFrom == "" ? "Callback" : "Callback - " + transferFrom);
                break;
        }
        $("#callType" + intid).text(callType);

        GetPOMReferenceObj(intid).customerName = contactNumbers[0].Name;
        GetPOMReferenceObj(intid).phoneNumber = contactNumbers[0].Number;

        $("#txtCamapignName" + intid).val(campaignName);
        $("#divTabHeader" + intid).text(contactNumbers[0].Number);
        $("#txtName" + intid).val(contactNumbers[0].Name);
        $("#txtMobileNumber" + intid).val(contactNumbers[0].Number);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.IncomingCallUUIData()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------


//----------------------------------GENERIC CALL EVENTS---------------------------------------
function OnOutboundCallUUIData(event) {
    try {
        let intid = event.InteractionID;
        let data = JSON.parse(event.JsonData);
        let deviceId = data.Device;
        let callId = data.CallID;
        let UCID = data.UCID;
        let connectionHandle = data.ConnectionHandle;
        let monitorHandle = data.MonitorHandle;
        let jsonData = JSON.parse(data.JsonData);

        let firstName = jsonData.Firstname.value;
        let lastName = jsonData.Lastname.value;
        let title = jsonData.Title.value;
        let id = jsonData.ID.value;

        let addressList = jsonData.AddressList;
        let emailFeildsList = jsonData.EmailFields;
        let phoneFeildsList = jsonData.PhoneFields;
        let customFeildsList = jsonData.CustomFields;

        GetPOMReferenceObj(intid).callId = callId;
        GetPOMReferenceObj(intid).connectionHandle = connectionHandle;

        $("#txtId" + intid).val(id);

        $("#txtAddress" + intid).val(
            addressList[0].Line1.value + "\n" +
            addressList[0].Line2.value + "\n" +
            addressList[0].Line3.value + "\n" +
            addressList[0].Line4.value + "\n" +
            addressList[0].Line5.value + "\n" +
            addressList[0].ZipCode.value);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OnOutboundCallUUIData()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------


//----------------------------------AGENT COMMANDS--------------------------------------------
function POMDialPreviewCall(intid) {
    try {
        let obj = {};
        let data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
        data.numberToDial = GetPOMReferenceObj(intid).phoneNumber;
        data.custName = GetPOMReferenceObj(intid).customerName;

        obj.method = "DialPOMPreviewCall";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMDialCall()", ex, false);
    }
}

function DialPOMPreviewCallDone(result, obj) {
    try {
        POMSetCallControlStatus(obj.intid, false, false, false, false, false, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.DialPOMPreviewCallDone()", ex, false);
    }
}

function POMCancelPreviewCall(intid) {
    try {
        let obj = {};
        let data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;

        obj.method = "CancelPOMPreviewCall";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CancelPOMPreviewCall()", ex, false);
    }
}

function CancelPOMPreviewCallDone(result, obj) {
    try {
        GetPOMReferenceObj(obj.intid).closeTab = false;
        POMSetCallControlStatus(obj.intid, false, false, false, false, false, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CancelPOMPreviewCallDone()", ex, false);
    }
}

function POMRejectConsultCall(intid) {
    try {
        let obj = {};
        let data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;

        obj.method = "RejectPOMConsultCallByRemoteAgent";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMRejectConsultCall()", ex, false);
    }
}

function RejectPOMConsultCallByRemoteAgentDone(result, obj) {
    try {
        GetPOMReferenceObj(obj.intid).closeTab = true;
        POMSetCallControlStatus(obj.intid, false, false, false, false, false, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.CancelPOMConsultCallByRemoteAgentDone()", ex, false);
    }
}

function POMDropCall(intid) {
    try {
        if (GetPOMReferenceObj(intid).isConference) {
            let obj = {};
            let data = {};
            data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;

            obj.method = "EndPOMConferenceCall";
            obj.intid = intid;

            SendGenericCTICommand(obj.method, obj, data);
        }
        else
            DisconnectCall(global_DeviceID, intid);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.DropPOMCall()", ex, false);
    }
}

function EndPOMConferenceCallDone(result, obj) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "POMUI.EndPOMConferenceCallDone()", ex, false);
    }
}

function POMHoldDropCall(intid) {
    try {
        HoldCall(global_DeviceID, intid, null);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.HoldDropPOMCall()", ex, false);
    }
}

function POMUnHoldDropCall(intid) {
    try {
        UnHoldCall(global_DeviceID, intid, null);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.UnHoldDropPOMCall()", ex, false);
    }
}

function POMRedialDropCall(intid) {
    try {
    } catch (ex) {
        log.LogDetails("Error", "POMUI.RedialDropPOMCall()", ex, false);
    }
}

function POMScheduleCall(intid) {
    try {
        //popup the modal
        $("#pom_schedule_callback_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SchedulePOMCall()", ex, false);
    }
}

function POMWrapUpCallContact(intid) {
    try {
        let wrapUpDropDown = $("#wrapupCodeDropDown" + intid).data("kendoDropDownList");
        let obj = {};
        let data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
        data.compCode = wrapUpDropDown.value();
        data.compValue = wrapUpDropDown.text();

        obj.method = "WrapUpCallContact";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);

        $("#btnSubmitWrapUp" + intid).addClass("disabled");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMWrapUpCallContact()", ex, false);
    }
}

function WrapUpCallContactDone(result, obj) {
    try {
        let intid = obj.intid;
        POMSetCallControlStatus(intid, false, false, false, false, false, false, false, false, false, false, true);
        CloseTab(intid);
        RemovePOMReference(intid);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.WrapUpCallContactDone()", ex, false);
    }
}

function SubmitPOMScheduledCallbackReuest() {
    try {
        ShowNotify("SubmitPOMScheduledCallbackReuest", "info", null, "top-center");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SubmitPOMScheduledCallbackReuest()", ex, false);
    }
}

function SearchCustomer(intid) {

    try {
        let nric = $('#txtNRIC' + intid).text().trim();
        if (nric == '') {
            ShowNotify("Please enter NRIC", "danger", null, "top-center");
            return;
        }
        ShowNotify("Searching Customer: " + nric, "info", null, "top-center");
    } catch (ex) {
        log.LogDetails("Error", "POMUI.SearchCustomer()", ex, false);
    }
}

function OpenPOMTransfConfDialog(intid, type) {
    try {
        $("#consult_transfer_type").data("kendoDropDownList").text("Select Consult Type...");
        $("#consult_transfer_type").data("kendoDropDownList").value("");
        $("#pomAgentList").data("kendoGrid").dataSource.data([]);
        $("#btnpomtransfercall").addClass("uk-display-none");
        $("#btnpomconferencecall").addClass("uk-display-none");
        $("#pomTxtNumberTransConf").val("");
        if (type == "trans") {
            global_CallType = "Transfer";
            global_transferIntID = intid;
            $("#pom_trans_conf_dialog").data("kendoWindow").title("Transfer Agent List");
            $("#btnpomtransfercall").removeClass("uk-display-none");
        }
        else {
            global_CallType = "Conference";
            global_conferenceIntID = intid;
            $("#pom_trans_conf_dialog").data("kendoWindow").title("Conference Agent List");
            $("#btnpomconferencecall").removeClass("uk-display-none");
        }
        $("#pom_trans_conf_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OpenPOMTransfConfDialog()", ex, false);
    }
}

function ClosePOMTransConfDialog() {
    try {
        $("#pom_trans_conf_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "POMUI.OpenPOMTransfConfDialog()", ex, false);
    }
}

function GetConsultDestinationAgentsList(intid, type) {
    try {
        let obj = {};
        let data = {};
        data.connectionHandle = GetPOMReferenceObj(intid).connectionHandle;
        data.consultType = type;

        obj.method = "GetConsultDestinationAgentsList";
        obj.intid = intid;

        SendGenericCTICommand(obj.method, obj, data);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetConsultDestinationAgentsList()", ex, false);
    }
}

function GetConsultDestinationAgentsListDone(result, obj) {
    try {
        if (result !== 0) {
            $("#pomAgentList").data("kendoGrid").dataSource.data([]);
        }
        if (result == "-382")
            log.LogDetails("Error", "CommandManager.SendGenericCTICommandDone()", "No Destinations Available", true);
        else if (result == "-383")
            log.LogDetails("Error", "CommandManager.SendGenericCTICommandDone()", "Agents are not Available", true);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.GetConsultDestinationAgentsListDone()", ex, false);
    }
}

function POMTransferCall() {
    try {
        DisableButton("#btnpomtransfercall");
        let comment = "";
        let number = $("#pomTxtNumberTransConf").val();
        //get the interaction id
        let intId = global_transferIntID;
        let obj = {};
        obj.buttonId = "#btnpomtransfercall";
        obj.icon = "swap_horiz";
        obj.type = "pom";
        if (number === "") {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Please provide the destination number", "danger", null, "top-center");
            return;
        }
        TransferCallCommand(global_DeviceID, intId, number, comment, obj);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMTransferCall()", ex, false);
    }
}

function POMConferenceCall() {
    try {
        DisableButton("#btnpomconferencecall");
        let comment = "";
        let number = $("#pomTxtNumberTransConf").val();
        //get the interaction id
        let intId = global_conferenceIntID;
        let obj = {};
        obj.buttonId = "#btnpomconferencecall";
        obj.icon = "call_split";
        obj.type = "pom";
        if (number === "") {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Please provide destination number", "danger", null, "top-center");
            return;
        }
        ConferenceCall(global_DeviceID, intId, number, comment, obj);
    } catch (ex) {
        log.LogDetails("Error", "POMUI.POMConferenceCall()", ex, false);
    }
}

//--------------------------------------------------------------------------------------------


//----------------------------------GENERIC METHODS-------------------------------------------
function SavePOMReference(intid) {
    try {
        let pomRef = {};
        pomRef.intid = intid;
        pomRef.callId = "";
        pomRef.connectionHandle = "";
        pomRef.phoneNumber = "";
        pomRef.customerName = "";
        pomRef.closeTab = false;
        pomRef.isConference = false;

        //push to the array for that interaction
        global_POMReference.push(pomRef);
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.SaveFaxReference()", ex, false);
    }
}

function GetPOMReferenceObj(intid) {
    try {
        for (let i = 0; i < global_POMReference.length; i++) {
            if (global_POMReference[i] !== undefined && global_POMReference[i].intid === parseInt(intid))
                return global_POMReference[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetPOMReferenceObj()", ex, false);
    }
}

function RemovePOMReference(intid) {
    try {
        for (var i = 0; i < global_POMReference.length; i++) {
            if (global_POMReference[i] !== undefined && global_POMReference[i].intid === parseInt(intid)) {
                global_POMReference.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.RemovePOMReference()", ex, false);
    }
}

function POMSetCallControlStatus(intid, dial, reject, transferCancel, drop, hold, unhold, trans, conf, redial, schedule, tabClose) {
    try {
        if (dial === false) {
            $('#pomDialBtn' + intid).addClass('disabled');
        } else {
            $('#pomDialBtn' + intid).removeClass('disabled');
        }

        if (reject) {
            $('#pomCancelBtn' + intid).css("display", "inline-block");
            $('#pomCancelBtn' + intid).removeClass('disabled');
            $('#pomRejectConsultBtn' + intid).css("display", "none");
            $('#pomDropBtn' + intid).css("display", "none");
        }
        else if (transferCancel) {
            $('#pomRejectConsultBtn' + intid).css("display", "inline-block");
            $('#pomRejectConsultBtn' + intid).removeClass('disabled');
            $('#pomCancelBtn' + intid).css("display", "none");
            $('#pomDropBtn' + intid).css("display", "none");
        }
        else if (drop) {
            $('#pomDropBtn' + intid).css("display", "inline-block");
            $('#pomDropBtn' + intid).removeClass('disabled');
            $('#pomCancelBtn' + intid).css("display", "none");
            $('#pomRejectConsultBtn' + intid).css("display", "none");
        } else {
            $('#pomCancelBtn' + intid).css("display", "inline-block");
            $('#pomCancelBtn' + intid).addClass('disabled');
            $('#pomRejectConsultBtn' + intid).css("display", "none");
            $('#pomDropBtn' + intid).css("display", "none");
        }

        if (!hold && !unhold) {
            $('#pomHoldBtn' + intid).css("display", "inline-block");
            $('#pomUnHoldBtn' + intid).css("display", "none");
            $('#pomHoldBtn' + intid).addClass('disabled');
        } else if (hold) {
            $('#pomHoldBtn' + intid).css("display", "inline-block");
            $('#pomUnHoldBtn' + intid).css("display", "none");
            $('#pomHoldBtn' + intid).removeClass('disabled');
        } else if (unhold != "disable") {
            $('#pomUnHoldBtn' + intid).css("display", "inline-block");
            $('#pomHoldBtn' + intid).css("display", "none");
            $('#pomUnHoldBtn' + intid).removeClass('disabled');
        } else {
            $('#pomUnHoldBtn' + intid).css("display", "inline-block");
            $('#pomHoldBtn' + intid).css("display", "none");
            $('#pomUnHoldBtn' + intid).addClass('disabled');
        }

        if (trans === false) {
            $('#pomTransBtn' + intid).addClass('disabled');
        } else {
            $('#pomTransBtn' + intid).removeClass('disabled');
        }

        if (conf === false) {
            $('#pomConfBtn' + intid).addClass('disabled');
        } else {
            $('#pomConfBtn' + intid).removeClass('disabled');
        }

        if (redial === false) {
            $('#pomRediaBtn' + intid).addClass('disabled');
        } else {
            $('#pomRediaBtn' + intid).removeClass('disabled');
        }

        if (schedule === false) {
            $('#pomScheduleBtn' + intid).addClass('disabled');
        } else {
            $('#pomScheduleBtn' + intid).removeClass('disabled');
        }

        if (tabClose === true) {
            EnableTabCloseButton(intid);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.POMSetCallControlStatus()", ex, false);
    }
}

function CheckPOMAgentStatus(type) {
    try {
        let newAgentState = type;
        let lastAgentState = pomLastAgentState.toLocaleLowerCase();
        //if the status on call disable make call button
        if (lastAgentState == "pendingnotready") {
            FadeOutButton("#main_logout_btn");
        } else {
            if (isCloseTabsOnTSC)
                CloseAllTabs();
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.POMSetCallControlStatus()", ex, false);
    }
}

function POMTransferCompleteDone(data, obj) {
    try {
        GetPOMReferenceObj(obj.interactionid).closeTab = true;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.POMTransferCompleteDone()", ex, false);
    }
}

//-------------------------------------------------------------------------------------------

