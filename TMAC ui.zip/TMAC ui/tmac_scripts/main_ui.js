﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "MainUI.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------
window.onbeforeunload = function () {
    try {
        if (con !== undefined && con !== null)
            con.stop();
    } catch (ex) {
    }
}

//before Page Unload
function beforePageUnload() {
    try {
        call_log_out = false;
        if (logout_button_clicked)
            call_log_out = false;
        else if (global_AgentForcedLogoffEventFlag)
            call_log_out = false;
        else {
            call_log_out = true;
            return 'Are you sure you want to Logout?';
        }
    } catch (ex) {
    }
}

//page Unload
function onPageUnload() {
    try {
        if (call_log_out && isLogoutOnClose) {
            Logout(global_DeviceID);
        }
    } catch (ex) {
    }
}

//register beforunload and unload during page ready
$(function () {
    $(window).bind('beforeunload', beforePageUnload);
    $(window).bind('unload', onPageUnload);
});

//document ready 
$(document).ready(function () {
    console.log('main ui loaded');
    if (isVoiceBio) {
        let getAgentId = getQueryStringValue("agentid");
        if (getAgentId == "") {
            while (getAgentId == null || getAgentId == "") {
                getAgentId = prompt("Please Enter Agent id");
            }
        }
        Login("", voiceBioStationId, getAgentId, false, false, "");
    }
    else {
        DocumentReady();
        TriggerResize();
    }
});

function DocumentReady() {
    try {
        //resize the page content size according to the screensize
        SetHeight();
        //resize the tab size according to the screensize
        SetTabHeight();
        //get login data opener
        let loginData = (isVoiceBio ? getSuccessfullyLoggedInData() : opener.getSuccessfullyLoggedInData());
        //after successful login
        SuccessfullyLoggedIn(loginData.data, loginData.global_DeviceID, loginData.lanid, loginData.password,
            loginData.Application_Window_width, loginData.Application_Window_height, loginData.tmacServer);
        //initialise all the tabs
        LoadInitialTabs();
        //initialise all the kendo window dialogs
        LoadDialogUtils();
        //custom configurations
        Configurations();
        //initialise the wallboard
        LoadWallboardGrid();
        //initalise the remider grid if enabled
        LoadReminderGrid();
        //initialise utility functions
        UtilFunctions();
        //show main page content for animation effect
        $(".an-loader").addClass("uk-display-none");
        $("#header_main").removeClass("uk-display-none");
        $("#page_content").removeClass("uk-display-none");
        $("#footer").removeClass("uk-display-none");
        if (isFullTMAC)
            $("#sidebar_main").removeClass("uk-display-none");
        if (isVoiceBio) {
            ResizeWindow(true);
        }
        //set timer for status change
        SetTimer();
    } catch (ex) {
        log.LogDetails("Error", "MainUI.DocumentReady()", ex, false);
    }
}

//load the kendo tabs on page load
function LoadInitialTabs() {
    try {
        //initialise the main tabstrip
        tabstrip = $("#tabstrip").kendoTabStrip({
            animation: false,
            select: OnTabStripSelected,
            activate: OnTabStripActivate
        }).data("kendoTabStrip");
        //add the main tab to main tabstrip
        if (isCustomMainTab) {
            AddMainTab("main_tab_header", "custom_tab_body", "main", "Main", true);
        }
        else if (!isCustomMainTab && !isFullTMAC) {
            AddMainTab("main_tab_header", "main_tab_body", "main", "Main", true);
        }
        if (isDashboardEnabled && isFullTMAC) {
            AddMainTab("main_tab_header", "iframe_tab_body", "dashboard", "Dashboard", false);
            var param = "agentId=" + global_AgentID + "&profile=" +
                global_UserProfileForAgent + "&channel=" + "" + "&channelList=" + globalChannelList;
            param = ToEncodedString(param);
            LoadIFrame("ui_global_framedashboard", dashboardUrl + "?" + param);
        }
        if (isVoiceBio) $("#tabstrip").find(".k-tabstrip-items").addClass("uk-display-none");
        //initialise make call tabstrip
        tabstrip_call = $("#tabstrip_call").kendoTabStrip({
            animation: false,
        }).data("kendoTabStrip");
        //initialise transfer call tabstrip
        tabstrip_transfer = $("#tabstrip_transfer").kendoTabStrip({
            animation: false,
            select: function (arg) {
                let tabName = $(arg.item).find("> .k-link").text().trim();
                $('#txtNumberTrans').val("");
                EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
                EnableButton("#btndialogblindtransfercall", "BT", "tag");
                if (tabName == "Agent List") {
                    $("#transfer_skill_list_grid").show();
                }
                else {
                    $("#transfer_skill_list_grid").hide();
                }
                if (tabName == favouriteSkillTabName) {
                    FadeOutButton("#btndialogtransfercall");
                }
                RefreshTransCallagentListGrid();
            }
        }).data("kendoTabStrip");
    } catch (ex) {
        log.LogDetails("Error", "MainUI.LoadInitialTabs()", ex, false);
    }
}

//kendo main tab strip tab onactive event
function OnTabStripActivate(arg) {
    try {
        //trigger window resize on each tab active
        TriggerResize();
        //get the interaction id from the tab id
        var intId = arg.contentElement.getAttribute("intid");
        //if the interaction is main the don't call SwapTabs
        if (!isNaN(intId)) {
            //assign the interaction id to global_activeTabInteractionID
            global_activeTabInteractionID = intId;
            //if the chat is on going and a new voice tab in then hold the chat.
            //if the tab is newly created then skip and assign select tab reference to false
            if (isChatEnabled) {
                if ((GetChatReferenceObj(active_tab_id) !== undefined && !GetChatReferenceObj(active_tab_id).isDisconnected) ||
                    (!GetTabReferenceObj(intId).firstSelect && (GetTabReferenceObj(intId).type !== "acallback") && (GetTabReferenceObj(intId).type !== "pcallback"))) {
                    SelectTab(global_DeviceID, global_activeTabInteractionID);
                    //if the chat is on going and a new voice tab in then hold the chat and make first select of other tab false
                    if ((GetChatReferenceObj(active_tab_id) !== undefined && !GetChatReferenceObj(active_tab_id).isDisconnected))
                        GetTabReferenceObj(intId).firstSelect = false;
                } else if (!GetTabReferenceObj(intId).firstSelect && GetTabReferenceObj(intId).type == "acallback") {
                    //custom callback select
                    custom_AgentInitCallbackSelect(intId);
                } else {
                    GetTabReferenceObj(intId).firstSelect = false;
                }
                if (isChatEnabled && (GetChatReferenceObj(intId) !== undefined && !GetChatReferenceObj(intId).isDisconnected))
                    active_tab_id = intId;
                else
                    active_tab_id = "";
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.OnTabStripActivate()", ex, false);
    }
}

//kendo main tab strip tab on select event
function OnTabStripSelected(arg) {
    try {
        //get the interaction id from the tab id
        var intId = arg.contentElement.getAttribute("intid");
        if (!isNaN(intId)) {
            if (isChatEnabled && (GetChatReferenceObj(intId) !== undefined && !GetChatReferenceObj(intId).isDisconnected)) {
                if (GetChatReferenceObj(intId).isBlink) {
                    $("#li_" + intId).removeClass("blink_chattab");
                    GetChatReferenceObj(intId).isBlink = false;
                }
                GetChatReferenceObj(intId).isActive = true;
                if (intId != active_tab_id && active_tab_id !== "" && GetChatReferenceObj(active_tab_id) !== undefined)
                    GetChatReferenceObj(active_tab_id).isActive = false;
            }
        }
        //expand the tmac if we select supervisor tab
        if (isExpandCollapseOnIframes.Supervisor || isExpandCollapseOnIframes.Workbench) {
            if (isSupervisor && intId == "supervisor")
                window.resizeTo(screen.width, screen.height);
            else if (isWorkbench && intId == "workbench")
                window.resizeTo(screen.width, screen.height);
            else
                ResizeWindow(false);
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.OnTabStripSelected()", ex, false);
    }
}

//initialise all window dialogs
function LoadDialogUtils() {
    try {
        //dialog elements - title, elementId, width(global vars config), height
        let windowElements = {
            "add_reminder_dialog": "Set Reminder," + kendo_window_width.add_reminder + ", auto",
            "barge_in_dialog": "Textchat Barge-In," + kendo_window_width.barge_in_dialog + ", auto",
            "barge_in_display_dialog": "Barge-In Display," + kendo_window_width.barge_in_dialog + ", auto",
            "make_call_dialog": "Make Call," + kendo_window_width.make_call_dialog + ", auto",
            "transfer_dialog": "Transfer," + kendo_window_width.transfer_dialog + ", auto",
            "pom_trans_conf_dialog": "Transfer," + kendo_window_width.transfer_dialog + ", auto",
            "conference_dialog": "Conference," + kendo_window_width.conference_dialog + ", auto",
            "confirm_dialog": "Confirm," + kendo_window_width.confirm_dialog + ", auto",
            "schedule_callback_dialog": "Schedule Callback," + kendo_window_width.callback_dialog + ", auto",
            "pom_schedule_callback_dialog": "Schedule Callback," + kendo_window_width.pob_callback_dialog + ", auto",
            "schedule_multiple_callback_dialog": "Schedule Callback Request," + kendo_window_width.callback_dialog + ", auto",
            "callback_grid_dialog": "Callback Grid," + kendo_window_width.callback_dialog + ", auto",
            "callback_dialog": "Callback Request," + kendo_window_width.callback_dialog + ", auto",
            "callback_detail_dialog": "Callback Details," + kendo_window_width.callback_dialog + ", auto",
            "va_history_request_dialog": "VA History Details," + kendo_window_width.va_history + ", auto",
            "chat_template_dialog": "Chat Templates," + kendo_window_width.chat_template_dialog + ", auto",
            "close_callback_dialog": "Close/Re-schedule Callback," + kendo_window_width.callback_dialog + ", auto",
            "video_call_dialog": "Video Call, 50%, 50%",
            "from_filling_dialog": "Form Filling, 75%, 75%",
            "whiteboard_dialog": "Whiteboard, 90%, 65%",
            "draw_together_dialog": "Draw Together, 75%, 75%",
            "start_chat_dialog": "Start Chat," + kendo_window_width.start_chat + ", auto",
            "compose_fax_dialog": "Compose Fax," + kendo_window_width.start_chat + ", auto",
        };
        //initialise each kendo dialog elements
        $.each(windowElements, function (i, val) {
            //dialog id
            let id = i;
            //dialog title
            let title = val.split(',')[0];
            //dialog width
            let width = val.split(',')[1];
            //dialog height
            let height = val.split(',')[2];
            //dynamic initialisation
            InitKendoWindow(id, title, width, height);
        });

        //bind make call dialog onclose event
        $("#make_call_dialog").data("kendoWindow").bind("close", function (arg) {
            var internalCallSelector = document.querySelector('#makeCallCb');
            internalCallSelector.checked = false;
            onSwitchChange(internalCallSelector);
        });

        //bind chat template dialog onclose event
        $("#chat_template_dialog").data("kendoWindow").bind("close", function (arg) {
            ChatTemplateDialogClose(arg);
        });

        //bind barge in dialog onclose event
        $("#barge_in_dialog").data("kendoWindow").bind("close", function (arg) {
            $("#barge_in_grid").data("kendoGrid").dataSource.data([]);
        });

        //bind form filling dialog onclose event
        $("#from_filling_dialog").data("kendoWindow").bind("close", function (arg) {
            LoadIFrame("formFillingIframe", "");
        });

        //bind whiteboard dialog onclose event
        $("#from_filling_dialog").data("kendoWindow").bind("close", function (arg) {
            LoadIFrame("whiteboardIframe", "");
        });

        //bind whiteboard dialog onclose event
        $("#draw_together_dialog").data("kendoWindow").bind("close", function (arg) {
            LoadIFrame("drawTogetherIframe", "");
        });

        if (isFaxEnabled) {
            //bind fax compose dialog onclose event
            $("#compose_fax_dialog").data("kendoWindow").bind("close", function (arg) {
                $("#DNISList").data("kendoDropDownList").text("Select a Fax Line...");
                $("#DNISList").data("kendoDropDownList").enable(true);
                $("#faxNumber").val("");
                $("#faxNumber").removeAttr("readonly", "readonly");
                $("#faxFiles").data("kendoUpload").clearAllFiles();
                FadeInButton("#btn_compose_fax");
            });

            //bind fax compose dialog onclose event
            $("#compose_fax_dialog").data("kendoWindow").bind("open", function (arg) {
                FadeOutButton("#btn_compose_fax");
            });
        }

        if (isVideoCall && videoCallType == "window") {
            //add aditional actions for video call dialog
            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").html("");
            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_large_video" onclick="BigVideoScreen();" class="k-button k-bare k-button-icon k-window-action uk-display-none" aria-label="Custom"><span class="k-icon k-i-hyperlink-open-sm"></span></a>');
            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_small_video" onclick="SmallVideoScreen();" class="k-button k-bare k-button-icon k-window-action" aria-label="Custom"><span class="k-icon k-i-launch"></span></a>');
            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_minimize_video" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Minimize"><span class="k-icon k-i-window-minimize"></span></a>');
            $("#video_call_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" id="btn_maximize_video" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Maximize"><span class="k-icon k-i-window-maximize"></span></a>');

            //bind custom events for video call dialog
            $("#video_call_dialog").data("kendoWindow").wrapper
                .find(".k-i-window-maximize").click(function (e) {
                    $("#btn_small_video").css("display", "none");
                    setTimeout(function () {
                        $("#video_call_dialog").data("kendoWindow").wrapper
                            .find(".k-i-window-restore").click(function (e) {
                                $("#btn_small_video").css("display", "inline-flex");
                            });
                    }, 500);
                });

            //bind custom events for video call dialog
            $("#video_call_dialog").data("kendoWindow").wrapper
                .find(".k-i-window-minimize").click(function (e) {
                    $("#btn_small_video").css("display", "none");
                    setTimeout(function () {
                        $("#video_call_dialog").data("kendoWindow").wrapper
                            .find(".k-i-window-restore").click(function (e) {
                                $("#btn_small_video").css("display", "inline-flex");
                            });
                    }, 500);
                });
        }

        if (isFormFilling) {
            //add aditional actions for form filling dialog
            $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").html("");
            $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Minimize"><span class="k-icon k-i-window-minimize"></span></a>');
            $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Maximize"><span class="k-icon k-i-window-maximize"></span></a>');
            $("#from_filling_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="Close"><span class="k-icon k-i-close"></span></a>');
        }

        if (isWhiteboard) {
            //add aditional actions for whiteboard dialog
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").html("");
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Minimize"><span class="k-icon k-i-window-minimize"></span></a>');
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="window-Maximize"><span class="k-icon k-i-window-maximize"></span></a>');
            $("#whiteboard_dialog").closest(".k-window").find(".k-window-actions").append('<a role="button" href="#" class="k-button k-bare k-button-icon k-window-action" aria-label="Close"><span class="k-icon k-i-close"></span></a>');
        }

        //bind set reminder dialog onclose event
        if (isReminder) {
            $("#add_reminder_dialog").data("kendoWindow").bind("close", function (arg) {
                if (arg.sender.title().split(' ')[0] == "Edit")
                    EnableButton("#btnDeleteReminder", "delete", "icon");
            });
        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.LoadDialogUtils", ex, false);
    }
}

//dynamic initialisation of kendo window dialogs
function InitKendoWindow(windowId, title, width, height) {
    try {
        $("#" + windowId).kendoWindow({
            modal: modalOnDialog,
            title: title,
            width: width,
            height: height,
            visible: false,
            resizable: false,
            open: OnKendoWindowOpen,
            actions: ["Close"]
        }).data("kendoWindow");
        altair_md.inputs($(windowId));
    } catch (ex) {
        log.LogDetails("Error", "MainUI.InitKendoWindow()", ex, false);
    }
}

//on close of kendo window dialog
function OnKendoWindowOpen() {
    TriggerResize();
}

//Intitalse utility functions
function UtilFunctions() {
    try {
        //theme switcher configs
        var $colors_li = $("#color_li");
        $colors_li.hide();
        $('#change_theme_color').change(function () {
            if (this.checked === true) {
                $colors_li.show();
            } else {
                $colors_li.hide();
            }
        });

        //transfer skill list dropdown 
        $("#transfer_skill_list").kendoDropDownList({
            dataTextField: "SkillName",
            dataValueField: "SkillID",
            select: OnSkillListChange
        });

        if (isPOM) {
            //consult transfer_type dropdown
            $("#consult_transfer_type").kendoDropDownList({
                dataTextField: "text",
                dataValueField: "value",
                dataSource: [
                    { text: "Agent", value: "Agent" },
                    { text: "External", value: "External" }
                ],
                select: OnConsultTransferTypeSelected
            });

            $("#consult_transfer_type").data("kendoDropDownList").text("Select Consult Type...");
        }

        //callback schedule dialog callback time kendo masked textbox initialisation
        ConfigureMaskedTextBox("chatcallbackScheduleRequestTime", "00:00");

        //callback schedule dialog callback time kendo masked textbox initialisation
        ConfigureMaskedTextBox("pomSCRequestTime", "00:00:00");

        //multiple callback schedule dialog callback time kendo masked textbox initialisation
        ConfigureMaskedTextBox("multipleCallbackScheduleTime", "00:00");

        //reminder time kendo masked textbox initialisation
        ConfigureMaskedTextBox("reminderTime", "00:00:00");

        if (isChatEnabled && isAttachement) {
            $("#attachFiles").kendoUpload({
                async: {
                    saveUrl: tmac_asmx_url_list[tmac_asmx_url_count] + "ChatFileUpload",
                    autoUpload: false
                },
                multiple: false,
                upload: function (e) {
                    var obj = {};
                    e.data = obj;
                },
                success: function (e) {
                    if (e.files === undefined) e.files = files;
                    GetChatReferenceObj(global_activeTabInteractionID).isAgent = true;
                    var src = e.XMLHttpRequest.statusText;
                    var type = "";
                    $.each(e.files, function (i, val) {
                        let msgid = uuid();
                        let message = "";
                        let isReply = false;
                        let replyJson = {};
                        let obj = {};
                        obj.id = msgid;
                        if (imageFormats.indexOf(val.extension.toUpperCase()) >= 0) {
                            obj.messageType = "image";
                            obj.message = '<img class="attach_img" src="' + src + '"/>';
                            type = "image";
                        }
                        else if (audioFormats.indexOf(val.extension.toUpperCase()) >= 0) {
                            obj.messageType = "audio";
                            obj.message = '<audio controls src="' + src + '"></audio>';
                            type = "audio";
                        }
                        else if (videoFormats.indexOf(val.extension.toUpperCase()) >= 0) {
                            obj.messageType = "video";
                            obj.message = '<video class="videoTag" controls src="' + src + '"></video>';
                            type = "video";
                        }
                        else {
                            var fileType = GetFileExtension(val.extension);
                            if (fileType == "doc" || fileType == "docx" || fileType == "pdf")
                                type = "file";
                            else
                                type = "others";
                            obj.messageType = "file";
                            obj.message = '<a class="document-filename" download="' + val.name + '" href="' + src + '">' + val.name + '</a>';
                            src = val.name + "|" + src;
                        }
                        GetChatReferenceObj(global_activeTabInteractionID).replyText != "" ? isReply = true : isReply = false;
                        if (isReply) {
                            obj.type = "reply";
                            obj.replyIdTextType = GetChatReferenceObj(global_activeTabInteractionID).replyTextId + "|" + GetChatReferenceObj(global_activeTabInteractionID).replyText + "|" + GetChatReferenceObj(global_activeTabInteractionID).replyType;
                        }
                        else
                            obj.type = "new";
                        message = JSON.stringify(obj);
                        SendTextChat(global_DeviceID, global_activeTabInteractionID, message);

                        replyJson.replyType = GetChatReferenceObj(global_activeTabInteractionID).replyType;
                        replyJson.replyTextId = GetChatReferenceObj(global_activeTabInteractionID).replyTextId;
                        replyJson.replyText = GetChatReferenceObj(global_activeTabInteractionID).replyText;
                        replyJson.replyUser = GetChatReferenceObj(global_activeTabInteractionID).replyUser;

                        AddMessageToChatbox(global_activeTabInteractionID, msgid, src, "agent", "", "divTxtChatTranscript", type, isReply, replyJson);
                    });
                    $("#attachFiles").data("kendoUpload").clearAllFiles();
                    //success
                },
                error: function (e) {
                    //error
                },
                remove: function (e) {
                    //remove
                },
                progress: function (e) {
                    $("#div_uk_progress_bar" + global_activeTabInteractionID).removeClass("uk-display-none");
                    $("#uk_progress_bar" + global_activeTabInteractionID).css("width", e.percentComplete + "%");
                    console.log(e.percentComplete);
                },
                complete: function (e) {
                    $("#div_uk_progress_bar" + global_activeTabInteractionID).addClass("uk-display-none");
                },
                select: function (e) {
                    $("#uk_progress_bar" + global_activeTabInteractionID).css("width", "0%");
                    files = {};
                    $.each(e.files, function () {
                        if (this.size > parseInt(maxAttachFileSize) * 1024 * 1024) {
                            var msg = this.name + ": File size is too large.";
                            log.LogDetails("Error", "MainUI.UtilFunctions().kendoUpload()", msg, true);
                            e.preventDefault(); // This cancels the upload for the file
                        }

                        if (this.extension == "") {
                            var msg = this.name + " is a invalid file";
                            log.LogDetails("Error", "MainUI.UtilFunctions().kendoUpload()", msg, true);
                            e.preventDefault(); // This cancels the upload for the file
                        }

                        if (imageFormats.indexOf(this.extension.toUpperCase()) >= 0) {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let clip_img = document.getElementById('img_screenshot' + global_activeTabInteractionID);
                                        if (clip_img !== null) {
                                            var base64 = this.result.split(',')[1];
                                            var binary = FixBinary(atob(base64));
                                            var blob = new Blob([binary], { type: 'image/png' });
                                            var url = URL.createObjectURL(blob);
                                            clip_img.src = url;
                                            console.log("Image attach: " + url);
                                            ShowAttachment("image");
                                        }
                                    }
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                        else if (audioFormats.indexOf(this.extension.toUpperCase()) >= 0) {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let clip_audio = document.getElementById('aud_screenshot' + global_activeTabInteractionID);
                                        if (clip_audio !== null) {
                                            var base64 = this.result.split(',')[1];
                                            var binary = FixBinary(atob(base64));
                                            var blob = new Blob([binary], { type: 'audio/x-mpeg-3' });
                                            var url = URL.createObjectURL(blob);
                                            clip_audio.src = url;
                                            console.log("Audio attach: " + url);
                                            ShowAttachment("audio");
                                        }
                                    }
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                        else if (videoFormats.indexOf(this.extension.toUpperCase()) >= 0) {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let clip_video = document.getElementById('vid_screenshot' + global_activeTabInteractionID);
                                        if (clip_video !== null) {
                                            var base64 = this.result.split(',')[1];
                                            var binary = FixBinary(atob(base64));
                                            var blob = new Blob([binary], { type: 'video/webm' });
                                            var url = URL.createObjectURL(blob);
                                            clip_video.src = url;
                                            console.log("Video attach: " + url);
                                            ShowAttachment("video");
                                        }
                                    }
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                        else {
                            setTimeout(function () {
                                var fileInfo = e.files[0];
                                externalFileName = fileInfo.name;
                                var raw = fileInfo.rawFile;
                                var reader = new FileReader();
                                if (raw) {
                                    reader.onloadend = function () {
                                        let file_preview = document.getElementById('file_preview' + global_activeTabInteractionID);
                                        if (file_preview !== null) {
                                            file_preview.href = this.result;
                                            $("#file_preview" + global_activeTabInteractionID).html('<span class="k-icon ' + GetIconByExtension(fileInfo.extension.toUpperCase()) + ' k-icon-48"></span><br/>' + fileInfo.name);
                                            ShowAttachment("file");
                                        }
                                    }
                                    reader.readAsDataURL(raw);
                                }
                            });
                        }
                    });
                    files = e.files;
                }
            });
        }

        if (isFaxEnabled) {
            //DNISList list dropdown
            $("#DNISList").kendoDropDownList();

            //fax templates dropdown
            $("#faxTemplates").kendoDropDownList();
            $("#faxTemplates").data("kendoDropDownList").text("Select a fax template...");

            $("#faxFiles").kendoUpload({
                async: {
                    saveUrl: tmac_asmx_url_list[tmac_asmx_url_count] + "SendFaxFiles",
                    autoUpload: false
                },
                validation: {
                    allowedExtensions: [".pdf", ".jpg", ".jpeg"]
                },
                multiple: true,
                upload: function (e) {
                    var obj = {};
                    obj.interactionId = faxInteractionId;
                    obj.DNIS = $("#DNISList").data("kendoDropDownList").value();
                    obj.faxNumber = $("#faxNumber").val();
                    obj.deviceId = global_DeviceID;
                    obj.tmacServer = _tmacServer;
                    e.data = obj;
                },
                success: function (e) {
                    let jsonResult = JSON.parse(e.XMLHttpRequest.statusText);
                    let resultMessage = jsonResult.ResultMessage == "Success" ? "Fax sent successfully" : "Fax sent failed";
                    log.LogDetails(jsonResult.ResultMessage, "MainUI.InitKendoWindow()", resultMessage, true);
                    $("#compose_fax_dialog").data("kendoWindow").close();
                },
                error: function (e) {
                    //error
                },
                remove: function (e) {
                    //remove
                },
                progress: function (e) {
                    console.log(e.percentComplete);
                },
                complete: function (e) {
                    //$("#div_uk_progress_bar" + global_activeTabInteractionID).addClass("uk-display-none");
                },
                select: function (e) {
                    //$("#uk_progress_bar" + global_activeTabInteractionID).css("width", "0%");
                }
            });

        }
    } catch (ex) {
        log.LogDetails("Error", "MainUI.UtilFunctions()", ex, false);
    }
}

//assign kendo masked feature to the textbox
function ConfigureMaskedTextBox(textBoxId, maskFormat) {
    try {
        $("#" + textBoxId).kendoMaskedTextBox({
            mask: maskFormat
        });
        $("#" + textBoxId).removeClass("k-textbox");
    } catch (ex) {
        log.LogDetails("Error", "MainUI.ConfigureMaskedTextBox() - " + textBoxId, ex, false);
    }
}

//TMAC UI configurations
function Configurations() {
    try {
        //Push notification config
        var pushNotification = document.querySelector('#push_notification_enabled');
        if (isPushNotification === true) {
            pushNotification.checked = true;
            onSwitchChange(pushNotification);
        } else {
            pushNotification.checked = false;
            onSwitchChange(pushNotification);
        }

        $('#push_notification_enabled').change(function () {
            if (this.checked === true) {
                isPushNotification = true;
            } else
                isPushNotification = false;
        });

        //blink status config
        var blinkStatus = document.querySelector('#blink_status_enabled');
        if (isBlinkStatus === true) {
            blinkStatus.checked = true;
            onSwitchChange(blinkStatus);
        } else {
            blinkStatus.checked = false;
            onSwitchChange(blinkStatus);
        }

        $('#blink_status_enabled').change(function () {
            if (this.checked === true) {
                isBlinkStatus = true;
            } else
                isBlinkStatus = false;
        });

        //utilities barg-in configs
        if (global_UserProfileForAgent.toLowerCase() == "s") {
            if (isBargeIn) {
                $('#btnSupervisor').remove();
                $('#btnChatBargeIn').removeClass("uk-display-none-important");
                //create barge in grid
                CreateBargeInGrid([]);
            }
            if (isSupervisor) {
                $('#btnChatBargeIn').remove();
                $('#btnSupervisor').removeClass("uk-display-none-important");
            }
        } else {
            $('#btnChatBargeIn').remove();
            $('#btnSupervisor').remove();
        }

        if (isWorkbench) {
            $('#btnWorkbech').removeClass("uk-display-none-important");
        }
        else {
            $('#btnWorkbech').remove();
        }

        $("#div_marquee").click(function () {
            if ($.trim($("#marquee").text()) != "")
                UIkit.modal.alert($("#marquee").text());
        });
    } catch (ex) {
        log.LogDetails("Error", "MainUI.Configurations()", ex, false);
    }
}

function onSwitchChange(el) {
    if (typeof Event === 'function' || !document.fireEvent) {
        var event = document.createEvent('HTMLEvents');
        event.initEvent('change', true, true);
        el.dispatchEvent(event);
    } else {
        el.fireEvent('onchange');
    }
}

//only number validation
function ValidateChar(event) {
    if (isNaN(String.fromCharCode(event.keyCode)) || $.trim(String.fromCharCode(event.keyCode)) === "")
        event.preventDefault();
}

//Logout modal confirm
function AgentLogout() {
    try {
        UIkit.modal.confirm('Please confirm your log-out',
            function () {
                logout_button_clicked = true;
                Logout(global_DeviceID);
                // Kill all the popupalerts
                CloseNotifications();
                LogoffAlert("Logging Out", false, 10000);
            });
    } catch (ex) {
        log.LogDetails("Error", ",MainUI.AgentLogout()", ex, false);
    }
}

function ResizeWindow(move) {
    var Current_Width = CalculateTMACWindowWidth();
    var Current_Height = CalculateTMACWindowHeight();
    window.resizeTo(Current_Width, Current_Height);
    if (move) {
        if (isVoiceBio) {
            window.moveTo(screen.width, screen.height);
        }
        else {
            window.moveTo(0, 0);
        }
    }
}

//window resize event
$(window).resize(function () {
    setTimeout(function () {
        SetHeight();
        SetTabHeight();
    }, 300);
    SetHeight();
    SetTabHeight();
    if (isDisableResize) {
        var Current_Width = CalculateTMACWindowWidth();
        var Current_Height = CalculateTMACWindowHeight();
        window.resizeTo(Current_Width, Current_Height);
    }

    if (editingImage && isPdfEditor) {
        var img = document.getElementById("img_screenshot_" + global_activeTabInteractionID);
        if (img !== null) {
            var canvas = document.getElementById("sketch");
            var con = canvas.getContext("2d");
            canvas.width = img.width;
            canvas.height = img.height;
            con.clearRect(0, 0, $("#sketch").width(), $("#sketch").height());
            var image = new Image();
            image.src = img.src;
            con.drawImage(image, 0, 0, img.width, img.height);
            drawInit();
        }
    }
});

//trigger the window resize event
function TriggerResize() {
    setTimeout(function () {
        $(window).trigger('resize');
    }, 100);
}

//set the height of the page content
function SetHeight() {
    try {
        setTimeout(function () {
            var totalHeight = $(window).height();
            var headerHeight = $("#header_main").height();
            var footerHeight = $("#footer").height();
            var mainContentHeight = totalHeight - headerHeight - footerHeight;
            $("#page_content").height(mainContentHeight);
            $("#page_content_inner").height(mainContentHeight);
            if (isFullTMAC && isReminder && isWallboard)
                $("#reminder_grid_side .k-grid-content").height(totalHeight - headerHeight - footerHeight - $("#wallboardGrid_side").height() - $("#side_agent_info").height() - 95);
            else if (isFullTMAC && isReminder && !isWallboard)
                $("#reminder_grid_side .k-grid-content").height(totalHeight - headerHeight - footerHeight - $("#side_agent_info").height() - 84);
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "MainUI.SetHeight()", ex, false);
    }
}

//set the tab height
function SetTabHeight() {
    try {
        setTimeout(function () {
            var tabCardHeight = $("#tab_card_content").height();
            var tabHeaderHeight = isVoiceBio ? 0 : $(".k-reset").height();
            var tabContentHeight = tabCardHeight - tabHeaderHeight - 10;
            $("#tabstrip.k-tabstrip .k-content").height(tabContentHeight);
            if (isFullTMAC)
                $(".custom-main-body").height(tabContentHeight);
            if (!isFullTMAC && isReminder && isWallboard)
                $("#reminder_grid .k-grid-content").height(tabContentHeight - $("#wallboardGrid_main").height() - $(".has-user-block").height() - 100);
            else if (!isFullTMAC && isReminder && !isWallboard)
                $("#reminder_grid .k-grid-content").height(tabContentHeight - $(".has-user-block").height() - 84);
            $(".md-card-content.chatbox_content").css("height", $(window).height() - 255 - (isVaChatHistoryAccordion === true ? 35 : 0) - (isChatAuthenticationPanel === true ? 100 : 54));
            if (isCustomerJourney) $(".interaction-history-frame").css("height", $(window).height() - 210 - (isVaChatHistoryAccordion === true ? 35 : 0) - (isChatAuthenticationPanel === true ? 100 : 54));
            $(".facebook-post").css("max-height", $(window).height() - 125);
            $(".facebook-customer-journey").css("height", $(window).height() - 125);
            if (isVoiceBio) $(".voice-bio-card").height($(window).height() - 10);
            if (isDashboardEnabled && isFullTMAC) $(".full_tab_iframe").height(tabContentHeight);
            if (isFaxEnabled) $(".fax-loader").height($(window).height() - 235);
        }, 200);
    } catch (ex) {
        log.LogDetails("Error", "MainUI.SetTabHeight()", ex, false);
    }
}