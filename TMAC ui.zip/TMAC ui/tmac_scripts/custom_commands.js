﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CustomCommand.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}

//----------------------------------------- Custom Update Interaction History -----------------------------------
function Custom_InvokeFunction(moduleName, className, funcitonName, parameters, object) {
    try {
        var data = {};
        data.moduleName = moduleName;
        data.className = className;
        data.funcitonName = funcitonName;
        data.parameters = parameters;
        //inform the server
        command(data, "Custom_InvokeFunction", object);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.Custom_InvokeFunction()", ex, false);
    }
}

function Custom_InvokeFunctionDone(data, object) {
    try {
        if (isVoiceBio && object !== undefined) {
            window[object.callbackFunction + "Done"](data, object);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.Custom_InvokeFunctionDone()", ex, false);
    }
}

//---------------------------------------------Callback Submit Validate------------------------------------------
function Validate(intid) {
    try {
        var startDate = $("#startDate" + intid).val();
        var yearone = startDate.substring(0, 4);
        var monthone = startDate.substring(5, 7);
        var dayone = startDate.substring(8, 10);
        var time = $("#ddl_time" + intid).val();
        var hour = time.split(':')[0];
        var min = time.split(':')[1];
        if (min == undefined) {
            min = "";
        }
        var newstartdate = new Date(yearone, monthone - 1, dayone, hour, min, "00");
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();

        var callbackDate = yearone + monthone + dayone;

        if (($("#ddl_status" + intid).val() == "Callback")) {

            if (newstartdate < today) {
                ShowNotify("Callback Date Time should be greater than today", "danger", null, "top-center");
                return false;
            }
        }

        try {
            //check if the call is active
            if (GetTabReferenceObj(intid).status != "new" && GetTabReferenceObj(intid).status != "CallDisconnected") {
                ShowNotify("Please complete the call before submit", "danger", null, "top-center");
                return false;
            }
        } catch (ex) {
            log.LogDetails("Error", "CustomCommand.Validate() - Inside1", ex, false);
        }

        //fetch the srno from the pending callback grid
        try {
            var myGrid = $("#pending_callback_grid" + intid).data('kendoGrid');
            var gridData = myGrid.dataSource.data();
            var srnoArray = "";
            // iterate one by one rows
            for (var i = 0; i < gridData.length; i++) {
                // Do Close call back either one by one or just pass selRowIds single shot
                if (i == 0) {
                    srnoArray = gridData[i].SRNO;
                } else {
                    srnoArray = srnoArray + "," + gridData[i].SRNO;
                }
            }
            if ($.trim(srnoArray) != "" && srnoArray.split(',').length > 0) {
                srnoArray = $("#hfSRNO" + intid).val() + "," + srnoArray;
            } else {
                srnoArray = $("#hfSRNO" + intid).val();
            }
        } catch (ex) {
            log.LogDetails("Error", "CustomCommand.Validate() - Inside2", ex, false);
        }

        if (global_voiceCallHasCallback) {
            custom_submit($("#ddl_status" + intid).val(),
                $("#hfCBUCID" + intid).val(),
                $("#txtComments" + intid).val(),
                $("#hfSRNO" + intid).val(),
                startDate,
                hour,
                min,
                $("#hfTYPE" + intid).val(),
                intid, $("#lbl_PCN" + intid).val(),
                global_AgentID, "",
                callbackDate,
                hour + min,
                globalConfig_DigibankCallbackType,
                srnoArray);
        } else {
            custom_submit($("#ddl_status" + intid).val(),
                $("#hfCBUCID" + intid).val(),
                $("#txtComments" + intid).val(),
                $("#hfSRNO" + intid).val(),
                startDate,
                hour,
                min,
                $("#hfTYPE" + intid).val(),
                intid,
                $("#lbl_PCN" + intid).val(),
                "0", "", callbackDate, hour + min, globalConfig_DigibankCallbackType, srnoArray);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.Validate()", ex, false);
    }
}

//----------------------------------------- Custom Update Interaction History -----------------------------------
//Custom Make Call
function custom_MakeCall(intid, sourcePath) {
    try {
        try {
            //remove object from the array
            RemoveGlobalTimeoutReference(intid);
        } catch (ex) {
            log.LogDetails("Error", "CustomCommand.custom_MakeCall() - Inside", ex, false);
        }
        //disable callback dial buttons
        DisableCallbackDialButtons(intid);
        if (globalConfig_IsACWQMSCRMEnabled || globalConfig_CRMCallbackEnd) {
            // enable the submit button
            EnableCallbackSubmitButtons(intid);
        }
        if (sourcePath == "CID") {
            var phoneNum = $("#lbl_CallerID" + intid).val();
            MakeCall(global_DeviceID, phoneNum, "customMakeCallCallerId", intid);
            GetTabReferenceObj(intid).OtherData.customMakeCallDone = true;
            ChangeTabReferenceStatus(intid, 'MakeCall');

        } else if (sourcePath == "PCN") {
            MakeCall(global_DeviceID, $("#lbl_PCN" + intid).val(), "customMakeCallPreferredNo", intid);
            GetTabReferenceObj(intid).OtherData.customMakeCallDone = true;
            ChangeTabReferenceStatus(intid, 'MakeCall');
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_MakeCall()", ex, false);
    }
}

function custom_MakeCallDone(data) {
    try {

        if (data.ResultCode == 0) {
            //MakeCall success
        } else {
            //MakeCall failed
            ShowNotify(data.ResultMessage, "danger", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_MakeCallDone()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
// Get QueueTime Color Code 
function custom_getQueueTimeColorCode(intid) {
    try {
        var parameters = [global_DeviceID, intid, "GetQueueTimeColorCodeEvent"];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetQueueTimeColorCode", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getQueueTimeColorCode()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom ddlStatusChange
function custom_ddlStatusChange(intid) {
    try {
        var hfTYPE = $('#hfTYPE' + intid).val();
        var status = $('#ddl_status' + intid).val();
        if (status == "Callback") {
            var parameters = [global_DeviceID, intid, "ddlStatusChangeEvent", hfTYPE];
            Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "CallbackStatusChange", parameters);
            $('#startDate' + intid).removeAttr('disabled', 'disabled');
            $('#ddl_time' + intid).data("kendoMaskedTextBox").enable();
        } else if (status == "Closed") {
            $('#startDate' + intid).val('');
            $('#ddl_time' + intid).val('');
            $('#startDate' + intid).attr('disabled', 'disabled');
            $('#ddl_time' + intid).data("kendoMaskedTextBox").enable(false);
        }
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_ddlStatusChange()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom submit
function custom_submit(status, ucid, comments, srno, startDate, hour, min, type, intid, prefNum, agentId, cif, callbackDate, callbackTime, callbackVdn, srnoArray) {
    try {
        var parameters = [global_DeviceID, intid, "submitEvent", status, ucid, comments, srno, startDate, hour, min, type, prefNum, agentId, cif, callbackDate, callbackTime, callbackVdn, srnoArray];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "Submit", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_submit()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Detail Grid
function CustomDetailGrid(intid) {
    try {
        $("#callback_detail_dialog").data("kendoWindow").center().open();
        CreateCallbackDetailGrid();
        var ucid = $("#hfCBUCID" + intid).val();
        var parameters = [global_DeviceID, intid, "GetDetailsEvent", ucid];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetDetails", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.CustomDetailGrid()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get Details for UCID
function custom_getdetailsforUCID(intid, ucid) {
    try {
        var parameters = [global_DeviceID, intid, "GetDetailsForUCIDEvent", ucid, global_AgentID];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetDetailsForUCID", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getdetailsforUCID()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get VDN List
function custom_getVDNList(intid, modulename) {
    try {
        var parameters = [global_DeviceID, intid, "GetVDNListEvent", modulename];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetVDNList", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getVDNList()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get Popup URL
function custom_getPopUpURL(intid, modulename) {
    try {
        var parameters = [global_DeviceID, intid, "GetPopUpURLEvent", modulename];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetPopUpURL", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getPopUpURL()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get Data
function custom_getData(intid, callerid) {
    try {
        var parameters = [global_DeviceID, intid, "GetDataEvent", callerid];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetData", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getData()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Text Chat Load VA Chat History
function custom_LoadVAChatHistory(deviceid, intid) {
    try {
        var sessionid = GetTabReferenceObj(intid).OtherData.VAChatSessionID;
        var cif = GetTabReferenceObj(intid).OtherData.CIF;
        var parameters = [global_DeviceID, intid, "LoadVAChatHistoryEvent", sessionid, cif];
        Custom_InvokeFunction("AMACWebCustomerLayer_Generic.dll", "AMACWebCustomerLayer_Generic.TextChatCustomClass", "TextChat_LoadVAChatHistory", parameters);
        //Custom_InvokeFunction("AMACWebCustomerLayer_Generic.dll", "AMACWebCustomerLayer_Generic.TextChatCustomClass", "TextChat_LoadVAChatHistoryID", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_LoadVAChatHistory()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Load Text Chat Templates
function custom_LoadChatTemplates(intid) {
    try {
        var parameters = [global_DeviceID, intid, "LoadChatTemplatesEvent"];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "LoadChatTemplates", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_LoadChatTemplates()", ex, false);
    }
}

//----------------------------------------- Custom Update Interaction History -----------------------------------
function custom_UpdateInteractionHistory(sessionId, nric, email, chatID, clid, cif, text, direction, channel, groupID, subtype, insertedby) {
    try {
        var parameters = [sessionId, nric, email, chatID, clid, cif, text, direction, channel, groupID, subtype, insertedby];
        Custom_InvokeFunction("AMACWebCustomerLayer_Generic.dll", "AMACWebCustomerLayer_Generic.TextChatCustomClass", "UpdateInteractionHistory", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_UpdateInteractionHistory()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get CIF From Custom Data Table
function custom_LoadCIF(intid, UCID) {
    try {
        var parameters = [global_DeviceID, intid, "LoadCIFEvent", UCID];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "LoadCIF", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_LoadCIF()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get CIF From Custom Data Table
function custom_LoadUCIDChatToCallback(interactionid, sessionid) {
    try {
        var parameters = [global_DeviceID, interactionid, "LoadUCIDChatToCallbackEvent", sessionid];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "LoadUCIDChatToCallback", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_LoadUCIDChatToCallback()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get CIF From Custom Data Table
function custom_UpdateChatToCallback(interactionid, ucid, sessionid) {
    try {
        var parameters = [global_DeviceID, interactionid, "UpdateUCIDChatToCallbackEvent", ucid, sessionid];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "UpdateUCIDChatToCallback", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_UpdateChatToCallback()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get CIF From Custom Data Table
function custom_GetVASessionIDForCallback(intid, cif, chatsessionid, srno) {
    try {
        var parameters = [global_DeviceID, intid, "GetVASessionIDForCallbackEvent", cif, chatsessionid, srno];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetVASessionIDForCallback", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_GetVASessionIDForCallback()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Changes for Digibank Enhancement
//Custom Get Data
function custom_getTextChatData(intid, cif, textchatsessionid) {
    try {
        var parameters = [global_DeviceID, intid, "GetTextChatDataEvent", cif, textchatsessionid];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetTextChatData", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getTextChatData()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get Details for CIF
function custom_getdetailsforCIF(intid, srno) {
    try {
        var parameters = [global_DeviceID, intid, "GetDetailsForCIFEvent", srno, global_AgentID];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "GetDetailsForCIF", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getdetailsforCIF()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Added By Ajith For Nice Integrtion
function custom_PushMessageToNICE(intid, ucid) {
    try {
        var parameters = [intid, ucid];
        Custom_InvokeFunction("NICEIntegrationCustomLayer.dll", "NICEIntegrationCustomLayer.NICEIntegrationLayer", "PushMessageToNICE", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_PushMessageToNICE()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get Details for CIF
function custom_closeRequest(intid, srno, comments) {
    try {
        var parameters = [global_DeviceID, intid, "CloseRequestEvent", srno, global_AgentID, comments];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "CloseRequest", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_closeRequest()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom submit
function custom_submitMultipleScheduleCallback(status, srno, startDate, hour, min, intid, callbackdate, callbacktime, type, prefNumber, rowid, comments) {
    try {
        var parameters = [global_DeviceID, intid, "submitScheduleCallbackEvent", status, srno, startDate, hour, min, callbackdate, callbacktime, type, prefNumber, rowid, comments];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "SubmitScheduleCallback", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_submitMultipleScheduleCallback()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom updateDialDateTimeForCallback
function custom_updateDialDateTimeForCallback(intid, srno) {
    try {
        var parameters = [global_DeviceID, intid, "updateDialDateTimeForCallbackEvent", srno];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "UpdateDialDateTimeForCallback", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_updateDialDateTimeForCallback()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Custom Get Details for Srno
function custom_getdetailsforSrno(intid, srno) {
    try {
        var parameters = [global_DeviceID, intid, "GetDetailsForSrnoEvent", srno, global_AgentID];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.SIPDialerIntegration", "GetDetailsForSrno", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_getdetailsforSrno()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
//Update Date & Time for callback
function custom_updateDataOnConnectForCallback(intid, srno) {
    try {
        var parameters = [global_DeviceID, intid, "UpdateDataOnConnectForCallbackEvent", srno, global_AgentID];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.SIPDialerIntegration", "UpdateDataOnConnectForCallback", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_updateDataOnConnectForCallback()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_UpdateVasessionIdForTextChat(intid, ucid, vasessionid) {
    try {
        var parameters = [global_DeviceID, intid, "UpdateVasessionIdForTextChatEvent", ucid, vasessionid];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "UpdateVasessionIdForTextChat", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_UpdateVasessionIdForTextChat()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_UpdateAgentIdForCallbackTransfer(srno, intid) {
    try {
        var parameters = [global_DeviceID, intid, "UpdateAgentIdForCallbackTransferEvent", srno, global_AgentID];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "UpdateAgentIdForCallbackTransfer", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_UpdateAgentIdForCallbackTransfer()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_UpdateCustomTableForCallbackTransfer(srno, intid) {
    try {
        var parameters = [global_DeviceID, intid, "UpdateCustomTableForCallbackTransferEvent", srno, global_AgentID];
        Custom_InvokeFunction("CallbackCustomLayer.dll", "CallbackCustomLayer.CallbackLayer", "UpdateCustomTableForCallbackTransfer", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_UpdateCustomTableForCallbackTransfer()", ex, false);
    }
}

//----------------------------------------- Custom Update Interaction History -----------------------------------
function custom_TextChatCsatSurvey(intid, ucid, segment, lanid, cin, cinSuffix, intent, channel, brand) {
    try {
        var parameters = [global_DeviceID, intid, "TextChatCSATSurveyEvent", ucid, segment, lanid, cin, cinSuffix, intent, channel, brand];
        Custom_InvokeFunction("AMACWebCustomerLayer_Generic.dll", "AMACWebCustomerLayer_Generic.TextChatCustomClass", "TextChat_CsatSurvey", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_TextChatCsatSurvey()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_LoadVAChatHistory1(deviceid, intid) {
    try {
        var cif = $("#hfTextChatKcin" + intid).val();
        var parameters = [global_DeviceID, intid, "LoadVAChatHistoryEvent", cif, global_LanID];
        Custom_InvokeFunction("AMACWebCustomerLayer_Generic.dll", "AMACWebCustomerLayer_Generic.TextChatCustomClass", "TextChat_LoadVAChatHistory", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_LoadVAChatHistory()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_cin(kcin) {
    try {
        var parameters = [kcin];
        Custom_InvokeFunction("AMACWebCustomerLayer_Generic.dll", "AMACWebCustomerLayer_Generic.TextChatCustomClass", "TextChat_RetrieveCin", parameters);
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_cin()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_EnrollCustomer(intid) {
    try {
        let parameters = [global_DeviceID, intid];
        Custom_InvokeFunction("TetherfiVoiceRecorderIntegrationLib.dll", "TetherfiVoiceRecorderIntegrationLib.CallSessionManager", "EnrollCustomer", parameters, { callbackFunction: "EnrollCustomer" });
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_EnrollCustomer()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_UpdateVBNric(intid, nric) {
    try {
        let parameters = [global_DeviceID, intid, nric];
        Custom_InvokeFunction("TetherfiVoiceRecorderIntegrationLib.dll", "TetherfiVoiceRecorderIntegrationLib.CallSessionManager", "UpdateNric", parameters, { callbackFunction: "UpdateVBNric", NRIC: nric });
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_EnrollCustomer()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_OptOutEnrollment(intid, nric) {
    try {
        let parameters = [global_DeviceID, intid];
        Custom_InvokeFunction("TetherfiVoiceRecorderIntegrationLib.dll", "TetherfiVoiceRecorderIntegrationLib.CallSessionManager", "DeleteEnrollment", parameters, { callbackFunction: "OptOutEnrollment" });
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_OptOutEnrollment()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_RejectEnrollment(intid, nric) {
    try {
        let parameters = [global_DeviceID, intid];
        Custom_InvokeFunction("TetherfiVoiceRecorderIntegrationLib.dll", "TetherfiVoiceRecorderIntegrationLib.CallSessionManager", "Reject", parameters, { callbackFunction: "RejectEnrollment" });
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_RejectEnrollment()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_ThirdPartyEnrollment(intid, nric) {
    try {
        let parameters = [global_DeviceID, intid];
        Custom_InvokeFunction("TetherfiVoiceRecorderIntegrationLib.dll", "TetherfiVoiceRecorderIntegrationLib.CallSessionManager", "ThirdParty", parameters, { callbackFunction: "ThirdPartyEnrollment" });
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_ThirdPartyEnrollment()", ex, false);
    }
}

//---------------------------------------------------------------------------------------------------------------
function custom_CheckAgentStaffed() {
    try {
        let parameters = [global_AgentID];
        Custom_InvokeFunction("TetherfiVoiceRecorderIntegrationLib.dll", "TetherfiVoiceRecorderIntegrationLib.CallSessionManager", "CheckAgentStaffed", parameters, { callbackFunction: "CheckAgentStaffed" });
    } catch (ex) {
        log.LogDetails("Error", "CustomCommand.custom_CheckAgentStaffed()", ex, false);
    }
}