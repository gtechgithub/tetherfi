﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var file_versions = [];
var filename = "CommonUI.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
//remote logger instance
var log = new Logger();
$(document).ready(function () {
    console.log('common ui loaded');
});
// ----------------------------------------------------------------------------------
// Get the Dynamic CRM Resilution and Position
// ----------------------------------------------------------------------------------
function DynamicsCRMScreenResolution_Width() {
    try {
        // Is my Tmac occupied max [more than 75% of the Screen ?], in this case , cRM window will take Fulll Width.	
        if ((Application_Window_Current_Width * 100) / screen.width > 75) return screen.width - 50;
        else return screen.width - Application_Window_Current_Width - 40;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DynamicsCRMScreenResolution_Width()", ex, false);
    }
}

function DynamicsCRMScreenResolution_Height() {
    try {
        //var height=(CalculateWindowHeight()*Application_window_height_Percentage)/100
        return Application_Window_Current_Height;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DynamicsCRMScreenResolution_Height()", ex, false);
    }
}

function DynamicsCRMScreenResolution_Position_Left() {
    try {
        //return DynamicsCRMScreenResolution_Width()+80;
        return Application_Window_Current_Width + 20;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DynamicsCRMScreenResolution_Position_Left()", ex, false);
    }
}

function DynamicsCRMScreenResolution_Position_Top() {
    return 0;
}

// ----------------------------------------------------------------------------------
// All the Coomon Utilities/Functions related to the TMAC Goes here ...
// ----------------------------------------------------------------------------------
function global_addVersions(file, version) {
    try {
        var val = file + ":" + version;
        if (file_versions !== undefined) {
            if (file_versions.indexOf(val) < 0) {
                file_versions.push(val);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.global_addVersions()", ex, false);
    }
}

function ShowVersionDetails() {
    try {
        file_versions.sort();
        $("#version_table_tbody").html("");
        let innerHtml = "";
        let arraylenfgth = file_versions.length;
        let str = "<tr><td> " + global_AssemblyVersion.substr(0, global_AssemblyVersion.indexOf(":")) + "</td><td>" + global_AssemblyVersion.substr(global_AssemblyVersion.indexOf(":")) + "</td></tr>";
        for (var i = 0; i < arraylenfgth; i++) {
            $("#version_table_tbody").append("<tr><td>" + file_versions[i].substr(0, file_versions[i].indexOf(":")) + "</td><td>" + file_versions[i].substr(file_versions[i].indexOf(":") + 1) + "</td></tr>");
        }
        innerHtml = "<div class='uk-text-small custom-padding'>" +
            "<p><b>TMAC Server</b>:<br/>" + _tmacServer + "</p>" +
            "<p><b>TMAC Proxy</b>:<br/>" + global_connectedProxy + "</p>" +
            "<p><b>SignalR Server</b>:<br/><span id='signalRVersion'>" + (signalRVersion == undefined ? "NA" : signalRVersion) + "</span></p></div>";
        $("#div_version_info").html(innerHtml);
        UIkit.modal("#model_version_info").show();
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.ShowVersionDetails()", ex, false);
    }
}
// ---------------------------------------------------------------------------------------
// This method will Convert current Widow width to pixel width based on Percentage we set
// ---------------------------------------------------------------------------------------
function CalculateTMACWindowWidth() {
    try {
        var current_screen_width = screen.width;
        if (isApplication_window_size_type_pixel == true) {
            Application_Window_Current_Width = Application_window_width;
        }
        else {
            Application_Window_Current_Width = (current_screen_width * Application_window_width) / 100;
        }
        return Application_Window_Current_Width;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.CalculateTMACWindowWidth()", ex, false);
    }
}

// ---------------------------------------------------------------------------------------
// This method will Convert current window Height to pixel Height based on Percentage we set
// ---------------------------------------------------------------------------------------
function CalculateTMACWindowHeight() {
    try {
        var current_screen_height = screen.height;
        if (isApplication_window_size_type_pixel == true) {
            Application_Window_Current_Height = Application_window_height;
        }
        else {
            Application_Window_Current_Height = (current_screen_height * Application_window_height) / 100;
        }
        return Application_Window_Current_Height;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.CalculateTMACWindowHeight()", ex, false);
    }
}

//-------------- Connectivity Status -------------------------
function SetConnectivityStatus(status) {
    try {
        var date = new Date();
        try {
            date = moment(date).format("DD/MM/YYYY, HH:mm:ss");
            $("#ui_tmac_clock_span").text(date);
        } catch (ex) {
            log.LogDetails("Error", "CommonUI.SetConnectivityStatus() - Inside1", ex, false);
        }

        try {
            if ((status === 0 || status === 1) && $("#ui_tmac_logo").hasClass("blink_status")) {
                $("#ui_tmac_logo").removeClass("blink_status");
            }
            //status - 0,1,2
            if (status === 0)
                isVoiceBio ? $("#favicon").attr("href", "assets/img/voice_bio_success.png") : $("#img_mainlogo").attr("src", "assets/img/logo_normal.png");
            else if (status === 1)
                isVoiceBio ? $("#favicon").attr("href", "assets/img/voice_bio_success.png") : $("#img_mainlogo").attr("src", "assets/img/logo_online.png");
            else if (status === 2) {
                isVoiceBio ? $("#favicon").attr("href", "assets/img/voice_bio_failed.png") : $("#img_mainlogo").attr("src", "assets/img/logo_offline.png");
                $("#ui_tmac_logo").addClass("blink_status");
            }
        } catch (ex) {
            log.LogDetails("Error", "CommonUI.SetConnectivityStatus() - Inside2", ex, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.SetConnectivityStatus()", ex, false);
    }
}

//-------------------------------------- Get Current Date in YYYYMMDD Format -------------------------------------------
function GetCurrentDate() {
    try {
        var d = new Date,
            date = (("00" + d.getDate()).slice(-2) + "/" + ("00" + (d.getMonth() + 1)).slice(-2) + "/" + d.getFullYear());
        return date;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetCurrentDate()", ex, false);
    }
}

//-------------------------------------- Get Current Time in HHMMSS Format -------------------------------------------
function GetCurrentTime() {
    try {
        var d = new Date,
            time = (("00" + d.getHours()).slice(-2) + ":" + ("00" + d.getMinutes()).slice(-2) + ":" + ("00" + d.getSeconds()).slice(-2));
        return time;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetCurrentTime()", ex, false);
    }
}

//-------------------------------------- Format Date -------------------------------------------
function FormatDate(date) {
    try {
        return CheckForDay(date);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.FormatDate()", ex, false);
    }
}

function CheckForDay(date) {
    try {
        let dateTime = moment(new Date(date)).format("YYYYMMDD");
        let yesterday = moment(new Date()).add(-1, 'days').format("YYYYMMDD");
        let today = moment(new Date()).format("YYYYMMDD");
        let tomorrow = moment(new Date()).add(1, 'days').format("YYYYMMDD");
        switch (dateTime) {
            case yesterday:
                return "Yesterday at " + moment(date).format("hh:mma");
                break;
            case today:
                return "Today at " + moment(date).format("hh:mma");
                break;
            case tomorrow:
                return "Tomorrow at " + moment(date).format("hh:mma");
                break;
            default:
                return moment(new Date(date)).format("MMMM DD, YYYY") + " at " + moment(date).format("hh:mma");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.CheckForDay()", ex, false);
    }
}

//------------------Get the current Date and Time to display in Chat Transcript-----------------------------------
function GetCurrentDateTime() {
    return GetCurrentDate() + " " + GetCurrentTime();
}

// ------------------------------------------------------------------------------------------
// Insert text inside Textbox at current Cursor Position
// ------------------------------------------------------------------------------------------
function InsertTextAtCurrentCursorPosition(textboxCntl, textToInsert) {
    try {
        var cursorPos = $("#" + textboxCntl).prop('selectionStart');
        var v = $("#" + textboxCntl).val();
        var textBefore = v.substring(0, cursorPos);
        var textAfter = v.substring(cursorPos, v.length);
        $("#" + textboxCntl).val(textBefore + textToInsert + textAfter);
        $("#" + textboxCntl).focus();
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.InsertTextAtCurrentCursorPosition()", ex, false);
    }
}

// --------------------------------------add a method to global timer loop-------------------------------------------------
function AddMethodToTimerLoop(deviceid, intid, methodName, data) {
    try {
        var object = {};
        object.data = data;
        object.methodName = methodName;
        object.deviceid = deviceid;
        object.intid = intid;
        global_timeoutFunctions.push(object);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.AddMethodToTimerLoop()", ex, false);
    }
}

//-------------------------------show notification alert--------------------------------------------
function ShowNotify(message, status, group, pos) {
    try {
        if (isVTM) {
            pos = "bottom-center";
        }
        if (isVoiceBio && !$(".an-loader").hasClass("uk-display-none")) {
            $(".an-loader").addClass("uk-display-none");
        }
        var thisNotify = UIkit.notify({
            message: message ? message + '<a href="#" class="notify-action">X</a>' : '',
            status: status ? status : '',
            timeout: notifyTimeout ? notifyTimeout : 3000,
            group: group ? group : null,
            pos: pos ? pos : 'top-center',
            onClose: function () {
                $body.find('.md-fab-wrapper').css('margin-bottom', '');
                // clear notify timeout (sometimes callback is fired more than once)
                clearTimeout(thisNotify.timeout);
            }
        });
        if ((($window.width() < 768) && ((thisNotify.options.pos == 'bottom-right') || (thisNotify.options.pos == 'bottom-left') ||
            (thisNotify.options.pos == 'bottom-center'))) || (thisNotify.options.pos == 'bottom-right')) {
            var thisNotify_height = $(thisNotify.element).outerHeight();
            var spacer = $window.width() < 768 ? -6 : 8;
            $body.find('.md-fab-wrapper').css('margin-bottom', thisNotify_height + spacer);
        }
        if (isVoiceBio && !$(".uk-notify").hasClass("uk-notify-vb")) {
            $(".uk-notify").addClass("uk-notify-vb");
        }
        AddMessageAlerts(status, message);
        log.LogDetails(status == "danger" ? "Error" : status == "" ? "info" : status, "CommonUI.AddMessageAlerts()", message, false);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.ShowNotify()", ex, false);
    }
}

//-------------------------------add alerts to the array--------------------------------------------
function AddMessageAlerts(status, message) {
    try {
        //type of message success,warning, danger or primary
        var messagetype = "";
        switch (status) {
            case "success":
                messagetype = "uk-text-success";
                break;
            case "warning":
                messagetype = "uk-text-warning";
                break;
            case "danger":
                messagetype = "uk-text-danger";
                break;
            default:
                messagetype = "uk-text-primary";
                break;
        }
        //creat the li of alert
        var alertManagerHtml = '<li class="uk-text-bold ' + messagetype + '">' + message + " - " + GetCurrentDateTime() + '</li>';
        //append to the array
        recentAlerts.push(alertManagerHtml);
        $("#btnrecentalerts i").text("notifications_active");
        $("#btnrecentalerts i").addClass("wiggle");
        let recentAlertCount = parseInt($("#recentAlertCount").text());
        $("#recentAlertCount").text(++recentAlertCount);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.AddMessageAlerts()", ex, false);
    }
}
//disable load more button
function DisableLoadMoreButton(intId) {
    try {
        var loadmorebuttonid = "#loadMoreInteraction" + intId;
        $(loadmorebuttonid).addClass('uk-icon-spin icon-disabled');
        $(loadmorebuttonid).parent().css("cursor", "not-allowed");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableLoadMoreButton()", ex, false);
    }
}

//enable load more button
function EnableLoadMoreButton(intId) {
    try {
        var loadmorebuttonid = "#loadMoreInteraction" + intId;
        $(loadmorebuttonid).removeClass('uk-icon-spin icon-disabled');
        $(loadmorebuttonid).parent().css("cursor", "");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableLoadMoreButton()", ex, false);
    }
}

//-------------------------enable tab close button-----------------------------------
function EnableTabCloseButton(intid) {
    try {
        $('#divCloseButton' + intid).css("display", "inline");
        $('#btnCloseTab' + intid).css("display", "");
        $('#btnCloseTab' + intid).removeAttr('disabled', 'disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableTabCloseButton()", ex, false);
    }
}

//------------------------------------enable/disable callback dial buttons--------------------------------
function EnableCallbackDialButtons(intid) {
    //check if this is a callback tab. Then enable both PCN dial and CID buttons
    try {
        if (GetTabReferenceObj(intid).type.indexOf("callback") !== -1) {
            $('#btnDialCallerID' + intid).removeClass('disabled');
            $('#btnDialPCN' + intid).removeClass('disabled');
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableCallbackDialButtons()", ex, false);
    }
}

function DisableCallbackDialButtons(intid) {
    try {
        $('#btnDialCallerID' + intid).addClass('disabled');
        $('#btnDialPCN' + intid).addClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackDialButtons()", ex, false);
    }
}

//------------------------------------enable/disable callback submit buttons--------------------------------
function DisableCallbackSubmitButtons(intid) {
    try {
        $('#btnSubmit' + intid).addClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackSubmitButtons()", ex, false);
    }
}

function EnableCallbackSubmitButtons(intid) {
    try {
        $('#btnSubmit' + intid).removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackSubmitButtons()", ex, false);
    }
}

//------------------------------------enable/disable callback details buttons--------------------------------
function DisableCallbackDetailsButtons(intid) {
    try {
        $('#btnDetail' + intid).addClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackDetailsButtons()", ex, false);
    }
}

function EnableCallbackDetailsButtons(intid) {
    try {
        $('#btnDetail' + intid).removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableCallbackDetailsButtons()", ex, false);
    }
}

//------------------------------------disable callback buttons--------------------------------
function DisableCallbackButtons(intid) {
    try {
        //disable callback dial buttons
        DisableCallbackDialButtons(intid);
        //disable callback submit button
        DisableCallbackSubmitButtons(intid);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableCallbackButtons()", ex, false);
    }
}
//---------------------------------------------- Enable/Disable Logout Button ------------------------------------------------------
function FadeOutButton(buttonId) {
    try {
        if (buttonId == "#btn_change_status") {
            $(buttonId).parent().addClass("disable-aux");
        }
        else {
            $(buttonId).addClass('disabled');
            $(buttonId).parent().css("cursor", "not-allowed");
            $(buttonId).fadeTo("fast", 0.3);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableLogoutButton()", ex, false);
    }
}

function FadeInButton(buttonId) {
    try {
        if (buttonId == "#btn_change_status") {
            $(buttonId).parent().removeClass("disable-aux");
        }
        else {
            $(buttonId).removeClass('disabled');
            $(buttonId).parent().css("cursor", "");
            $(buttonId).fadeTo("fast", 1);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.FadeInButton()", ex, false);
    }
}
//----------------------------------------------Enable/Disable Transfer to IVR Button ------------------------------------------------------
function DisableTransferToIVR(intId) {
    try {
        $('#btn_ddlTransferToIVR' + intId).addClass('disabled');
        $("#btn_ddlTransferToIVR" + intId).parent().css("pointer-events", "none");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableTransferToIVR()", ex, false);
    }
}

function EnableTransferToIVR(intId) {
    try {
        $('#btn_ddlTransferToIVR' + intId).removeClass('disabled');
        $("#btn_ddlTransferToIVR" + intId).parent().css("pointer-events", "");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableTransferToIVR()", ex, false);
    }
}

//----------------------------------------------Enable/Disable Transfer Button and dialog buttons------------------------------------------------------
function EnableButton(buttonId, item, type) {
    try {
        if (type == "tag")
            $(buttonId).html(item);
        else if (type == "icon")
            $(buttonId).html('<i class="material-icons sm-24 md-light">' + item + '</i>');
        $(buttonId).removeClass("disabled");
        $(buttonId).fadeTo("fast", 1);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.EnableButton()", ex, false);
    }
}

function DisableButton(buttonId) {
    try {
        $(buttonId).addClass("disabled");
        //$(buttonId).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
        $(buttonId).html('<i class="material-icons sm-24 md-light uk-icon-spin">sync</i>');
        $(buttonId).fadeTo("fast", 0.3);
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.DisableButton()", ex, false);
    }
}

//----------------------------------------------Enable/Disable conf Button ------------------------------------------------------
function ShowKendoLoading(target) {
    var element = $(target);
    kendo.ui.progress(element, true);
}

function HideKendoLoading(target) {
    var element = $(target);
    kendo.ui.progress(element, false);
}

function PreviewAttachment(src) {
    $("#btn_refresh_cobrowse").addClass("uk-display-none");
    $("#imagePreviewImg").attr("src", src);
    UIkit.modal("#modal_previewImage").show();
}

function SecondsTimeSpanToMS(s) {
    try {
        var h = Math.floor(s / 3600); //Get whole hours
        s -= h * 3600;
        var m = Math.floor(s / 60); //Get remaining minutes
        s -= m * 60;
        return (m < 10 ? '0' + m : m) + ":" + (s < 10 ? '0' + s : s); //zero padding on minutes and seconds
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.SecondsTimeSpanToMS()", ex, false);
    }
}

//function to load url into an iframe
function LoadIFrame(iframeName, url) {
    try {
        var $iframe = $("#" + iframeName);
        if ($iframe.length) {
            $iframe.attr('src', url);
            return false;
        }
        return true;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.LoadIFrame()", ex, false);
    }
}

function SmallVideoScreen() {
    try {
        $("#video_call_dialog").data("kendoWindow").wrapper.css({
            width: '30%',
            height: '30%'
        });
        $("#btnMuteAudio").hide();
        $("#btnMuteVideo").hide();

        $("#btn_small_video").css("display", "none");
        $("#btn_minimize_video").css("display", "none");
        $("#btn_maximize_video").css("display", "none");
        $("#btn_large_video").css("display", "inline-flex");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.SmallVideoScreen()", ex, false);
    }
}

function BigVideoScreen() {
    try {
        $("#video_call_dialog").data("kendoWindow").wrapper.css({
            width: '50%',
            height: '50%'
        });
        $("#btnMuteAudio").show();
        $("#btnMuteVideo").show();

        $("#btn_large_video").css("display", "none");
        $("#btn_minimize_video").css("display", "inline-flex");
        $("#btn_maximize_video").css("display", "inline-flex");
        $("#btn_small_video").css("display", "inline-flex");
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.BigVideoScreen()", ex, false);
    }
}

function CheckForForms(text, intid) {
    var html = text;
    try {
        if (IsFormExist(text)) {
            var nUrl = StartCobrSession(global_AgentName, $('#divCustomerName' + intid).text(), GetCobrowseUrl(text), intid);
            //html = '<a href=' + '"' + nUrl + '"' + '  target="_blank">Open Form</a>';
            html = '<a href="#" onclick="OpenFormFillingDialog(\'' + nUrl + '\');">Open Form</a>';
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.CheckForForms()", ex, false);
    }
    return html;
}

function IsFormExist(text) {
    var isExist = false;
    try {
        $.each(forms, function (i, val) {
            if (val.name === text)
                isExist = true;
            return;
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.IsFormExist()", ex, false);
    }
    return isExist;
}

function GetCobrowseUrl(name) {
    try {
        var obj = $.grep(forms, function (e) { return e.name == name; });
        var url = obj[0].url;
        return url;
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetCobrowseUrl()", ex, false);
    }
}

function StartCobrSession(agentName, customerName, pageUrl, tmacSessionId) {
    try {
        var base = pageUrl + "#&togetherjs=" + tmacSessionId + "&cobruser=";
        OpenFormFillingDialog(encodeURI(base + global_AgentID));
        return encodeURI(base + global_AgentID);
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.StartCobrSession()", ex, false);
    }
}

function OpenFormFillingDialog(url) {
    try {
        LoadIFrame("formFillingIframe", url);
        $("#from_filling_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenFormFillingDialog()", ex, false);
    }
}

function StartWhiteboardSession(intid) {
    try {
        UIkit.modal.confirm("Do you want to share whiteboard?",
            function () {
                let msg = "";
                let msgid = uuid();
                let obj = {};
                obj.id = msgid;
                obj.message = whiteboardUrl;
                obj.messageType = "whiteboard";
                obj.type = "new";
                msg = JSON.stringify(obj);
                SendTextChat(global_DeviceID, intid, msg);
                OpenWhiteBoard(whiteboardUrl);
            },
            function oncancel() { });
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.StartWhiteboardSession()", ex, false);
    }
}

function OpenWhiteBoard(url) {
    try {
        LoadIFrame("whiteboardIframe", url);
        $("#whiteboard_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.OpenWhiteBoard()", ex, false);
    }
}

function GetTabHtml(templateId, intid, customData) {
    try {
        var t = $("#" + templateId).html(), //template divs
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                intid: intid,
                deviceid: global_DeviceID
            }; //add context data

        if (customData !== null) {
            $.each(customData, function (i, val) {
                context[i] = val;
            });
        }

        return template = n(context); //execute the template with handlebar and context
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.GetTabHtml()", ex, false);
    }
}
//----------------------------------------------Encrpty string------------------------------------------------------
function ToEncodedString(ostr) {
    try {
        ostr = ostr.replace(/\s+/g, '');
        var x, nstr = '',
            len = ostr.length;
        for (x = 0; x < len; ++x) {
            nstr += (255 - ostr.charCodeAt(x)).toString(36).toUpperCase();
        };
        return nstr;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.ToEncodedString()", ex, false);
    }
}

function FromEncodedString(ostr) {
    try {
        var x, nstr = '', len = ostr.length;
        for (x = 0; x < len; x += 2) {
            nstr += String.fromCharCode(255 - parseInt(ostr.substr(x, 2), 36));
        };
        return nstr;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.FromEncodedString()", ex, false);
    }
    return ostr;
}

var sort_by = function (field, reverse, primer) {
    try {
        var key = primer ?
            function (x) {
                return primer(x[field])
            } :
            function (x) {
                return x[field]
            };

        reverse = !reverse ? 1 : -1;

        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.sort_by()", ex, false);
    }
}

function uuid() {
    try {
        //0f8fad5b-d9cb-469f-a165-70867728950e
        var x = document.getElementById("demo")
        var possible = "0a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z";
        var guid = "";
        for (var i = 1; i <= 32; i++) {
            var randChar = possible.charAt(Math.floor(Math.random() * possible.length));
            guid += randChar;
            if (i === 8 || i === 12 || i === 16 || i === 20)
                guid += "-";
        }
        return guid;
    } catch (ex) {
        log.LogDetails("Error", "CommonUI.uuid()", ex, false);
    }
}