﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TmacChatUI.js";
var file_version = "3.0.10.16";
var changedBy = "Sirajuddin"
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

//-----------------------------------------------Flash Chat Events ---------------------------------------------------
//--------------------------------------add a chat tab-------------------------------------------------------
function chat_newChatReceived(data) {
    //add chat tab
    chat_addChatTab(data.InteractionID, data.PhoneNumber);

    //save the interaction id
    $("#hfChatANI" + data.InteractionID).val(data.PhoneNumber);

    //enable answer button
    $('#btnChat_Answer' + data.InteractionID).toggle(true);
}

//--------------------------------------add a chat tab-------------------------------------------------------
//add a chat tab
function chat_addChatTab(intid, phonenumber) {


    var tabs = $("#tabs").tabs();
    var ul = tabs.find("ul");

    //get html for voice tab
    var tempChatTabContent = document.getElementById('divChatTabBody').innerHTML;

    //set interaction id for voice tab
    var chatTabContent = tempChatTabContent.replace(/_CHAT_INTID/g, intid);
    //tab header content
    var tmpTabHeaderContent = document.getElementById('divVoiceTabHeader').innerHTML;

    //set interaction id for voice tab header
    var tabHeaderContent = tmpTabHeaderContent.replace(/_INTID/g, intid);

    $("<li id=li_" + intid + "  style='width:100px;'><a href='#" + intid + "'><div>" + tabHeaderContent + "</div></a></li>").appendTo(ul);

    //tab body content
    $(" <div id=" + intid + " style='border: 1px solid #a8a8a8;padding:0px;'>" + chatTabContent + "</div>").appendTo(tabs);

    //Hide the wallboard
    hideHomepage();

    //refresh the tab container
    tabs.tabs('refresh');

    //set the newly added tab active
    $("#tabs").tabs('option', 'active', global_tabCount);
    global_tabCount++;

    //bind the intent list for this tab
    //amacUI.js
    bindIntentList(intid);

    //set tab header details
    $('#divCustomerName' + intid).text(phonenumber);

    //resize the window 
    //window.resizeTo(410, 1200);

    //create interaction history grid
    //amacUI.js
    //CreateInteractionHistoryGrid(intid);

    //show answer button
    //hide chat sent button and chat text box

    setChatControlVisibility(intid, true, false, false, false);

    //create chat accordian
    $("#chatAccordian" + intid).accordion();
}


//--------------------------------------set chat control visibility-------------------------------------------------------
function setChatControlVisibility(intid, answer, send, drop, vdo) {
    $('#btnChat_Answer' + intid).toggle(answer);
    $('#btnChatSend' + intid).toggle(send);
    $('#txtChatMessage' + intid).toggle(send);
    $('#btnChat_Disconnect' + intid).toggle(drop);
    $('#btnChat_Video' + intid).toggle(vdo);
}


//--------------------------------------chat call answered-------------------------------------------------------
function chat_callAnswered(data) {

    //hide answer button
    //hide chat sent button and chat text box

    setChatControlVisibility(data.InteractionID, false, false, false, false);

    //load the flash component
    //connect to video server
    //bridge
    //chatAPI.js
    chatAPI_loadAPI(data.InteractionID);
}

//--------------------------------------chat connection closed-------------------------------------------------------
function chat_ConnectionClosed(intid) {

    //chat ended
    //disable the ui controls

    setChatControlVisibility(intid, false, false, false, false);


    //enable tab close button
    //$('#btnCloseTab' + intid).removeAttr('disabled', 'disabled');

    EnableTabCloseButton(intid);
}

//--------------------------------------bridge me success-------------------------------------------------------
function chat_Bridge_Success(eventdata, intid) {

    var video = "0";
    var audio = "0";


    //check audio/video availability
    var parts = eventdata.split("|");

    if (parts.length > 1) {
        if (parts[1].length > 1) {
            video = parts[1].substring(0, 1);
            audio = parts[1].substring(1, 2);
        }
    }

    var videovisible = false;
    if (global_agentCamera == "1" && video == "1")
        videovisible = true;

    //set control visibility
    setChatControlVisibility(intid, false, true, true, videovisible);


    //parse data and bind
    //call server to handle bridge data
    //commandManager.js
    Chat_BridgeSuccess(global_DeviceID, intid, eventdata);
}

//-------------------------------------send chat message-------------------------------------------------------
function chat_send(intid) {
    //message
    var msg = $("#txtChatMessage" + intid).val();
    //chatAPI.js
    sendTextFlash(msg, intid);

    //update chat transcript in DB
    //commandManager.js
    Chat_TextSent(global_DeviceID, intid, msg);

    var agentHtml = '<div class="chatSend">' + msg + '</div><br><div class="chatDate" style="text-align:right;">' + GetCurrentDateTime() + '</div>';

    $("#divChatTranscript" + intid).html($("#divChatTranscript" + intid).html() + agentHtml + '<br>');

    $("#txtChatMessage" + intid).val("");
}

//-------------------------------------send chat message done-------------------------------------------------------
function chat_agnetTextSent(intid) {
    //add last text to chat transcript
    //alert('chat_agnetTextSent');
}

//-------------------------------------chat message received-------------------------------------------------------
function chat_messageReceived(txt, intid) {

    //add text to chat transcript

    //update chat transcript in DB
    //commandManager.js
    Chat_TextReceived(global_DeviceID, intid, txt);

    //send ack
    var msgId = txt.substring(0, 4);

    //chatAPI.js
    SendAppMessage("textRecvdAck", msgId, intid);

    var userHtml = '<div class="chatRecieve">' + txt.substring(4) + '</div><br><div class="chatDate" style="text-align:left;">' + GetCurrentDateTime() + '</div>';
    $("#divChatTranscript" + intid).html($("#divChatTranscript" + intid).html() + userHtml + '<br>');
}

//-------------------------------------disconnect chat call-------------------------------------------------------
function chat_endChat(intid) {
    //disconnect the voice call
    DisconnectCall(global_DeviceID, intid)

    //chatAPI.js
    chatApi_endCall(intid);
}

//-------------------------------------send video request-------------------------------------------------------
function chat_sendVideoRequest(intid) {
    //chatAPI.js
    SendAppMessage("rqVideo", "", intid);
}