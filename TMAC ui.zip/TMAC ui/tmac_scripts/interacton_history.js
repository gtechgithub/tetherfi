// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "InteractionHistory.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    //global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------
// A $( document ).ready() block.
$(document).ready(function () {
    console.log("Interaction history loaded");
});
var jsonData;
var initialJsonData;
var global_referenceId = "";
var global_agent = "";
var global_interactionReference = [];

var sort_by = function (field, reverse, primer) {
    try {
        var key = primer ?
            function (x) {
                return primer(x[field])
            } :
            function (x) {
                return x[field]
            };

        reverse = !reverse ? 1 : -1;

        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.sort_by()", ex, false);
    }
}

function AddInteractionReference(id, type, channel) {
    try {
        var obj = {};
        obj.id = id;
        obj.type = type;
        obj.channel = channel;

        global_interactionReference[id] = obj;
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.AddInteractionReference()", ex, false);
    }
}

function AddInteraction(data, intid) {
    try {
        if (data.length > 0) {
            initialJsonData = data;
            data.sort(sort_by('ItemID', false, parseInt));
            jsonData = data;
            if (jsonData !== undefined)
                $.each(jsonData, function (i, val) {
                    var id = val.ID + intid;
                    var channel = val.Channel;

                    if (global_referenceId == "") {
                        global_referenceId = id;
                        AddInteractionReference(id, "new", channel);
                    } else {
                        if (id == global_referenceId)
                            global_interactionReference[id].type = "old";
                        else {
                            global_referenceId = id;
                            AddInteractionReference(id, "new", channel);
                        }
                    }
                    switch (channel.toLowerCase()) {
                        case "voice":
                            //create voice div
                            CreateVoiceDiv(val, intid);
                            break;

                        case "chat":
                        case "textchat":
                            //create chat div                    
                            CreateChatDiv(val, intid);
                            break;

                        case "email":
                            //create email div
                            break;

                        default:
                            console.log("No channel: " + val);
                            break;
                    }
                });
            $("#timeline" + intid).AscSortDivs();
            $("#md_history_div_loader" + intid).toggle();
            altair_helpers.hierarchical_slide('#timeline' + intid);
            $("#timeline" + intid).show();
            $("#expand" + intid).toggle(true);
            $("#sorting" + intid).toggle(true);
            $("#loadMoreInteraction" + intid).toggle(true);
        }
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.AddInteraction()", ex, false);
    }
}

function CreateVoiceDiv(obj, intid) {
    try {
        var id = obj.ID + intid;
        var itemId = obj.ItemID + "_" + id + "_" + intid;
        var interactionText = obj.InteractionText;
        var interactionDate = obj.InteractionDate;
        var direction = obj.Direction;
        var phoneNo = obj.PhoneNumber;
        var intent = obj.Intent;

        var phoneNoSpan = "";
        var intentSpan = "";
        var typeSpan = "";

        if (global_interactionReference[id].type == "new") {
            var dateSpan = '<span class="uk-text-danger">' + interactionDate + '</span>';
            var directionSpan = "";
            var mainSpan = "";
            var timelineIcon = "";
            if (direction == "In")
                directionSpan = '<span class="uk-badge uk-badge-primary">' + direction + '</span>';
            else
                directionSpan = '<span class="uk-badge uk-badge-danger">' + direction + '</span>';
            mainSpan = '<span>' + directionSpan + '&nbsp;Voice with agent</span>';
            var timeline_item = '<div class="timeline_item" id="timeline_item' + id + '" data-sort=' + id + '></div>';
            timelineIcon = '<div class="timeline_icon md-bg-green-700" id="timelineicon' + id + '"><i class="material-icons">local_phone</i></div>';
            var timeline_date = '<div class="timeline_date" id="timeline_date' + id + '">' + dateSpan + '</div>';
            var timeline_content = '<div class="timeline_content" id="timeline_content' + id + '"></div>'
            $("#timeline" + intid).append(timeline_item);
            var $timeline_item = $("#timeline_item" + id);
            $timeline_item.append(timelineIcon);
            $("#timelineicon" + id).click(function () {
                $("#timeline_content_addon" + id).toggle(function () { });
            });
            $timeline_item.append(timeline_date);
            $timeline_item.append(timeline_content);
            $("#timeline_content" + id).append(mainSpan);
            var timeline_content_addon = '<div class="timeline_content_addon" id="timeline_content_addon' + id + '" style="display:none;"></div>';
            $("#timeline_content" + id).append(timeline_content_addon);
            var ul_list_addon = '<ul class="md-list md-list-addon" id="list_addon' + id + '"><ul>';
            $("#timeline_content_addon" + id).append(ul_list_addon);
            var li_list_addon = '<li><div class="md-list-content" id="list_content' + id + '"></div></li>'
            $("#list_addon" + id).append(li_list_addon);
            phoneNoSpan = '<span class="uk-text-small">Phone Number: ' + phoneNo + '</span>';
            intentSpan = '<span class="uk-text-small">Intent: ' + intent + '</span>';
            typeSpan = '<span class="uk-text-small">Type: ' + interactionText + '</span>';
        } else {
            $("#list_content" + id).append("<br/>");
            phoneNoSpan = '<span class="uk-text-small">PhoneNumber: ' + phoneNo + '</span>';
            intentSpan = '<span class="uk-text-small">Intent: ' + intent + '</span>';
            typeSpan = '<span class="uk-text-small">Type: ' + interactionText + '</span>';
        }
        $("#list_content" + id).append(phoneNoSpan);
        $("#list_content" + id).append(intentSpan);
        $("#list_content" + id).append(typeSpan);
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.CreateVoiceDiv()", ex, false);
    }
}

function CreateChatDiv(obj, intid) {
    try {
        var id = obj.ID + intid;
        var itemId = obj.ItemID + "_" + id + "_" + intid;
        var interactionText = obj.InteractionText;
        var interactionDate = obj.InteractionDate;
        var agentName = obj.AgentName;

        if (interactionText === "[RemoteUserConnected]") {
            if (global_interactionReference[id].type == "new") {
                var direction = obj.Direction;
                var dateSpan = '<span class="uk-text-danger">' + interactionDate + '</span>';
                var directionSpan = "";
                var mainSpan = "";
                var timelineIcon = "";
                if (direction == "In")
                    directionSpan = '<span class="uk-badge uk-badge-primary">' + direction + '</span>';
                else
                    directionSpan = '<span class="uk-badge uk-badge-danger">' + direction + '</span>';
                mainSpan = '<span>' + directionSpan + '&nbsp;Chat with agent</span>';
                var timeline_item = '<div class="timeline_item" id="timeline_item' + id + '" data-sort=' + id + '></div>';
                timelineIcon = '<div class="timeline_icon md-bg-orange-700" id="timelineicon' + id + '"><i class="material-icons">chat_bubble_outline</i></div>';
                var timeline_date = '<div class="timeline_date" id="timeline_date' + id + '">' + dateSpan + '</div>';
                var timeline_content = '<div class="timeline_content" id="timeline_content' + id + '"></div>'
                $("#timeline" + intid).append(timeline_item);
                var $timeline_item = $("#timeline_item" + id);
                $timeline_item.append(timelineIcon);
                $("#timelineicon" + id).click(function () {
                    $("#timeline_content_addon" + id).toggle(function () { });
                });
                //$("#timelineicon" + id).attr("data-uk-scrollspy", "{cls:'uk-animation-scale-up uk-invisible', delay:100, repeat: true}");
                $timeline_item.append(timeline_date);
                $timeline_item.append(timeline_content);
                $("#timeline_content" + id).append(mainSpan);

                var timeline_content_addon = '<div class="timeline_content_addon" id="timeline_content_addon' + id + '" style="display:none;"></div>';
                $("#timeline_content" + id).append(timeline_content_addon);
                var userTag = '<span class="uk-text-bold"><span class="md-color-green-800">Chat connected at </span><br/ ><span>' + interactionDate + '</span></span>';
                var blockquote = '<blockquote class="blockquote_center" id="blockquote_connected' + itemId + '"><blockquote>';
                $("#timeline_content_addon" + id).append(blockquote);
                $("#blockquote_connected" + itemId).html("");
                $("#blockquote_connected" + itemId).append(userTag);
            } else {
                var userTag = '<span class="uk-text-bold"><span class="md-color-green-800">Chat transfer connected at </span><br/ ><span>' + interactionDate + '</span></span>';
                var blockquote = '<blockquote class="blockquote_center" id="blockquote_connected' + itemId + '"><blockquote>';
                $("#timeline_content_addon" + id).append(blockquote);
                $("#blockquote_connected" + itemId).html("");
                $("#blockquote_connected" + itemId).append(userTag);
            }
        } else if (interactionText == "[RemoteEndDisconnected]") {
            var userTag = '<span class="uk-text-bold"><span class="md-color-red-800">Chat disconnected at </span><br/ ><span>' + interactionDate + '</span></span>';
            var blockquote = '<blockquote class="blockquote_center" id="blockquote_disconnected' + itemId + '"><blockquote>';
            $("#timeline_content_addon" + id).append(blockquote);
            $("#blockquote_disconnected" + itemId).html("");
            $("#blockquote_disconnected" + itemId).append(userTag);
        } else if (interactionText == "[Agent-EndTextChat]") {
            //do nothing
        } else {
            if (global_interactionReference[id].type == "old") {
                var user = obj.DisplayText.substring(0, 1);
                var blockquote = "";
                var userTag = "";
                var textTag = "";
                if (user == "A") {
                    userTag = '<span class="uk-text-bold">' + agentName.split(' ')[0] + ' - <span class="uk-text-small-10">' + interactionDate + '</span>:</span>';
                    textTag = '<span class="md-color-indigo-800">' + interactionText + '</span>';
                    blockquote = '<blockquote class="blockquote_left" id="blockquote_agent' + itemId + '"><blockquote>';
                    $("#timeline_content_addon" + id).append(blockquote);
                    $("#blockquote_agent" + itemId).html("");
                    $("#blockquote_agent" + itemId).append(userTag);
                    $("#blockquote_agent" + itemId).append('<br />');
                    $("#blockquote_agent" + itemId).append(textTag);
                } else if (user == "C") {
                    userTag = '<span class="uk-text-bold">Customer - <span class="uk-text-small-10">' + interactionDate + '</span>:</span>';
                    textTag = '<span class="md-color-indigo-800">' + interactionText + '</span>';
                    blockquote = '<blockquote class="blockquote_right" id="blockquote_customer' + itemId + '"><blockquote>';
                    $("#timeline_content_addon" + id).append(blockquote);
                    $("#blockquote_customer" + itemId).html("");
                    $("#blockquote_customer" + itemId).append(userTag);
                    $("#blockquote_customer" + itemId).append('<br />');
                    $("#blockquote_customer" + itemId).append(textTag);
                }
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.CreateChatDiv()", ex, false);
    }
}

function AddMoreInteractions(data, intid) {
    try {
        data.sort(sort_by('ItemID', false, parseInt));
        jsonData = data;
        if (jsonData !== undefined)
            $.each(jsonData, function (i, val) {
                var id = val.ID + intid;
                var channel = val.Channel;

                if (global_referenceId == "") {
                    global_referenceId = id;
                    AddInteractionReference(id, "new", channel);
                } else {
                    if (id == global_referenceId)
                        global_interactionReference[id].type = "old";
                    else {
                        global_referenceId = id;
                        AddInteractionReference(id, "new", channel);
                    }
                }
                switch (channel) {
                    case "Voice":
                        //create voice div
                        CreateVoiceDiv(val, intid);
                        break;

                    case "Chat":
                        //create chat div                    
                        CreateChatDiv(val, intid);
                        break;

                    case "Email":
                        //create email div
                        break;
					
					case "TextChat":
                        CreateChatDiv(val, intid);
                        break;

                    default:
                        console.log("No channel: " + val);
                        break;
                }
            });
        $("#timeline" + intid).AscSortDivs();
        altair_helpers.hierarchical_slide('#timeline' + intid);
        EnableLoadMoreButton(intid);
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.AddMoreInteractions()", ex, false);
    }
}

jQuery.fn.AscSortDivs = function AscSortDivs() {
    try {
        $("> div", this[0]).sort(dec_sort).appendTo(this[0]);

        function dec_sort(a, b) {
            return ($(b).data("sort")) > ($(a).data("sort")) ? 1 : -1;
        }
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.AscSortDivs()", ex, false);
    }
}

jQuery.fn.DescSortDivs = function DescSortDivs() {
    try {
        $("> div", this[0]).sort(dec_sort).appendTo(this[0]);

        function dec_sort(a, b) {
            return ($(b).data("sort")) < ($(a).data("sort")) ? 1 : -1;
        }
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.DescSortDivs()", ex, false);
    }
}

function Asc(e, intid) {
    try {
        $("#timeline" + intid).AscSortDivs();
        altair_helpers.hierarchical_slide('#timeline' + intid);
        $(e).addClass('uk-active').siblings().removeClass('uk-active');
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.Asc()", ex, false);
    }
}

function Desc(e, intid) {
    try {
        $("#timeline" + intid).DescSortDivs();
        altair_helpers.hierarchical_slide('#timeline' + intid);
        $(e).addClass('uk-active').siblings().removeClass('uk-active');
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.Desc()", ex, false);
    }
}

function ExpandAll(intid) {
    try {
        $('.timeline_content_addon').each(function () {
            debugger
            var id = this.id;
            if ($("#" + id).css("display") == "none")
                $("#" + id).show(function () { });
        });
        $("#expand" + intid).toggle(false);
        $("#collapse" + intid).toggle(true);
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.ExpandAll()", ex, false);
    }
}

function CollapsAll(intid) {
    try {
        $('.timeline_content_addon').each(function () {
            var id = this.id;
            if ($("#" + id).css("display") == "block")
                $("#" + id).hide(function () { });
        });
        $("#expand" + intid).toggle(true);
        $("#collapse" + intid).toggle(false);
    } catch (ex) {
        log.LogDetails("Error", "InteractionHistory.CollapsAll()", ex, false);
    }
}