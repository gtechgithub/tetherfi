﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "iServeCommands.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

$(document).ready(function () {
    console.log('iServe Commands loaded');

});

// Update QueueTime for relavant UCID
function custom_insertQueueTimeForUCID(intid, queuetime, ucid) {
    try {
        var parameters = [global_DeviceID, intid, "InsertQueueTimeForUCIDEvent", queuetime, ucid];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "InsertQueueTimeForUCID", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_insertQueueTimeForUCID()", ex, false);
    }
}

// Get QueueTime For UCID
function custom_getQueueTimeForUCID(intid, ucid, queuetime) {
    try {
        var parameters = [global_DeviceID, intid, "GetQueueTimeForUCIDEvent", ucid, queuetime];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "GetQueueTimeForUCID", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_getQueueTimeForUCID()", ex, false);
    }
}

// Start ACW Timer
function custom_UpdateEndOfCallACWStartTime(intid, ucid, lanid) {
    try {
        var parameters = [global_DeviceID, intid, "UpdateEndOfCallACWStartTimeEvent", ucid, lanid, global_AgentID];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "UpdateEndOfCallACWStartTime", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_UpdateEndOfCallACWStartTime()", ex, false);
    }
}

// End ACW Timer
function custom_UpdateEndOfCallACWEndTime(intid, ucid, lanid) {
    try {
        var parameters = [global_DeviceID, intid, "UpdateEndOfCallACWEndTimeEvent", ucid, lanid, global_AgentID];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "UpdateEndOfCallACWEndTime", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_UpdateEndOfCallACWEndTime()", ex, false);
    }
}

// iServe Call Disconnect
function custom_CallDisconnected(intid) {
    try {
        var parameters = [global_DeviceID, intid, "CallDisconnectedEvent"];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "CallDisconnected", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_CallDisconnected()", ex, false);
    }
}

// Update UCID to Custom Table for Blind Transfer
function custom_UpdateUCIDOnBlindTransfer(intid, ucid) {
    try {
        var parameters = [global_DeviceID, intid, "UpdateUCIDOnBlindTransferEvent", ucid];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "UpdateUCIDOnBlindTransfer", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_UpdateUCIDOnBlindTransfer()", ex, false);
    }
}

// Clear Call Data(iServe Layer) for TPIN Transfer
function custom_ClearCallDataForTpinTransfer(intid, ucid) {
    try {
        var parameters = [global_DeviceID, intid, "ClearCallDataForTpinTransferEvent", ucid, global_AgentID];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "ClearCallDataForTpinTransfer", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_ClearCallDataForTpinTransfer()", ex, false);
    }
}

//-----------------------Update ACW Start - iServe --------------------------------------------------------
function Custom_UpdateEndOfCallACWStartTimeEvent(event) {
    // do nothing
}

//-----------------------Update ACW End - iServe --------------------------------------------------------
function Custom_UpdateEndOfCallACWEndTimeEvent(event) {
    //customCommands
    custom_CallDisconnected(1);
}

//-----------------------Call Disconnected - iServe --------------------------------------------------------
function Custom_CallDisconnectedEvent(event) {
    //do nothing
}

// When Transfer Completed...
function Custom_AnotherAgentTransferedToMeEvent(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        // global_connectUCID[parse.InteractionID] = parse.UCID;
        // global_connectINTID[parse.InteractionID]=parse.InteractionID;
        // Update the 'triggerIServeLayer' to True, coz this call is Completed
        var array = $.grep(global_ConnectedCalls, function (n, i) {
            return n.InteractionID == parse.InteractionID;
        });

        // update the 'triggerIServeLayer' to true
        if (array && array.length == 1) {
            array[0].triggerIServeLayer = true;
        }
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.Custom_AnotherAgentTransferedToMeEvent()", ex, false);
    }
}

// When Conference Completed...
function Custom_AnotherAgentConferencedToMeEvent(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        // global_connectUCID[parse.InteractionID] = parse.UCID;
        // global_connectINTID[parse.InteractionID]=parse.InteractionID;
        // Update the 'triggerIServeLayer' to True, coz this call is Completed
        var array = $.grep(global_ConnectedCalls, function (n, i) {
            return n.InteractionID == parse.InteractionID;
        });

        // update the 'triggerIServeLayer' to true
        if (array && array.length == 1) {
            array[0].triggerIServeLayer = true;
        }
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.Custom_AnotherAgentConferencedToMeEvent()", ex, false);
    }
}

// Agent Initiated callback - trigger iServe
function custom_TextChatCallback(sessionid, srno, intid) {
    try {
        var parameters = [global_DeviceID, intid, sessionid, srno, global_AgentID];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "TextChatCallback", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_TextChatCallback()", ex, false);
    }
}

// On callback submit - trigger iServe
function custom_TextChatCallbackSubmit(intid) {
    try {
        var parameters = [global_DeviceID, intid, sessionid, global_AgentID];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "TextChatCallbackSubmit", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_TextChatCallbackSubmit()", ex, false);
    }
}

// On agent init callbacktab swap - trigger iServe
function custom_AgentInitCallbackSelect(intid) {
    try {
        var parameters = [global_DeviceID, intid, global_AgentID];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "SwapCallbackTab", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_AgentInitCallbackSelect()", ex, false);
    }
}

// On Tab Select of Chat disconnected tab, call this method
function custom_TextChatTabSelectOnDisconnect(intid) {
    try {
        var parameters = [global_AgentID, intid];
        Custom_InvokeFunction("DBS_Custom_iServeIntegration.dll", "DBS_Custom_iServeIntegration.iServerIntegrationServer", "TextChatTabSelectOnDisconnect", parameters);
    } catch (ex) {
        log.LogDetails("Error", "iServeCommands.custom_AgentInitCallbackSelect()", ex, false);
    }
}