/*
 * Copyright (c) 2018 Tetherfi Pte. Ltd. (www.tetherfi.com).
 * All rights reserved.
 *
 * This source code is property of Tetherfi Pte. Ltd. product suit. Any use of this code in any 
 * form, for any purpose is strictly prohibited unless prior written permission is obtained from 
 * Tetherfi Pte. Ltd.
 */

var WrsJsVersion = "1.0.0.4";

/**
 * The Channel interface represents the interface used by the WrsPeerConnection class to 
 * do the signalling between it and MediaServer.
 * 
 * User is expected to implement a class with the bellow interface.
 *
 * @class WrsChannelInterface
 */
WrsChannelInterface = function(instance) {
	var this_ = instance;
	
	/**
	 * The channel should trigger this callback upon sucessfull recipt and decode of a JSON 
	 * message.
	 * It is assumed that the messages recieved is in the same order of the messages sent via
	 * the MediaServer that this channel connects to (i.e. If the underlying transport does not
	 * support message sequencing the application should handle sequencing and make sure this 
	 * event is fired in proper sequence).
	 * 
	 * @param   JSON   jsonObject should be a valid JSON object (i.e. a javascript object with  
	 *  a dictionary interface). A string can be converted to such object by calling 
	 *  JSON.parse(jsonString) function call supported in most web browsers.
	 */
	this_.onMessage = function(jsonObject) { }
	
	/**	
	 * The chennel should implement the function getId that returns a string that represents 
	 * the remote end point identifier (i.e. A name for the remote endpoint such as 'customer',
	 * 'agent', an-agent-ID). This string is used only for identification and loging purposes and
	 * this API does not depend on the format or the content of this identifier. However it is 
	 * recomended that this identifoer be unique for a single instance (i.e. a web page or a 
	 * session)
	 * 
	 * @return   string   The identifier representing the destination of the channel
	 */
	this_.getId = function() { return stringId; }
	
	/**
	 * The channel should implement the send() function to send the message to the other party that 
	 * this channel represents.
	 * The WrsPeerConnection class assumes any message sent is delivered to the other pary, any send 
	 * errors and exceptions should be handled by the implementer.
	 * 
	 * @param  JSON   jsonObject A JSON object (i.e. a javascript object with a dictionary interface). 
	 *  This can be converted to a string using JSON.stringify(jsonObject) function call supported 
	 *  in most web browsers. 
	 */
	this_.send  = function (jsonObject) { }
}

/**
 * The Configuration interface represents the interface used by the WrsPeerConnection class to 
 * retrive runtime configurations. The methods implemented in this class will be called when
 * those configurations are required.
 * 
 * User is expected to implement a class with the bellow interface.
 *
 * @class WrsConfigurationInterface
 */
WrsConfigurationInterface = function(instance) {
	var this_ = instance;
	
	/**
	 * @return   RTCConfiguration   A WebRTC configuration dictionary as specified at 
	 *  https://www.w3.org/TR/webrtc. An example configuration would be.\\
	 * 
	 *     var configuration = {
	 *         iceServers : [
	 *             {urls: 'turn:turn2.l.google.com:19303', credential: 'test', username: 'test'},
	 *             {urls: 'stun:stun2.l.google.com:19302'}
	 *         ],
	 *         iceTransportPolicy : "relay",
	 *     }
	 */
	this_.getWebRTCConfigurations = function() { }
	
	/**
	 * @return   MediaStreamConstraints   A WebRTC media constraints dictionary as specified at
	 *  https://www.w3.org/TR/mediacapture-streams. An example constraints would be.
	 * 
	 *     var mediaConstraints = { audio: true, video: true }
	 */
	this_.getMediaConstraints = function() { }

	/**
	 * @return   RTCOfferOptions   A WebRTC offer options dictionary as specified at 
	 *  https://www.w3.org/TR/webrtc. Usually it would be a variable as shown bellow.
	 *
	 *     var offerOptions = { offerToReceiveAudio: true, offerToReceiveVideo: true, iceRestart: true }
	 */	
	this_.getOfferOptions = function() { }

	/**
	 * @return   RTCAnswerOptions   A WebRTC answer options dictionary as specified at
	 *  https://www.w3.org/TR/webrtc.  Usually it would be a variable as shown bellow.
	 * 
	 *     var answerOptions = { iceRestart: true }
	 */	
	this_.getAnswerOptions = function() { }
	
	/**
	 * @return   int   The bandwidth upper limit for the entire connection (i.e. all tracks)
	 *  in kbps (kilobits per second).
	 */
	this_.getConnectionBandwidthUpperLimit = function() { return 2048; }
	
	/**
	 * @return   int   The bandwidth upper limit for a single audio track in kbps (kilobits per 
	 *  second).
	 */
	this_.getAudioTrackBandwidthUpperLimit = function() { return 128; }
	
	/**
	 * @return   int   The bandwidth upper limit for a single video track in kbps (kilobits per 
	 *  second).
	 */
	this_.getVideoTrackBandwidthUpperLimit = function() { return 256; }
}

/**
 * The WrsPeerConnection class handles a single WebRTC audio/video call. Using the channel given 
 * in the constructor it communicates with the MediaServer to establish a WebRTC call.
 * 
 * @class WrsPeerConnection
 * 
 * @param   WrsChannelInterface   channel   The channel to communicate with MediaServer. The object  
 *  should implement the WrsChannelInterface.
 *
 * @param   WrsConfigurationInterface   configs   The object used to query runtime configurations.
 *  The object should implement the WrsConfigurationInterface.
*/
function WrsPeerConnection(channel, configs) {
	var this_ = this;
	
	/**
	 * This callback will be triggered when a new stream is recieved or a existing stream is modified
	 * (i.e. a new track is added to a stream). The user can override this method to handle the new
	 * stream and to place audio/video as required.
	 * 
	 * @param   Array   streams   An array of MediaStream objects (note: the actual datatype is
	 *  FrozenArray<MediaStream>) as specified in https://www.w3.org/TR/webrtc and 
	 *  https://www.w3.org/TR/mediacapture-streams.
	 */
	this_.onAddVideo = function(streams) { }
	
	/**
	 * This callback will be triggered when the connection was established upon sucessfull WebRTC 
	 * handshake. The onAddVideo() may be called prior to this call and it is recomended that the 
	 * video display to be hidden from view while onAddVideo() is called and only shown to user 
	 * after onConnect() is triggered. User may display a connecting message (i.e. ring tone, 
	 * advertisement ...etc) during the period between user call to call() method and until 
	 * onConnect() is triggered.
	 */
	this_.onConnect = function() { }
	
	/**
	 * This callback will be triggered when the connection has been ended. When this callback is 
	 * triggered, application can hide the video views.
	 */
	this_.onDisconnect = function() { }
	
	/**
	 * This callback will be triggered when a error occurs.
	 * @param   int   code   The error code
	 * @param   string   msg   The error message string
	 */
	this_.onError = function(code, msg) { }
	
	/**
	 * This callback will be triggered when this application needs to output log messages. These log 
	 * messages are usefull for troubleshooting issues, thus application should output them in a 
	 * appropriate manner. The default implementation is to log to the debug console.
	 */
	this_.onTrace = function(messageString) {
		console.log(messageString)
	}
	
	/**
	 * User should call this method to initiate a WebRTC audio/video communication. If the application
	 * is awaiting a communication from other party, the application does not need to call this method.
	 */
	this_.call = function () { }
	
	/**
	 * User can call this method to mute components of the call.
	 * 
	 * @param   bool   audio   Specifies whether to mute all audio tracks
	 * @param   bool   video   Specifies whether to mute all video tracks
	 */	
	this_.mute = function (audio, video) { }
	
	/**
	 * User can call this method to unmute components of the call.
	 * 
	 * @param   bool   audio   Specifies whether to mute all audio tracks
	 * @param   bool   video   Specifies whether to mute all video tracks
	 */	
	this_.unMute = function (audio, video) { }
	
	/**
	 * User can call this method to end a connected WebRTC communication channel. Upon calling this method
	 * user should dispose of this WrsPeerConnection instance and it should not be used for further 
	 * communications.
	 */
	this_.close = function() { }
	
	/**
	 * User can check whether the connection is alive by using this method.
	 * @return   bool   Returns whether the connection is initiated or not.
	 */
	this_.isConnected = function() { }
	
	/**
	 * This call can be used to check if the current instance is in a error state. When the object is in a 
	 * error state any user method call will result in a failure and object is not usable. User should 
	 * dispose the object by calling close() method and instenciate a new object.
	 * User will be notified via a onError callback prior to the object moving to the error state.
	 */
	this_.isError = function() { }
	
	/**
	 * This is a internal function call and user should not modify/change this code.
	 */
	WrsPeerConnectionInternal(this_, channel, configs);
}

var WrsErrorCodes = {
	/**
	 * Following errors are recoverable and would not cause the object to transit to a error state.
	 */
	INVALID_USER_STATE : 10,
	INVALID_CONNECTION_STATE : 11,
	ADD_ICE_FAILED : 12,
	
	/**
	 * Following errors are irrecoverable and would cause the object to transit to a error state. 
	 * Any subsequen t calls to the functions of the object would result a error after the object 
	 * has moved to a error state. 
	 */
	GET_USER_MEDIA_FAILED : 30,
	CREATE_SDP_FAILED : 31
}

