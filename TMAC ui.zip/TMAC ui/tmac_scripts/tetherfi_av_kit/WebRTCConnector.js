﻿//----------------------------------------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
//----------------------------------------------------------------------------------------------------------------
var filename = "WebRTCConnector.js";
var file_version = "3.1.08.08";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
//----------------------------------------------------------------------------------------------------------------
//ice servers urls
var _iceServers = [
    //{ urls: 'turn:202.150.214.54:3579?transport=udp', credential: 'nuwan', username: 'tetherfi' }
    //{ urls: 'stun:stun2.l.google.com:19302' }
];

//ice transport policy 
// -relay(with turn urls) 
// -all (without turn urls)
var _iceTransportPolicy = "all";

//iceRestart for getOfferOptions
var _offerIceRestart = true;

//iceRestart for getAnswerOptions
var _answerIceRestart = true;

//video size
var videoSize = {
    width: { min: 320, max: 640 },
    height: { min: 240, max: 480 }
};

//AV configuration method
var AVConfiguration = function (audioOnly) {
    try {
        var this_ = this;

        //call base constructor
        WrsConfigurationInterface(this_);

        this_.video_ = !audioOnly;

        this_.getWebRTCConfigurations = function () {
            var configuration = {
                iceServers: _iceServers,
                iceTransportPolicy: _iceTransportPolicy,
            }
            return configuration;
        }

        this_.getMediaConstraints = function () {
            var mediaConstraints = { audio: true, video: this_.video_ ? videoSize : false }
            return mediaConstraints;
        }

        this_.getOfferOptions = function () {
            var offerOptions = {
                offerToReceiveAudio: true,
                offerToReceiveVideo: this_.video_,
                iceRestart: _offerIceRestart
            }
            return offerOptions;
        }

        this_.getAnswerOptions = function () {
            var answerOptions = { iceRestart: _answerIceRestart }
            return answerOptions;
        }
    } catch (ex) {
        log.LogDetails("Error", "WebRTCConnector.AVConfiguration()", ex, false);
    }
}

//AV channel method
var AVChannel = function (intid, agentId, deviceId, audioOnly, remoteDiv) {
    try {
        var this_ = this;

        this_.remoteVideoContainer = document.getElementById(remoteDiv);

        this_.remoteVideo = new VideoLauout(this_.remoteVideoContainer);

        //call base constructor
        WrsChannelInterface(this_);

        this_.connected_ = false;

        this_.audioonly_ = audioOnly;

        this_.id_ = agentId + "_" + intid;

        this_.send = function (json) {
            var jsonStr = JSON.stringify(json);
            SendAVControlMessage(deviceId, intid, jsonStr, json.type);
        }

        this_.getId = function () {
            return this_.id_;
        }

        this_.onCommMessage = function (jsond) {
            var json = JSON.parse(jsond);
            this_.onMessage(json)
        }

        this_.configuration = new AVConfiguration(audioOnly);

        this_.pc = new WrsPeerConnection(this_, this_.configuration);

        this_.call = function () {
            if (this_.pc !== undefined)
                this_.pc.call();
        }

        this_.mute = function (audio, video) {
            if (this_.pc !== undefined)
                this_.pc.mute(audio, video);
        }

        this_.unMute = function (audio, video) {
            if (this_.pc !== undefined)
                this_.pc.unMute(audio, video);
        }

        this_.close = function () {
            if (this_.pc !== undefined)
                this_.pc.close();
        }

        this_.onConnected = function () { };

        this_.pc.onConnect = function () {
            this_.connected_ = true;
            this_.onConnected();
        }

        this_.onDisconnected = function () { };

        this_.pc.onDisconnect = function () {
            this_.connected_ = false;
            this_.onDisconnected();
        }

        this_.pc.onAddVideo = function (streams) {
            this_.remoteVideo.addVideo(streams);
        }

        this_.pc.onError = function (code, msg) {
            AVTrace("WrsPeerConnection - onError|" + code + "|" + msg);
        }

        this_.pc.onTrace = function (log) {
            AVTrace(log);
        }
    } catch (ex) {
        log.LogDetails("Error", "WebRTCConnector.AVChannel()", ex, false);
    }
}

//Video layout method
var VideoLauout = function (div) {
    try {
        var this_ = this;

        this_.table_ = document.createElement("TABLE");
        div.appendChild(this_.table_);

        this_.addedStreams_ = {}

        this_.addVideo = function (streams) {
            streams.forEach(function (stream) {
                var v = null;
                var d = null;

                if (this_.addedStreams_[stream.id]) {
                    v = this_.addedStreams_[stream.id].video;
                    d = this_.addedStreams_[stream.id].tag;
                } else {
                    var videoRow = this_.table_.insertRow(-1);
                    v = document.createElement('video');
                    d = document.createElement('div');

                    videoRow.appendChild(v);
                    videoRow.appendChild(d);
                    this_.addedStreams_[stream.id] = { video: v, tag: d };
                }

                v.setAttribute('autoplay', 'autoplay');
                v.setAttribute('muted', 'muted');

                v.addEventListener('loadedmetadata', function () {
                    AVTrace('Remote video videoWidth: ' + this.videoWidth +
                        'px,  videoHeight: ' + this.videoHeight + 'px');
                    v.width = this.videoWidth;
                    v.height = this.videoHeight;
                });

                v.srcObject = stream;

                v.onresize = function () {
                    AVTrace('Remote video size changed to ' +
                        this.videoWidth + 'x' + this.videoHeight);
                    // We'll use the first onsize callback as an indication that video has started
                    // playing out.
                }

                d.innerHTML = 'stream {' + stream.id + '}';
                AVTrace('Added stream to video element ' + stream.id);
            });
        }

        this_.clear = function () {
            // clear table
            while (this_.table_.rows.length > 0) {
                this_.table_.deleteRow(-1);
            }
            this_.addedStreams_ = {};
        }
    } catch (ex) {
        log.LogDetails("Error", "WebRTCConnector.VideoLauout()", ex, false);
    }
}

//Trace method
function AVTrace(message) {
    try {
        log.LogDetails("Info", "WebRTCConnector.AVTrace()", message, false);
    } catch (ex) {
        log.LogDetails("Error", "WebRTCConnector.AVTrace()", ex, false);
    }
}