﻿//----------------------------------------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
//----------------------------------------------------------------------------------------------------------------
var filename = "FacebookUI.js";
var file_version = "3.1.07.05";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
//----------------------------------------------------------------------------------------------------------------
$(document).ready(function () {
    console.log('facebook ui js loaded');
    RegisterFacebookSDK();
});
//----------------------------------------------------------------------------------------------------------------
//RegisterFacebookSDK
function RegisterFacebookSDK() {
    try {
        tmac_facebook_initialize(
            global_DeviceID,
            global_AgentID,
            global_AgentName,
            "FbIncomingPostCallback", "FbIncomingConversationCallback", "FbPostReceived",
            "FbPostCommectReceived", "FbPostCommentReplyReceived",
            "FbPrivateMessageReceived");
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.RegisterFacebookSDK()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function AddFacebokTab(intId, userName, postId, message, postData) {
    try {
        //get html for fb post tab
        var tempTabContent = document.getElementById("fb_post_tab_body").innerHTML;
        //tab header content
        let headerTemplate = GetTabHtml("tab_header_template", intId, { icon: "assignment" });
        //set interaction id for voice tab
        let bodyTemplate = tempTabContent.replace(/_POSTID/g, postId);
        //let bodyTemplate = GetTabHtml("", intId, "");
        //save facebook tab reference
        SaveTabReference("facebook", intId, "new");
        //add the facebook post tab
        AddTab(bodyTemplate, headerTemplate, intId, userName, false, true, false);
        // if shift + enter is pressed, goes to new line [Since Alt+Enter will maximize the browser window, so we replaced with shift + Enter]
        $("#txtFbPostComment" + postId).keypress(function (e) {
            if (e.keyCode == 13 && !e.shiftKey) {
                SendPostComment(intId, postId);
                // Remove the unnecessary character
                return false;
            }
        });
        //Initialize the UIKit accordion for the created tab
        UIkit.accordion($('#facebook_post_accordion' + intId), {
            collapse: false,
            showfirst: true
        });
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.AddFacebokTab()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function FbIncomingPostCallback(event) {
    try {
        let intid = event.InteractionID;
        let postid = event.PostId;

        //add a new tab
        AddFacebokTab(intid, event.UserName, postid, event.Message, event.PostDate);

        //set post data
        $("#post_message" + intid + postid).text(event.Message);
        $("#post_date" + intid + postid).text(FormatDate(event.PostDate));
        $("#post_userName" + intid + postid).text(event.UserName);

        //fb_CreatePostDiv(event.InteractionID, event.PostId, event.Message, event.PostDate, event.UserName);

        ////hine the customer data panel for Post
        ////divCxData_INTID
        //$("#divCxData" + event.InteractionID).css("visibility", "hidden");
        //$("#divCxData" + event.InteractionID).css("display", "none");

        ////change the tab header icon
        //////divFBIcon_INTID
        //$("#divFBIcon" + event.InteractionID).addClass("fb_post_header");

        SaveFbReference(event.UserName, "post", intid, postid, "", "");
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.RegisterFacebookSDK()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function ShowCommentBox(intId, postId) {
    try {
        $("#div_reply_post" + intId + postId).show();
        $("#txtFbPostComment" + postId).focus();
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.ShowCommentBox()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function FbPostCommectReceived(event) {
    try {
        let intid = event.InteractionID;
        let postid = event.PostId;
        let commentid = event.CommentId;
        let userType = event.Me === "True" ? "agent" : "customer";
        let pictureUrl = event.PictureUrl;


        //add a comment item to post item - add the new ul inside div
        AddReplyPostBox("#facebook_post_comment_ul_template", "#div_reply_post" + event.InteractionID + event.PostId, "before",
            intid, postid, commentid, "", event.Message, event.PostDate, event.UserName, userType, pictureUrl);

        // if shift + enter is pressed, goes to new line [Since Alt+Enter will maximize the browser window, so we replaced with shift + Enter]
        $("#txtFbCommentReply" + commentid).keypress(function (e) {
            if (e.keyCode == 13 && !e.shiftKey) {
                SendCommentReply(intid, postid, commentid);
                // Remove the unnecessary character
                return false;
            }
        });
        AddFbNotifications("comment", intid, postid, commentid, "", userType, event.UserName, global_FbReference[0].from, "commented", event.PostDate);
        SaveFbReference(event.UserName, "comment", intid, postid, commentid, "");
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.FbPostCommectReceived()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function FbPostCommentReplyReceived(event) {
    try {
        let intid = event.InteractionID;
        let postid = event.PostId;
        let commentid = event.CommentId;
        let replyid = event.ReplyId;
        let userType = event.Me === "True" ? "agent" : "customer";
        let pictureUrl = event.PictureUrl;

        //get all the reference for this post comment
        var fbRef = GetFbReferenceObj(intid, postid, commentid, "");
        //check if the reference has more than one element, if 1 then add article for the post comment else create first post comment reply (ul)
        if (fbRef.length > 1) {
            //reply already there in ul, so add article for that post comment
            AddReplyPostBox("#facebook_post_reply_article_template", "#facebook_post_reply_li" + intid + postid + commentid, "to",
                intid, postid, commentid, replyid, event.Message, event.PostDate, event.UserName, userType, pictureUrl);
        }
        else {
            //first reply for the post comment
            AddReplyPostBox("#facebook_post_reply_ul_template", "#facebook_post_comment_article" + intid + postid + commentid, "after",
                intid, postid, commentid, replyid, event.Message, event.PostDate, event.UserName, userType, pictureUrl);
        }
        SaveFbReference(event.UserName, "reply", intid, postid, commentid, replyid);
        ShowMore(intid, postid, commentid);
        $('.facebook-post').scrollTo("#facebook_post_reply_article" + intid + postid + commentid + replyid);
        $("#facebook_post_reply_article" + intid + postid + commentid + replyid).find(".fb-post-comment").addClass("blink_once");
        setTimeout(function () { $("#facebook_post_reply_article" + intid + postid + commentid + replyid).find(".fb-post-comment").removeClass("blink_once"); }, 1000);
        AddFbNotifications("reply", intid, postid, commentid, replyid, userType, event.UserName, global_FbReference[0].from, "replied", event.PostDate);
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.FbPostCommentReplyReceived()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function SaveFbReference(from, type, intid, postid, commentid, replyid) {
    try {
        var fbRef = {};
        fbRef.from = from;
        fbRef.type = type;
        fbRef.intid = intid;
        fbRef.postid = postid;
        fbRef.commentid = commentid;
        fbRef.replyid = replyid;

        global_FbReference.push(fbRef);
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.AddFbReference()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function GetFbReferenceObj(intid, postid, commentid, replyid) {
    try {
        let resultArray = [];
        for (var i = 0; i < global_FbReference.length; i++) {
            if (replyid != "") {
                if (global_FbReference[i] !== undefined && global_FbReference[i].intid === parseInt(intid) && global_FbReference[i]["postid"] == postid && global_FbReference[i]["commentid"] == commentid && global_FbReference[i]["replyid"] == replyid)
                    resultArray.push(global_FbReference[i]);
            }
            else if (commentid != "" && replyid == "") {
                if (global_FbReference[i] !== undefined && global_FbReference[i].intid === parseInt(intid) && global_FbReference[i]["postid"] == postid && global_FbReference[i]["commentid"] == commentid)
                    resultArray.push(global_FbReference[i]);
            }
            else if (postid != "" && commentid == "" && replyid == "") {
                if (global_FbReference[i] !== undefined && global_FbReference[i].intid === parseInt(intid) && global_FbReference[i]["postid"] == postid)
                    resultArray.push(global_FbReference[i]);
            }
        }
        return resultArray;
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.GetFbReferenceObj()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function AddReplyPostBox(templateId, appendId, type, intid, postid, commentid, replyid, message, postDate, userName, userType, pictureUrl) {
    try {
        var t = $(templateId).html(), //template divs
            e = (appendId), //to be appended before/after/to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                intid: intid,
                postid: postid,
                commentid: commentid,
                usertype: userType,
                username: userName,
                postdate: FormatDate(postDate),
                postmessage: message,
                replyid: replyid,
                pictureurl: pictureUrl == "" ? "assets/img/" + userType + ".png" : pictureUrl
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        switch (type) {
            case "before":
                $(s).insertBefore(e);
                break;
            case "after":
                $(s).insertAfter(e);
                break;
            case "to":
                $(e).append(s);
                break;
        }
        altair_md.inputs($(e).parent());
        $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.AddReplyPostBox()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function AddFbNotifications(type, intid, postid, commentid, replyid, userType, fromUser, postOf, postType, postDate) {
    try {
        var t = $("#fb_notification_template").html(), //template divs
            e = $("#fb_notfication_list" + intid + postid), //to be appended before/after/to
            n = Handlebars.compile(t), //initialize handlebars for the template divs     
            context = {
                type: type,
                intid: intid,
                postid: postid,
                commentid: commentid,
                replyid: replyid,
                usertype: userType,
                fromuser: fromUser,
                postof: postOf == fromUser ? "their own " : postOf + "'s",
                postdate: FormatDate(postDate),
                posttype: postType,
                sortid: moment(new Date(postDate)).format("YYYYMMDDHHmmss")
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
        $("#fb_notfication_list" + intid + postid).sortLis();
        let currentCount = parseInt($("#notification_count" + intid + postid).text());
        $("#notification_count" + intid + postid).text(++currentCount);
        $("#notification_count" + intid + postid).show();
        $("#notification_bell" + intid + postid).addClass("blink_chat");

    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.AddFbNotifications()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function GotoThisPostItem($this, type, intid, postid, commentid, replyid) {
    try {
        var id = "";
        var offSetTop = "";
        if (type == "comment") {
            id = "#facebook_post_comment_article" + intid + postid + commentid;
        }
        else if (type == "reply") {
            id = "#facebook_post_reply_article" + intid + postid + commentid + replyid;
        }
        offSetTop = $(id).height() + 10;
        $(".facebook-post").scrollTo(id, 500, { offset: { top: -offSetTop } });
        $(id).find(".fb-post-comment").addClass("blink_once");
        setTimeout(function () { $(id).find(".fb-post-comment").removeClass("blink_once"); }, 1000);
        let currentCount = parseInt($("#notification_count" + intid + postid).text());
        if ($($this).find('.fb-notification-read').length === 0) {
            $($($this).find('span:last')).append(' <i class="material-icons md-16 uk-text-facebook fb-notification-read">done_all</i>');
            if (currentCount > 0) {
                $("#notification_count" + intid + postid).text(--currentCount);
                $("#notification_bell" + intid + postid).removeClass("blink_chat");
            }
            else {
                $("#notification_count" + intid + postid).hide();
                $("#notification_count" + intid + postid).text(0);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.GotoThisPostItem()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function SendPostComment(intid, postid) {
    try {
        var comment = $("#txtFbPostComment" + postid).val();
        if (comment != "")
            tmac_FB_CommentOnPost("SendPostCommentDone", { postid: postid }, global_DeviceID, intid, postid, comment);
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.SendPostComment()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function SendPostCommentDone(data, obj) {
    try {
        if (data.ResultCode > 0) {
            //clear the textarea
            $("#txtFbPostComment" + obj.postid).val("");
        } else {
            log.LogDetails("Error", "FacebookUI.SendPostCommentDone()", "Post comment failed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.SendPostCommentDone()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function SendCommentReply(intid, postid, commentid) {
    try {
        var reply = $("#txtFbCommentReply" + commentid).val();
        if (reply != "")
            tmac_FB_ReplyToComment("SendCommentReplyDone", { commentid: commentid }, global_DeviceID, intid, commentid, postid, reply);
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.SendCommentReply()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function SendCommentReplyDone(data, obj) {
    try {
        if (data.ResultCode > 0) {
            //clear the textarea
            $("#txtFbCommentReply" + obj.commentid).val("");
        } else {
            log.LogDetails("Error", "FacebookUI.SendCommentReplyDone()", "Comment reply failed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.SendCommentReplyDone()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function ShowReplyBox(intId, postId, commentId) {
    try {
        $("#div_reply_comment" + intId + postId + commentId).show();
        $("#txtFbCommentReply" + commentId).focus();
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.ShowReplyBox()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function ShowLess(intId, postId, commentId) {
    try {
        var ul = $("#facebook_post_reply_ul" + intId + postId + commentId);
        var reply = $("#div_reply_comment" + intId + postId + commentId);
        if (ul.length > 0) {
            ul.hide(300);
            var totalReplies = $("#facebook_post_reply_ul" + intId + postId + commentId + " > li > article").length;
            $("#btnShowMore" + commentId).removeClass("uk-display-none");
            $("#btnShowLess" + commentId).addClass("uk-display-none");
            $("#btnShowMore" + commentId)[0].innerHTML = "<i class='material-icons md-16'>reply</i> View " + totalReplies + (totalReplies === 1 ? " reply" : " replies");
        }
        reply.hide();
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.ShowLess()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
function ShowMore(intId, postId, commentId) {
    try {
        var ul = $("#facebook_post_reply_ul" + intId + postId + commentId);
        if (ul.length > 0) {
            ul.show();
        }
        $("#btnShowLess" + commentId).removeClass("uk-display-none");
        $("#btnShowMore" + commentId).addClass("uk-display-none");
    } catch (ex) {
        log.LogDetails("Error", "FacebookUI.ShowLess()", ex, false);
    }
}

//----------------------------------------------------------------------------------------------------------------
jQuery.fn.sortLis = function sortLis() {
    $("> li", this[0]).sort(dec_sort).appendTo(this[0]);
    function dec_sort(a, b) { return ($(b).data("sort")) > ($(a).data("sort")) ? 1 : -1; }
}

//----------------------------------------------------------------------------------------------------------------