// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Login.js";
var file_version = "3.1.06.04";
var changedBy = "Sirajuddin"
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

//this method will be exceuted after loading the file.
window.onload = function () {
    // lets set focus to lanid/station
    if ($.trim(GetLanID()) == "")
        $("#lan_id").focus();
    else
        $("#station_no").focus();
}

$(document).ready(function () {
    console.log("login loaded");

    $("#div_station").toggle(isStationAvailable);
    $("#div_password").toggle(isLoginWithPassword);
    $("#div_domain").toggle(isDomainList);

    // create DropDownList from input HTML element
    $("#domainList").kendoDropDownList();

    //put loading indicator for domain list, remove it after loading the items
    $('.k-i-arrow-60-down').addClass('k-i-loading')

    if (isDomainList) {
        GetUserDomainList();
    }

    $('#lan_id').keypress(function (e) {
        var key = e.which;
        if (key == 13) {
            $('#login_btn').click();
        }
    });

    $('#station_no').keypress(function (e) {
        var key = e.which;
        if (key == 13) {
            $('#login_btn').click();
        }
    });

    $('#agent_id').keypress(function (e) {
        var key = e.which;
        if (key == 13) {
            $('#login_btn').click();
        }
    });

    $('#password').keypress(function (e) {
        var key = e.which;
        if (key == 13) {
            $('#login_btn').click();
        }
    });
});

function GetLanID() {
    return $("#lan_id").val();
}

function GetStation() {
    if (isStationAvailable)
        return $("#station_no").val();
    else
        return GetLanID();
}

function GetAgent() {
    return $("#agent_id").val();
}

function GetPassword() {
    return $("#password").val();
}

function GetDomain() {
    return $("#domainList").val();
}

function loginDone() {
    window.open('', '_self', '');
}

//perform login function
function PerformLogin() {
    try {
        //get the values
        let domain = GetDomain();
        let lanid = GetLanID();
        let station = GetStation();
        let password = GetPassword();
        if (isDomainList && domain == "") {
            ShowNotify("Please select a domain", "danger", null, "top-center");
            return;
        }
        else if (lanid == "") {
            ShowNotify("Please provide lan id", "danger", null, "top-center");
            return;
        }
        else if (station == "") {
            ShowNotify("Please provide station", "danger", null, "top-center");
            return;
        }
        else if (isLoginWithPassword && password == "") {
            ShowNotify("Please provide password", "danger", null, "top-center");
            return;
        }
        if (!global_LoginRedisplay) {
            Login(isDomainList ? lanid = domain + "\\" + lanid : lanid, station, "", false, false, password);
        } else {
            var agent = $("#agent_id").val();
            if (agent == "") {
                ShowNotify("Please provide agent id", "danger", null, "top-center");
                return;
            }
            Login(isDomainList ? lanid = domain + "\\" + lanid : lanid, station, agent, false, true, password);
        }
        $("#login_btn").addClass("disabled");
        $("#login_spinner").removeClass("uk-display-none");
        $("#login_card").addClass("blur-background");
    } catch (ex) {
        log.LogDetails("Error", "Login.PerformLogin()", ex, false);
    }
}

//update the login div text
function UpdateLoginTextDiv(text, append) {
    try {
        $("#login_spinner").removeClass("uk-display-none");
        $("#login_card").addClass("blur-background");
        if (append) {
            document.getElementById('login_text').innerHTML = text;
        } else
            document.getElementById('login_text').innerHTML = text;
    } catch (ex) {
        log.LogDetails("Error", "Login.UpdateLoginTextDiv()", ex, false);
    }
}

//for invalid lan id response from server
function InvalidLanID() {
    try {
        if (isAgentIdOnInvalidLanId) {
            global_LoginRedisplay = true;
            $("#agent_extension").removeClass("uk-display-none");
            $("#agent_id").focus();
            ShowNotify("Invalid LAN ID detected. Please provide agent id.", "danger", null, "top-center");
        } else {
            ShowNotify("Invalid LAN ID detected. Please contact administrator for TMAC access.", "danger", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "Login.InvalidLanID()", ex, false);
    }
}

//to redisplay login
function LoginReDisplay(flag) {
    try {
        var lanid = $("#lan_id").val();
        $("#login_spinner").addClass("uk-display-none");
        $("#login_card").removeClass("blur-background");
        if (flag) {
            $("#login_card").removeClass("uk-display-none");
            document.getElementById("agent_extension").style.display = "block";
            $("#agent_id").val(lanid);
            document.getElementById("agent_id").readOnly = true;
        } else {
            $("#login_card").addClass("uk-display-none");
            document.getElementById("agent_extension").style.display = "block";
        }
    } catch (ex) {
        log.LogDetails("Error", "Login.LoginReDisplay()", ex, false);
    }
}

//only number validation
function ValidateChar(event) {
    try {
        if (isNaN(String.fromCharCode(event.keyCode)) || String.fromCharCode(event.keyCode).trim() === "")
            event.preventDefault();
    } catch (ex) {
        log.LogDetails("Error", "Login.ValidateChar()", ex, false);
    }
}