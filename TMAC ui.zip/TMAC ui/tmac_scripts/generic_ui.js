﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "GenericUI.js";
var file_version = "3.1.06.22";
var changedBy = "Sirajuddin"
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}

function GenericInteraction(event) {
    try {
        let headerTemplate = "";
        let bodyTemplate = "";
        let item = event.Item;
        let customData = JSON.parse(event.Item.Data);
        CloseAllTabs();
        SaveTabReference("generic_" + item.Type, event.InteractionID, "new");
        switch (item.Type) {
            case "VoiceBio":
                headerTemplate = GetTabHtml("tab_header_template", event.InteractionID, { icon: "phone" });
                bodyTemplate = GetTabHtml("voice_bio_body_template", event.InteractionID, null);
                break;
        }
        AddTab(bodyTemplate, headerTemplate, event.InteractionID, item.CustomerIdentifier, true, false, true);
        window[item.Type + "Interaction"](event);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.GenericInteraction()", ex, false);
    }
}

function HandleGenericCTIEvent(event) {
    try {
        window[event.SubEventName](event);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.HandleGenericCTIEvent()", ex, false);
    }
}

function HandleGenericCallEvent(event) {
    try {
        window[event.SubEventName](event);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.HandleGenericCallEvent()", ex, false);
    }
}

function GCEAgentStateChangeNotify(event) {
    try {
        let data = JSON.parse(event.JsonData);
        POMAgentStateChange(data);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.GCEAgentStateChangeNotify()", ex, false);
    }
}

function GCECallStateChangeNotify(event) {
    try {
        let data = JSON.parse(event.JsonData);
        POMCallStateChange(data);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.GCECallStateChangeNotify()", ex, false);
    }
}

function GCEOnOutboundCallInitiated(event) {
    try {
        let data = JSON.parse(event.JsonData);
        let deviceId = data.Device;
        let callId = data.CallID;
        let UCID = data.UCID;
        let campaignType = data.CampaignType;
        let connectionHandle = data.ConnectionHandle;
        let jsonData = JSON.parse(data.JsonData);
        CreatePOMCallbackTab(callId, connectionHandle, campaignType, jsonData);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.GCEOnOutboundCallInitiated()", ex, false);
    }
}

function GCEOutboundCallUUIData(event) {
    try {
        let data = JSON.parse(event.JsonData);
        POMOutboundCallUUIData(data);
    } catch (ex) {
        log.LogDetails("Error", "GenericUI.GCEOutboundCallUUIData()", ex, false);
    }
}