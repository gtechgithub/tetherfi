// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "VTM.js";
var file_version = "3.1.01.03";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
function AddScannedImages(intid, url, eid) {
    try {
        if (eid) {
            $("#eid_images_ul" + intid).append('<li style="max-height: 100px; max-width: 300px;" onclick="PreviewAttachment(\'' + url + '\');"><img src="' + url + '" width="100%" id="eid_img_' + intid + '"/></li>');
        }
        else {
            $("#scanned_images_ul" + intid).append('<li style="max-height: 100px; max-width: 300px;" onclick="PreviewAttachment(\'' + url + '\');"><img src="' + url + '" width="100%" id="scanned_img_' + intid + '"/></li>');
        }
        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.AppendScannedImages()", ex, false);
    }
}

function AddHardwareError(intid, message, type, isClose) {
    try {
        //append alerts for hardware errors
        //default alert color is blue or pass type as uk-alert-info[dark green], uk-alert-danger[red], uk-alert-success[green], uk-alert-warning[orange], this can be passed as parameter
        if (isClose)
            $("#div_hardware_status" + intid).append('<div class="uk-alert ' + type + '" data-uk-alert><a href="#" class="uk-alert-close uk-close"></a>' + message + '</div>');
        else
            $("#div_hardware_status" + intid).append('<div class="uk-alert ' + type + '" data-uk-alert>' + message + '</div>');
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.AppendScannedImages()", ex, false);
    }
}

function VTMCobrowse(intid, el) {
    try {
        //call for cobrowse
        //send EJLog
        sendCoBrowseCmd(el);
        sendEJLog("Clicked Button: CoBrowse");
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.VTMCobrowse()", ex, false);
    }
}

function AddCobrowseImage(intid, url) {
    try {
        if ($("#cobrowse_img" + intid).hasClass("uk-display-none"))
            $("#cobrowse_img" + intid).removeClass("uk-display-none");
        $("#cobrowse_img" + intid).attr("src", url);
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.AddCobrowseImage()", ex, false);
    }
}

function PreviewCoBrowse(intid) {
    try {
        var src = $("#cobrowse_img" + intid)[0].src;
        $("#imagePreviewImg").attr("src", src);
        $("#btn_refresh_cobrowse").removeClass("uk-display-none");
        UIkit.modal("#modal_previewImage").show();
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.PreviewCoBrowse()", ex, false);
    }
}

function AddVTMCustomerJourney(intid, journeyData) {
    try {
        $.each(journeyData, function (i, val) {
            $("#vtm_customer_journey" + intid).append(
                '<ul class="breadcrumbs vtmbreadcrumbs" id="ul_customer_journey' + intid + '">' +
                '<li><span>' + val.ActionName + '</span></li>' +
                '<li><span>' + val.ActionResult + '</span></li>' +
                '<li><span>' + val.ActionTime + '</span></li>' +
                '</ul>');
        });
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.AddVTMCustomerJourney()", ex, false);
    }
}

function ReScan(intId) {
    try {
        sendRescanCmd();
        $("#scanned_images_ul" + intId).html(""); //clear images
        $("#rescanMsg" + intId).text("Pending Customer to Rescan...");
        $("#btn_rescan" + intId).addClass("disabled");
        sendEJLog("Clicked Button: ReScan");
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.ReScan()", ex, false);
    }
}

function SaveEID(intid) {
    try {
        //verify not same user
        //required fields only if 1FA and Passport/NRIC
        if ($("#txtCheckerUserName").val().trim() == "") {
            ShowNotify("Checker username is required", "danger", null, "top-center");
            return;
        }

        if ($("#txtCheckerPwd").val().trim() == "") {
            ShowNotify("Checker password is required", "danger", null, "top-center");
            return;
        }

        sendEJLog("Clicked Button: SaveEID");

        var checkerUserName = $("#txtCheckerUserName").val().trim();
        var checkerPassword = $("#txtCheckerPwd").val().trim();

        if (checkerUserName.toLowerCase() == global_LanID.toLowerCase()) {
            ShowNotify("Logged In User cannot be a checker", "danger", null, "top-center");
            return;
        }
        sendEIDCmd = true;
        custom_VerifyCheckerCredentials(checkerUserName, checkerPassword, vtma_refId_intId.intId);
        $("#btn_save_eid").addClass("disabled");
        $("#btn_skip_eid").addClass("disabled");
        $("#eidMsg").text("Verifying...");
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.SaveEID()", ex, false);
    }
}

function ProcessFirstLevelManualAuth(result) {
    try {
        var data = JSON.parse(result.JsonData);
        if (data.result) {
            //hide first level Li tab
            //clear scanned images
            //take comments and send save EID command to vtma
            //Send Save EID command to VTMA
            //close modal
            //hide authentication part
            $("#fistLevelLi" + vtma_refId_intId.intId).addClass("uk-display-none");
            $("#scanned_images_ul" + vtma_refId_intId.intId).html("");
            $("#eid_images_ul" + vtma_refId_intId.intId).html("");
            sendFirstPassAuthCmd();
            if (sendEIDCmd) {
                sendSaveEIDCmd();
                sendEJLog("Clicked Button: SaveEID");
            }
            else {
                sendEJLog("Clicked Button: SkipEID");
            }
            $("#btn_save_eid").removeClass("disabled");
            $("#btn_skip_eid").removeClass("disabled");
            UIkit.modal("#modal_makerchecker").hide();
            $("#first_authentication" + result.InteractionID).addClass("uk-display-none");
            //$("#eidBlock" + vtma_refId_intId.intId).addClass("uk-display-none");
            $("#btn_rescan" + vtma_refId_intId.intId).addClass("uk-display-none");
            $("#rescanMsg" + vtma_refId_intId.intId).text("");
            isCallForAuth = false;
        }
        else {
            $("#btn_save_eid").removeClass("disabled");
            $("#btn_skip_eid").removeClass("disabled");
            ShowNotify("Checker credentials are wrong", "danger", null, "top-center");
        }
        $("#eidMsg").text("");
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.ProcessFirstLevelManualAuth()", ex, false);
    }
}

var sendEIDCmd = true;

function SkipEID(intid) {
    try {
        //take comments
        //proceed to maker checker
        if ($("#txtCheckerUserName").val().trim() == "") {
            ShowNotify("Checker username is required", "danger", null, "top-center");
            return;
        }

        if ($("#txtCheckerPwd").val().trim() == "") {
            ShowNotify("Checker password is required", "danger", null, "top-center");
            return;
        }

        sendEJLog("Clicked Button: SkipEID");

        var checkerUserName = $("#txtCheckerUserName").val().trim();
        var checkerPassword = $("#txtCheckerPwd").val().trim();

        if (checkerUserName.toLowerCase() == global_LanID.toLowerCase()) {
            ShowNotify("Logged In User cannot be a checker", "danger", null, "top-center");
            return;
        }

        sendEIDCmd = false;

        custom_VerifyCheckerCredentials(checkerUserName, checkerPassword, vtma_refId_intId.intId);
        $("#btn_save_eid").addClass("disabled");
        $("#btn_skip_eid").addClass("disabled");
        $("#eidMsg").text("Verifying...");
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.SkipEID()", ex, false);
    }
}

var autoDisconnect = false;
//can auto disconnect call
function vtma_canDisconnectCall() {
    return autoDisconnect;
}

//manual authentication block
function enableManualAuthentication(intId) {
    try {
        $("#fistLevelLi" + intId).removeClass("uk-display-none");
        $("#first_authentication" + intId).removeClass("uk-display-none");
        $("#btn_rescan" + intId).removeClass("uk-display-none");
        isCallForAuth = true;
        $("#btnDrop" + intId).addClass("disabled");
        //HoldCall(global_DeviceID, global_activeTabInteractionID, null);       commented by vasanth on 11Jan2018, to make it configurable from OCM in next sprint
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.enableManualAuthentication()", ex, false);
    }
}

function AuthenticationPass(intid, type) {
    try {
        switch (type) {
            case 'first':
                $("#txtCheckerUserName").val("");
                $("#txtCheckerPwd").val("");
                //$("#btn_rescan" + intid).addClass("uk-display-none");
                $("#rescanMsg" + intid).text("");
                sendEJLog("Clicked the Pass for 2FA MA");
                UIkit.modal("#modal_makerchecker").show();
                break;
            case 'tp':
            case 's':
            case 'm':
            default:
                //confirm for success
                //send pass command to vtma
                UIkit.modal.confirm("Confirm to Pass customer for 3FA Authentication?", function () {
                    SendSecondAuthStatusCmd(type, 'pass', 'success', "");
                    $("#second_authentication_methods" + intid).addClass("uk-display-none");
                    $("#second_authentication_" + type + intid).addClass("uk-display-none");
                    $("#secondLevelLi" + intid).addClass("uk-display-none");
                    sendEJLog("Clicked the Authentication Pass for 3FA: " + authMethodTypes[type]);
                    isCallForAuth = false;
                });
                break;
        }
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.AuthenticationPass()", ex, false);
    }
}

function AuthenticationFail(intid, type) {
    try {
        //check comments required
        //send fail command to vtma
        switch (type) {
            case 'main':
                sendFailAuthCmd('2014');
                break;
            case 'first':
                UIkit.modal.confirm("Confirm to fail customer for 2FA Authentication?", function () {
                    sendFailAuthCmd('2014');
                    $("#fistLevelLi" + intid).addClass("uk-display-none");
                    $("#first_authentication" + intid).addClass("uk-display-none");
                    $("#btn_rescan" + intid).addClass("uk-display-none");
                    $("#rescanMsg" + intid).text("");
                    isCallForAuth = false;
                    sendEJLog("Clicked the Authentication Fail for 2FA");
                });
                break;
            case 'tp':
            case 's':
            case 'm':
            default:
                //confirm for success
                //send fail command to vtma
                //flow change: send last auth failed
                UIkit.modal.confirm("Confirm to fail customer for 3FA Authentication?", function () {
                    SendSecondAuthStatusCmd(last3FAAuthFailType, 'fail', 'fail', "");
                    $("#second_authentication_" + last3FAAuthFailType + intid).addClass("uk-display-none");
                    $("#second_authentication_methods" + intid).addClass("uk-display-none");
                    var failBtn = (type == "" ? "Fail3FA" : last3FAAuthFailType);
                    sendEJLog("Clicked the Authentication Fail for " + failBtn);
                });
                break;
        }
        isCallForAuth = false; //true : meaning enfore condition on end call, false: remove condition
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.AuthenticationFail()", ex, false);
    }
}

//2nd level authentication
//1-Signature, 2-Thumbprint, 3-MA
var actionCodes = {
    "s": "1",
    "tp": "2",
    "m": "3"
}
//12->Verified 16->Other3FAOptions 17->faild 18->Retry
var eventNumbers = {
    "pass": "12",
    "other": "16",
    "fail": "17",
    "retry": "18"
}

// resultCode, 0000->successful 9999->faild
var resultCodes = {
    "success": "0000",
    "fail": "9999"
}

var authMethodTypes = {
    "s": "Signature",
    "tp": "Thumbprint",
    "m": "MA Questions"
}

function EnableSecondLevelAuthenticationMethods(intid, isFirstCompleted) {
    try {
        if (isFirstCompleted) {
            $("#second_authentication_methods" + intid).removeClass("uk-display-none");
            $("#fistLevelLi" + intid).addClass("uk-display-none");
            $("#btn_rescan" + intid).addClass("uk-display-none");
            //$("#divCinSuffix" + intid).addClass("uk-display-none");
        }
        $("#secondLevelLi" + intid).removeClass("uk-display-none");
        isCallForAuth = true;
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.EnableSecondLevelAuthenticationMethods()", ex, false);
    }
}

function SecondAuthMethodChoosen(intid, type) {
    try {
        //show alert
        //hide auth methods
        //show signature block
        //send sig command
        //send EJ Log
        switch (type) {
            case 's':
            case 'tp':
            case 'm':
                $("#btn_fail_3fa" + intid).removeClass('disabled');
                $("#second_authentication_methods" + intid).addClass("uk-display-none");
                if (type == 'm')
                    $("#second_authentication_m" + intid).removeClass("uk-display-none");
                SendSecondLevelAuthReqCmd(type);
                sendEJLog("Clicked Button: " + authMethodTypes[type] + " Authentication");
                break;
        }
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.SecondAuthMethodChoosen(): " + type, ex, false);
    }

}

//call on receiving sig from vtma
function SignatureCaptured(intid, src) {
    try {
        ShowNotify("Customer signature has been captured successfully.", "success", null, "top-center");
        //show dialog on receiving signature and enable signature portion
        //set image
        $("#second_authentication_s" + intid).removeClass("uk-display-none");
        var imgUrl = imgRepoServerUrl + src + "&" + new Date().getTime();
        AddScannedImages(intid, imgUrl, false);
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.SignatureCaptured()", ex, false);
    }
}

//call on receiving sig cancel from vtma
function SignatureCancel(intid) {
    try {
        ShowNotify("Customer signature has been cancelled.", "success", null, "top-center");
        //clear image and hide signature portion
        //show auth methods
        $("#scanned_images_ul" + intid).html("");
        $("#second_authentication_s" + intid).addClass("uk-display-none");
        $("#second_authentication_methods" + intid).removeClass("uk-display-none");
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.SignatureCancel()", ex, false);
    }
}

//call on receiving tp from vtma
function ThumbprintCaptured(intid, src) {
    try {
        //set image
        //show dialog on receiving thumbprint and enable thumbprint portion
        $("#second_authentication_tp" + intid).removeClass("uk-display-none");
        var imgUrl = imgRepoServerUrl + src + "&" + new Date().getTime();
        AddScannedImages(intid, imgUrl, false);
        ShowNotify("Customer Thumbprint has been captured successfully.", "success", null, "top-center");
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.ThumbprintCaptured()", ex, false);
    }
}

//call on receiving tp cancel from vtma
function ThumbprintCancel(intid) {
    try {
        ShowNotify("Customer thumbprint has been cancelled.", "success", null, "top-center");
        //clear image and hide signature portion
        //show auth methods
        $("#scanned_images_ul" + intid).html("");
        $("#second_authentication_tp" + intid).addClass("uk-display-none");
        $("#second_authentication_methods" + intid).removeClass("uk-display-none");
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.ThumbprintCancel()", ex, false);
    }
}

function AuthenticationRetry(intid, authType) {
    try {
        //clear images
        UIkit.modal.confirm("Would you like to capture again?", function () {
            $("#scanned_images_ul" + intid).html("");
            SendSecondAuthStatusCmd(authType, 'retry', 'success', "");
            sendEJLog("Clicked Button: Retry " + authMethodTypes[authType]);
        });
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.AuthenticationRetry()", ex, false);
    }
};

var last3FAAuthFailType = '';
function OtherFAOptions(intid, type) {
    try {
        //clear images
        //hide all auth types
        //show auth methods
        $("#scanned_images_ul" + intid).html("");
        $("#second_authentication_tp" + intid).addClass("uk-display-none");
        $("#second_authentication_s" + intid).addClass("uk-display-none");
        $("#second_authentication_m" + intid).addClass("uk-display-none");
        $("#second_authentication_methods" + intid).removeClass("uk-display-none");
        SendSecondAuthStatusCmd(type, 'other', 'success', "");
        sendEJLog("Clicked Button: Fail for 3FA: " + authMethodTypes[type]);
        last3FAAuthFailType = type;
    } catch (ex) {
        log.LogDetails("Error", "VTMUI.OtherFAOptions()", ex, false);
    }
}

//CIN Suffix Reload SOI
function custom_ddlSuffixChange(intid) {
    try {
        //reload SOI Info
        //send getEID cmd to reload EID
        //send EJLog
        var cin = $("#nric" + intid).text();
        var cinSuffix = $("#ddl_suffix" + intid).val();
        custom_FetchCustProf(intid, cin, cinSuffix);
        sendGetEIDCmd(cin, cinSuffix);
        sendEJLog("Clicked Dropdown: Checked with CINSuffix " + cinSuffix);
    }
    catch (ex) {
        log.LogDetails("Error", "VTMUI.custom_ddlSuffixChange()", ex, false);
    }
}

//Complete Button
function Complete(intid) {
    $("#btn_complete" + intid).addClass("uk-display-none");
    sendCompleteCmd();
}