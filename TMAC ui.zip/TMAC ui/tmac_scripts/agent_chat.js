// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "AgentChat.js";
var file_version = "3.1.06.11";
var changedBy = "Sirajuddin"
try {
    //global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------
var $chatbox_wrapper = $('#chatbox_wrapper');
agent_chat = {
    agentlist: function () {
        $("#loadagentlist").addClass("uk-icon-spin");
        GetLoggedInAgentList();
    },
    agentlist_loaded: function (data, obj) {
        try {
            $("#loadagentlist").removeClass("uk-icon-spin");
            $("#chatboxes").html("");
            if (data.length > 1) {
                $.each(data, function (i, val) {
                    if (val.AgentLoginID !== global_AgentID) {
                        agent_chat.add_agent_list(val);
                    }
                });
            } else {
                var li = "<li>No agents logged In</li>";
                $("#chatboxes").html(li);
            }
        } catch (ex) {
            console.log(ex);
        }
    },
    add_agent_list: function (data) {
        try {
            var t = $("#agent_list_template").html(), //template divs
                e = $("#chatboxes"), //to be appended to
                n = Handlebars.compile(t), //initialize handlebars for the template divs       
                context = {
                    agentid: data.AgentLoginID,
                    agentname: data.AgentName,
                    agentprofile: data.UserProfileForAgent == "S" ? "Supervisor" : "Agent",
                    currentstatus: data.CurrentAgentStatus,
                    agentstatus:
                        (data.CurrentAgentStatus.indexOf("On Call") >= 0) ? "danger" :
                            (data.CurrentAgentStatus == "Available") ? "success" :
                                (data.CurrentAgentStatus == "ACW") ? "warning" : "info",
                    class: ""
                    //class: data.CurrentAgentStatus.indexOf("On Call") >= 0 ? "disable-agent" : ""
                }, //add context data
                s = n(context); //execute the template with handlebar and context
            e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
        } catch (ex) {
            console.log(ex);
        }
    },
    chat_list: function () {
        // show chatbox
    },
    chatboxes: function () {

        // disable page scroll when scrolling chatbox content
        $chatbox_wrapper.on('mousewheel DOMMouseScroll', '.chatbox_content', function (e) {
            var e0 = e.originalEvent;
            var delta = e0.wheelDelta || -e0.detail;
            this.scrollTop += (delta < 0 ? 1 : -1) * 30;
            e.preventDefault();
        });

        // make chatbox active
        $chatbox_wrapper.on('click', '.chatbox', function (e) {
            e.preventDefault();
            $chatbox_wrapper.find('.cb_active').not($(this)).removeClass('cb_active');
            var $chatbox = $(this);
            if ($(e.target).closest('.chatbox_close').length) {
                return;
            }
            else if ($(e.target).closest('.chatbox_header').length) {
                if ($chatbox.hasClass('expanded')) {
                    $chatbox.removeClass('expanded cb_active');
                    $chatbox.addClass('minimizing');
                }
                else {
                    $chatbox.removeClass('minimizing');
                    $chatbox.addClass('expanded cb_active');
                    let user = $chatbox.attr('data-user-id');
                    if (!$("#unread" + user).hasClass("uk-display-none")) {
                        $("#unread" + user).addClass("uk-display-none");
                        $("#unread" + user).text(0);
                        $chatbox.find(".chatbox_header").removeClass("blink_IM");
                    }
                }
                return;
            }
            if (!$chatbox.hasClass('cb_active')) {
                $chatbox.addClass('cb_active');
                if (!$(e.target).closest('.actions_dropdown').length) {
                    $chatbox.find('.message_input').focus();
                }
            }
        });

        // make chatbox inactive
        $document.on('click', function (e) {
            if (!$(e.target).closest('.chatbox').length) {
                $chatbox_wrapper.find('.cb_active').removeClass('cb_active');
            }
        });

        // close chatbox
        $chatbox_wrapper.on('click', '.chatbox_close', function (e) {
            e.preventDefault();

            var $chatbox = $(this).closest('.chatbox').addClass('removing'),
                user = $chatbox.attr('data-user');
            setTimeout(function () {
                $('#chatboxes').children('li[data-user="' + user + '"]').removeClass('chatbox_active');
                $chatbox.remove();
            }, 280)
        });

        // send message
        $chatbox_wrapper.on('keyup', '.message_input', function (e) {
            var $this = $(this);
            e.preventDefault();
            var code = e.keyCode || e.which;
            if (code == 13 && $this.val() != '') {
                var $chatbox = $(this).closest('.chatbox'),
                    $chatbox_content = $chatbox.find('.chatbox_content'),
                    conversation_template = Handlebars.compile($("#chatbox_conversation").html()),
                    messages_template = Handlebars.compile($("#chatbox_messages").html());
                if ($.trim($this.val()) != "") {
                    tmacAgentChatObj.push({
                        agentId: $chatbox.attr('data-user-id'),
                        time: new Date().getTime(),
                        message: $this.val(),
                        type: "own"
                    });
                    var context = {
                        conversation: [{
                            own: true,
                            messages: [{
                                time: new Date().getTime(),
                                text: $this.val()
                            }]
                        }]
                    };

                    var conversation = conversation_template(context),
                        messages = messages_template(context.conversation[0]);

                    if (!$chatbox_content.children('.chatbox_message:last-child').hasClass('own')) {
                        $chatbox_content.append(conversation);
                    } else {
                        $chatbox_content.children('.chatbox_message:last-child').children('ul').append(messages);
                    }
                    $chatbox_content.scrollTop($chatbox_content[0].scrollHeight);
                    SendIMToAgent($chatbox.attr('data-user-id'), $this.val());
                    $(this).val('');
                }
            }
        });
    },
    chat_received: function (data) {
        try {
            let type = "other";
            if (data.mType !== undefined) {
                type = data.mType;
            }
            tmacAgentChatObj.push({
                agentId: data.FromAgentId,
                time: new Date().getTime(),
                message: data.Message,
                type: type
            });

            //get the agent reference from agent list
            let $that = $('li[data-user="' + data.FromAgentName + '"]');
            //if the agent not found in the list, then reload the list
            if ($that.length == 0) {
                //load the list again
                GetLoggedInAgentList();
                //set a timer and wait until the agent list is loaded then show the chat
                var timer = setInterval(function (e) {
                    $that = $('li[data-user="' + data.FromAgentName + '"]');
                    if ($that.length > 0) {
                        //if the agent list is loaded then show the chat
                        agent_chat.show_received_chat($that, data, type);
                        //clear interval
                        clearInterval(timer);
                    }
                }, 500);
            }
            else {
                agent_chat.show_received_chat($that, data, type);
            }
        } catch (ex) {
            console.log(ex);
        }
    },
    show_received_chat: function ($that, data, type) {
        try {
            let isActive = $that.hasClass('chatbox_active');
            if (!isActive) {
                $that.trigger('click');
            } else {
                let msg = "";
                let context = {};
                let chatTranscriptObj = tmacAgentChatObj.sort(sort_by('time', true, parseInt));
                for (var i = 0; i < chatTranscriptObj.length; i++) {
                    if (type == "own") {
                        msg = data.Message;
                        context = {
                            conversation: [{
                                own: true,
                                messages: [{
                                    time: new Date().getTime(),
                                    text: msg
                                }]
                            }]
                        };
                        break;
                    }
                    else if (chatTranscriptObj[i].type == "other") {
                        msg = chatTranscriptObj[i].message;
                        context = {
                            conversation: [{
                                messages: [{
                                    time: new Date().getTime(),
                                    text: msg
                                }]
                            }]
                        };
                        break;
                    }
                }
                let conversation_template = Handlebars.compile($("#chatbox_conversation").html());
                let conversation = conversation_template(context),
                    messages_template = Handlebars.compile($("#chatbox_messages").html()),
                    messages = messages_template(context.conversation[0]);

                let $chatbox = $chatbox_wrapper.children('.chatbox:first-child'),
                    $chatbox_content = $chatbox.find('.chatbox_content');

                if (type == "own") {
                    if (!$chatbox_content.children('.chatbox_message:last-child').hasClass('own')) {
                        $chatbox_content.append(conversation);
                    } else {
                        $chatbox_content.children('.chatbox_message:last-child').children('ul').append(messages);
                    }
                }
                else {
                    if ($chatbox_content.children('.chatbox_message:last-child').hasClass('own')) {
                        $chatbox_content.append(conversation);
                    } else {
                        $chatbox_content.children('.chatbox_message:last-child').children('ul').append(messages);
                    }
                }
                if ($chatbox.hasClass("minimizing")) {
                    let currentCount = parseInt($("#unread" + data.FromAgentId).text());
                    $("#unread" + data.FromAgentId).removeClass("uk-display-none");
                    $("#unread" + data.FromAgentId).text(++currentCount);
                    $chatbox.find(".chatbox_header").addClass("blink_IM");
                }
                else {
                    $chatbox_content.scrollTop($chatbox_content[0].scrollHeight);
                }
            }
            ShowNotification(data.FromAgentName, data.Message);
        } catch (ex) {

        }
    }
};
$('#chatboxes').on('click', '> li', function () {
    var source = $("#chatbox_template").html();
    var $this = $(this),
        isActive = $this.hasClass('chatbox_active');
    var conv = [];
    var lastAdded = "";
    var agentId = $(this).attr('data-user-id');
    var chatTranscriptObj = tmacAgentChatObj.sort(sort_by('time', false, parseInt));
    $.each(chatTranscriptObj, function (i, val) {
        if (val.agentId == agentId) {
            if (val.type == "own") {
                if (lastAdded != "own" || conv.length === 0)
                    conv.push({
                        own: true,
                        messages: [{
                            time: val.time,
                            text: val.message
                        }]
                    });
                else
                    conv[conv.length - 1].messages.push({
                        time: val.time,
                        text: val.message
                    });
            } else {
                if (lastAdded != "other" || conv.length === 0)
                    conv.push({
                        //avatarUrl: 'assets/img/' + $(this).attr('data-user-avatar') + '.png',
                        avatarUrl: '',
                        messages: [{
                            time: val.time,
                            text: val.message
                        }]
                    });
                else
                    conv[conv.length - 1].messages.push({
                        time: val.time,
                        text: val.message
                    });
            }
            lastAdded = val.type;
        }
    });
    var template = Handlebars.compile(source);
    var messages_template = Handlebars.compile($("#chatbox_messages").html());
    if (!isActive) {
        $this.addClass('chatbox_active');
        var context = {
            username: $(this).attr('data-user'),
            agentid: $(this).attr('data-user-id'),
            conversation: conv
        };
        Handlebars.registerPartial("conversation", $("#chatbox_conversation").html());
        Handlebars.registerPartial("messages", $("#chatbox_messages").html());
        var html = template(context);
        $chatbox_wrapper.prepend(html);
        if (global_UserProfileForAgent == "A")
            $("#showDetailsBtn" + $(this).attr('data-user-id')).hide();
        var $chatbox = $chatbox_wrapper.children('.chatbox:first-child'),
            $chatbox_content = $chatbox.find('.chatbox_content');

        $chatbox_content.scrollTop($chatbox_content[0].scrollHeight);

        //$chatbox_content.height($chatbox.closest('.chatbox').height() - $chatbox.find('.chatbox_header').height() - $chatbox.find('.chatbox_footer').height() );

        // message input autosize
        var $messageInput = $chatbox_wrapper.find('.message_input');
        autosize($messageInput);

        $messageInput.on('autosize:resized', function () {
            $chatbox.css({
                'padding-bottom': $messageInput.outerHeight()
            })
        });
        $chatbox.find(".chatbox_max").toggle();
    }
});
/* handlebars helpers */
//  moment syntax example: moment(Date("2011-07-18T15:50:52")).format("MMMM YYYY")
//  usage: {{dateFormat creation_date format="MMMM YYYY"}}
Handlebars.registerHelper('dateFormat', function (context, block) {
    if (window.moment) {
        var f = block.hash.format || "MMM DD, YYYY hh:mm:ss A";
        return moment(context).format(f); //had to remove Date(context)
    } else {
        return context; //  moment plugin not available. return data as is.
    }
});

// extended "if" block helper
// usage {{#ifCond var1 '==' var2}}
Handlebars.registerHelper('ifCond', function (v1, operator, v2, options) {
    switch (operator) {
        case '==':
            return (v1 == v2) ? options.fn(this) : options.inverse(this);
        case '===':
            return (v1 === v2) ? options.fn(this) : options.inverse(this);
        case '!==':
            return (v1 !== v2) ? options.fn(this) : options.inverse(this);
        case '<':
            return (v1 < v2) ? options.fn(this) : options.inverse(this);
        case '<=':
            return (v1 <= v2) ? options.fn(this) : options.inverse(this);
        case '>':
            return (v1 > v2) ? options.fn(this) : options.inverse(this);
        case '>=':
            return (v1 >= v2) ? options.fn(this) : options.inverse(this);
        case '&&':
            return (v1 && v2) ? options.fn(this) : options.inverse(this);
        case '||':
            return (v1 || v2) ? options.fn(this) : options.inverse(this);
        default:
            return options.inverse(this);
    }
});

/**
 * The {{#exists}} helper checks if a variable is defined.
 */
Handlebars.registerHelper('exists', function (variable, options) {
    if (typeof variable !== 'undefined') {
        return options.fn(this);
    } else {
        return options.inverse(this);
    }
});

$(function () {
    $body.addClass('sidebar_secondary_persisten');
    agent_chat.agentlist();
    agent_chat.chat_list();
    agent_chat.chatboxes();
});