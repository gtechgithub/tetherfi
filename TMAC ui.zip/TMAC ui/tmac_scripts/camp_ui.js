﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CampUI.js";
var file_version = "3.1.05.25";
var changedBy = "Sirajuddin";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
function AcceptCallack(fromAddr) {
    try {
        OnAgentResponseToDacRequest(fromAddr, "accept", global_AgentID, global_DeviceID, "");
    } catch (ex) {
        log.LogDetails("Error", "CampUI.AcceptCallack()", ex, false);
    }
}

function RejectCallack(fromAddr) {
    try {
        OnAgentResponseToDacRequest(fromAddr, "reject", global_AgentID, global_DeviceID, "");
    } catch (ex) {
        log.LogDetails("Error", "CampUI.RejectCallack()", ex, false);
    }
}

function SnoozeCallback(fromAddr) {
    try {
        let date = new Date();
        let d = moment(date).add(parseInt($("#txtSnooze").val()), 'm').toDate();
        scheduletTime = moment(d).format("YYYYMMDDHHmmss");
        OnAgentResponseToDacRequest(fromAddr, "snooze", global_AgentID, global_DeviceID, scheduletTime);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.SnoozeCallback()", ex, false);
    }
}

function OnAgentResponseToDacRequestDone(result, mydata) {
    try {
        callbackDialog.dialog("close");
        if (result == 0) {
            log.LogDetails("Success", "CampUI.OnAgentResponseToDacRequestDone", mydata + " success", true);
        } else {
            log.LogDetails("Error", "CampUI.OnAgentResponseToDacRequestDone", mydata + " failed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CampUI.OnAgentResponseToDacRequestDone()", ex, false);
    }
}

function tmacevent_TCM_DirectAgentNotifyEvent(event) {
    try {
        let obj = JSON.parse(event.JsonData);
        let contact = JSON.parse(obj.Contact);
        let data = "Callback for " + contact.Name + " number " + contact.PhoneNumber + ".";
        callbackAlertMessageDialog(data, "info", event.JsonData);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.tmacevent_TCM_DirectAgentNotifyEvent()", ex, false);
    }
}

function tmacevent_TCM_DirectAgentNotifyTimeoutEvent(event) {
    try {
        let obj = JSON.parse(event.JsonData);
        let contact = JSON.parse(obj.Contact);
        let data = "Callback for " + contact.Name + " number " + contact.PhoneNumber + " will be routed to skill.";
        log.LogDetails("Error", "CampUI.OnAgentResponseToDacRequestDone", data, true);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.tmacevent_TCM_DirectAgentNotifyTimeoutEvent()", ex, false);
    }
}

function camp_setCallerData(intid, phone, recordid, intent) {
    try {
        //intent
        // try {
        // let intentEvent = {};
        // intentEvent.InteractionID = intid;
        // intentEvent.IntentName = intent;
        // intentEvent.IntentStatus = 'Close';
        // tmacevent_CallerIntentEvent(intentEvent);
        // } catch (e) {
        // }

        ChangeStatus(global_DeviceID, "acw", 0);
        $("#hf_voice_phone" + intid).val(phone);
        $("#hf_voice_source" + intid).val('tcamp');
        $("#hf_voice_sourceid" + intid).val(recordid);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.camp_setCallerData()", ex, false);
    }
}

function NotifyCampaignType(type, intid) {
    try {
        if (type == "pop") {

        }
        else if (type == "iframe") {
            $("#custom_frame" + intid).removeClass("uk-display-none");
        }
    } catch (ex) {
        log.LogDetails("Error", "CampUI.NotifyCampaignType()", ex, false);
    }
}

function OnAgentResponseToDacRequest(fromAddr, response, agentID, extension, scheduletime) {
    try {
        let d = {};
        d.fromAddr = fromAddr;
        d.response = response;
        d.agentID = agentID;
        d.extension = extension;
        d.scheduletime = scheduletime;
        CallServer(d, "OnAgentResponseToDacRequest", response);
    } catch (ex) {
        log.LogDetails("Error", "CampUI.OnAgentResponseToDacRequest()", ex, false);
    }
}

function CallServer(obj, method, mydata) {
    try {
        $.ajax({
            type: "POST",
            url: campServiceUrl + "/" + method,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(obj),
            success: function (result) {
                window[method + "Done"](result.d, mydata);
            },
            error: function (result) {
                log.LogDetails("Error", "CampUI.CallServer() - AJAX - ", result.responseText, false);
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "CampUI.CallServer()", ex, false);
    }
}