﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CommandManager.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    //global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

$(document).ready(function () {
    console.log('dynamic crm loaded');
});

//--------------------------------------Chat Start CRM Popup---------------------------------------------
function DynamicsCRMStartChatPopUpScreen(event) {
    console.log('Inside - DynamicsCRMStartChatPopUpScreen');
    if (global_IsCRMEnabled == 0) {
        return;
    }
    if (global_CRMName != "MSD") {
        return;
    }

    var scName;
    if (event.screenName == null || event.screenName == '') {
        scName = event.screenName1;
    }
    else {
        scName = event.screenName;
    }
	var parse = JSON.parse(event.JsonData);
	var cif = parse.eCif;
    var date = getCurrentDateCRM();
    var time = getCurrentTimeCRM();
    var popupURL = global_MSDChatAcceptPopUpURL;

    popupURL = popupURL.replace(/CIFIDTag/g, cif); //replace CIF
    popupURL = popupURL.replace(/ChatSessionIDTag/g, event.TextChatSessionID); // replace ChatSessionID
    popupURL = popupURL.replace(/ChatIntentTag/g, parse.pTopic); // replace ChatIntent
    popupURL = popupURL.replace(/ChatSessionStartDateTag/g, date); // replace ChatSessionStartDate
    popupURL = popupURL.replace(/ChatSessionStartTimeTag/g, time); // replace ChatSessionStartTime
    popupURL = popupURL.replace(/AgentIdTag/g, global_LanID); // replace AgentId
    popupURL = popupURL.replace(/ActionFlagTag/g, '1'); // replace ActionFlagTag
    popupURL = popupURL.replace(/CustomerNameTag/g, scName); // replace Customer Name
	log.LogDetails(log.logType.Info, "DynamicsCRMStartChatPopUpScreen", "popup URL:[" + popupURL + "]", false);
    //assign CRM data
    GetTabReferenceObj(event.InteractionID).CRMWindowData.URL = popupURL;
    GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
																							"MSDChat" + event.InteractionID,
																							"menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
																							",height=" + DynamicsCRMScreenResolution_Height() +
																							",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
																							",left=" + DynamicsCRMScreenResolution_Position_Left());

    // alert indicatior for Incoming chat
    ShowNotification("You have new ", "Incoming Chat");
}

//--------------------------------------Chat End CRM Popup---------------------------------------------
function DynamicsCRMEndChatPopUpScreen(event) {
    if (global_IsCRMEnabled == 0) {
        return;
    }
	if (global_CRMName != "MSD") {
        return;
    }
    var date = getCurrentDateCRM();
    var time = getCurrentTimeCRM();
	var popupURL;
	
	 try {
			popupURL = GetTabReferenceObj(event.InteractionID).CRMWindowData.URL;
    }
    catch (e) {
		popupURL = global_MSDChatClosePopUpURL;
	}
    
    popupURL = popupURL.slice(0, -1); // remove last char
    popupURL += '2'; // add char, that you want to be placed instead of the earlier action flag
    popupURL += '&ChatSessionEndDate=ChatSessionEndDateTag';
    popupURL = popupURL.replace(/ChatSessionEndDateTag/g, date); //replace Chat End Date
    popupURL += '&ChatSessionEndTime=ChatSessionEndTimeTag';
    popupURL = popupURL.replace(/ChatSessionEndTimeTag/g, time); //replace Chat End Time	
    try {

        //change the URL
        GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle.location.href = popupURL;
    }
    catch (e) {
        GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
																							"MSDChat" + event.InteractionID,
																							"menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
																							",height=" + DynamicsCRMScreenResolution_Height() +
																							",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
																							",left=" + DynamicsCRMScreenResolution_Position_Left());
    }
	log.LogDetails(log.logType.Info, "DynamicsCRMEndChatPopUpScreen", "popup URL:[" + popupURL + "]", false);
}

//--------------------------------------Voice Start CRM Popup---------------------------------------------
/* ----------------------- Added by Manjunath for Voice Start CRM popup ---------------------------- */
function DynamicsCRMStartVoicePopUpScreen(event, isInboundCall) {
    console.log('Inside - DynamicsCRMStartVoicePopUpScreen');
    if (global_IsCRMEnabled == 0) {
        return;
    }

    if (global_CRMName != "MSD") {
        return;
    }

    if (GetTabReferenceObj(event.InteractionID).OtherData.customMakeCallDone) {
        return;
    }

    if (isInboundCall) {
        //if it is a station to station call do not pop up crm
        if (event.CallType == "2") {
            return;
        }
    }

    var date = getCurrentDateCRM();
    var time = getCurrentTimeCRM();
    var popupURL = "";
    var callerId = "";
    //var isInternalCallFlag = false;
    if (isInboundCall) {
        popupURL = global_MSDInboundVoicePopUpURL;
        popupURL = popupURL.replace(/UCIDTag/g, event.UCID); // replace UCID
        popupURL = popupURL.replace(/CallerIdTag/g, event.PhoneNumber); // replace CallerID
        callerId = event.PhoneNumber;
    }
    else {
        popupURL = global_MSDOutboundVoicePopUpURL;
        callerId = GetTabReferenceObj(event.InteractionID).OtherData.PhoneNumber;
        popupURL = popupURL.replace(/UCIDTag/g, event.PhoneNumber); // replace UCID
        popupURL = popupURL.replace(/CallerIdTag/g, callerId); // replace CallerID
    }

    //isInternalCallFlag = isInternalCall(callerId);

    popupURL = popupURL.replace(/VoiceSessionStartDateTag/g, date); // replace VoiceCallStartDate
    popupURL = popupURL.replace(/VoiceSessionStartTimeTag/g, time); // replace VoiceCallStartTime
    popupURL = popupURL.replace(/AgentIdTag/g, global_LanID); // replace AgentId
	
	log.LogDetails(log.logType.Info, "DynamicsCRMStartVoicePopUpScreen", "popup URL:[" + popupURL + "]", false);
    //assign CRM data
    GetTabReferenceObj(event.InteractionID).CRMWindowData.URL = popupURL;
    //if (!isInternalCallFlag) {
        GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
            "MSDVoice" + event.InteractionID,
            "menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
            ",height=" + DynamicsCRMScreenResolution_Height() +
            ",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
            ",left=" + DynamicsCRMScreenResolution_Position_Left());
    //}

    // alert indicatior for Incoming voice call
    if (isInboundCall) {
        ShowNotification("You have new ", "Incoming Voice Call");
    }
}
//--------------------------------------Voice End CRM Popup---------------------------------------------
function DynamicsCRMEndVoicePopUpScreen(event, isInboundCall) {
    console.log('Inside - DynamicsCRMEndVoicePopUpScreen');
    if (global_IsCRMEnabled == 0) {
        return;
    }
	if (global_CRMName != "MSD") {
        return;
    }

    if (GetTabReferenceObj(event.InteractionID).OtherData.customMakeCallDone) {
        return;
    }

    if (GetTabReferenceObj(event.InteractionID).OtherData.CallType == '2') {
        return;
    }

    var date = getCurrentDateCRM();
    var time = getCurrentTimeCRM();
	var popupURL;
	
	try {
		popupURL = GetTabReferenceObj(event.InteractionID).CRMWindowData.URL;
    }
    catch (e) {
		if (isInboundCall) {
			popupURL = global_MSDInboundVoicePopUpURL;
		}
		 else {
			 popupURL = global_MSDOutboundVoicePopUpURL;
		 }
    }
	
	if (isInboundCall) {
        popupURL = popupURL.slice(0, -1); // remove last char
    }
    else {
        popupURL = popupURL.slice(0, -2); // remove last 2 char
    }

    popupURL += isInboundCall ? "8" : "12"; // add char, that you want to be placed instead of the earlier action flag
    popupURL += '&CallEndDate=VoiceSessionEndDateTag';
    popupURL = popupURL.replace(/VoiceSessionEndDateTag/g, date); //replace voice call End Date
    popupURL += '&CallEndTime=VoiceSessionEndTimeTag';
    popupURL = popupURL.replace(/VoiceSessionEndTimeTag/g, time); //replace voice call End Time
	
	log.LogDetails(log.logType.Info, "DynamicsCRMEndVoicePopUpScreen", "popup URL:[" + popupURL + "]", false);

    try {

        //change the URL
        GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle.location.href = popupURL;

    }
    catch (e) {
        GetTabReferenceObj(event.InteractionID).CRMWindowData.WindowHandle = window.open(popupURL,
																							"MSDVoice" + event.InteractionID,
																							"menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
																							",height=" + DynamicsCRMScreenResolution_Height() +
																							",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
																							",left=" + DynamicsCRMScreenResolution_Position_Left());
    }
}

//--------------------------------------Callback Start CRM Popup---------------------------------------------
function DynamicsCRMStartCallbackPopUpScreen(intid, cif, ucid, chatsessionid) {
    if (global_IsCRMEnabled == 0) {
        return;
    }
    if (global_CRMName != "MSD") {
        return;
    }

    var date = getCurrentDateCRM();
    var time = getCurrentTimeCRM();
    var popupurl = global_MSDCallbackAcceptPopUpURL;

    popupurl = popupurl.replace(/CIFIDTag/g, cif); //replace CIF
    popupurl = popupurl.replace(/CallbackSessionIDTag/g, ucid); // replace Callback Session ID
    popupurl = popupurl.replace(/ParentChatSessionIDTag/g, chatsessionid); // replace VA Chat Session ID
    popupurl = popupurl.replace(/CallStartDateTag/g, date); // replace Callback Start Date
    popupurl = popupurl.replace(/CallStartTimeTag/g, time); // replace Callback Start Time
    popupurl = popupurl.replace(/CallBackType/g, 'CallbackType'); // replace Callback Type
    popupurl = popupurl.replace(/AgentIdTag/g, global_LanID); // replace AgentId
    popupurl = popupurl.replace(/IntentTag/g, ''); // replace IntentTag
    popupurl = popupurl.replace(/ActionFlagTag/g, '3'); // replace ActionFlagTag
	
	log.LogDetails(log.logType.Info, "DynamicsCRMStartCallbackPopUpScreen", "popup URL:[" + popupurl + "]", false);

    GetTabReferenceObj(intid).CRMWindowData.URL = popupurl;
    GetTabReferenceObj(intid).CRMWindowData.WindowHandle = window.open(popupurl,
																			"MSDCallback" + intid,
																			"menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
																			",height=" + DynamicsCRMScreenResolution_Height() +
																			",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
																			",left=" + DynamicsCRMScreenResolution_Position_Left());

    // alert indicatior for Incoming chat
    ShowNotification("You have new ", "Callback");
}

//--------------------------------------Callback Chat End CRM Popup---------------------------------------------
function DynamicsCRMEndCallbackPopUpScreen(intid, callOutcome, status) {
    if (global_IsCRMEnabled == 0) {
        return;
    }
	if (global_CRMName != "MSD") {
        return;
    }

    if (global_voiceCallHasCallback) {
        return;
    }
    var date = getCurrentDateCRM();
    var time = getCurrentTimeCRM();
	var popupurl;
		
    try {
		popupurl = GetTabReferenceObj(intid).CRMWindowData.URL;
	}
    catch (e) {
		popupurl = global_MSDCallbackAcceptPopUpURL;
	}
	
    popupurl = popupurl.slice(0, -1); // remove last char
    popupurl += '4'; // add char, that you want to be placed instead of the earlier action flag

    popupurl += '&CallEndDate=CallEndDateTag';
    popupurl = popupurl.replace(/CallEndDateTag/g, date); //replace Callback End Time
    popupurl += '&CallEndTime=CallEndTimeTag';
    popupurl = popupurl.replace(/CallEndTimeTag/g, time); //replace Callback End Time

    popupurl += '&Calloutcome=CallOutcomeFlag';
    if (callOutcome == "Record Successfully updated") {
        popupurl = popupurl.replace(/CallOutcomeFlag/g, status); //replace status as closed
    }
    else if (callOutcome == "RescheduleRequest success") {
        popupurl = popupurl.replace(/CallOutcomeFlag/g, status); //replace status as callback
    }
    else {
        popupurl = popupurl.replace(/CallOutcomeFlag/g, "Unsuccessful"); //replace status as unsuccesful	
    }

	log.LogDetails(log.logType.Info, "DynamicsCRMEndCallbackPopUpScreen", "popup URL:[" + popupurl + "]", false);
	
    try {

        //change the URL
        GetTabReferenceObj(intid).CRMWindowData.WindowHandle.location.href = popupurl;
    }
    catch (e) {
        GetTabReferenceObj(intid).CRMWindowData.WindowHandle = window.open(popupurl,
																			"MSDCallback" + intid,
																			"menubar=no,location=no,scrollbars=yes,width=" + DynamicsCRMScreenResolution_Width() +
																			",height=" + DynamicsCRMScreenResolution_Height() +
																			",resizable=yes,top=" + DynamicsCRMScreenResolution_Position_Top() +
																			",left=" + DynamicsCRMScreenResolution_Position_Left());
    }


}

//-------------------------------------- Get Current Time in HHMMSS Format -------------------------------------------
function getCurrentTimeCRM() {
    Date.prototype.yyyymmddhhmmss = function () {
        var yyyy = this.getFullYear();
        var mm = this.getMonth() < 9 ? "0" + (this.getMonth() + 1) : (this.getMonth() + 1); // getMonth() is zero-based
        var dd = this.getDate() < 10 ? "0" + this.getDate() : this.getDate();
        var hh = this.getHours() < 10 ? "0" + this.getHours() : this.getHours();
        var min = this.getMinutes() < 10 ? "0" + this.getMinutes() : this.getMinutes();
        var ss = this.getSeconds() < 10 ? "0" + this.getSeconds() : this.getSeconds();
        return "".concat(yyyy).concat(mm).concat(dd).concat(hh).concat(min).concat(ss);
    };

    d = new Date();
    var a = d.yyyymmddhhmmss();
    var time = a.substring(8, 14);
    return time;

}

//-------------------------------------- Get Current Date in YYYYMMDD Format -------------------------------------------
function getCurrentDateCRM() {
    Date.prototype.yyyymmddhhmmss = function () {
        var yyyy = this.getFullYear();
        var mm = this.getMonth() < 9 ? "0" + (this.getMonth() + 1) : (this.getMonth() + 1); // getMonth() is zero-based
        var dd = this.getDate() < 10 ? "0" + this.getDate() : this.getDate();
        var hh = this.getHours() < 10 ? "0" + this.getHours() : this.getHours();
        var min = this.getMinutes() < 10 ? "0" + this.getMinutes() : this.getMinutes();
        var ss = this.getSeconds() < 10 ? "0" + this.getSeconds() : this.getSeconds();
        return "".concat(yyyy).concat(mm).concat(dd).concat(hh).concat(min).concat(ss);
    };

    d = new Date();
    var a = d.yyyymmddhhmmss();
    var date = a.substring(0, 8);
    return date;

}
