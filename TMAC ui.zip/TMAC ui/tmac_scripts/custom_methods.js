﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CustomMethods.js";
var file_version = "3.0.10.10";
var changedBy = "Sirajuddin"
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

//CUSTOM Method1
function custom_method1(intid) {
    alert('custom_method1');
    //string deviceid, string sql, string eventName
    var parameters = [global_DeviceID, intid, "myEvent", "select * from ccl"];
    Custom_InvokeFunction("AMACWebServerCustomLayer_Test1.dll", "AMACWebServerCustomLayer_Test1.TestLayer", "TesMethod", parameters)
}


//CUSTOM Method1
function custom_method2(intid) {
    alert('custom_method2');
    //string deviceid, string sql, string eventName
    var parameters = [global_DeviceID, intid, ""];
    Custom_InvokeFunction("AMACWebServerCustomLayer_Test1.dll", "AMACWebServerCustomLayer_Test1.TestLayer", "GetInteracitonData", parameters, "custom2")
}

function custom_method2_done(data) {
    alert('custom_method2_done' + data);
}

//GetAgentList

//CUSTOM Method3
function custom_method3(intid) {
    alert('custom_method3');
    //string deviceid, string sql, string eventName
    var parameters = [global_DeviceID, intid, "myEvent"];
    Custom_InvokeFunction("AMACWebServerCustomLayer_Test1.dll", "AMACWebServerCustomLayer_Test1.TestLayer", "GetAgentList", parameters, "custom3")
}

function custom_method3_done(data) {
    alert('custom_method3_done' + data);
}
