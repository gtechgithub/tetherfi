﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "CommandManager.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

// ----------------------------------------------------------------------------------
// Load all intents from DB
// ----------------------------------------------------------------------------------

function LoadIntents() {
    try {
        var data = {};
        data.deviceid = global_DeviceID;
        //command(data, "LoadIntents");
        tmac_LoadIntents("LoadIntentsDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadIntents()", ex, false);
    }
}

function LoadIntentsDone(data) {
    try {
        global_Intents = data;
        if (global_Intents !== null) {
            //do nothing
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadIntentsDone()", ex, false);
    }
}
//-----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------
// Load the Aux codes from Database
// ----------------------------------------------------------------------------------

function LoadAUXCodes() {
    try {
        if (isLoadAgentAux)
            tmac_LoadAUXCodesForAgent("LoadAUXCodesDone", null);
        else
            tmac_LoadAUXCodes("LoadAUXCodesDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAUXCodes()", ex, false);
    }
}

function LoadAUXCodesDone(data) {
    try {
        global_AUXCodes = data;
        //tmac_ui.js
        AuxCodesLoaded();
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAUXCodesDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Get the List of Staffed Agents from TMAC Server
// ----------------------------------------------------------------------------------
function GetAgentListStaffed(intid, dialogName, buttonName, icon) {
    try {
        let data = {};
        data.intid = intid;
        data.isLocal = true;
        data.dialogName = dialogName;
        data.buttonName = buttonName;
        data.icon = icon;
        tmac_GetAgentListStaffed("GetAgentListStaffedDone", data, false);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetAgentListStaffed()", ex, false);
    }
}

function GetAgentListStaffedDone(data, object) {
    try {
        global_AgentList = data;
        AgentListLoaded(object);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetAgentListStaffedDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// load the favoirute skill/vdn list from DB
// ----------------------------------------------------------------------------------
function GetFavouriteSkills() {
    try {
        var data = {};
        data.deviceid = global_DeviceID;
        //command(data, "GetFavouriteSkills");
        tmac_GetFavouriteSkills("GetFavouriteSkillsDone");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFavouriteSkills()", ex, false);
    }
}

function GetFavouriteSkillsDone(data) {
    try {
        global_FavouriteSkills = data;
        if (global_FavouriteSkills !== null) {
            //bind favourite list grid
            LoadFavListGrid();
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFavouriteSkillsDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// load speed dial numbers from the database
// ----------------------------------------------------------------------------------
function GetSpeedDialNumber() {
    var data = {};
    data.deviceid = global_DeviceID;
    tmac_GetSpeedDialNumber("GetSpeedDialNumberDone");
}

function GetSpeedDialNumberDone(data) {
    global_SpeedDial = data;
    if (global_SpeedDial !== null) {
        //bind speed dial list
        LoadSpeedDialGrid("speedDialMakeCallGrid", "txtMakeCallNumber");
        LoadSpeedDialGrid("speedDialGrid", "txtNumberTrans");
    }
}

// ----------------------------------------------------------------------------------
// Login to TMAC
// ----------------------------------------------------------------------------------

function Login(lanId, stationid, agentloginid, forceReload, isInvalidLanId, password) {
    var obj = {};
    obj.invalidLanId = isInvalidLanId;

    global_DeviceID = stationid;
    global_AgentID = agentloginid;
    global_LanID = lanId;
    global_Password = ToEncodedString(password);

    if (isLoginWithPassword)
        tmac_LoginWithPassword("LoginDone", obj, lanId, stationid, agentloginid, false, "", forceReload, password);
    else
        tmac_Login("LoginDone", obj, lanId, stationid, agentloginid, false, "", forceReload);
}

function LoginDone(data, obj) {
    try {
        if (data !== null) {
            if (data.ResultCode > 0) {
                if (data.ResultCode == 3) {
                    if (isVoiceBio) {
                        Login(global_LanID, global_DeviceID, global_AgentID, true, "", FromEncodedString(global_Password));
                    } else {
                        UIkit.modal.confirm('Another session detected. Do you want to take it over?',
                            function () {
                                Login(global_LanID, global_DeviceID, global_AgentID, true, "", FromEncodedString(global_Password));
                            },
                            function oncancel() {
                                location.reload();
                            });
                    }
                    return;
                }
                //inform the user about the session takeover. This message will show "Agent[123] is already logged in to station[44008].
                // You will takeover this session".
                //once clicked "OK" it will continue to login
                if (data.ErrorDetails !== "") {
                    if (isVoiceBio) {
                        LoginToTMAC(data, obj);
                    } else {
                        UIkit.modal.confirm(data.ErrorDetails,
                            function () {
                                LoginToTMAC(data, obj);
                            },
                            function oncancel() {
                                location.reload();
                            });
                    }
                    return;
                } else {
                    LoginToTMAC(data, obj);
                }
            } else if (data.ResultCode == -1) {
                ShowNotify("Station ID not provided", "danger", null, "top-center");
            } else if (data.ResultCode == -2) {
                ShowNotify("LAN ID not provided", "danger", null, "top-center");
            } else if (data.ResultCode == -3) {
                if (isVoiceBio)
                    ShowNotify("Invalid LAN ID detected. Please contact administrator for TMAC access.", "danger", null, "top-center");
                else
                    InvalidLanID();
            } else if (data.ResultCode == -4) {
                ShowNotify("Invalid Extension", "danger", null, "top-center");
            } else if (data.ResultCode == -5) {
                ShowNotify("Destination is in use. " + data.ErrorDetails, "danger", null, "top-center"); // This will show a message saying "Agent[123] is already logged in to station[234]"
            } else if (data.ResultCode == -6) {
                ShowNotify("Invalid Agent ID", "danger", null, "top-center");
            } else if (data.ResultCode == -7) {
                ShowNotify("Station Busy", "danger", null, "top-center");
            } else if (data.ResultCode == -8) {
                ShowNotify("Station not allowed", "danger", null, "top-center");
            } else if (data.ResultCode == -9) {
                ShowNotify("Station ID is in use. " + data.ErrorDetails, "danger", null, "top-center"); // This will show a message saying "Agent[123] is already logged into station[234]"
            } else if (data.ResultCode == -10) {
                ShowNotify("Agent login failed", "danger", null, "top-center");
            } else if (data.ResultCode == -15) {
                ShowNotify("Agent not logged in to any station, Please login to AIC", "danger", null, "top-center");
                if (isVoiceBio && retryLogin) {
                    CheckAgentStaffed();
                    $(".an-loader").removeClass("uk-display-none");
                }
            } else if (data.ResultCode == -5001) {
                ShowNotify(data.ResultMessage, "danger", null, "top-center");
            }
            else {
                //login failed
                ShowNotify(data.ResultMessage, "danger", null, "top-center");
            }
            if (data.ResultCode < 0)
                EnableLogInButton();
        } else {
            ShowNotify("Server Error", "danger", null, "top-center");
            EnableLogInButton();
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoginDone()", ex, false);
    }
}

function LoginToTMAC(data, obj) {
    try {
        global_LoginRedisplay = !obj.invalidLanId;
        var key = data.AgentSessionKey;
        key = key.substring(0, 5);
        global_successfullyLoggedInData = {};
        if (isVoiceBio)
            global_successfullyLoggedInData.global_DeviceID = data.Data.StationID;
        else
            global_successfullyLoggedInData.global_DeviceID = global_DeviceID;
        global_successfullyLoggedInData.global_LanID = global_AgentID;
        global_successfullyLoggedInData.lanid = global_LanID;
        global_successfullyLoggedInData.password = FromEncodedString(global_Password);
        global_successfullyLoggedInData.data = data;
        global_successfullyLoggedInData.tmacServer = _tmacServer;

        Application_Window_Current_Width = CalculateTMACWindowWidth();
        Application_Window_Current_Height = CalculateTMACWindowHeight();
        global_successfullyLoggedInData.Application_Window_width = Application_Window_Current_Width;
        global_successfullyLoggedInData.Application_Window_height = Application_Window_Current_Height;

        if (isVoiceBio) {
            DocumentReady();
            TriggerResize();
        } else {
            var amac = window.open("MainscreenUI.html", key, "menubar=no,resizable=0,location=no,scrollbars=no,width=" + Application_Window_Current_Width + ",height=" + Application_Window_Current_Height);
            amac.moveTo(0, 0);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoginToTMAC()", ex, false);
    }
    return;
}

function EnableLogInButton() {
    $("#login_spinner").addClass("uk-display-none");
    $("#login_card").removeClass("blur-background");
    $("#login_btn").removeClass("disabled");
}

// ----------------------------------------------------------------------------------
// After successfully login, get the data
// ----------------------------------------------------------------------------------

function getSuccessfullyLoggedInData() {
    //Commented by Sirajuddin on 05-04-2017
    setTimeout(CloseLoginPage, 5000);
    return global_successfullyLoggedInData;
}

// ----------------------------------------------------------------------------------
// Close the TMAC Window
// ----------------------------------------------------------------------------------
function CloseLoginPage() {
    EnableLogInButton();
    $("#login_card").addClass("uk-display-none");
    $("#login_spinner").addClass("uk-display-none");
    $("#login_card").removeClass("blur-background");
    if (isCloseLoginPage) window.close();
}

// ----------------------------------------------------------------------------------
// After succesfully login
// ----------------------------------------------------------------------------------
function SuccessfullyLoggedIn(data, deviceid, lanid, password, Application_Current_Width, Application_Current_Height, tmacServer) {
    try {
        if (data.EventName == "LoginReload") {
            global_ReloadDone = true;
            //SIP Dialer - Check for Callback Call - Changed by Mukesh - 8th Aug, 2016
            //SIP Dialer - Callback Extensions now will be range eg. 1000-1500
            var str = globalConfig_DigibankCallbackExtensionRange;
            var indices = 0;
            for (var i = 0; i < str.length; i++) {
                if (str[i] === "-") {
                    indices = i;
                }
            }

            global_CallbackVDNListStart = str.substring(0, indices);
            global_CallbackVDNListEnd = str.substring((indices + 1), str.length);
        } else
            global_ReloadDone = false;
        global_DeviceID = deviceid;
        global_LanID = lanid;
        global_AgentID = data.Data.AgentID;
        global_AgentName = data.Data.AgentName;
        global_Password = ToEncodedString(password);
        statusTimeCounter = 0;
        global_IsCRMEnabled = data.Data.IsCRMEnabled;
        global_TextChatGreetingText = data.Data.TextChatGreetingText;
        global_CRMName = data.Data.CRMName;
        global_AgentSessionKey = data.AgentSessionKey;
        global_TeamID = data.Data.TeamID;
        global_UserProfileForAgent = data.Data.UserProfileForAgent;
        _tmacServer = tmacServer;
        // set the Curent TMAC window Resolution.
        Application_Window_Current_Width = Application_Current_Width;
        Application_Window_Current_Height = Application_Current_Height;
        //load initial global data
        LoadIntents();
        LoadAUXCodes();
        LoadAgentListGrids();
        GetFavouriteSkills();
        GetSpeedDialNumber();
        //show home page (wallboard,status,timer,etc)
        AgentLoginSuccess();
        //Get Color Code
        GetQueueTimeColorCode();
        //initially set to 2 to load offline logo
        SetConnectivityStatus(2);
        //start event processing after 2 seconds as the UI is loaded dynamically
        setTimeout(GetEvent, 2000);
        //load work codes
        if (isWorkCode) LoadCallWorkCodes(global_TeamID);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SuccessfullyLoggedIn()", ex, false);
    }
}
// ----------------------------------------------------------------------------------
// Logout of TMAC
// ----------------------------------------------------------------------------------

function Logout(deviceid) {
    try {
        var data = {};
        data.deviceid = deviceid;
        global_LogoutCommandSend = true;
        tmac_Logout("LogoutDone", null, deviceid, false);
        isLogoutDone = true;
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.Logout()", ex, false);
    }
}

function LogoutDone(data) {
    if (data.ResultCode === 0) {
        //logout success
        //go back to login page
        window.close();
    } else {
        //logout failed
        global_LogoutCommandSend = false;
        ShowNotify("Logout Failed", "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// GetEvent List - Polling to TMAC Server
// ----------------------------------------------------------------------------------

function GetEvent() {
    SetConnectivityStatus(0);
    if (isLoginWithPassword)
        tmac_GetEventWithPassword("GetEventDone", null, global_DeviceID, global_AgentSessionKey, false, FromEncodedString(global_Password));
    else
        tmac_GetEvent("GetEventDone", null, global_DeviceID, global_AgentSessionKey, false);
}

function GetEventDone(data) {
    try {
        if (data !== null) {
            //eventHandler.js
            HandleEvent(data);
        }
        //perform generic actions
        //tmac_ui.js
        PerformInfiniteActions();
    } catch (ex) { }

    //if the agent is logged out then stop polling until window close
    if (!isLogoutDone) {
        //set timer for next event poll
        setTimeout(GetEvent, 600);
    }
}

// ----------------------------------------------------------------------------------
// Change Agent Status
// ----------------------------------------------------------------------------------

function ChangeStatus(deviceid, statustype, statuscode) {
    tmac_ChangeStatus("ChangeStatusDone", null, deviceid, statustype, statuscode);
}

function ChangeStatusDone(data) {
    if (data.EventName == "AgentStatusChangeEvent") {
        //ChangeStatus success
        //bind new status to status control
        AgentStatusChange(data);
        isStatusManagerChange = true;
    } else {
        //ChangeStatus failed
        ShowNotify("Change Status Failed", "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Answer Incoming Voice Call
// ----------------------------------------------------------------------------------
function AnswerCall(deviceid, interactionid) {
    $("#btnAnswer" + interactionid).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
    tmac_AnswerCall("AnswerCallDone", interactionid, deviceid, interactionid);
}

function AnswerCallDone(data, interactionid) {
    if (data.ResultCode === 0) {
        //AnswerCall success
    } else {
        //AnswerCall failed
        ShowNotify("Answer Call failed", "danger", null, "top-center");
    }
    $("#btnAnswer" + interactionid).html('<i class="material-icons">call</i>');
}

// ----------------------------------------------------------------------------------
// Disconnect Voice Call
// ----------------------------------------------------------------------------------

function DisconnectCall(deviceid, interactionid) {
    $("#btnDrop" + interactionid).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
    tmac_DisconnectCall("DisconnectCallDone", interactionid, deviceid, interactionid);
}

function DisconnectCallDone(data, interactionid) {
    if (data.ResultCode === 0) {
        //DisconnectCall success
    } else {
        //DisconnectCall failed
        ShowNotify("Disconnect Failed", "danger", null, "top-center");
    }
    $("#btnDrop" + interactionid).html('<i class="material-icons">call_end</i>');
}

// ----------------------------------------------------------------------------------
// Hold Voice Call
// ----------------------------------------------------------------------------------

function HoldCall(deviceid, interactionid, obj) {
    if (obj === null) {
        $("#btnHold" + interactionid).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
        obj = {};
        obj.intid = interactionid;
        obj.chatoncall = false;
        obj.buttonId = "#btndialogtransfercall";
        obj.icon = "swap_horiz";
    }
    tmac_HoldCall("HoldCallDone", obj, deviceid, interactionid);

}

function HoldCallDone(data, obj) {
    if (data.ResultCode === 0) {
        //HoldCall success
        if (obj.chatoncall) {
            tmac_InitiateCall("InitiateCallDone", obj, obj.deviceid, obj.number, obj.intid, obj.source, obj.sourceid, "");
        }
    } else {
        //HoldCall failed
        ShowNotify("Hold Call Failed", "danger", null, "top-center");
    }
    if (!obj.chatoncall) {
        $("#btnHold" + obj.intid).html('<i class="material-icons">phone_paused</i>');
        $("#btnUnHold" + obj.intid).html('<i class="material-icons">phone_in_talk</i>');
    }
}

// ----------------------------------------------------------------------------------
// Unhold Voice Call
// ----------------------------------------------------------------------------------

function UnHoldCall(deviceid, interactionid, obj) {
    if (obj === null) {
        $("#btnUnHold" + interactionid).html('<i class="uk-icon-spinner uk-icon-small uk-icon-spin" style="color:#fff;"></i>');
        obj = {};
        obj.intid = interactionid;
        obj.chatoncall = false;
    }
    tmac_UnHoldCall("UnHoldCallDone", obj, deviceid, interactionid);
}

function UnHoldCallDone(data, obj) {
    if (data.ResultCode === 0) {
        //UnHoldCall success
    } else {
        //UnHoldCall failed
        ShowNotify("UnHold Call Failed", "danger", null, "top-center");
    }
    if (!obj.chatoncall) {
        $("#btnUnHold" + obj.intid).html('<i class="material-icons">phone_in_talk</i>');
        $("#btnHold" + obj.intid).html('<i class="material-icons">phone_paused</i>');
    }
}

// ----------------------------------------------------------------------------------
// Transfer Voice Call
// ----------------------------------------------------------------------------------

function TransferCallCommand(deviceid, interactionid, number, comment, obj) {
    tmac_TransferCall("TransferCallCommandDone", obj, deviceid, interactionid, number, comment);
}

function TransferCallCommandDone(data, obj) {
    if (data.ResultCode === 0) {
        //TransferCall success
        //if the type is text chat no confirm dialog
        if (obj.type !== "TextChatTransfer") {
            OpenConfirmDialog(obj.type);
        } else {
            //if the type is TextChatTransfer close the transfer dialog here else it will be closed in OpenConfirmDialog
            CloseTransferDialog();
            GetChatReferenceObj(obj.intId).isTransfer = true;
        }
    } else {
        //TransferCall failed
        ShowNotify("Transfer Call Failed", "danger", null, "top-center");
    }
    EnableButton(obj.buttonId, obj.icon, "icon");
}

// ----------------------------------------------------------------------------------
// Cancel Voice Call Transfer
// ----------------------------------------------------------------------------------

function TransferCancelCommand(deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;

    tmac_TransferCancel("TransferCancelCommandDone", data, deviceid, interactionid);
}

function TransferCancelCommandDone(data, object) {
    if (data.ResultCode === 0) {
        //TransferCancel success
        let obj = {};
        obj.intid = object.interactionid;
        obj.chatoncall = false;
        try {
            //check if it is a callback transfer, if yes disable the dial and submit button
            if (GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferInit) {
                DisableCallbackButtons(object.interactionid);
                $('#divCloseButton' + object.interactionid).css("visibility", "visible");
                $('#btnCloseTab' + object.interactionid).removeAttr('disabled', 'disabled');
            }
        } catch (ex) { }
    } else {
        //TransferCancel failed
        ShowNotify("Transfer Cancel Failed", "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Complete the Voice Call Transfer
// ----------------------------------------------------------------------------------

function TransferCompleteCommand(deviceid, interactionid) {
    try {
        var data = {};
        data.deviceid = deviceid;
        data.interactionid = interactionid;
        if (isIServe) {
            let date = GetCurrentDateTime();
            //Insert current time to custom data table to calculate the queuetime
            custom_insertQueueTimeForUCID(interactionid, date, global_UCID[interactionid]);
        }
        tmac_TransferComplete("TransferCompleteCommandDone", data, deviceid, interactionid);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CommandManager()", ex, false);
    }
}

function TransferCompleteCommandDone(data, object) {
    if (data.ResultCode === 0) {
        try {
            //check if it is a callback transfer, if yes disable the dial and submit button
            if (GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferInit) {

                //update custom table 
                custom_UpdateCustomTableForCallbackTransfer(GetTabReferenceObj(object.interactionid).OtherData.srno, object.interactionid);
                //disable callback buttons
                DisableCallbackButtons(object.interactionid);
                //Update CRM
                //DynamicsCRMEndCallbackPopUpScreen(object.interactionid, "Record Successfully updated", "Closed");
                GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferComplete = true;
            }
            if (isPOM) {
                POMTransferCompleteDone(data, object);
            }
        } catch (ex) { }

        //TransferComplete success
        ShowNotify("Transfer Completed", "success", null, "top-center");
    } else {
        //TransferComplete failed
        ShowNotify("Transfer Complete Failed", "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Conference Voice Call
// ----------------------------------------------------------------------------------

function ConferenceCall(deviceid, interactionid, number, comment, obj) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.number = number;
    data.comment = comment;
    tmac_ConferenceCall("ConferenceCallDone", obj, deviceid, interactionid, number, comment);
}

function ConferenceCallDone(data, obj) {
    if (data.ResultCode === 0) {
        //ConferenceCallDone success
        OpenConfirmDialog(obj.type);
    } else {
        //ConferenceCallDone failed
        ShowNotify("Conference Call Failed", "danger", null, "top-center");
    }
    EnableButton(obj.buttonId, obj.icon, "icon");
}

// ----------------------------------------------------------------------------------
// Cancel Voice Call Conference
// ----------------------------------------------------------------------------------

function ConferenceCancel(deviceid, interactionid) {
    tmac_ConferenceCancel("ConferenceCancelDone", null, deviceid, interactionid);
}

function ConferenceCancelDone(data) {
    if (data.ResultCode === 0) {
        //ConferenceCancel success
    } else {
        //ConferenceCancel failed
        ShowNotify("Conference Cancel Failed", "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Complete Voice Call Conference
// ----------------------------------------------------------------------------------

function ConferenceCompleteCommand(deviceid, interactionid) {
    tmac_ConferenceComplete("ConferenceCompleteCommandDone", null, deviceid, interactionid);
}

function ConferenceCompleteCommandDone(data) {
    if (data.ResultCode === 0) {
        //ConferenceComplete success
    } else {
        //ConferenceComplete failed
        ShowNotify("Conference Complete Failed", "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Dial a call from TMAC
// ----------------------------------------------------------------------------------

function MakeCall(deviceid, number, value, intid) {
    log.LogDetails("Info", "Inside CommandManager.MakeCall()", "", false);
    var data = {};

    var hasWhiteSpaces;
    var regex;
    var regexChars;
    var hasSpecialChars;
    var hasChars;
    var isNotANumber;
    var source;
    var sourceid;

    data.deviceid = deviceid;
    if (value == "customMakeCallCallerId") {
        disconnectByHandleType = "callback";
        var customNumberToDial = number.trim();
        if (customNumberToDial === "") {
            ShowNotify("Invalid number", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        } else if (customNumberToDial === global_DeviceID || customNumberToDial === global_AgentID) {
            ShowNotify("Cannot call logged in station", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        }
        hasWhiteSpaces = /\s/.test(customNumberToDial);
        regex = /[^\w\s]/gi;
        regexChars = /^[a-zA-Z]/;
        hasSpecialChars = regex.test(customNumberToDial);
        hasChars = regexChars.test(customNumberToDial);
        isNotANumber = isNaN(customNumberToDial);
        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        }

        if (global_trimDigitsBeforeMakeCall != "") {
            customNumberToDial = customNumberToDial.substring(global_trimDigitsBeforeMakeCall);
        }
        number = globalConfig_Prefix + customNumberToDial;
        source = "custom";
        sourceid = "";
    } else if (value == "customMakeCallPreferredNo") {
        disconnectByHandleType = "callback";
        var customNumberToDial = number.trim();
        if (customNumberToDial === "") {
            ShowNotify("Invalid number", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        } else if (customNumberToDial === global_DeviceID || customNumberToDial === global_AgentID) {
            ShowNotify("Cannot call logged in station", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        }
        hasWhiteSpaces = /\s/.test(customNumberToDial);
        regex = /[^\w\s]/gi;
        regexChars = /^[a-zA-Z]/;
        hasSpecialChars = regex.test(customNumberToDial);
        hasChars = regexChars.test(customNumberToDial);
        isNotANumber = isNaN(customNumberToDial);
        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        }
        number = customNumberToDial;
        source = "custom";
        sourceid = "";
    } else {
        disconnectByHandleType = "makecall";
        var numberToDial = $("#txtMakeCallNumber").val();
        numberToDial = numberToDial.trim();

        if (numberToDial === "") {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        } else if (numberToDial === global_DeviceID || numberToDial === global_AgentID) {
            ShowNotify("Cannot call logged in station", "danger", null, "top-center");
            EnableCallbackDialButtons(intid);
            DisableCallbackSubmitButtons(intid);
            return;
        }
        hasWhiteSpaces = /\s/.test(numberToDial);
        regex = /[^\w\s]/gi;
        regexChars = /^[a-zA-Z]/;
        hasSpecialChars = regex.test(numberToDial);
        hasChars = regexChars.test(numberToDial);
        isNotANumber = isNaN(numberToDial);

        if (hasWhiteSpaces || hasSpecialChars || isNotANumber) {
            ShowNotify("Invalid number", "danger", null, "top-center");
            if (intid !== undefined) {
                EnableCallbackDialButtons(intid);
                DisableCallbackSubmitButtons(intid);
            }
            return;
        }

        if (value == "makecall") {
            DisableButton("#btndialogmakecall");
        }

        number = numberToDial;
        intid = "";

        var val = document.getElementById('makeCallCb');
        source = "t";
        if (val.checked) {
            sourceid = "N";
        } else {
            sourceid = "Y";
        }
    }
    var obj = {};
    obj.intid = intid;
    obj.buttonId = "#btndialogmakecall";
    try {
        if (!GetChatReferenceObj(global_activeTabInteractionID).isDisconnected) {
            var obj = {};
            obj.intid = "";
            obj.buttonId = "#btndialogmakecall";
            obj.deviceid = deviceid;
            obj.number = number;
            obj.source = source;
            obj.sourceid = sourceid;
            obj.chatoncall = true;
            HoldCall(global_DeviceID, global_activeTabInteractionID, obj);
            return;
        }
    } catch (e) { }

    //command(data, "MakeCall", intid);
    tmac_InitiateCall("InitiateCallDone", obj, deviceid, number, intid, source, sourceid, "");
    isStatusManagerChange = true;
    //tmac_MakeCall("MakeCallDone", obj, deviceid, number, intid);
}

function InitiateCallDone(data, obj) {
    try {
        if (data.ResultCode === 0) {
            //MakeCall success
        } else {
            //MakeCall failed
            ShowNotify("Make Call failed: " + data.ResultMessage, "danger", null, "top-center");
            if (obj.intid !== "") {
                ChangeTabReferenceStatus(obj.intid, 'MakeCallFailed');
                //check if this is a callback tab. then enable dial buttons
                EnableCallbackDialButtons(obj.intid);
            }
        }
        if (obj.buttonId != "") {
            EnableButton(obj.buttonId, "call", "icon");
        }
        if ((data === null || data.ResultCode !== 0) && obj.chatoncall) {
            //unhold chat if error on init voice call
            UnHoldCall(obj.deviceid, obj.intid, obj)
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InitiateCallDone()", ex, false);
    }
}

function MakeCallDone(data, obj) {
    try {
        if (data.ResultCode === 0) {
            //MakeCall success
        } else {
            //MakeCall failed
            ShowNotify("Make Call failed: " + data.ResultMessage, "danger", null, "top-center");
            ChangeTabReferenceStatus(obj.intId, 'MakeCallFailed');
            //check if this is a callback tab. then enable dial buttons
            EnableCallbackDialButtons(obj.intId);
        }
        if (obj.buttonId != "") {
            EnableButton(obj.buttonId, "call", "icon");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.MakeCallDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Get Agent Status
// ----------------------------------------------------------------------------------
function GetAgentStatus(deviceid, agentid, object, destTmacServerName) {
    tmac_GetAgentStatus("GetAgentStatusDone", object, deviceid, agentid, destTmacServerName);
}

function GetAgentStatusDone(data, object) {
    if (data.ResultCode == 1) {
        //GetAgentStatus success
        GetGridAgentStatusDone(object, data.ResultMessage);
    } else {
        //GetAgentStatus failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Get Queue Status
// ----------------------------------------------------------------------------------

function GetQueueStatus(deviceid, skillid, object) {
    var data = {};
    data.skillid = skillid;
    data.rowid = object;
    tmac_GetQueueStatus("GetQueueStatusDone", data, deviceid, skillid);
}

function GetQueueStatusDone(data, object) {
    if (data.EventName == "QueueStatusEvent") {
        //GetAgentStatus success
        GetQueueStatusSuccess(data, object);
    } else {
        //GetAgentStatus failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Transfer Call to IVR for TPIN Verification/OTP - Blind Transfer
// ----------------------------------------------------------------------------------

function TransferToIVR(deviceid, interactionid, type, languageid) {
    if (type == "feewaiver") {
        global_isFeewaiverTrasnferOutbound = true;
    } else {
        custom_ClearCallDataForTpinTransfer(interactionid, global_UCID[global_activeTabId]);
    }
    if (isIServe) {
        let date = GetCurrentDateTime();
        //Insert current time to custom data table to calculate the queuetime
        custom_insertQueueTimeForUCID(interactionid, date, global_UCID[interactionid]);
    }
    tmac_TransferToIVR("TransferToIVRDone", null, deviceid, interactionid, type, languageid);
}

function TransferToIVRDone(data, object) {
    if (data.ResultCode === 0) {
        if (GetTabReferenceObj(object.interactionid).direction == 'out') {
            global_isTPINTrasnferOutbound = true;
        }
        if (global_isFeewaiverTrasnferOutbound) {
            return;
        }
        global_isTPINTransferDone = true;
        var executionTime = new Date();
        executionTime.setSeconds(executionTime.getSeconds() + 300);
        AddMethodToTimerLoop(object.deviceid, object.interactionid, 'TPINTransferTimer', executionTime);
    } else {
        //GetAgentStatus failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Close Tab
// ----------------------------------------------------------------------------------

function CloseTab(interactionid) {
    $("#btnCloseTab" + interactionid + " i").removeAttr('class');
    $("#btnCloseTab" + interactionid + " i").addClass('uk-icon-spinner uk-icon-spin');
    $("#btnCloseTab" + interactionid + " i").attr('disabled', false);
    var data = {};
    data.deviceid = global_DeviceID;
    data.interactionid = interactionid;

    //inform the server
    tmac_CloseTab("CloseTabDone", data, global_DeviceID, interactionid, false);
}

function CloseTabDone(data, object) {
    if (data.ResultCode === 0) {
        //CloseTab success
        CloseUITab(object.interactionid);
    } else {
        //CloseTab failed
    }
    $("#btnCloseTab" + object.interactionid + " i").removeAttr('class');
    $("#btnCloseTab" + object.interactionid + " i").addClass('k-icon k-font-icon k-i-x');
    $("#btnCloseTab" + object.interactionid + " i").attr('disabled', false);
}

// ----------------------------------------------------------------------------------
// Select Tab
// ----------------------------------------------------------------------------------

function SelectTab(deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;

    try {
        //inform the server if it is a chat tab only
        if (GetTabReferenceObj(interactionid).type != 'callback') {
			if (GetTabReferenceObj(interactionid).type == 'chat' && GetTabReferenceObj(interactionid).status.toLowerCase() == 'calldisconnected') {
				custom_TextChatTabSelectOnDisconnect(interactionid);
			}
			else
				tmac_SelectTab("SelectTabDone", null, deviceid, interactionid);
        }
    } catch (ex) { }
}

function SelectTabDone(data) {
    if (data.ResultCode === 0) {
        //SelectTab success

    } else {
        //SelectTab failed
    }
}

// ----------------------------------------------------------------------------------
// Open Intent
// ----------------------------------------------------------------------------------

function OpenIntent(deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.intent = intent;

    tmac_OpenIntent("OpenIntentDone", null, deviceid, interactionid, intent);
}

function OpenIntentDone(data) {
    if (data.ResultCode == 1) {
        //OpenIntent success
    } else {
        //OpenIntent failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}


// ----------------------------------------------------------------------------------
// Update Intent
// ----------------------------------------------------------------------------------

function UpdateIntent(deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.intent = intent;

    tmac_UpdateIntent("UpdateIntentDone", null, deviceid, interactionid, intent);
}

function UpdateIntentDone(data) {
    if (data.ResultCode == 1) {
        //UpdateIntent success
    } else {
        //UpdateIntent failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Load More History - Voice/Chat
// ----------------------------------------------------------------------------------

function LoadMoreHistory(deviceid, interactionid) {
    DisableLoadMoreButton(interactionid);

    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    tmac_LoadMoreHistory("LoadMoreHistoryDone", null, deviceid, interactionid);
}

function LoadMoreHistoryDone(data) {
    if (data.ResultCode == 1) {
        //LoadMoreHistory success
    } else {
        //LoadMoreHistory failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Load Interaction History on Demand - Voice/Chat
// ----------------------------------------------------------------------------------
function LoadInteractionHistoryOnDemand(deviceid, interactionid, cif, nric, phonenumber) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.cif = cif;
    data.nric = nric;
    data.phonenumber = phonenumber;

    tmac_LoadInteractionHistoryOnDemand("LoadInteractionHistoryOnDemandDone", null, deviceid, interactionid, cif, nric, phonenumber);
}

function LoadInteractionHistoryOnDemandDone(data) {
    if (data.ResultCode === 0) {
        //LoadInteractionHistoryOnDemandDone success
    } else {
        //LoadInteractionHistoryOnDemandDone failed
    }
}

// ----------------------------------------------------------------------------------
// Send Text Chat Message
// ----------------------------------------------------------------------------------
function SendTextChat(deviceid, interactionid, text) {
    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.text = text;
    if (isAppMessage) {
        tmac_SendAppMessage("SendTextChatDone", data, deviceid, interactionid, text);
    } else
        //tmac_SendTextChat("SendTextChatDone", data, deviceid, interactionid, text);
        tmac_SendTextChatFromTemplate("SendTextChatFromTemplatetDone", data, deviceid, interactionid, text, GetChatReferenceObj(interactionid).selectedTemplateId);

    //show the freeze button
    $("#btnTextChat_FreezeAutoResponse" + interactionid).css("display", "inline-block");

    //disable the text chat input area until the current text chat is sent
    //document.getElementById("textChatMessage" + interactionid).disabled = true;
}

function SendTextChatAsAppMessage(deviceid, interactionid, text) {
    tmac_SendAppMessage("SendTextChatDone", null, deviceid, interactionid, text);
}

function SendTextChatDone(data, object) {
    if (data == 1) {
        //SendTextChat success, enable the text chat input area
        //document.getElementById("textChatMessage" + object.interactionid).disabled = false;
    } else {
        //SendTextChat failed
        ShowNotify("Message Sending Failed", "danger", null, "top-center");
        //document.getElementById("textChatMessage" + object.interactionid).disabled = false;
    }
    //document.getElementById("textChatMessage" + object.interactionid).disabled = false;
    SetCareToPos(document.getElementById("textChatMessage" + object.interactionid), 0);
}

function SendAVControlMessage(deviceid, interactionid, message, type) {
    tmac_SendAVControlMessage("SendAVControlMessageDone", null, deviceid, interactionid, message, type);
}

function SendAVControlMessageDone(data, object) {
    if (data.ResultCode == 1) {
        //success
    } else {
        //failed
        log.LogDetails("Error", "TmacTextChatUI.SendAVControlMessageDone()", data.ResultMessage, false);
    }
}

// ----------------------------------------------------------------------------------
// End Text Chat Message
// ----------------------------------------------------------------------------------

function EndTextChat(deviceid, interactionid, isCallback, reason) {
    try {
        let msg = $("#hfCsatUrl" + interactionid).val();
        let msgid = uuid();
        if (msg != "") {
            if (isAppMessage) {
                var obj = {};
                obj.id = msgid;
                obj.message = msg;
                obj.messageType = "text";
                obj.type = "new";
                msg = JSON.stringify(obj);
            }
            SendTextChat(deviceid, interactionid, msg);
            $("#hfCsatUrl" + interactionid).val("");
        }

        var data = {};
        try {
            data.isCallback = isCallback;
            data.intid = interactionid;
        } catch (e) {
            data.isCallback = false;
        }
        tmac_EndTextChatWithReason("EndTextChatDone", data, deviceid, interactionid, reason);
        //tmac_EndTextChat("EndTextChatDone", data, deviceid, interactionid);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.EndTextChat()", ex, false);
    }
}

function EndTextChatDone(data, object) {
    try {
        EnableButton("#btnTextChat_Disconnect" + object.intid, "close", "icon");
        if (object.isCallback) {
            setTimeout(function () {
                log.LogDetails("Info", "CommandManager.EndTextChatDone()", "Adding Delay for iserve close " + GetCurrentDateTime(), false);
                CloseTab(global_TextChatCallbackID);
            }, 1000);
            log.LogDetails("Info", "CommandManager.EndTextChatDone()", "After delay" + GetCurrentDateTime(), false);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.EndTextChatDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Agent Initiated Callback
// ----------------------------------------------------------------------------------

function RegisterTextChatCallback(deviceid, interactionid, preferrednumber, preferredtime) {

    var data = {};
    data.deviceid = deviceid;
    data.interactionid = interactionid;
    data.preferrednumber = preferrednumber;
    data.preferredtime = '20150316101722';
    preferredtime = '20150316101722';

    tmac_RegisterTextChatCallback("RegisterTextChatCallbackDone", data, deviceid, interactionid, preferrednumber, preferredtime);
}

function RegisterTextChatCallbackDone(data, object) {
    if (data.ResultCode === 0) {
        //we have to change the status to acw before disconnecting the chat
        ChangeStatus(global_DeviceID, 'acw', '0');
        global_endTextChatNotification[object.interactionid] = true;
        EndTextChat(object.deviceid, object.interactionid, true, "AgentInitiatedCallback");
        ShowNotify("Agent Initiated Callback - Disconnecting Chat", "info", null, "top-center");
    } else {
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Send TextChat Transfer/Conference notification to remote agent
// ----------------------------------------------------------------------------------

function SendTextChatTransferNotification(deviceid, interactionid, remoteAgentId, comment, cutomData, TmacServer, obj) {
    //tmac_SendTextChatTransferNotification("SendTextChatTransferNotificationDone", null, deviceid, interactionid, remoteAgentId, comment, cutomData);
    tmac_SendTextChatTransferNotificationToServer("SendTextChatTransferNotificationDone", obj, interactionid, remoteAgentId, TmacServer, comment, cutomData);
}

function SendTextChatTransferNotificationDone(data, obj) {
    if (data.ResultCode >= 0) {
        let type = "";
        //send success
        if (obj !== null && obj.type == "TextChatConference") {
            type = "conference";
        }
        else
            type = "transfer";
        ShowNotify("Chat " + type + " notification sent to remote agent. Please wait for response.", "info", null, "top-center");
    } else {
        //send failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Transfer Text Chat to Queue
// ----------------------------------------------------------------------------------

function TransferTextChatToQueue(deviceid, interactionId, skillNumber, isBlind, chatMode, obj) {
    tmac_TransferTextChatToQueue("TransferTextChatToQueueDone", obj, deviceid, interactionId, skillNumber, isBlind, chatMode);
}

function TransferTextChatToQueueDone(data, obj) {
    if (data.ResultCode >= 0) {
        //send success
        //ShowNotify("Text Chat Transfer to queue is complete", "info", null, "top-center");
        favListGridItemSelectForChat = "";
        CloseTransferDialog();
    } else {
        //send failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
    EnableButton(obj.buttonId, obj.icon, "icon");
}

// ----------------------------------------------------------------------------------
// Transfer Text Chat to Server
// ----------------------------------------------------------------------------------

function TransferTextChatToServer(deviceid, sourceagentid, intid, number, comment, chatSessionId, agentid, lineid, toAgentTmacServer, confType, chatMode, obj) {
    tmac_TransferTextChatToServer("TransferTextChatToServerDone", obj, deviceid, chatSessionId, sourceagentid, intid, number, comment, agentid, lineid, toAgentTmacServer, confType, chatMode);
}

function TransferTextChatToServerDone(data, obj) {
    if (data === 0) {
        //TransferCall success
        //if the type is text chat no confirm dialog
        if (obj.type == "TextChatTransfer") {
            //if the type is TextChatTransfer close the transfer dialog here else it will be closed in OpenConfirmDialog
            CloseTransferDialog();
            GetChatReferenceObj(obj.intId).isTransfer = true;
        }
        else if (obj.type == "TextChatConference") {
            //if the type is TextChatConference close the conference dialog
            CloseConfDialog();
            GetChatReferenceObj(obj.intId).isConference = true;
        }
        else {
            OpenConfirmDialog("transfer");
        }
    } else {
        //TransferCall failed
        ShowNotify("Transfer Call Failed", "danger", null, "top-center");
    }
    EnableButton(obj.buttonId, obj.icon, "icon");
}

// ----------------------------------------------------------------------------------
// Send text chat tranfer notification response to requested agent
// ----------------------------------------------------------------------------------

function SendTextChatTransferNotificationRespond(toTmacServer, originatedAgentId,
    originatedInteractionID, response, comment, customdata) {
    //tmac_SendTextChatTransferNotificationRespond("SendTextChatTransferNotificationRespondDone", null, deviceid, originatedAgentId,
    //originatedInteractionID, response, comment, customdata);

    tmac_SendTextChatTransferNotificationResponseToServer("SendTextChatTransferNotificationRespondDone", null, toTmacServer, originatedAgentId,
        originatedInteractionID, response, comment, customdata);
}

function SendTextChatTransferNotificationRespondDone(data) {
    if (data.ResultCode >= 0) {
        //send success

    } else {
        //send failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// TextChat Typing Status Notification
// ----------------------------------------------------------------------------------

function TextChatNotifyTypingStatusChange(deviceid, intid, stat) {
    tmac_TextChatNotifyTypingStateChange("TextChatNotifyTypingStatusChangeDone", null, deviceid, intid, stat);
}

function TextChatNotifyTypingStatusChangeDone(data) {
    if (data.ResultCode >= 0) {
        //send success

    } else {
        //send failed
        ShowNotify(data.ResultMessage, "danger", null, "top-center");
    }
}

// ----------------------------------------------------------------------------------
// Get Agent List for BargeIn
// ----------------------------------------------------------------------------------

function GetTextChatAgentListForBargein(teamid, supervisorid) {
    //tmac_GetTextChatAgentListForBargein("GetTextChatAgentListForBargeinDone", null, teamid, supervisorid);
    tmac_GetTextChatAgentListForBargeinAll("GetTextChatAgentListForBargeinDone", null, teamid, supervisorid);
}

function GetTextChatAgentListForBargeinDone(data) {
    var $kendoGrid = $("#barge_in_grid").data('kendoGrid');
    $kendoGrid.dataSource.data(data);
}

// ----------------------------------------------------------------------------------
// Barge In to the selected conversation
// ----------------------------------------------------------------------------------

function TextChatBargeinToServer(AgentID, InteractionID, SupervisorAvayaLoginID, tmacServer) {
    var obj = {};
    obj.agentId = AgentID;
    tmac_TextChatBargeinToServer("TextChatBargeinToServerDone", obj, AgentID, InteractionID, SupervisorAvayaLoginID, tmacServer);
}

function TextChatBargeinToServerDone(data, obj) {
    try {
        if (data.ResultCode >= 0) {
            $("#bargeinchatTranscript").html("");
            AddMessageToChatbox("", "", "Agent " + obj.agentId + " conversation", "divider", "", "bargeinchatTranscript", "", false, "", "");
            let transcript = data.Data.Transcript;
            if (transcript.length !== 0) {
                $.each(transcript, function (i, val) {
                    let msg = "";
                    let msgid = uuid();
                    let msgDateTime = val.DateTime;
                    if (isAppMessage) {
                        let jsonData = JSON.parse(val.Message);
                        msg = jsonData.message;
                        if (val.Type.toLowerCase() == "agent")
                            AddMessageToChatbox("", msgid, msg, "agent", msgDateTime, "bargeinchatTranscript", jsonData.messageType, false, "", "Agent");
                        else if (val.TypetoLowerCase() == "user")
                            AddMessageToChatbox("", msgid, msg, "customer", msgDateTime, "bargeinchatTranscript", jsonData.messageType, false, "", "Customer");
                    } else {
                        msg = val.Message;
                        if (val.Type.toLowerCase() == "agent")
                            AddMessageToChatbox("", msgid, msg, "agent", msgDateTime, "bargeinchatTranscript", "", false, "", "Agent");
                        else if (val.Type.toLowerCase() == "user")
                            AddMessageToChatbox("", msgid, msg, "customer", msgDateTime, "bargeinchatTranscript", "", false, "", "Customer");
                    }
                });
            }
            $("#barge_in_dialog").data("kendoWindow").close();
            $("#barge_in_display_dialog").data("kendoWindow").center().open();
        } else {
            //send failed
            ShowNotify(data.ResultMessage, "danger", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.TextChatBargeinToServerDone()", ex, false);
    }
}

// ----------------------------------------------------------------------------------
// Disconnect the call via headset
// ----------------------------------------------------------------------------------

function DisconnectCallByHandle(deviceid, btnId, type) {
    var obj = {};
    obj.buttonId = "#" + btnId;
    obj.icon = "call_end";
    obj.type = type;
    DisableButton(obj.buttonId);
    isStatusManagerChange = true;
    tmac_DisconnectCallByHandle("DisconnectCallByHandleDone", obj, deviceid, global_ConnectionHandle);
}

function DisconnectCallByHandleDone(data, obj) {
    EnableButton(obj.buttonId, obj.icon, "icon");
    //if the disconnect by handle is from callback then interachange the drop buttons display
    //as each button has its own purpose
    if (obj.type == "callback") {
        var intId = obj.buttonId.substring(obj.buttonId.length - 4, obj.buttonId.length);
        //enable dial buttons
        EnableButton("#btnDialCallerID" + intId, "call", "icon");
        EnableButton("#btnDialPCN" + intId, "call", "icon");
        //show DisconnectCall button
        $("#btndisconnectDial" + intId).addClass("uk-display-none");
        //hide DisconnectCallByHandle button
        $("#btnDrop" + intId).removeClass("uk-display-none");
    } else $("#btndisconnectSpan").addClass("uk-display-none");
    global_ConnectionHandle = "";
    CloseMakeCallDialog();
}

function GetTmacWallboardSkills() {
    try {
        tmac_GetTmacWallboardSkills("GetTmacWallboardSkillsDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetTmacWallboardSkills()", ex, false);
    }
}

function GetTmacWallboardSkillsDone(data) {
    try {
        var $kendoDrpDwn = $('#transfer_skill_list').data('kendoDropDownList');
        $kendoDrpDwn.dataSource.data(data);
        $kendoDrpDwn.dataSource.sort({
            field: "SkillName",
            dir: "asc"
        });
        $kendoDrpDwn.text("Select skill..");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetTmacWallboardSkillsDone()", ex, false);
    }
}

function FreezeTextChatAutoResponse(deviceid, interactionid) {
    try {
        var obj = {};
        obj.intid = interactionid;
        tmac_FreezeTextChatAutoResponse("FreezeTextChatAutoResponseDone", obj, deviceid, interactionid);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.FreezeTextChatAutoResponse()", ex, false);
    }
}

function FreezeTextChatAutoResponseDone(data, obj) {
    try {
        EnableButton("#btnTextChat_FreezeAutoResponse" + obj.intid, "stop", "icon");
        $("#btnTextChat_FreezeAutoResponse" + obj.intid).hide();
        ShowNotify("Chat auto response freeze successful", "success", null, "top-center");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.FreezeTextChatAutoResponseDone()", ex, false);
    }
}

//added on 2017-07-21
function GetAgentSessionsList(teamid, supervisorid, agentid, interactionid, tmacServer, object) {
    try {
        tmac_GetAgentSessionsList("GetAgentSessionsListDone", object, teamid, supervisorid, agentid, interactionid, tmacServer);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetAgentSessionsList()", ex, false);
    }
}

function GetAgentSessionsListDone(resultdata, userobject) {
    try {
        AgentSessionsListLoaded(resultdata, userobject);
    } catch (ex) { }
}

//added on 2017-09-27
function GetLoggedInAgentList() {
    try {
        tmac_GetLoggedInAgentList("GetLoggedInAgentListDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetLoggedInAgentList()", ex, false);
    }
}

function GetLoggedInAgentListDone(resultdata, userobject) {
    try {
        if (resultdata !== null)
            agent_chat.agentlist_loaded(resultdata, userobject);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetLoggedInAgentListDone()", ex, false);
    }
}

function InteractionSaveComment(interactionid, comment) {
    try {
        tmac_Interaction_SaveComment(null, null, interactionid, comment);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.InteractionSaveComment()", ex, false);
    }
}

function SendIMToAgent(agentId, message) {
    try {
        tmac_SendIMToAgent(null, null, agentId, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendIMToAgent()", ex, false);
    }
}

function SendIMToAgentFromSupervisor(toAgentId, AgentName, agentStatus, agentProfile, message) {
    try {
        let obj = {};
        obj.FromAgentId = toAgentId;
        obj.FromAgentName = AgentName;
        obj.UserProfileForAgent = agentProfile;
        obj.CurrentAgentStatus = agentStatus;
        obj.Message = message;
        obj.mType = "own";
        tmac_SendIMToAgent("SendIMToAgentFromSupervisorDone", obj, toAgentId, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendIMToAgentFromSupervisor()", ex, false);
    }
}

function SendIMToAgentFromSupervisorDone(resultdata, userobject) {
    try {
        //open IM box
        agent_chat.chat_received(userobject);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendIMToAgentFromSupervisorDone()", ex, false);
    }
}

function SendCommandToAgent(obj, fromIntId, toAgentId, toTmacServer, toIntId, name, message) {
    try {
        tmac_SendCommandToAgent("SendCommandToAgentDone", obj, fromIntId, toAgentId, toTmacServer, toIntId, name, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendCommandToAgent()", ex, false);
    }
}

function SendCommandToAgentDone(resultdata, userobject) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendCommandToAgentDone()", ex, false);
    }
}

function LoadAgentReminders(status, startTime, endTime, message) {
    try {
        tmac_GetAgentReminders(null, null, global_DeviceID, global_AgentID, status, startTime, endTime, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAgentReminder()", ex, false);
    }
}

//CreateAgentReminder(string deviceid, string agentid, string reminddate, string remindtime,string message)
function CreateAgentReminder(reminddate, remindtime, message) {
    try {
        DisableButton("#btnSetReminder");
        tmac_CreateAgentReminder("CreateAgentReminderDone", null, global_DeviceID, global_AgentID, reminddate, remindtime, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.CreateAgentReminder()", ex, false);
    }
}

function CreateAgentReminderDone(resultdata, userobject) {
    try {
        EnableButton("#btnSetReminder", "add", "icon");
        $("#add_reminder_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.CreateAgentReminderDone()", ex, false);
    }
}

//UpdateAgentReminder(string deviceid, string agentid, string id, string status, string message)
function UpdateAgentReminder(id, status, message, obj) {
    try {
        tmac_UpdateAgentReminder("UpdateAgentReminderDone", obj, global_DeviceID, global_AgentID, id, status, message);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.UpdateAgentReminder()", ex, false);
    }
}

function UpdateAgentReminderDone(resultdata, userobject) {
    try {
        if (userobject !== null) {
            if (userobject.status == "delete") {
                EnableButton("#btnDeleteReminder", "delete", "icon");
            } else if (userobject.status == "edit") {
                $("#txtReminder").removeAttr("readonly", "readonly");
                EnableButton("#btnEditReminder", "mode_edit", "icon");
                $("#add_reminder_dialog").data("kendoWindow").close();
            }
            $("#btnDeleteReminder").addClass("disabled");
            $("#btnEditReminder").addClass("disabled");
            $("#btnClearSelectedReminder").addClass("disabled");
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.UpdateAgentReminderDone()", ex, false);
    }
}

function GetCustomerList() {
    try {
        tmac_GetWorkItems("GetCustomerListDone", null, "textchat", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetCustomerList()", ex, false);
    }
}

function GetCustomerListDone(resultdata, userobject) {
    try {
        customer_chat.customerlistloaded(resultdata, userobject);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetCustomerListDone()", ex, false);
    }
}

function GetUserDomainList() {
    try {
        tmac_GetUserDomainList("GetUserDomainListDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetUserDomainList()", ex, false);
    }
}

function GetUserDomainListDone(data, obj) {
    try {
        //remove loading indicator
        $('.k-i-arrow-60-down').removeClass('k-i-loading');
        if (data !== null)
            $("#domainList").data("kendoDropDownList").dataSource.data(data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetUserDomainListDone()", ex, false);
    }
}

function GetQueueTimeColorCode() {
    try {
        tmac_GetQueueTimeColorCode("GetQueueTimeColorCodeDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetQueueTimeColorCode()", ex, false);
    }
}

function GetQueueTimeColorCodeDone(data) {
    try {
        SetColorCodes(data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadAUXCodesDone()", ex, false);
    }
}

function LoadCallWorkCodes(teamid) {
    try {
        if (!isNullOrWhitespace(teamid))
            tmac_LoadCallWorkCodes("LoadCallWorkCodesDone", null, global_DeviceID, teamid);
        else
            log.LogDetails("Error", "CommandManager.LoadCallWorkCodes()", "Please provide teamid to load CallWorkCodes.", false);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadCallWorkCodes()", ex, false);
    }
}

function LoadCallWorkCodesDone(data, obj) {
    try {
        global_WorkCodeList = data;
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.LoadCallWorkCodesDone()", ex, false);
    }
}

function SetCallWorkCode(intid, code) {
    try {
        tmac_SetCallWorkCode("SetCallWorkCodeDone", null, global_DeviceID, intid, code);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SetCallWorkCode()", ex, false);
    }
}

function SetCallWorkCodeDone(data) {
}

function RemoveCallWorkCode(intid, code) {
    try {
        tmac_RemoveCallWorkCode("RemoveCallWorkCodeDone", null, global_DeviceID, intid, code);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.RemoveCallWorkCode()", ex, false);
    }
}

function RemoveCallWorkCodeDone(data) {
}

function SendGenericCTICommand(commandName, userobject, data) {
    try {
        tmac_SendGenericCTICommand("SendGenericCTICommandDone", commandName, userobject, data);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendGenericCTICommand()", ex, false);
    }
}

function SendGenericCTICommandDone(data, obj) {
    try {
        if (data === 0 || obj.method == "GetConsultDestinationAgentsList")
            window[obj.method + "Done"](data, obj);
        else
            log.LogDetails("Error", "CommandManager.SendGenericCTICommandDone()", obj.method + " Failed", true);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.SendGenericCTICommandDone()", ex, false);
    }
}

function GetFaxLineNumbers() {
    try {
        tmac_GetFaxLineNumbers("GetFaxLineNumbersDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxLineNumbers()", ex, false);
    }
}

function GetFaxLineNumbersDone(data, obj) {
    try {
        faxLineNumbers = [];
        $.each(data, function (i, val) {
            if (val.Enabled && val.SendEnabled)
                faxLineNumbers.push(val.DNIS);
        });
        $('#DNISList').data('kendoDropDownList').dataSource.data(faxLineNumbers);
        $("#DNISList").data("kendoDropDownList").text("Select a fax line...");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxLineNumbersDone()", ex, false);
    }
}

function GetFaxTemplateNames() {
    try {
        tmac_GetFaxTemplateNames("GetFaxTemplateNamesDone", null);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplateNames()", ex, false);
    }
}

function GetFaxTemplateNamesDone(data, obj) {
    try {
        if (data !== null)
            $('#faxTemplates').data('kendoDropDownList').dataSource.data(data);
        $("#faxTemplates").data("kendoDropDownList").text("Select a fax template...");
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplateNamesDone()", ex, false);
    }
}

function SendFax(intid, file, faxNumber, DNIS, fileName, type) {
    try {
        tmac_SendFax("SendFaxDone", null, intid, file, faxNumber, DNIS, fileName, type);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplateNames()", ex, false);
    }
}

function SendFaxDone(result, obj) {
    try {
        let resultMessage = result.ResultMessage == "Success" ? "Fax sent successfully" : "Fax sent failed";
        log.LogDetails(result.ResultMessage, "MainUI.SendFaxDone()", resultMessage, true);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.GetFaxTemplateNamesDone()", ex, false);
    }
}

function PullQueueItem(obj, channel, itemid) {
    try {
        tmac_PullQueueItem("PullQueueItemDone", obj, channel, itemid);
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.PullQueueItem()", ex, false);
    }
}

function PullQueueItemDone(resultdata, userobject) {
    try {
        if (resultdata > 0) {
            log.LogDetails("Success", "CommandManager.PullQueueItemDone()", "item pulled successfully", true);
        } else {
            log.LogDetails("Error", "CommandManager.PullQueueItemDone()", "Item pull failed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "CommandManager.PullQueueItemDone()", ex, false);
    }
}
