﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//EMC email channel
//Author - Weerathungage Sumudu Saman
//Last updated date - 2016/09/07

var version_tmac_emc_sdk = "2.0.09.07";

var tmac_emc_onIncomingEmailCallback;
var tmac_emc_onIncomingEmailUpdateCallback;

var tmac_emc_stationid;
var tmac_emc_agentid;
var tmac_emc_agentname;

function tmac_emc_initialize(stationid, agentid, agentname, incomingEmailCallback, incomingEmailUpdateCallback) {
    tmac_emc_stationid = stationid;
    tmac_emc_agentid = agentid;
    tmac_emc_agentname = agentname;
    tmac_emc_onIncomingEmailCallback = incomingEmailCallback;
    tmac_emc_onIncomingEmailUpdateCallback = incomingEmailUpdateCallback;
}


function EMC_IncomingEmailEvent(event) {

    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    window[tmac_emc_onIncomingEmailCallback](
        event.InteractionID,
        event.SessionId,
        event.RouteId,
        event.From,
        event.To,
        event.Subject,
        event.EmailType,
        event.Skill,
        event.Intent,
        event.JsonData,
        event.RouteReason
    );
}

function EMC_UpdateEmailEvent(event) {
    window[tmac_emc_onIncomingEmailUpdateCallback](
        event.InteractionID,
        event.SessionId,
        event.RouteId,
        event.From,
        event.To,
        event.Subject,
        event.EmailType,
        event.Skill,
        event.Intent,
        event.JsonData,
        event.RouteReason
    );
}

    
function tmac_EMC_GetEmailContent(callbackfunction, userobject, contactID, routeID,emailType) {
    var data = {};
   
    data.contactID = contactID;
    data.routeID = routeID;  //String
    data.emailType = emailType;  //String

    tmac_command(callbackfunction, userobject, data, "EMC_GetEmailContent");
}
function tmac_EMC_GetEmailContentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = EmailContentData
    //bccAddr,ccAddr,contactID,emailBody,fromAddr,subject,toAddr
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMC_SendEmail(callbackfunction, userobject, agentID, agentRole, bccAddr, ccAddr, CIF, clid, contactID, emailBodyContent, emailType,
    fromAddr, hasAttachments, hasLockedTemplate, intent, isAgentTransfer, isNewEmail, isSkillTransfer,
    NRIC, routeId, skill, subject, toAddr, transfereeAgentID
) {
   
    var data = {};

    data.agentID = agentID;
    data.agentRole = agentRole;  //String
    data.bccAddr = bccAddr;  //String
    data.ccAddr = ccAddr;  //String
    data.CIF = CIF;  //String
    data.clid = clid;  //String
    data.contactID = contactID;  //String
    data.emailBodyContent = emailBodyContent;  //String
    data.emailType = emailType;  //String
    data.fromAddr = fromAddr;  //String
    data.hasAttachments = hasAttachments;  //bool
    data.hasLockedTemplate = hasLockedTemplate;  //bool
    data.intent = intent;  //String
    data.isAgentTransfer = isAgentTransfer;  //bool
    data.isNewEmail = isNewEmail;  //bool
    data.isSkillTransfer = isSkillTransfer;  //bool
    data.NRIC = NRIC;  //String
    data.routeId = routeId;  //String
    data.skill = skill;  //String
    data.subject = subject;  //String
    data.toAddr = toAddr;  //String
    data.transfereeAgentID = transfereeAgentID ;  //String

    tmac_command(callbackfunction, userobject, data, "EMC_SendEmail");
}

function tmac_EMC_SendEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = RetVal_t
    //retCode (int) ,retVal(string)
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}