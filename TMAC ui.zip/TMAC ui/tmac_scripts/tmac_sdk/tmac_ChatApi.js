﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//WebRTC and Falsh Chat API
//Author - Weerathungage Sumudu Saman
//Last updated date - 2016/11/15

var version_tmac_chat_sdk = "3.0.10.10";

//delegate incoming chat call event (TMAC event)
var tmac_onChatIncomingCallback;

//delegate for incoming chat connected event (TMAC event)
var tmac_onChatCallConnectedCallback;

//delegate to handle chat connection error (WebRTC/Flash event)
var tmac_onChatConnectionError;

//delegate for chat completed event (TMAC event- call disconencted)
var tmac_onChatCompleted;

//delegate for chat connection success (WebRTC/Flash event)
var tmac_onChatConnectionSuccessCallback;

//delegate for chat audio/video request (WebRTC/Flash event)
var tmac_onChatAudioVideoRequestStatusCallback;

//delegate for new message in chat (WebRTC/Flash event)
var tamc_onChatNewTextReceivedCallback;

//delegate for text chat sent (WebRTC/Flash event)
var tamc_onChatTextSentCallback;

//delegate to receive chat transcript from TMAC (TMAC event)
var tmac_onChatTranscriptForTransferCallback;

//delegate to handle chat customer data (WebRTC/Flash event)
var tmac_onChatCustomerDataCallback;

//chat protocol to use (flash/webrtc)
var tmac_chat_protocol = "flash";

//html control (div) to load the Flash SWF or WebRTC iFrame
var tmac_chat_api_container;

//active chat interaction id (for transfer purpose)
var tmac_activeChatIntId;

//chat API reference for flash
var tmac_chat_api_ref;

//flag to show if the api is loaded
var tmac_chat_api_loaded = false;

//flasg to show if the chat is connected
var tmac_chat_connected = false;

//tmac agent details
var tmac_stationid;
var tmac_agentid;
var tmac_agentname;

//WebRTC api window list (for multiple tabs)
var tmac_chat_webRtcWindowList = new Array();

//ANI for latest chat call (TMAC)
var tmac_chat_last_ani;

//chat config (for flash)
var tmac_chat_config = '<?xml version="1.0" encoding="UTF-8"?><config><myWidth>320</myWidth><myHeight>240</myHeight><mediaserver>rtmp://202.150.214.55:1935</mediaserver><sessionActiveNotifyTime>10</sessionActiveNotifyTime></config>';

var tmac_chat_confid = "";

//call this method from your UI to initialize the chat
//this has to be called after login is completed
function tmac_chat_initialize(stationid, agentid, agentname,
    incomingChatCallback,
    chatCallConnectedCallback,
    chatConnectionSuccessCallback,
    chatConnectionErrorCallback,
    chatConnectionClosedCallback,
    chatCustomerDataCallback,
    chatAudioVideoRequestStatusCallback,
    chatNewTextReceivedCallback,
    chatTextSentCallback,
    chatTranscriptForTransfer,
    chatApiContainerdivId) {


    //find the browser 
    var ie = detectIE();
    if (ie) {
        //alert("IE");
        tmac_chat_protocol = "flash";
        chatApiContainerdivId = "flashDiv";
    } else {
        tmac_chat_protocol = "webrtc";
    }

    tmac_stationid = stationid;
    tmac_agentid = agentid;
    tmac_agentname = agentname;
    tmac_onChatIncomingCallback = incomingChatCallback;
    tmac_onChatConnectionSuccessCallback = chatConnectionSuccessCallback;
    tmac_chat_api_container = chatApiContainerdivId;
    tmac_onChatConnectionError = chatConnectionErrorCallback;
    tmac_onChatCompleted = chatConnectionClosedCallback;

    tmac_onChatAudioVideoRequestStatusCallback = chatAudioVideoRequestStatusCallback;
    tamc_onChatNewTextReceivedCallback = chatNewTextReceivedCallback;
    tamc_onChatTextSentCallback = chatTextSentCallback;
    tmac_onChatTranscriptForTransferCallback = chatTranscriptForTransfer;
    tmac_onChatCustomerDataCallback = chatCustomerDataCallback;

    tmac_onChatCallConnectedCallback = chatCallConnectedCallback;
}

//load the chat api (flash swf or webrtc iframe)
function tmac_chatAPI_loadAPI(intid, istransfer, isconference, agentconfid, userconfid) {
    tmac_chat_api_loaded = false;
    tmac_chat_connected = false;

    tmac_activeChatIntId = intid;

    if (tmac_chat_protocol == "flash") {
        //clear the current html
        $("#" + tmac_chat_api_container + intid).html("");

        var flashvars = {};
        var params = {};
        var attributes = {};
        attributes.id = "as3_js" + intid;
        //swfobject.embedSWF("ChatAPI.swf", "tmac_chat_api_container" + intid, "320", "240", "11.0.0", false, flashvars, params, attributes);
        swfobject.embedSWF("ChatAPI.swf", tmac_chat_api_container + intid, "320", "240", "11.0.0", false, flashvars, params, attributes);
    }
    else {
        if (isconference) {

            //set agent data
            var agentData = tmac_agentid + "," + tmac_agentname + ",1,1," +
        new Date().getHours() + ":" + new Date().getMinutes() + new Date().getSeconds();


            //user window
            var url1 = "WebRTCAPI.htm" + "?ani=" + tmac_chat_last_ani + "&intid=" + intid + "&pagetype=conf&pid=" +
                userconfid + "&agentdata=" + agentData + "&iframeid=" + tmac_chat_api_container + intid;
            //if this is a conference call, agent has to open two windows
            tmac_util_load_iframe(tmac_chat_api_container + intid, url1);
            tmac_chat_webRtcWindowList[intid] = document.getElementById(tmac_chat_api_container + intid).contentWindow;


            //other agent window
            var url2 = "WebRTCAPI.htm" + "?ani=" + tmac_chat_last_ani + "&intid=" + intid + "&pagetype=conf&pid=" +
                agentconfid + "&agentdata=" + agentData + "&iframeid=" + "iframe_webrtc_conf" + intid;
            
            //if this is a conference call, agent has to open two windows
            tmac_util_load_iframe('iframe_webrtc_conf' + intid, url2);
            //tmac_chat_webRtcWindowList[intid] = document.getElementById('iframe_webrtc_conf' + intid).contentWindow;

        } else {
            //WebRTCVideoAPI
            var url = "WebRTCAPI.htm" + "?ucid=" + tmac_chat_last_ani + "&intid=" + intid +"&iframeid=" + tmac_chat_api_container + intid;
            tmac_util_load_iframe(tmac_chat_api_container + intid, url);

            //add this iframe to iframe list
            tmac_chat_webRtcWindowList[intid] = document.getElementById(tmac_chat_api_container + intid).contentWindow;
        }
    }
}


function tmac_chat_openConferenceFrame(ani,confid,intid) {
    //set agent data
    var agentData = tmac_agentid + "," + tmac_agentname + ",1,1," +
        new Date().getHours() + ":" + new Date().getMinutes() + new Date().getSeconds();


    //user window
    var url1 = "WebRTCAPI.htm" + "?ani=" + ani + "&intid=" + intid + "&pagetype=conf&pid=" +
                confid + "&agentdata=" + agentData + "&iframeid=" + "iframe_webrtc_conf" + intid;
    
    //if this is a conference call, agent has to open two windows
    tmac_util_load_iframe('iframe_webrtc_conf' + intid, url1);
    
    //tmac_chat_webRtcWindowList[intid] = document.getElementById(tmac_chat_api_container + intid).contentWindow;
}

/////TMAC SERVER EVENTS
//new chat event received from server
function ChatIncomingEvent(event) {
    tmac_chat_confid = "";
    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    //load the flash/webrtc api
    tmac_chat_last_ani = event.PhoneNumber;

    window[tmac_onChatIncomingCallback](event.InteractionID, event.PhoneNumber, false);

}

//chat call answered
function ChatCallConnectedEvent(event) {
    tmac_chat_connected = true;

    tmac_chatAPI_loadAPI(event.InteractionID, event.IsTransfer, event.IsConference, event.ConfIdForAgent, event.ConfIdForUser);

    window[tmac_onChatCallConnectedCallback](event.InteractionID);

}

//transfered chat incoming call
function TransferredChatIncomingEvent(event) {
    tmac_chat_confid = "trans";


    //load the flash/webrtc api
    tmac_chat_last_ani = event.PhoneNumber;
    
    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    window[tmac_onChatIncomingCallback](event.InteractionID, event.PhoneNumber, true);

    //auto answer the call
    tmac_AnswerCall(null, null, tmac_stationid, event.InteractionID);
}


//on chat hold event (when chat voice calls goes on hold)
function VideoChatHoldEvent(event) {
}

function VideoChatHoldReconnectEvent(event) {
    if (tmac_chat_protocol != "flash") {
        var vdo = tmac_chat_webRtcWindowList[event.InteractionID].IsVideoStarted();
    }
}

function VideoChatHoldTimerEvent(event) {
}

function ChatCallDisConnectedEvent(event) {
    //voice call disconnected for chat
    //check if call is answered
    if (tmac_chat_webRtcWindowList[event.InteractionID] == null || tmac_chat_webRtcWindowList[event.InteractionID] == undefined) {
        window[tmac_onChatCompleted](event.InteractionID, "CallDisconnectedBeforeBridge");
    } else {
        tmac_chat_end_chat(event.InteractionID);
        window[tmac_onChatCompleted](event.InteractionID, "CallDisconnectedAfterBridge");
    }
}

function ChatCallTransferCompletedEvent(event) {
    tmac_chat_end_chat(event.InteractionID);
}


function TextChatTranscriptForTransferEvent(event) {
    try {
        if (event.Transcript != null) {
            var html = "";
            $.each(event.Transcript, function (i, val) {


                if (val.Type == 'Agent') {
                    //agent data
                    html += val.DateTime + ":" + val.AgentName + ":" + val.Message + "<br>";
                }
                else if (val.Type == 'User') {
                    html += val.DateTime + ": Customer :" + val.Message + "<br>";
                }

            });
            if (html != "") {
                var finalHtml = "<div>Chat history<br>" + html + "</div>";
                window[tmac_onChatTranscriptForTransferCallback](event.InteractionID, finalHtml);
            }
        }
    } catch (e) {

    }
}

////END OF TMAC SERVER EVENTS




////FLASH/WebRTC EVENTS
//events received from flash component or webRTC
//function Notify(event, eventdata) {
function Notify(event, eventdata, tintid, selfServiceMessages) {
    var intid = tmac_activeChatIntId;
    switch (event) {
        case "Initiated":
            tmac_chat_api_ref = document.getElementById("as3_js" + intid);
            tmac_chat_api_ref.style.visibility = 'hidden';
            //load the chat server config into flash component
            tmac_chat_api_ref.LoadConfig(tmac_chat_config);
            break;

        case "LoadComplete": //flash loading completed.
            tmac_chat_api_loaded = true;
            //call bridge 
            tmac_chat_bridge(eventdata, intid);
            break;
        case "ConnectionFailed": //connect to server failed
            window[tmac_onChatConnectionError](intid, "ConnectionFailed");
            break;

        case "ConnectionClosed": //connection closed
            //issue a disconnect voice call command
            tmac_DisconnectCall("tmac_chat_disconnect_done", intid, tmac_stationid, intid);
            window[tmac_onChatCompleted](intid, "ConnectionClosed");
            break;

        case "ConnectionSuccess": //connection success. Now flash api will try to set the application
            window[tmac_onChatConnectionSuccessCallback](intid, "ConnectionSuccess");
            break;

        case "RACKPINION_STATUS_SETTYPESUCCESS": //setting the applicaiton is success. Now api will try to start a call

            break;

        case "RACKPINION_STATUS_SETTYPEFAILURE": //setting the applicaiton failed.
            tmac_DisconnectCall("tmac_chat_disconnect_done", intid, tmac_stationid, intid);
            window[tmac_onChatCompleted](intid, "FlashSetupFailure");
            break;

        case "RACKPINION_STATUS_INVITESUCCESS": //call success. Now you have to wait till you get a connected event

            break;

        case "RACKPINION_CALLSTATUS_CONNECTED": //call connected with Avaya. Now API will start publishing

            break;

        case "RACKPINION_CALL_BRIDGEMESUCCESS": //agent connected. 
            tmac_chat_bridge_success(eventdata, intid, selfServiceMessages);
            //tmac_chat_bridge_success(eventdata, tintid, selfServiceMessages);
            break;

        case "RACKPINION_CALLSTATUS_HANGUP": //call ended
            tmac_DisconnectCall("tmac_chat_disconnect_done", intid, tmac_stationid, intid);
            window[tmac_onChatCompleted](intid, "CallHangup");
            break;
    }
}

//--------------------------------------chat api messages (flash to JS)-------------------------------------------------------
function chatApi_AppMessage(txt, data) {
    var intid = tmac_activeChatIntId;
    switch (txt) {

        case "okAudio": //audio chat accepted
            window[tmac_onChatAudioVideoRequestStatusCallback](intid, "okAudio");

            break;
        case "noAudio": //audio chat rejected
            window[tmac_onChatAudioVideoRequestStatusCallback](intid, "noAudio");

            break;

        case "okVideo": //video chat accepted by user
            window[tmac_onChatAudioVideoRequestStatusCallback](intid, "okVideo");
            tmac_chat_start_video(intid);
            break;

        case "noVideo": //video chat rejected
            window[tmac_onChatAudioVideoRequestStatusCallback](intid, "noVideo");
            break;

        case "textSentAck": //agent text sent
            window[tamc_onChatTextSentCallback](intid);
            break;

        case "24": //call back request received
            break;

        case "netStat":
            //chat_parse_netstat(data, intid);
            break;

        case "fileReady": //file ready to download
            chat_filereceived(data, intid);
            break;
    }
}


//flash to JS when new text received
//function TextReceived(txt, intid) {
function TextReceived(txt,iid,username) {
    var intid = tmac_activeChatIntId;


    if (txt.indexOf('fileReady') >= 0) {
        chat_filereceived(txt, intid, username);
        return;
    }
    
    //update chat transcript in DB
    tmac_Chat_TextReceived(null, null, tmac_stationid, intid, txt);

    //send ack
    var msgId = txt.substring(0, 4);
    var msg = txt.substring(4, txt.length);
    tmac_chat_send_app_message("textRecvdAck", msgId, intid);
    window[tamc_onChatNewTextReceivedCallback](intid, msg, username);

}
////END OF FLASH EVENTS


///FLASH METHODS
function tmac_chat_bridge(eventdata, intid) {
    //get ANI
    var ani = tmac_chat_last_ani;

    //Get video cam availability
    var cam = eventdata.substring(0, 1);

    //get MIC availability
    var mic = eventdata.substring(1, 2);

    //set agent data
    var agentData = tmac_agentid + "," + tmac_agentname + "," + cam + "," + mic + "," +
        new Date().getHours() + ":" + new Date().getMinutes() + new Date().getSeconds();

    if (tmac_chat_protocol == "flash") {
        var flash = document.getElementById("as3_js" + intid);
        //connect to video server
        flash.ConnectToServer("MySessionID", 2, ani, agentData);
    } else {
        //connect to video server
        tmac_chat_webRtcWindowList[intid].ConnectToServer(ani, agentData);
    }
}


//send text to user via flash
function tmac_chat_send_text(txt, intid) {
    if (tmac_chat_protocol == "flash") {
        var flash = document.getElementById("as3_js" + intid);
        flash.SendText("1001" + txt);
    } else {
        tmac_chat_webRtcWindowList[intid].SendText("1001" + txt,tmac_agentname);
    }

    //update database
    tmac_Chat_TextSent(null, null, tmac_stationid, intid, txt);


}

//--------------------------------------Send App message to flash-----------------------------------
function tmac_chat_send_app_message(txt, msgId, intid) {
    if (tmac_chat_protocol == "flash") {
        var flash = document.getElementById("as3_js" + intid);
        flash.SendAppMessage(txt, msgId);
    } else {
        tmac_chat_webRtcWindowList[intid].SendAppMessage(txt, msgId);
    }
}


//disconnet the call
function tmac_chat_end_chat(intid) {
    if (tmac_chat_protocol == "flash") {
        var flash = document.getElementById("as3_js" + intid);
        flash.EndCall();
    } else {
        tmac_chat_webRtcWindowList[intid].EndCall();
    }
    tmac_DisconnectCall("tmac_chat_disconnect_done", intid, tmac_stationid, intid);
}


function tmac_chat_start_video(intid) {
    if (tmac_chat_protocol == "flash") {
        var flash = document.getElementById("as3_js" + intid);
        flash.style.visibility = 'visible';
        flash.StartStreamingMyVideo();
    } else {
        tmac_chat_webRtcWindowList[intid].StartStreamingMyVideo();
    }
}
///END FLASH METHODS


function tmac_chat_disconnect_done(data) {

}



//--------------------------------------bridge me success-------------------------------------------------------
function tmac_chat_bridge_success(eventdata, intid, selfServiceMessages) {
    var video = "0";
    var audio = "0";
    var cxname = "";

    //sessionid|11|name|CIF|nric|REGPhone|Segment|inb-session
    //check audio/video availability
    var parts = eventdata.split("|");

    if (parts.length > 1) {
        if (parts[1].length > 1) {
            video = parts[1].substring(0, 1);
            audio = parts[1].substring(1, 2);
        }
    }

    if (parts.length > 2)
        cxname = parts[2];


    try {
        tmac_chat_webRtcWindowList[intid].document.getElementById('divVideoName').innerHTML = cxname;
    } catch (e) {

    }

    //parse data and bind
    //call server to handle bridge data
    tmac_Chat_BridgeSuccess(null, null, tmac_stationid, intid, eventdata);

   
    //invoke self service callback


    window[tmac_onChatCustomerDataCallback](intid, audio, video, cxname, selfServiceMessages);

}

function tmac_chat_hold(intid) {
    tmac_chat_send_app_message("holdChat", "", intid);
    tmac_HoldCall(null, null, tmac_stationid, intid);

}

function tmac_chat_unhold(intid) {
    tmac_chat_send_app_message("unholdChat", "", intid);
    tmac_UnHoldCall(null, null, tmac_stationid, intid);
}


function tmac_chat_mute_video(intid) {
    if (tmac_chat_protocol == "flash") {
        var flash = document.getElementById("as3_js" + intid);
        flash.StopStreamingMyVideo();

    } else {
        try {
            tmac_chat_webRtcWindowList[intid].muteVideo();
        } catch (e) {

        }
    }
}

function tmac_chat_unmute_video(intid) {
    if (tmac_chat_protocol == "flash") {
        var flash = document.getElementById("as3_js" + intid);
        flash.StartStreamingMyVideo();
    } else {
        try {
            tmac_chat_webRtcWindowList[intid].unMuteVideo();
        } catch (e) {

        }
    }
}





function tmac_util_load_iframe(iframeName, url) {
    var $iframe = $("#" + iframeName);
    if ($iframe.length) {
        $iframe.attr('src', url);
        return false;
    }
    return true;
}


function tmac_chat_send_video_request(intid) {
    tmac_chat_send_app_message("rqVideo", "", intid);
}


function detectIE() {
    var ua = window.navigator.userAgent;

    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        // IE 10 or older => return version number
        return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }

    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
        // IE 11 => return version number
        var rv = ua.indexOf('rv:');
        return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
    }

    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
        // Edge (IE 12+) => return version number
        return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    }

    // other browser
    return false;
}



function tmac_chat_transfer(intid, number) {
    SendTextChatTransferNotification(global_DeviceID, intid, number, "i want transfer this chat", "");
}

function tmac_chat_conference(intid, number) {
    SendTextChatTransferNotification(global_DeviceID, intid, number, "i want conference this chat", "conf");
}


//-------------------------------------Another agent trying to transfer a chat to me-------------------------------------------
function TextChatTransferNotificationEvent(event) {

    var response = "Reject";
    if (event.Data == "conf") {
        var ret1 = confirm(event.FromAgentName + " is trying to conference a text chat to you. Do you want to accept");

        //send the transfer notification response to requested agent
        if (ret1)
            response = "Accept";
    } else {
        var ret = confirm(event.FromAgentName + " is trying to tranfer a text chat to you. Do you want to accept");

        //send the transfer notification response to requested agent
        if (ret)
            response = "Accept";

        //deviceid,  originatedAgentId,originatedInteractionID, response, comment, customdata
        //alertMessageDialog('TextChatTransferNotificationEvent' +  event.FromAgentID + ',' + response);
        //SendTextChatTransferNotificationRespond(global_DeviceID, event.FromAgentID, event.InteractionID, response, response, response);
    }

    SendTextChatTransferNotificationRespond(global_DeviceID, event.FromAgentID, event.InteractionID, response, response, event.Data);

}

//-------------------------------------Remote agent accpeted/rejected the text chat transfer requset------------------------------------
function TextChatTransferNotificationResponseEvent(event) {
    if (event.Response == "Accept") {
        //accept
        //transfer the call to FromAgentID

        if (event.Data == "conf") {
            var confid = global_DeviceID + event.InteractionID;
            TransferCall(global_DeviceID, event.InteractionID, event.FromAgentID, "conf" + confid);

        } else {
            TransferCall(global_DeviceID, event.InteractionID, event.FromAgentID, "");
        }
    }
    else {
        //reject
        //alertMessageDialog(event.FromAgentName + " rejected your transfer request:" + event.Comment, "danger");
    }
}



//--------------------------------------party joined conference-------------------------------------------------------
function tmac_chat_conference_agent_joined(eventdata, intid) {

    try {
        var parts = eventdata.split(",");


        var txt = "1000" + parts[1] + " joined conference";

        TextReceived(txt, intid,"");
    } catch (e) {

    }
   
}
