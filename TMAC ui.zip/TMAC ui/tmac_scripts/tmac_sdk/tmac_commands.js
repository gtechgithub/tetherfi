﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//TMAC commands (all commands with websock connect and ajax connect)
//Author - Weerathungage Sumudu Saman
//Last updated date - 2017/06/19
var version_tmac_commands = "3.1.08.0805";

var global_DeviceID;
var global_LanID;
var global_AgentID;
var global_AgentSessionKey;
var global_successfullyLoggedInData = {};
var global_LogoutCommandSend = false;


var _tmacServer = "";

try {
    global_addVersion("tmac_commands", version_tmac_commands);
} catch (e) {
}

var tmac_ws_websock;
var tmac_ws_url_list = new Array();
var tmac_ws_url_listString;
var tmac_ws_last_try_id = -1;

var tmac_ws_url;
var tmac_ws_websock_isopen = false;
var tmac_ws_websock_autoconnect = false;
var tmac_ws_websock_method_call_id = 0;
var tmac_ws_websock_method_call_objects = {};
var tmac_ws_authcode = "authauthauthauth";
var command_error_callback = "on_tmac_sdk_connect_error";


function UnautherizedEvent(event) {
    alert(event.ResultMessage);
}

function tmac_ws_setConnectivityStatus(val) {
    try {
        SetConnectivityStatus(val);
    } catch (e) {

    }
}

function command(data, method, object, timeout) {
    tmac_command(method + "Done", object, data, method);
}

function tmac_ws_connect(retry) {
    //get session data from login page
    try {
        if (global_successfullyLoggedInData.tmac_ws_authcode == undefined) {
            tmac_ws_authcode = $('#hfAuthKey').val();

            global_successfullyLoggedInData.tmac_ws_authcode = tmac_ws_authcode;
        } else {
            tmac_ws_authcode = global_successfullyLoggedInData.tmac_ws_authcode;
        }
        if (global_successfullyLoggedInData.tmac_ws_url_listString == undefined) {
            tmac_ws_url_listString = $('#hfTmacConnectUrl').val();
            global_successfullyLoggedInData.tmac_ws_url_listString = tmac_ws_url_listString;
        } else {
            tmac_ws_url_listString = global_successfullyLoggedInData.tmac_ws_url_listString;
        }
        if (tmac_ws_url_listString == undefined) return;
        tmac_ws_url_list = tmac_ws_url_listString.split(',');
        if (tmac_ws_url_list.length <= 0)
            return;
        if (retry == true) {
            if (tmac_ws_url_list.length > tmac_ws_last_try_id + 1) {
                tmac_ws_last_try_id = tmac_ws_last_try_id + 1;
                tmac_ws_url = tmac_ws_url_list[tmac_ws_last_try_id];
                //reset tmac_ws_last_try_id if it has reached the max
                if (tmac_ws_last_try_id >= tmac_ws_url_list.length)
                    tmac_ws_last_try_id = -1;
            } else {
                tmac_ws_last_try_id = -1;
            }
        } else {
            //assign the first url
            tmac_ws_url = tmac_ws_url_list[0];
        }
    } catch (e) {

    }
    try {
        console.log("trying to connect:" + tmac_ws_url);
        tmac_ws_websock = new WebSocket(tmac_ws_url);
        //setup websocket callbacks
        tmac_ws_websock.addEventListener("message", on_tmac_ws_message, false);
        tmac_ws_websock.onopen = function (evt) {
            tmac_ws_websock_isopen = true;
            ///tmac_ws_authenticate();
            //alert("Socket open");
            tmac_ws_setConnectivityStatus(1);
            //call get event to restart get event thread
            tmac_UpdateAgentDetails();
        };
        tmac_ws_websock.onerror = function (error) {
            tmac_ws_setConnectivityStatus(2);
            if (tmac_ws_websock.readyState == 1) {
                console.log('ws normal error: ' + error.type);
            }
        };
        //web socket closed
        tmac_ws_websock.onclose = function (evt) {
            tmac_ws_websock_isopen = false;
            tmac_ws_setConnectivityStatus(2);
            if (evt.code == 3001) {
                ;
            } else {
                console.log('ws connection error: ' + evt.code);
                //retry connecting
                setTimeout(function () {
                    tmac_ws_connect(true);
                }, 4000);
            }
        };
    } catch (e) {

    }
}


function tmac_UpdateAgentDetails() {
    if (location.href.indexOf("mainscreen") >= 0) {
        var data = {};
        data.lanId = global_LanID;
        data.stationid = global_DeviceID;
        data.agentid = global_AgentID;
        data.sessionkey = global_AgentSessionKey;
        tmac_ws_sendMessage(null, null, data, "UpdateAgentDetails");
    }
}

function tmac_ws_authenticate() {
    var data = {};
    tmac_ws_sendMessage(null, null, data, "authenticate");
}

function tmac_authenticateDone(data) {
    alert('authenticateDone' + data);
}

function tmac_ws_sendMessage(callbackfunction, userobject, data, methodname, timeout, waitforsocketcount) {

    //check if the socket is open
    if (!tmac_ws_websock_isopen) {
        if (waitforsocketcount == undefined)
            waitforsocketcount = 0;
        if (waitforsocketcount > 5)//wait only 20 seconds
            return;
        //wait for a while and call the method again
        setTimeout(function () {
            waitforsocketcount = waitforsocketcount + 1;
            tmac_ws_sendMessage(callbackfunction, userobject, data, methodname, timeout, waitforsocketcount);
        }, 4000);

        return;
    }

    var msg = {};
    msg.Data = data;
    msg.Command = methodname;
    msg.AuthCode = tmac_ws_authcode;

    tmac_ws_websock_method_call_id = tmac_ws_websock_method_call_id + 1;
    msg.CommandID = tmac_ws_websock_method_call_id;

    if (tmac_ws_websock_method_call_id > 10000)
        tmac_ws_websock_method_call_id = 0;

    var object = {};
    object.callbackfunction = callbackfunction;
    object.userobject = userobject;
    object.data = data;
    tmac_ws_websock_method_call_objects[msg.CommandID] = object;

    try {
        tmac_ws_websock.send(JSON.stringify(msg));
    } catch (e) {

        SetConnectivityStatus(2); //error
        if (methodname == "Logout") {
            window.global_LogoutCommandSend = false;
        }
    }
}

function on_tmac_ws_message(evt) {
    try {
        //evt.data;
        var obj = JSON.parse(evt.data);
        //obj.methodname
        //obj.data : josndata
        //obj.methodcallid : id (tmac_websock_method_call_id)

        if (obj.Command == "UnautherizedEvent") {
            //not autherized
            UnautherizedEvent();
        }
        else if (obj.Command == "TmacServerConnectionStatus") {
            //obj.Data
            if (obj.Data.EventName == "TmacServerConnectionFailed") {
                alert("Tmac connection failed. Please wait while we reconnect you");
            }
            if (obj.Data.EventName == "TmacServerConnectionSuccess") {
                //reset the session key
                if (obj.Data.Data != "" && obj.Data.Data != undefined)
                    global_AgentSessionKey = obj.Data.Data;

                //recover interactions
                try {
                    tmac_RecoverInteractions(null, null, global_AgentID,
                        JSON.stringify(tmac_events_interaction_recovery_data));

                } catch (e) {
                }

                alert("Tmac connection established. Please use hard phone to control ongoing calls");
            }
            if (obj.Data.EventName == "TmacServerConnectionAborted") {
                alert("Critical error. Please logout and login");
                window.close();
            }
        }

        var object = tmac_ws_websock_method_call_objects[obj.CommandID];
        tmac_ws_websock_method_call_objects[obj.CommandID] = null;

        //window[obj.Command + "Done"](obj.Data, object);

        if (object != null)
            window["tmac_" + obj.Command + "Done"](object.callbackfunction, object.userobject, object.data, obj.Data);
        else
            window["tmac_" + obj.Command + "Done"](null, null, null, obj.Data);

    } catch (e) {
        alert(e);
    }
}


var tmac_asmx_url_count = 0;

//callbackfunction, userobject, data, "AnswerCall"
//----------------------------------------------------------------------------------------------------------------
function tmac_command(callbackfunction, userobject, data, methodname) {
    var timeout = 60000;
    var dataValue;
    var httpType = "POST";
    var url;
    //    if (!(methodname.substring(0, 4) == "EMC_"))
    //        data.tmacServer = _tmacServer;
    //    
    if (!(methodname.substring(0, 10) == "EMM_Email_") && methodname != "GetAgentSessionsList" && methodname !== "GetAgentStatus")
        data.tmacServer = _tmacServer;
    if (window.tmacconnectprotocol == "ws") {
        tmac_ws_sendMessage(callbackfunction, userobject, data, methodname, timeout);
        return;
    }
    if (window.tmacconnectprotocol == "webapi") {
        url = window.tamc_webapi_url;
        var commandjson = {};
        commandjson.Data = data;
        commandjson.Command = methodname;
        commandjson.CommandID = "0";
        commandjson.AuthCode = tmac_authcode; dataValue = JSON.stringify(commandjson);
        httpType = "POST";

    } else {
        url = tmac_asmx_url_list[tmac_asmx_url_count] + methodname;
        dataValue = JSON.stringify(data);
    }

    $.ajax({
        type: httpType,
        url: url,
        data: dataValue,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            try {
                SetConnectivityStatus(1); //success
                global_connectedProxy = tmac_asmx_url_list[tmac_asmx_url_count];
            } catch (e) {

            }
            var resultData;
            if (window.tmacconnectprotocol == "webapi") {
                resultData = JSON.parse(msg).Data;
            } else {
                resultData = msg.d;
            }
            try {
                //callbackfunction, userobject, inputdata,
                window["tmac_" + methodname + "Done"](callbackfunction, userobject, data, resultData);
            } catch (e) {

            }
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
            try {
                if (methodname == "GetEvent") {
                    SetConnectivityStatus(2); //error
                    //window[methodname + "Done"](msg.d);
                    //window["tmac_" + methodname + "Done"](callbackfunction, userobject, data, null);
                }
            } catch (e) {

            }
            try {
                if (xhr.status == 0) {
                    if (tmac_asmx_url_count >= tmac_asmx_url_list.length - 1) {
                        tmac_asmx_url_count = 0;
                    }
                    else
                        tmac_asmx_url_count++;
                    //2016-12-09 call below bethod after an interval (continuous calling might cause browser hung)
                    setTimeout(function () {
                        tmac_command(callbackfunction, userobject, data, methodname);
                    }, 1000);
                    return;
                }
                window[command_error_callback](error, userobject);
            } catch (e) {

            }
            try {
                if (methodname == "GetEvent") {
                    SetConnectivityStatus(2); //error
                    window["tmac_" + methodname + "Done"](callbackfunction, userobject, data, null);
                }
            } catch (e) {

            }
        },
        timeout: timeout
    });
}

function tmac_GetUserDomainList(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetUserDomainList");
}

function tmac_GetUserDomainListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_AnswerCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "AnswerCall");
}

function tmac_AnswerCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_AssignWorkItemToAgent(callbackfunction, userobject, agentid, channel, workitemid) {
    var data = {};
    data.agentid = agentid;  //String
    data.channel = channel;  //String
    data.workitemid = workitemid;  //String
    tmac_command(callbackfunction, userobject, data, "AssignWorkItemToAgent");
}

function tmac_AssignWorkItemToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_AssignWorkItemToAgentByGlobalKey(callbackfunction, userobject, agentid, globalKey) {
    var data = {};
    data.agentid = agentid;  //String
    data.globalKey = globalKey;  //Int32
    tmac_command(callbackfunction, userobject, data, "AssignWorkItemToAgentByGlobalKey");
}

function tmac_AssignWorkItemToAgentByGlobalKeyDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ChangeStatus(callbackfunction, userobject, deviceid, statustype, statuscode) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.statustype = statustype;  //String
    data.statuscode = statuscode;  //String
    tmac_command(callbackfunction, userobject, data, "ChangeStatus");
}

function tmac_ChangeStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ChangeTmacServer(callbackfunction, userobject, url) {
    var data = {};
    data.url = url;  //String
    tmac_command(callbackfunction, userobject, data, "ChangeTmacServer");
}

function tmac_ChangeTmacServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Chat_BridgeSuccess(callbackfunction, userobject, deviceid, interactionid, eventData) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.eventData = eventData;  //String
    tmac_command(callbackfunction, userobject, data, "Chat_BridgeSuccess");
}

function tmac_Chat_BridgeSuccessDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Chat_TextReceived(callbackfunction, userobject, deviceid, interactionid, text) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.text = text;  //String
    tmac_command(callbackfunction, userobject, data, "Chat_TextReceived");
}

function tmac_Chat_TextReceivedDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Chat_TextSent(callbackfunction, userobject, deviceid, interactionid, text) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.text = text;  //String
    tmac_command(callbackfunction, userobject, data, "Chat_TextSent");
}

function tmac_Chat_TextSentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ClearEmailQueue(callbackfunction, userobject, queue) {
    var data = {};
    data.queue = queue;  //String
    tmac_command(callbackfunction, userobject, data, "ClearEmailQueue");
}

function tmac_ClearEmailQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ClearServerMemory(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "ClearServerMemory");
}

function tmac_ClearServerMemoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int64
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_CloseTab(callbackfunction, userobject, deviceid, interactionid, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "CloseTab");
}

function tmac_CloseTabDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_CloseTabAsync(callbackfunction, userobject, deviceid, interactionid, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "CloseTabAsync");
}

function tmac_CloseTabAsyncDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ConferenceCall(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceCall");
}

function tmac_ConferenceCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ConferenceCancel(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceCancel");
}

function tmac_ConferenceCancelDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ConferenceComplete(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceComplete");
}

function tmac_ConferenceCompleteDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_CopyAgentSessionsFromRemoteServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "CopyAgentSessionsFromRemoteServer");
}

function tmac_CopyAgentSessionsFromRemoteServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_CreateAgentReminder(callbackfunction, userobject, deviceid, agentid, reminddate, remindtime, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    data.reminddate = reminddate;  //String
    data.remindtime = remindtime;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "CreateAgentReminder");
}

function tmac_CreateAgentReminderDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Custom_InvokeFunction(callbackfunction, userobject, moduleName, className, funcitonName, parameters) {
    var data = {};
    data.moduleName = moduleName;  //String
    data.className = className;  //String
    data.funcitonName = funcitonName;  //String
    data.parameters = parameters;  //String[]
    tmac_command(callbackfunction, userobject, data, "Custom_InvokeFunction");
}

function tmac_Custom_InvokeFunctionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Custom_InvokeFunction_SecondServer(callbackfunction, userobject, moduleName, className, funcitonName, parameters) {
    var data = {};
    data.moduleName = moduleName;  //String
    data.className = className;  //String
    data.funcitonName = funcitonName;  //String
    data.parameters = parameters;  //String[]
    tmac_command(callbackfunction, userobject, data, "Custom_InvokeFunction_SecondServer");
}

function tmac_Custom_InvokeFunction_SecondServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_DisconnectCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "DisconnectCall");
}

function tmac_DisconnectCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_DisconnectCallByHandle(callbackfunction, userobject, deviceid, connectionhandle) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.connectionhandle = connectionhandle;  //String
    tmac_command(callbackfunction, userobject, data, "DisconnectCallByHandle");
}

function tmac_DisconnectCallByHandleDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_DisconnectStation(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "DisconnectStation");
}

function tmac_DisconnectStationDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}




/*
function tmac_Email_BulkCloseInQueue(callbackfunction, userobject, deviceid, routeIdList) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.routeIdList = routeIdList;  //String
    tmac_command(callbackfunction, userobject, data, "Email_BulkCloseInQueue");
}

function tmac_Email_BulkCloseInQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_BulkCloseInQueueWithReply(callbackfunction, userobject, deviceid, routeIdList, body) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.routeIdList = routeIdList;  //String
    data.body = body;  //String
    tmac_command(callbackfunction, userobject, data, "Email_BulkCloseInQueueWithReply");
}

function tmac_Email_BulkCloseInQueueWithReplyDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_BulkCloseInQueueWithTransfer(callbackfunction, userobject, deviceid, routeIdList, body, transfer, transferType, transferTo) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.routeIdList = routeIdList;  //String
    data.body = body;  //String
    data.transfer = transfer;  //Boolean
    data.transferType = transferType;  //String
    data.transferTo = transferTo;  //String
    tmac_command(callbackfunction, userobject, data, "Email_BulkCloseInQueueWithTransfer");
}

function tmac_Email_BulkCloseInQueueWithTransferDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_BulkDeleteDraft(callbackfunction, userobject, deviceid, emailList) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.emailList = emailList;  //String
    tmac_command(callbackfunction, userobject, data, "Email_BulkDeleteDraft");
}

function tmac_Email_BulkDeleteDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_ChangeState(callbackfunction, userobject, deviceid, interctionid, status) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interctionid = interctionid;  //String
    data.status = status;  //String
    tmac_command(callbackfunction, userobject, data, "Email_ChangeState");
}

function tmac_Email_ChangeStateDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_CheckerApprove(callbackfunction, userobject, deviceid, interactionid, outemailsessionid, insessionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.outemailsessionid = outemailsessionid;  //String
    data.insessionid = insessionid;  //String
    tmac_command(callbackfunction, userobject, data, "Email_CheckerApprove");
}

function tmac_Email_CheckerApproveDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_CheckerReject(callbackfunction, userobject, deviceid, interactionid, outemailsessionid, insessionid, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.outemailsessionid = outemailsessionid;  //String
    data.insessionid = insessionid;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "Email_CheckerReject");
}

function tmac_Email_CheckerRejectDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_ClearConversations(callbackfunction, userobject, cnt) {
    var data = {};
    data.cnt = cnt;  //Int32
    tmac_command(callbackfunction, userobject, data, "Email_ClearConversations");
}

function tmac_Email_ClearConversationsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_Clone(callbackfunction, userobject, fromagent, sesionid, makerskill, toagent) {
    var data = {};
    data.fromagent = fromagent;  //String
    data.sesionid = sesionid;  //String
    data.makerskill = makerskill;  //String
    data.toagent = toagent;  //String
    tmac_command(callbackfunction, userobject, data, "Email_Clone");
}

function tmac_Email_CloneDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_ComposeNewEmail(callbackfunction, userobject, deviceid, agentId, mailbox) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentId = agentId;  //String
    data.mailbox = mailbox;  //String
    tmac_command(callbackfunction, userobject, data, "Email_ComposeNewEmail");
}

function tmac_Email_ComposeNewEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_DeleteDraft(callbackfunction, userobject, deviceid, interactionid, emailsessionid, emailOutSessionid, tolist, cclist, bcclist, subject, body, typeOfResponse) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.emailsessionid = emailsessionid;  //String
    data.emailOutSessionid = emailOutSessionid;  //String
    data.tolist = tolist;  //String
    data.cclist = cclist;  //String
    data.bcclist = bcclist;  //String
    data.subject = subject;  //String
    data.body = body;  //String
    data.typeOfResponse = typeOfResponse;  //String
    tmac_command(callbackfunction, userobject, data, "Email_DeleteDraft");
}

function tmac_Email_DeleteDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetFrequentEmailAddressList(callbackfunction, userobject, deviceid) {
    var data = {};
    data.deviceid = deviceid;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetFrequentEmailAddressList");
}

function tmac_Email_GetFrequentEmailAddressListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetHistoryForEmailId(callbackfunction, userobject, deviceid, emailId, source) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.emailId = emailId;  //String
    data.source = source;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetHistoryForEmailId");
}

function tmac_Email_GetHistoryForEmailIdDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetInboxEmail(callbackfunction, userobject, deviceid, sessionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionid = sessionid;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetInboxEmail");
}

function tmac_Email_GetInboxEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Email_InboxModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetInboxItems(callbackfunction, userobject, deviceid, email, sentDateFrom, sentDateTo, queue, subject, content, hasAttachments, assignedTo, replied, closed, sesisonid, global) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.email = email;  //String
    data.sentDateFrom = sentDateFrom;  //String
    data.sentDateTo = sentDateTo;  //String
    data.queue = queue;  //String
    data.subject = subject;  //String
    data.content = content;  //String
    data.hasAttachments = hasAttachments;  //Boolean
    data.assignedTo = assignedTo;  //String
    data.replied = replied;  //Boolean
    data.closed = closed;  //Boolean
    data.sesisonid = sesisonid;  //String
    data.global = global;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetInboxItems");
}

function tmac_Email_GetInboxItemsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetMailboxes(callbackfunction, userobject, agentId) {
    var data = {};
    data.agentId = agentId;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetMailboxes");
}

function tmac_Email_GetMailboxesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetmailTemplateAttachments(callbackfunction, userobject, template) {
    var data = {};
    data.template = template;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetmailTemplateAttachments");
}

function tmac_Email_GetmailTemplateAttachmentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetmailTemplateDepartments(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "Email_GetmailTemplateDepartments");
}

function tmac_Email_GetmailTemplateDepartmentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetmailTemplateGroups(callbackfunction, userobject, department) {
    var data = {};
    data.department = department;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetmailTemplateGroups");
}

function tmac_Email_GetmailTemplateGroupsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetmailTemplates(callbackfunction, userobject, group, type) {
    var data = {};
    data.group = group;  //String
    data.type = type;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetmailTemplates");
}

function tmac_Email_GetmailTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetMakerDraft(callbackfunction, userobject, deviceid, email, savedDateFrom, savedDateTo, agent, subject, content, insessionid, global) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.email = email;  //String
    data.savedDateFrom = savedDateFrom;  //String
    data.savedDateTo = savedDateTo;  //String
    data.agent = agent;  //String
    data.subject = subject;  //String
    data.content = content;  //String
    data.insessionid = insessionid;  //String
    data.global = global;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetMakerDraft");
}

function tmac_Email_GetMakerDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetMakerQueue(callbackfunction, userobject, deviceid, email, sentDateFrom, sentDateTo, queue, subject, content, global) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.email = email;  //String
    data.sentDateFrom = sentDateFrom;  //String
    data.sentDateTo = sentDateTo;  //String
    data.queue = queue;  //String
    data.subject = subject;  //String
    data.content = content;  //String
    data.global = global;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetMakerQueue");
}

function tmac_Email_GetMakerQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetOutboxEmail(callbackfunction, userobject, deviceid, sessionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionid = sessionid;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetOutboxEmail");
}

function tmac_Email_GetOutboxEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Email_OutboxModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_GetSentItems(callbackfunction, userobject, deviceid, email, sentDateFrom, sentDateTo, agent, subject, content, insessionid, global) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.email = email;  //String
    data.sentDateFrom = sentDateFrom;  //String
    data.sentDateTo = sentDateTo;  //String
    data.agent = agent;  //String
    data.subject = subject;  //String
    data.content = content;  //String
    data.insessionid = insessionid;  //String
    data.global = global;  //String
    tmac_command(callbackfunction, userobject, data, "Email_GetSentItems");
}

function tmac_Email_GetSentItemsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_MaskInboxEmail(callbackfunction, userobject, deviceid, sessionid, source, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionid = sessionid;  //String
    data.source = source;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "Email_MaskInboxEmail");
}

function tmac_Email_MaskInboxEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_Merge(callbackfunction, userobject, agentid, sessionlist) {
    var data = {};
    data.agentid = agentid;  //String
    data.sessionlist = sessionlist;  //String
    tmac_command(callbackfunction, userobject, data, "Email_Merge");
}

function tmac_Email_MergeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_PullFromMakerDraft(callbackfunction, userobject, deviceid, sessionid, insessionid, conversationid, routeId) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionid = sessionid;  //String
    data.insessionid = insessionid;  //String
    data.conversationid = conversationid;  //String
    data.routeId = routeId;  //String
    tmac_command(callbackfunction, userobject, data, "Email_PullFromMakerDraft");
}

function tmac_Email_PullFromMakerDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_PullFromMakerQueue(callbackfunction, userobject, deviceid, sessionid, conversationid, routeId) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionid = sessionid;  //String
    data.conversationid = conversationid;  //String
    data.routeId = routeId;  //String
    tmac_command(callbackfunction, userobject, data, "Email_PullFromMakerQueue");
}

function tmac_Email_PullFromMakerQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_SaveDraft(callbackfunction, userobject, deviceid, interactionid, outboxSessionId, inboxSessionId, conversationid, tolist, cclist, bcclist, subject, body, typeOfResponse) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.outboxSessionId = outboxSessionId;  //String
    data.inboxSessionId = inboxSessionId;  //String
    data.conversationid = conversationid;  //String
    data.tolist = tolist;  //String
    data.cclist = cclist;  //String
    data.bcclist = bcclist;  //String
    data.subject = subject;  //String
    data.body = body;  //String
    data.typeOfResponse = typeOfResponse;  //String
    tmac_command(callbackfunction, userobject, data, "Email_SaveDraft");
}

function tmac_Email_SaveDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_SaveEmailAsEml(callbackfunction, userobject, agentid, sesisonid, direction) {
    var data = {};
    data.agentid = agentid;  //String
    data.sesisonid = sesisonid;  //String
    data.direction = direction;  //String
    tmac_command(callbackfunction, userobject, data, "Email_SaveEmailAsEml");
}

function tmac_Email_SaveEmailAsEmlDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_Send(callbackfunction, userobject, deviceid, interctionid, outboxSessionid, inboxSessionid, tolist, cclist, bcclist, subject, body, typeOfResponse, attachmentList) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interctionid = interctionid;  //String
    data.outboxSessionid = outboxSessionid;  //String
    data.inboxSessionid = inboxSessionid;  //String
    data.tolist = tolist;  //String
    data.cclist = cclist;  //String
    data.bcclist = bcclist;  //String
    data.subject = subject;  //String
    data.body = body;  //String
    data.typeOfResponse = typeOfResponse;  //String
    data.attachmentList = attachmentList;  //String
    tmac_command(callbackfunction, userobject, data, "Email_Send");
}

function tmac_Email_SendDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_TransferToAgent(callbackfunction, userobject, deviceid, interactionid, sessionid, toAgentid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.sessionid = sessionid;  //String
    data.toAgentid = toAgentid;  //String
    tmac_command(callbackfunction, userobject, data, "Email_TransferToAgent");
}

function tmac_Email_TransferToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Email_TransferToSkill(callbackfunction, userobject, deviceid, interactionid, sessionid, skill) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.sessionid = sessionid;  //String
    data.skill = skill;  //String
    tmac_command(callbackfunction, userobject, data, "Email_TransferToSkill");
}

function tmac_Email_TransferToSkillDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EndTextChat(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "EndTextChat");
}

function tmac_EndTextChatDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}
*/

function tmac_Equals(callbackfunction, userobject, obj) {
    var data = {};
    data.obj = obj;  //Object
    tmac_command(callbackfunction, userobject, data, "Equals");
}

function tmac_EqualsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Boolean
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_External_SendEmail(callbackfunction, userobject, mailbox, subject, body, mailTo, mailCc, mailBcc, mailFrom, outEmailSessionId, attachmentFileList) {
    var data = {};
    data.mailbox = mailbox;  //String
    data.subject = subject;  //String
    data.body = body;  //String
    data.mailTo = mailTo;  //String
    data.mailCc = mailCc;  //String
    data.mailBcc = mailBcc;  //String
    data.mailFrom = mailFrom;  //String
    data.outEmailSessionId = outEmailSessionId;  //String
    data.attachmentFileList = attachmentFileList;  //String
    tmac_command(callbackfunction, userobject, data, "External_SendEmail");
}

function tmac_External_SendEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Facebook_Feed_GetAssignedAgent(callbackfunction, userobject, feedid, feedJson, autoRoute) {
    var data = {};
    data.feedid = feedid;  //String
    data.feedJson = feedJson;  //String
    data.autoRoute = autoRoute;  //Boolean
    tmac_command(callbackfunction, userobject, data, "Facebook_Feed_GetAssignedAgent");
}

function tmac_Facebook_Feed_GetAssignedAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Facebook_Feed_RouteToAgent(callbackfunction, userobject, feedid, feedJson, agentid) {
    var data = {};
    data.feedid = feedid;  //String
    data.feedJson = feedJson;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "Facebook_Feed_RouteToAgent");
}

function tmac_Facebook_Feed_RouteToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Facebook_PM_GetAssignedAgent(callbackfunction, userobject, pmId, pmJson, autoRoute) {
    var data = {};
    data.pmId = pmId;  //String
    data.pmJson = pmJson;  //String
    data.autoRoute = autoRoute;  //Boolean
    tmac_command(callbackfunction, userobject, data, "Facebook_PM_GetAssignedAgent");
}

function tmac_Facebook_PM_GetAssignedAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Facebook_PM_RouteToAgent(callbackfunction, userobject, feedid, pmJson, agentid) {
    var data = {};
    data.feedid = feedid;  //String
    data.pmJson = pmJson;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "Facebook_PM_RouteToAgent");
}

function tmac_Facebook_PM_RouteToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_FB_CommentOnPost(callbackfunction, userobject, deviceid, interactionid, postid, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.postid = postid;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "FB_CommentOnPost");
}

function tmac_FB_CommentOnPostDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_FB_ReplyToComment(callbackfunction, userobject, deviceid, interactionid, commentid, postid, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.commentid = commentid;  //String
    data.postid = postid;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "FB_ReplyToComment");
}

function tmac_FB_ReplyToCommentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_FB_ReplyToConversation(callbackfunction, userobject, deviceid, interactionid, postid, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.postid = postid;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "FB_ReplyToConversation");
}

function tmac_FB_ReplyToConversationDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetAgentList(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetAgentList");
}

function tmac_GetAgentListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetAgentListStaffed(callbackfunction, userobject, sync) {
    var data = {};
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "GetAgentListStaffedAll");
}

function tmac_GetAgentListStaffedAllDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1 {AgentModel:  TmacServer}
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetAgentReminders(callbackfunction, userobject, deviceid, agentid, status, reminddatetimeStart, reminddatetimeEnd, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    data.status = status;  //String
    data.reminddatetimeStart = reminddatetimeStart;  //String
    data.reminddatetimeEnd = reminddatetimeEnd;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "GetAgentReminders");
}

function tmac_GetAgentRemindersDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetAgentStatus(callbackfunction, userobject, deviceid, agentid, destTmacServerName) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
	if(destTmacServerName) data.tmacServer = destTmacServerName;
    tmac_command(callbackfunction, userobject, data, "GetAgentStatus");
}

function tmac_GetAgentStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetAllMethodNames(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetAllMethodNames");
}

function tmac_GetAllMethodNamesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetAutoSuggestResponseTemplates(callbackfunction, userobject, deviceid, interactionid, message, intent, channel) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.message = message;  //String
    data.intent = intent;  //String
    data.channel = channel;  //String
    tmac_command(callbackfunction, userobject, data, "GetAutoSuggestResponseTemplates");
}

function tmac_GetAutoSuggestResponseTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = TextResponseTemplate
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetAutoSuggestTemplateIntents(callbackfunction, userobject, channel) {
    var data = {};
    data.channel = channel;  //String
    tmac_command(callbackfunction, userobject, data, "GetAutoSuggestTemplateIntents");
}

function tmac_GetAutoSuggestTemplateIntentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetEmailQueue(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetEmailQueue");
}

function tmac_GetEmailQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Dictionary`2
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetEmailServerStatus(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetEmailServerStatus");
}

function tmac_GetEmailServerStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetEmailSkills(callbackfunction, userobject, type) {
    var data = {};
    data.type = type;  //String
    tmac_command(callbackfunction, userobject, data, "GetEmailSkills");
}

function tmac_GetEmailSkillsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetEvent(callbackfunction, userobject, deviceid, sessionkey, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionkey = sessionkey;  //String
    data.sync = sync;  //Boolean
    data.agentid = global_AgentID;  //String
    data.lanid = global_LanID;  //String
    tmac_command(callbackfunction, userobject, data, "GetEvent");
}

function tmac_GetEventDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window["GetEventDone"](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetEventWithPassword(callbackfunction, userobject, deviceid, sessionkey, sync, password) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionkey = sessionkey;  //String
    data.sync = sync;  //Boolean
    data.agentid = global_AgentID;  //String
    data.lanid = global_LanID;  //String
    data.password = password;
    tmac_command(callbackfunction, userobject, data, "GetEventwithPassword");
}

function tmac_GetEventwithPasswordDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window["GetEventDone"](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetEventAsync(callbackfunction, userobject, deviceid, sessionkey, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sessionkey = sessionkey;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "GetEventAsync");
}

function tmac_GetEventAsyncDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetFavouriteSkills(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetFavouriteSkills");
}

function tmac_GetFavouriteSkillsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetHashCode(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetHashCode");
}

function tmac_GetHashCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetJSSdk(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetJSSdk");
}

function tmac_GetJSSdkDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetLoggedInAgentList(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetLoggedInAgentList");
}

function tmac_GetLoggedInAgentListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetLoggedInAgentList_SecondServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetLoggedInAgentList_SecondServer");
}

function tmac_GetLoggedInAgentList_SecondServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetMetaData(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetMetaData");
}

function tmac_GetMetaDataDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetQueueStatus(callbackfunction, userobject, deviceid, skillid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.skillid = skillid;  //String
    tmac_command(callbackfunction, userobject, data, "GetQueueStatus");
}

function tmac_GetQueueStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetQueueStatusForSkill(callbackfunction, userobject, vdn) {
    var data = {};
    data.vdn = vdn;  //String
    tmac_command(callbackfunction, userobject, data, "GetQueueStatusForSkill");
}

function tmac_GetQueueStatusForSkillDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = WallboardSkillModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetSpeedDialNumber(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetSpeedDialNumber");
}

function tmac_GetSpeedDialNumberDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetSpeedDialNumberForAgent(callbackfunction, userobject, agentId) {
    var data = {};
    data.agentId = agentId;  //String
    tmac_command(callbackfunction, userobject, data, "GetSpeedDialNumberForAgent");
}

function tmac_GetSpeedDialNumberForAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



function tmac_GetTMACServerProfile(callbackfunction, userobject, lanId, stationid, agentid) {
    var data = {};
    data.lanId = lanId;  //String
    data.stationid = stationid;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "GetTMACServerProfile");
}

function tmac_GetTMACServerProfileDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetTmacWallboardSkill(callbackfunction, userobject, skill) {
    var data = {};
    data.skill = skill;  //String
    tmac_command(callbackfunction, userobject, data, "GetTmacWallboardSkill");
}

function tmac_GetTmacWallboardSkillDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = WallboardSkillModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetTmacWallboardSkills(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetTmacWallboardSkills");
}

function tmac_GetTmacWallboardSkillsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetType(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetType");
}

function tmac_GetTypeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Type
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_HoldCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "HoldCall");
}

function tmac_HoldCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoadAUXCodes(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "LoadAUXCodes");
}

function tmac_LoadAUXCodesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoadAUXCodesForAgent(callbackfunction, userobject) {
    var data = {};
    data.agentid = global_AgentID;
    tmac_command(callbackfunction, userobject, data, "LoadAUXCodesForAgent");
}

function tmac_LoadAUXCodesForAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoadCallWorkCodes(callbackfunction, userobject, deviceid, teamid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.teamid = teamid;  //String
    tmac_command(callbackfunction, userobject, data, "LoadCallWorkCodes");
}

function tmac_LoadCallWorkCodesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoadIntents(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "LoadIntents");
}

function tmac_LoadIntentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoadInteractionHistoryOnDemand(callbackfunction, userobject, deviceid, interactionid, cif, nric, phonenumber) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.cif = cif;  //String
    data.nric = nric;  //String
    data.phonenumber = phonenumber;  //String
    tmac_command(callbackfunction, userobject, data, "LoadInteractionHistoryOnDemand");
}

function tmac_LoadInteractionHistoryOnDemandDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoadMoreHistory(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "LoadMoreHistory");
}

function tmac_LoadMoreHistoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Login(callbackfunction, userobject, lanId, stationid, agentloginid, sync, syncSessionKey, forceReload) {
    var data = {};
    data.lanId = lanId;  //String
    data.stationid = stationid;  //String
    data.agentloginid = agentloginid;  //String
    data.sync = sync;  //Boolean
    data.syncSessionKey = syncSessionKey;  //String
    data.forceReload = forceReload;  //Boolean
    data.jsonData = "";  //String
    tmac_command(callbackfunction, userobject, data, "Login");
}

function tmac_LoginDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        if (resultdata.ResultCode > 0) {
            _tmacServer = resultdata.TmacServerName;
        }
    } catch (e) {

    }

    try {
        //_tmacServer

        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoginWithPassword(callbackfunction, userobject, lanId, stationid, agentloginid, sync, syncSessionKey, forceReload, password) {
    var data = {};
    data.lanId = lanId;  //String
    data.stationid = stationid;  //String
    data.agentloginid = agentloginid;  //String
    data.sync = sync;  //Boolean
    data.syncSessionKey = syncSessionKey;  //String
    data.forceReload = forceReload;  //Boolean
    data.jsonData = "";  //String
    data.password = password; //String
    tmac_command(callbackfunction, userobject, data, "LoginWithPassword");
}

function tmac_LoginWithPasswordDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        if (resultdata.ResultCode > 0) {
            _tmacServer = resultdata.TmacServerName;
        }
    } catch (e) {

    }

    try {
        //_tmacServer

        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LoginAsync(callbackfunction, userobject, lanId, stationid, agentloginid, sync, syncSessionKey, forceReload) {
    var data = {};
    data.lanId = lanId;  //String
    data.stationid = stationid;  //String
    data.agentloginid = agentloginid;  //String
    data.sync = sync;  //Boolean
    data.syncSessionKey = syncSessionKey;  //String
    data.forceReload = forceReload;  //Boolean
    tmac_command(callbackfunction, userobject, data, "LoginAsync");
}

function tmac_LoginAsyncDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Logout(callbackfunction, userobject, deviceid, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "Logout");
}

function tmac_LogoutDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_LogoutAsync(callbackfunction, userobject, deviceid, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "LogoutAsync");
}

function tmac_LogoutAsyncDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_MakeCall(callbackfunction, userobject, deviceid, number, existingInteractionId) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //String
    data.existingInteractionId = existingInteractionId;  //String
    tmac_command(callbackfunction, userobject, data, "MakeCall");
}

function tmac_MakeCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_Manage_RemoveAgentSession(callbackfunction, userobject, deviceid, agentid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "Manage_RemoveAgentSession");
}

function tmac_Manage_RemoveAgentSessionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_OpenIntent(callbackfunction, userobject, deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.intent = intent;  //String
    tmac_command(callbackfunction, userobject, data, "OpenIntent");
}

function tmac_OpenIntentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



function tmac_ReloadData(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "ReloadData");
}

function tmac_ReloadDataDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ReLoadEmailTemplates(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "ReLoadEmailTemplates");
}

function tmac_ReLoadEmailTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ReLoadInteractionHistory(callbackfunction, userobject, deviceid, interactionid, nric, phoneNumber, email) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.nric = nric;  //String
    data.phoneNumber = phoneNumber;  //String
    data.email = email;  //String
    tmac_command(callbackfunction, userobject, data, "ReLoadInteractionHistory");
}

function tmac_ReLoadInteractionHistoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_ReloadTab(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "ReloadTab");
}

function tmac_ReloadTabDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_RemoveAgentSession(callbackfunction, userobject, agent, device) {
    var data = {};
    data.agent = agent;  //String
    data.device = device;  //String
    tmac_command(callbackfunction, userobject, data, "RemoveAgentSession");
}

function tmac_RemoveAgentSessionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_RemoveCallWorkCode(callbackfunction, userobject, deviceid, interactionid, code) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.code = code;  //String
    tmac_command(callbackfunction, userobject, data, "RemoveCallWorkCode");
}

function tmac_RemoveCallWorkCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_RestartMainVoiceProcess(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "RestartMainVoiceProcess");
}

function tmac_RestartMainVoiceProcessDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SelectTab(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "SelectTab");
}

function tmac_SelectTabDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendAgentNotification(callbackfunction, userobject, deviceid, message, pop) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.message = message;  //String
    data.pop = pop;  //Boolean
    tmac_command(callbackfunction, userobject, data, "SendAgentNotification");
}

function tmac_SendAgentNotificationDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendCommandToVoiceProcess(callbackfunction, userobject, deviceid, command, jsonData) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.command = command;  //String
    data.jsonData = jsonData;  //String
    tmac_command(callbackfunction, userobject, data, "SendCommandToVoiceProcess");
}

function tmac_SendCommandToVoiceProcessDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}







function tmac_SetCallWorkCode(callbackfunction, userobject, deviceid, interactionid, code) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.code = code;  //String
    tmac_command(callbackfunction, userobject, data, "SetCallWorkCode");
}

function tmac_SetCallWorkCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SetMaxEmailConversationsInMemory(callbackfunction, userobject, maxCount) {
    var data = {};
    data.maxCount = maxCount;  //Int32
    tmac_command(callbackfunction, userobject, data, "SetMaxEmailConversationsInMemory");
}

function tmac_SetMaxEmailConversationsInMemoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SMS_Compose(callbackfunction, userobject, deviceid, number, fromnumber, sourceinteractionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //String
    data.fromnumber = fromnumber;  //String
    data.sourceinteractionid = sourceinteractionid;  //String
    tmac_command(callbackfunction, userobject, data, "SMS_Compose");
}

function tmac_SMS_ComposeDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SMS_GetAssignedAgent(callbackfunction, userobject, sessionid, from, to, message, autoRoute) {
    var data = {};
    data.sessionid = sessionid;  //String
    data.from = from;  //String
    data.to = to;  //String
    data.message = message;  //String
    data.autoRoute = autoRoute;  //Boolean
    tmac_command(callbackfunction, userobject, data, "SMS_GetAssignedAgent");
}

function tmac_SMS_GetAssignedAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SMS_RouteToAgent(callbackfunction, userobject, sessionid, from, to, message, agentid) {
    var data = {};
    data.sessionid = sessionid;  //String
    data.from = from;  //String
    data.to = to;  //String
    data.message = message;  //String
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "SMS_RouteToAgent");
}

function tmac_SMS_RouteToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SMS_SendMessage(callbackfunction, userobject, deviceid, interactionid, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "SMS_SendMessage");
}

function tmac_SMS_SendMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_StartEmailServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "StartEmailServer");
}

function tmac_StartEmailServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_StopEmailServer(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "StopEmailServer");
}

function tmac_StopEmailServerDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_test(callbackfunction, userobject, deviceid, number, sync) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //Int32
    data.sync = sync;  //Boolean
    tmac_command(callbackfunction, userobject, data, "test");
}

function tmac_testDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}







function tmac_ToString(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "ToString");
}

function tmac_ToStringDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = String
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TransferCall(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "TransferCall");
}

function tmac_TransferCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TransferCancel(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "TransferCancel");
}

function tmac_TransferCancelDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_TransferComplete(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "TransferComplete");
}

function tmac_TransferCompleteDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_TransferToIVR(callbackfunction, userobject, deviceid, interactionid, type, languageid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.type = type;  //String
    data.languageid = languageid;  //String
    tmac_command(callbackfunction, userobject, data, "TransferToIVR");
}

function tmac_TransferToIVRDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_UnHoldCall(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    tmac_command(callbackfunction, userobject, data, "UnHoldCall");
}

function tmac_UnHoldCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_UpdateAgentReminder(callbackfunction, userobject, deviceid, agentid, id, status, message) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.agentid = agentid;  //String
    data.id = id;  //String
    data.status = status;  //String
    data.message = message;  //String
    tmac_command(callbackfunction, userobject, data, "UpdateAgentReminder");
}

function tmac_UpdateAgentReminderDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_UpdateIntent(callbackfunction, userobject, deviceid, interactionid, intent) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.intent = intent;  //String
    tmac_command(callbackfunction, userobject, data, "UpdateIntent");
}

function tmac_UpdateIntentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_UpdateInteractionHistory(callbackfunction, userobject, channel, session, nric, email, chat, clid, cif, text, direction, agent, grpId, subtype, updateServiceHisoty, serviceHisoryDescription, addIntentIfRequired, forceAddIntent, intentName, loadCCL) {
    var data = {};
    data.channel = channel;  //String
    data.session = session;  //String
    data.nric = nric;  //String
    data.email = email;  //String
    data.chat = chat;  //String
    data.clid = clid;  //String
    data.cif = cif;  //String
    data.text = text;  //String
    data.direction = direction;  //String
    data.agent = agent;  //String
    data.grpId = grpId;  //String
    data.subtype = subtype;  //String
    data.updateServiceHisoty = updateServiceHisoty;  //Boolean
    data.serviceHisoryDescription = serviceHisoryDescription;  //String
    data.addIntentIfRequired = addIntentIfRequired;  //Boolean
    data.forceAddIntent = forceAddIntent;  //Boolean
    data.intentName = intentName;  //String
    data.loadCCL = loadCCL;  //Boolean
    tmac_command(callbackfunction, userobject, data, "UpdateInteractionHistory");
}

function tmac_UpdateInteractionHistoryDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Int32
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_WorkQueueUpdated(callbackfunction, userobject, queueServerID, channel, skill) {
    var data = {};
    data.queueServerID = queueServerID;  //String
    data.channel = channel;  //String
    data.skill = skill;  //String
    tmac_command(callbackfunction, userobject, data, "WorkQueueUpdated");
}

function tmac_WorkQueueUpdatedDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetTMACVersion(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetTMACVersion");
}

function tmac_GetTMACVersionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetClientConnectionData(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetClientConnectionData");
}

function tmac_GetClientConnectionDataDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_GetLanID(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetLanID");
}

function tmac_GetLanIDDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetCrmUrl(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "GetCrmUrl");
}

function tmac_GetCrmUrlDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        //window[callbackfunction](resultdata, userobject);

        if (resultdata != "") {
            window.cutomer_data_window_url = resultdata;
        }
    }
    catch (e) {
    }
}

function tmac_SetCrmUrl(callbackfunction, userobject, url) {
    var data = {};
    data.url = url;
    tmac_command(callbackfunction, userobject, data, "SetCrmUrl");
}

function tmac_SetCrmUrlDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Void
    try {
        //window[callbackfunction](resultdata, userobject);

        if (resultdata != "") {
            window.cutomer_data_window_url = resultdata;
            //alertMessageDialog("CRM URL set to:" + resultdata, "success");
            return;
        }
    }
    catch (e) {
    }

    //alertMessageDialog("CRM URL set failed.", "error");
}





function tmac_TransferBlind(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "TransferBlind");
}

function tmac_TransferBlindDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_ConferenceBlind(callbackfunction, userobject, deviceid, interactionid, number, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.number = number;  //String
    data.comment = comment;  //String
    tmac_command(callbackfunction, userobject, data, "ConferenceBlind");
}

function tmac_ConferenceBlindDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_ChangeNumber(callbackfunction, userobject, deviceid, interactionid, newNumber) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.newNumber = newNumber;  //String
    tmac_command(callbackfunction, userobject, data, "SmsSurvey_ChangeNumber");
}

function tmac_SmsSurvey_ChangeNumberDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}




function tmac_SmsSurvey_SupressSurvey(callbackfunction, userobject, deviceid, interactionid, supress, comment) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.supress = supress;  //bool
    data.comment = comment;  //bool
    tmac_command(callbackfunction, userobject, data, "SmsSurvey_SupressSurvey");
}

function tmac_SmsSurvey_SupressSurveyDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



function tmac_SmsSurvey_SendManualSurvey(callbackfunction, userobject, deviceid, interactionid, templateID) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String
    data.templateID = templateID;  //int
    tmac_command(callbackfunction, userobject, data, "SmsSurvey_SendManualSurvey");
}

function tmac_SmsSurvey_SendManualSurveyDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_SetSMSSurveySubscriptionStatus(callbackfunction, userobject, deviceid, mobileNo, stat, reason) {
    var data = {};
    data.deviceid = deviceid; //String
    //data.interactionid = interactionid; //String
    data.mobileNo = mobileNo; //String
    data.stat = stat; //Bool
    data.reason = reason; //String

    tmac_command(callbackfunction, userobject, data, "SmsSurvey_SetSMSSurveySubscriptionStatus");
}

function tmac_SmsSurvey_SetSMSSurveySubscriptionStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = CommandResultEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SmsSurvey_GetSMSSurveySubscriptionStatus(callbackfunction, userobject, mobileNo) {
    var data = {};
    data.mobileNo = mobileNo; //String

    tmac_command(callbackfunction, userobject, data, "SmsSurvey_GetSMSSurveySubscriptionStatus");
}

function tmac_SmsSurvey_GetSMSSurveySubscriptionStatusDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = bool
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



function tmac_SMS_GetSMSTemplateGroups(callbackfunction, userobject, deptId) {
    var data = {};
    data.deptId = deptId; //String

    tmac_command(callbackfunction, userobject, data, "SMS_GetSMSTemplateGroups");
}

function tmac_SMS_GetSMSTemplateGroupsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<SMSTemplateGroup> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SMS_GetSMSTemplateDepartments(callbackfunction, userobject) {
    var data = {};

    tmac_command(callbackfunction, userobject, data, "SMS_GetSMSTemplateDepartments");
}

function tmac_SMS_GetSMSTemplateDepartmentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<SMSTemplateGroup> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SMS_GetSMSTemplates(callbackfunction, userobject, groupID) {
    var data = {};
    data.groupID = groupID;//string

    tmac_command(callbackfunction, userobject, data, "SMS_GetSMSTemplates");
}

function tmac_SMS_GetSMSTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<SMSTemplate> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}




function tmac_Voice_SendMessage(callbackfunction, userobject, deviceid, interactionid, mobile, message) {
    var data = {};
    data.deviceid = deviceid; //string
    data.interactionid = interactionid; //string
    data.mobile = mobile; //string
    data.message = message; //string

    tmac_command(callbackfunction, userobject, data, "Voice_SendMessage");
}

function tmac_Voice_SendMessageDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_RecoverInteractions(callbackfunction, userobject, agentid, jsonData) {
    var data = {};
    data.agentid = agentid; //string
    data.jsonData = jsonData; //string

    tmac_command(callbackfunction, userobject, data, "RecoverInteractions");
}

function tmac_RecoverInteractionsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Voice_Conference_Mute(callbackfunction, userobject, deviceid, interactionid,
    muteStation, fromStation, mute) {

    var data = {};
    data.deviceid = deviceid; //string
    data.interactionid = interactionid; //string
    data.muteStation = muteStation; //string
    data.fromStation = fromStation; //string
    data.mute = mute; //bool


    tmac_command(callbackfunction, userobject, data, "Voice_Conference_Mute");
}

function tmac_Voice_Conference_MuteDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_Voice_Get_ConferenceParties(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid; //string
    data.interactionid = interactionid; //string

    tmac_command(callbackfunction, userobject, data, "Voice_Get_ConferenceParties");
}

function tmac_Voice_Get_ConferencePartiesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<string>
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {
    }
}


function tmac_SendCommandToAgent(callbackfunction, userobject, fromIntId, toAgentId, toTmacServer, toIntId, name, message) {
    let data = {};
    data.fromAgentId = global_AgentID;
    data.fromTmacServer = _tmacServer;
    data.fromInteractionID = fromIntId;
    data.toAgentId = toAgentId;
    data.toTmacServer = toTmacServer;
    data.toInteractionID = toIntId;
    data.name = name;
    data.message = message;
    tmac_command(callbackfunction, userobject, data, "SendCommandToAgent");
}

function tmac_SendCommandToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_SendIMToAgent(callbackfunction, userobject, agentid, message) {
    var data = {};

    data.agentid = global_AgentID;
    data.toagent = agentid;
    data.message = message; //string
    data.popup = false;
    tmac_command(callbackfunction, userobject, data, "SendIMToAgent");
}

function tmac_SendIMToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



function tmac_CreateDummyVoiceInteraction(callbackfunction, userobject) {
    var data = {};

    data.deviceid = global_DeviceID;

    tmac_command(callbackfunction, userobject, data, "CreateDummyVoiceInteraction");
}

function tmac_CreateDummyVoiceInteractionDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetAgentListForAgent(callbackfunction, userobject) {
    var data = {};
    data.agentid = global_AgentID;
    tmac_command(callbackfunction, userobject, data, "GetAgentListForAgent");
}

function tmac_GetAgentListForAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List`1
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



function tmac_Interaction_SaveComment(callbackfunction, userobject, interactionid, comment) {
    var data = {};

    data.deviceid = global_DeviceID;
    data.interactionid = interactionid;
    data.comment = comment; //string

    tmac_command(callbackfunction, userobject, data, "Interaction_SaveComment");
}

function tmac_Interaction_SaveCommentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



//GetAgentStatusFull
function tmac_GetAgentStatusFull(callbackfunction, userobject, agentid) {
    var data = {};
    data.agentid = agentid;  //String
    tmac_command(callbackfunction, userobject, data, "GetAgentStatusFull");
}

function tmac_GetAgentStatusFullDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = AgentModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


//added on 2017-07-06
function tmac_LogoutWithReason(callbackfunction, userobject, deviceid, reason) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.reason = reason;  //String

    tmac_command(callbackfunction, userobject, data, "LogoutWithReason");
}

function tmac_LogoutWithReasonDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

//added on 2017-07-06
function tmac_EndTextChatWithReason(callbackfunction, userobject, deviceid, interactionid, reason) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String    
    data.reason = reason;  //String

    tmac_command(callbackfunction, userobject, data, "EndTextChatWithReason");
}

function tmac_EndTextChatWithReasonDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

//added on 2017-07-06
function tmac_FreezeTextChatAutoResponse(callbackfunction, userobject, deviceid, interactionid) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.interactionid = interactionid;  //String    

    tmac_command(callbackfunction, userobject, data, "FreezeTextChatAutoResponse");
}

function tmac_FreezeTextChatAutoResponseDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

//added on 2017-07-21
function tmac_GetAgentSessionsList(callbackfunction, userobject, teamid, supervisorid, agentid, interactionid, tmacServer) {
    var data = {};
    data.teamId = teamid;  //String
    data.supervisorId = supervisorid;  //String
    data.agentid = agentid;  //String
    data.interactionid = interactionid;  //String
    data.tmacServer = tmacServer;  //String  

    tmac_command(callbackfunction, userobject, data, "GetAgentSessionsList");
}

function tmac_GetAgentSessionsListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_InitiateCall(callbackfunction, userobject, deviceid, number, existingInteractionId, source, sourceid, tmacServer) {
    var data = {};
    data.deviceid = deviceid;  //String
    data.number = number;  //String
    data.existingInteractionId = existingInteractionId;  //String
    data.source = source;  //String
    data.sourceid = sourceid;  //String
    data.tmacServer = tmacServer;  //String
    tmac_command(callbackfunction, userobject, data, "InitiateCall");
}

function tmac_InitiateCallDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = IUIEvent
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_AddEventToAgentSession(callbackfunction, userobject, agentid, ev, isPriority, agentTmacServer) {
    var data = {};
    data.agentid = agentid; //String
    data.ev = JSON.stringify(ev); //IUIEvent    
    data.isPriority = isPriority; //String    
    data.agentTmacServer = agentTmacServer; //String    


    tmac_command(callbackfunction, userobject, data, "AddEventToAgentSession");
}

function tmac_AddEventToAgentSessionDone(callbackfunction, userobject, inputdata, resultdata) {

    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_GetWorkItems(callbackfunction, userobject, channel, skills) {
    var data = {};
    data.channel = channel; //String
    data.skills = skills; //list    
    tmac_command(callbackfunction, userobject, data, "GetWorkItems");
}

function tmac_GetWorkItemsDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_PullQueueItem(callbackfunction, userobject, channel, itemid) {
    var data = {};
    data.deviceid = global_DeviceID; //String
    data.channel = channel; //String
    data.itemid = itemid; //list    
    tmac_command(callbackfunction, userobject, data, "PullQueueItem");
}

function tmac_PullQueueItemDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_StartTextChatFromAgent(callbackfunction, userobject, custId, agentId, salute, name, phone, email) {
    var data = {};
    data.custId = custId;
    data.agentid = agentId;
    data.salute = salute;
    data.name = name;
    data.phone = phone;
    data.email = email;
    tmac_command(callbackfunction, userobject, data, "StartTextChatFromAgent");
}

function tmac_StartTextChatFromAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_SaveVideoData(callbackfunction, userobject, sessionid, intid, agentid, base64) {
    try {
        var data = {};
        data.sessionid = sessionid; //String
        data.intid = intid; //String    
        data.agentid = agentid; //String    
        data.base64 = base64; //String    
        tmac_command(callbackfunction, userobject, data, "SaveVideoData");
    } catch (e) {

    }
}


function tmac_GetQueueTimeColorCode(callbackfunction, userobject) {
    var data = {};
    tmac_command(callbackfunction, userobject, data, "GetQueueTimeColorCode");
}

function tmac_GetQueueTimeColorCodeDone(callbackfunction, userobject, inputdata, resultdata) {
    window[callbackfunction](resultdata, userobject);
}


function tmac_SendGenericCTICommand(callbackfunction, command, userobject, jsondata) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.command = command;
    data.jsonData = JSON.stringify(jsondata);

    tmac_command(callbackfunction, userobject, data, "SendGenericCTICommand");
}

function tmac_SendGenericCTICommandDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_GetFaxLineNumbers(callbackfunction, userobject) {
    let data = {};
    tmac_command(callbackfunction, userobject, data, "GetFaxLineNumbers");
}

function tmac_GetFaxLineNumbersDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_GetFaxTemplateNames(callbackfunction, userobject) {
    let data = {};
    tmac_command(callbackfunction, userobject, data, "GetFaxTemplateNames");
}

function tmac_GetFaxTemplateNamesDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}


function tmac_SendFax(callbackfunction, userobject, interactionid, file, faxnumber, dnis, filename, type) {
    let data = {};
    data.deviceId = global_DeviceID;
    data.interactionId = interactionid;
    data.file = file;
    data.faxNumber = faxnumber;
    data.DNIS = dnis;
    data.fileName = filename;
    data.type = type;
    tmac_command(callbackfunction, userobject, data, "SendFax");
}

function tmac_SendFaxDone(callbackfunction, userobject, inputdata, resultdata) {
    try {
        window[callbackfunction](resultdata, userobject);
    } catch (e) {

    }
}