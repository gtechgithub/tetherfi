﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//SMS channel
//Author - Weerathungage Sumudu Saman
//Last updated date - 2016/09/07

var version_tmac_sms_sdk = "2.0.09.07";

var tmac_onSMSIncomingCallback;
var tmac_onSMSSentCallback;
var tmac_onSMSReceivedCallback;
var tmac_onSMSOutgoingCallback;

var tmac_sms_stationid;
var tmac_sms_agentid;
var tmac_sms_agentname;

function tmac_sms_initialize(stationid, agentid, agentname, incomingSmsCallback, outgoingSmsCallback,
    smsSentCallback,smsReceivedCallback) {
    tmac_sms_stationid = stationid;
    tmac_sms_agentid = agentid;
    tmac_sms_agentname = agentname;
    tmac_onSMSIncomingCallback = incomingSmsCallback;
    tmac_onSMSOutgoingCallback = outgoingSmsCallback;
    tmac_onSMSSentCallback = smsSentCallback;
    tmac_onSMSReceivedCallback = smsReceivedCallback;
}


function SMSIncomingEvent(event) {

    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    window[tmac_onSMSIncomingCallback](event);
}

function SMSSentEvent(event) {
    window[tmac_onSMSSentCallback](event);
}

function SMSReceivedEvent(event) {
    window[tmac_onSMSReceivedCallback](event);
}

function SMSOutgoingEvent(event) {

    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    window[tmac_onSMSOutgoingCallback](event);
}