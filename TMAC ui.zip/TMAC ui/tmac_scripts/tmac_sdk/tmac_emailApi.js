﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//Email channel
//Author - Weerathungage Sumudu Saman
//Last updated date - 2016/10/12

var version_tmac_email_sdk = "2.0.10.12";

var tmac_onIncomingEmailCallback;
var tmac_onOutgoingEmailCallback;

var tmac_email_stationid;
var tmac_email_agentid;
var tmac_email_agentname;

function tmac_email_initialize(stationid, agentid, agentname, incomingEmailCallback, outgoingEmailCallback) {
    tmac_email_stationid = stationid;
    tmac_email_agentid = agentid;
    tmac_email_agentname = agentname;
    tmac_onIncomingEmailCallback = incomingEmailCallback;
    tmac_onOutgoingEmailCallback = outgoingEmailCallback;
}


function IncomingEmailEvent(event) {

    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    window[tmac_onIncomingEmailCallback](
        event.InteractionID,
        event.SessionId,
        event.RouteId,
        event.From,
        event.To,
        event.Subject,
        event.EmailType,
        event.Skill,
        event.Intent,
        event.JsonData,
        event.RouteReason
    );

  
}

function OutgoingEmailEvent(event) {

    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    //email_compose_callback
    window[tmac_onOutgoingEmailCallback](
        event.InteractionID,
        event.InSessionId,
        event.OutSessionId,
        event.Mailbox
    );
}


function tmac_EMM_Email_Get_InboxEmail(callbackfunction, userobject, sessionid, agentid) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;  //String

    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetInboxEmail");
}
function tmac_EMM_Email_Get_InboxEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Email_InboxModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_EMM_Email_Send(callbackfunction, userobject, agentid, outboxSessionid, inboxSessionid, routeId,
    tolist, cclist, bcclist, subject, body, typeOfResponse,
    attachmentFileList
) {
    
    var data = {};
    data.tmacserver = _tmacServer;
    
    data.agentid = agentid;
    data.outboxSessionid = outboxSessionid;
    data.inboxSessionid = inboxSessionid;
    data.routeId = routeId;
    data.tolist = tolist;
    data.cclist = cclist;
    data.bcclist = bcclist;
    data.subject = subject;
    data.body = body;
    data.typeOfResponse = typeOfResponse;
    data.attachmentFileList = attachmentFileList;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_Send");
}

function tmac_EMM_Email_SendDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_SaveDraft(callbackfunction, userobject, agentid, outboxSessionId,
    inboxSessionId, routeId,
    tolist, cclist, bcclist, subject, body, typeOfResponse) {

    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.outboxSessionId = outboxSessionId;
    data.inboxSessionId = inboxSessionId;
    data.routeId = routeId;
    data.tolist = tolist;
    data.cclist = cclist;
    data.bcclist = bcclist;
    data.subject = subject;
    data.body = body;
    data.typeOfResponse = typeOfResponse;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_SaveDraft");

}

function tmac_EMM_Email_SaveDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = string
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_DeleteDraft(callbackfunction, userobject,agentid, emailsessionid,
    emailOutSessionid) {
    
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.emailsessionid = emailsessionid;
    data.emailOutSessionid = emailOutSessionid;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_DeleteDraft");
}

function tmac_EMM_Email_DeleteDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}




function tmac_EMM_Email_ChangeState(callbackfunction, userobject, agentid, inboxsessionid, routeid, status) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.inboxsessionid = inboxsessionid;
    data.routeid = routeid;
    data.status = status;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_ChangeState");
}

function tmac_EMM_Email_ChangeStateDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



function tmac_EMM_Email_PullFromMakerQueue(callbackfunction, userobject, agentid, sessionid, conversationid, routeId) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;
    data.conversationid = conversationid;
    data.routeId = routeId;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_PullFromMakerQueue");
}

function tmac_EMM_Email_PullFromMakerQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_PullFromMakerDraft(callbackfunction, userobject, 
    agentid, sessionid, insessionid,conversationid, routeid) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;
    data.insessionid = insessionid;
    data.conversationid = conversationid;
    data.routeid = routeid;


    tmac_command(callbackfunction, userobject, data, "EMM_Email_PullFromMakerDraft");
}

function tmac_EMM_Email_PullFromMakerDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_TransferToAgent(callbackfunction, userobject, agentid, sessionid, routeid, toAgentid) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;
    data.routeid = routeid;
    data.toAgentid = toAgentid;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_TransferToAgent");
}

function tmac_EMM_Email_TransferToAgentDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_TransferToSkill(callbackfunction, userobject, agentid, sessionid, routeid, skill) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;
    data.routeid = routeid;
    data.skill = skill;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_TransferToSkill");
}

function tmac_EMM_Email_TransferToSkillDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_GetmailTemplateDepartments(callbackfunction, userobject) {
    var data = {};
    data.tmacserver = _tmacServer;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetmailTemplateDepartments");
}

function tmac_EMM_Email_GetmailTemplateDepartmentsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<EmailTemplateGroup> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_GetmailTemplateGroups(callbackfunction, userobject, department) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.department = department;
    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetmailTemplateGroups");
}


function tmac_EMM_Email_GetmailTemplateGroupsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<EmailTemplateGroup> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_EMM_Email_GetmailTemplates(callbackfunction, userobject, group, type) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.group = group;
    data.type = type;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetmailTemplates");
}

function tmac_EMM_Email_GetmailTemplatesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<EmailTemplate>
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_SaveEmailAsEml(callbackfunction, userobject, agentid, sesisonid, direction) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sesisonid = sesisonid;
    data.direction = direction;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_SaveEmailAsEml");
}


function tmac_EMM_Email_SaveEmailAsEmlDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = string
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

//string mailbox, string agentId
function tmac_EMM_Email_ComposeNewEmail(callbackfunction, userobject, mailbox, agentId) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.mailbox = mailbox;
    data.agentId = agentId;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_ComposeNewEmail");
}



function tmac_EMM_Email_ComposeNewEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}



//agentid
function tmac_EMM_Email_GetMailboxes(callbackfunction, userobject, agentid) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetMailboxes");
}

function tmac_EMM_Email_GetMailboxesDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<string> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_GetFrequentEmailAddressList(callbackfunction, userobject, agentid) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetFrequentEmailAddressList");
}

function tmac_EMM_Email_GetFrequentEmailAddressListDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = List<string> 
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_PullFromSentItems(callbackfunction, userobject, agentid, sessionid, conversationid, mailbox) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;
    data.conversationid = conversationid;
    data.mailbox = mailbox;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_PullFromSentItems");
}

function tmac_EMM_Email_PullFromSentItemsDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}

function tmac_EMM_Email_MaskInboxEmail(callbackfunction, userobject, agentid, sessionid, source) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;
    data.source = source;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_MaskInboxEmail");
}

function tmac_EMM_Email_MaskInboxEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_GetInboxEmail(callbackfunction, userobject, sessionid, agentid)
{
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    
    data.sessionid = sessionid;
    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetInboxEmail");
}

function tmac_EMM_Email_GetInboxEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Email_InboxModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_GetOutboxEmail(callbackfunction, userobject, sessionid, agentid) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.sessionid = sessionid;
    tmac_command(callbackfunction, userobject, data, "EMM_Email_GetOutboxEmail");
}


function tmac_EMM_Email_GetOutboxEmailDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = Email_OutboxModel
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_BulkCloseInQueue(callbackfunction, userobject, agentid, routeIdList) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.routeIdList = routeIdList;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_BulkCloseInQueue");
}

function tmac_EMM_Email_BulkCloseInQueueDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_BulkDeleteDraft(callbackfunction, userobject, agentid, emailList) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.agentid = agentid;
    data.emailList = emailList;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_BulkDeleteDraft");
}

function tmac_EMM_Email_BulkDeleteDraftDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}


function tmac_EMM_Email_Clone(callbackfunction, userobject, fromagent, sesionid, makerskill, toagent) {
    var data = {};
    data.tmacserver = _tmacServer;
    data.fromagent = fromagent;
    data.sesionid = sesionid;
    data.makerskill = makerskill;
    data.toagent = toagent;

    tmac_command(callbackfunction, userobject, data, "EMM_Email_Clone");
}

function tmac_EMM_Email_CloneDone(callbackfunction, userobject, inputdata, resultdata) {
    //resultdata = int
    try {
        window[callbackfunction](resultdata, userobject);
    }
    catch (e) {
    }
}