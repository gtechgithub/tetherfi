﻿//Tetherfi Multimedia Agent Client
//JavaScript SDK
//Facebook Feeds and Private messages
//Author - Weerathungage Sumudu Saman
//Last updated date - 2016/09/07


var version_tmac_facebook_sdk = "2.0.09.07";

//FacebookCreatePostInteractionEvent

var tmac_onFacebookIncomingPostReceivedCallback; //FacebookCreatePostInteractionEvent
var tmac_onFacebookIncomingConversationReceivedCallback; //FacebookCreateConversationInteractionEvent
var tmac_onFacebookPostMessageReceivedCallback; //FacebookPostMessageEvent
var tmac_onFacebookPostCommentReceivedCallback; //FacebookCommentMessageEvent
var tmac_onFacebookPostCommentReplyReceivedCallback; //FacebookReplyMessageEvent
var tmac_onFacebookPrivateMessageReceivedCallback; //FacebookPrivateMessageEvent


var tmac_facebook_stationid;
var tmac_facebook_agentid;
var tmac_facebook_agentname;

function tmac_facebook_initialize(stationid, agentid, agentname, incomingPostCallback, incomingConversationCallback,
    fbPostReceived, fbPostCommectReceived, fbPostCommentReplyReceived,fbPrivateMessageReceived) {
    tmac_facebook_stationid = stationid;
    tmac_facebook_agentid = agentid;
    tmac_facebook_agentname = agentname;
    tmac_onFacebookIncomingPostReceivedCallback = incomingPostCallback;
    tmac_onFacebookIncomingConversationReceivedCallback = incomingConversationCallback;
    tmac_onFacebookPostMessageReceivedCallback = fbPostReceived;
    tmac_onFacebookPostCommentReceivedCallback =  fbPostCommectReceived;
    tmac_onFacebookPostCommentReplyReceivedCallback = fbPostCommentReplyReceived;
    tmac_onFacebookPrivateMessageReceivedCallback = fbPrivateMessageReceived;
}


function FacebookCreatePostInteractionEvent(event) {
    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    
    window[tmac_onFacebookIncomingPostReceivedCallback](event);
}

function FacebookPostMessageEvent(event) {
    window[tmac_onFacebookPostMessageReceivedCallback](event);
}

function FacebookCommentMessageEvent(event) {
    window[tmac_onFacebookPostCommentReceivedCallback](event);
}

function FacebookReplyMessageEvent(event) {
    window[tmac_onFacebookPostCommentReplyReceivedCallback](event);
}

function FacebookCreateConversationInteractionEvent(event) {
    //save RecoveryData
    try {
        tmac_events_interaction_recovery_data[event.InteractionID] = event.RecoveryData;
    } catch (e) {

    }
    

    window[tmac_onFacebookIncomingConversationReceivedCallback](event);
}

function FacebookPrivateMessageEvent(event) {
    window[tmac_onFacebookPrivateMessageReceivedCallback](event);
}