// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Dashboard.js";
var file_version = "3.1.06.26";
var changedBy = "Sirajuddin"
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

//document ready 
$(document).ready(function () {
    console.log('dashboard loaded');
    if (!isFullTMAC) {
        //dashboard interval dropdown
        $("#drp_dashboard_interval").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            select: OnDashboardIntervalChange,
            dataSource: dashboardInterval
        });

        //set default select for dashboard dropdown
        $("#drp_dashboard_interval").data("kendoDropDownList").select(function (dataItem) {
            return dataItem.value === defaultDashboardInterval;
        });

        loadMyDashboard = setInterval(function () {
            if (globalChannelList.length > 0) {
                clearInterval(loadMyDashboard);
                LoadDashboardData();
            }
        }, 3000);
    }
});

function LoadDashboardData() {
    try {
        globalAgentList.push(global_AgentID);
        if (globalAgentList.length !== 0 && global_UserProfileForAgent != "") {
            con = $.hubConnection(dashboardSignalRUrl1);
            con.logging = true;
            con.qs = {
                'agentId': global_AgentID,
                'agentProfile': global_UserProfileForAgent,
                'stationId': global_DeviceID,
                'tmacServer': _tmacServer,
                'isTmac': true
            };
            hub = con.createHubProxy('tmacDataServerHub');
            hub.on('onRegistered', function (message, start, version) {
                try {
                    log.LogDetails("Info", "Dashboard.LoadDashboardData()", message + " - Start: " + start + ", Version: " + version, false);
                    ProcessMiniDashboard(start, "");
                    signalRVersion = version;
                } catch (ex) {
                    log.LogDetails("Error", "Dashboard.LoadDashboardData()", ex, false);
                }
            });
            ConnectToServer();
            con.disconnectTimeout = 10000;
            con.starting(function () {
                log.LogDetails("Info", "Dashboard.LoadDashboardData()", "SignalR - starting", false);
            });

            con.received(function (obj) {
                log.LogDetails("Info", "Dashboard.LoadDashboardData()", "SignalR - received", false);
            });

            con.connectionSlow(function () {
                log.LogDetails("Warning", "Dashboard.LoadDashboardData()", "SignalR - We are currently experiencing difficulties with the connection", true);
            });

            con.error(function (error) {
                log.LogDetails("Info", "Dashboard.LoadDashboardData()", "SignalR - error: " + error, false);
            });

            con.reconnecting(function () {
                log.LogDetails("Info", "Dashboard.LoadDashboardData()", "SignalR - reconnecting", false);
            });

            con.reconnected(function () {
                log.LogDetails("Info", "Dashboard.LoadDashboardData()", "SignalR - reconnected", false);
                ProcessMiniDashboard(true, "");
            });

            con.disconnected(function (obj) {
                log.LogDetails("Info", "Dashboard.LoadDashboardData()", "SignalR - disconnected: " + con.url, false);
                if (con.url == dashboardSignalRUrl1 + "/signalr") {
                    con.url = dashboardSignalRUrl2 + "/signalr";
                } else if (con.url == dashboardSignalRUrl2 + "/signalr") {
                    con.url = dashboardSignalRUrl1 + "/signalr";
                }
                setTimeout(function () {
                    log.LogDetails("Info", "Dashboard.LoadDashboardData()", "SignalR - try manual connecting: " + con.url, false);
                    ConnectToServer();
                }, 3000); // Re-start connection after 3 seconds
            });

            hub.on('onMiniDashboard', function (data) {
                try {
                    $("#totalVoice").text(data[0].totalVoice);
                    $("#totalCallback").text(data[0].totalCallback);
                    $("#totalChat").text(data[0].totalChat);
                } catch (ex) {
                    log.LogDetails("Error", "Dashboard.onMiniDashboard()", ex, false);
                }
            });

            hub.on('onUpdate', function (channel) {
                try {
                    var interval = $("#drp_dashboard_interval").data("kendoDropDownList").value();
                    hub.invoke('GetMiniDashboard', globalAgentList, con.id, interval, globalChannelList);
                } catch (ex) {
                    log.LogDetails("Error", "Dashboard.onUpdate()", ex, false);
                }
            });

            hub.on('onGrammerCheck', function (data, obj) {
                try {
                    GrammerCheckDone(data, obj);
                } catch (ex) {
                    log.LogDetails("Error", "Dashboard.onGrammerCheck()", ex, false);
                }
            });
        } else {
            log.LogDetails("Error", "Dashboard.LoadDashboardData()", "Agent id/ profile is emprty", false);
        }
    } catch (ex) {
        log.LogDetails("Error", "Dashboard.LoadDashboardData()", ex, false);
    }
}

function ConnectToServer() {
    try {
        con.start().done(function () {
            log.LogDetails("Info", "Dashboard.ConnectToServer()", "Connected, transport = " + con.transport.name, false);
            RegisterMe();
        });
    } catch (ex) {
        log.LogDetails("Error", "Dashboard.ConnectToServer()", ex, false);
    }
}

function RegisterMe() {
    try {
        log.LogDetails("Info", "Dashboard.RegisterMe()", "SignalR - Server ready", false);
        if (con.id !== undefined && con.id !== null && con.id !== "") {
            hub.invoke('RegisterMe', globalAgentList[0], global_UserProfileForAgent, con.id);
        } else
            log.LogDetails("Error", "Dashboard.RegisterMe()", "Connection id is empty", false);
    } catch (ex) {
        log.LogDetails("Error", "Dashboard.ConnectToServer()", ex, false);
    }
}

function CheckGrammer(text, obj) {
    try {
        if (con.id !== undefined && con.id !== null && con.id !== "") {
            hub.invoke('CheckGrammer', con.id, text, obj);
        } else
            log.LogDetails("Error", "Dashboard.ProcessMiniDashboard()", "Connection id is empty", false);
    } catch (ex) {
        log.LogDetails("Error", "Dashboard.ConnectToServer()", ex, false);
    }
}

function ProcessMiniDashboard(start, interval) {
    try {
        if (start) {
            if (interval == "") {
                interval = $("#drp_dashboard_interval").data("kendoDropDownList").value();
                log.LogDetails("Info", "Dashboard.ProcessMiniDashboard()", "Dashboard Interval: " + interval, false);
            }
            hub.invoke('GetMiniDashboard', globalAgentList, con.id, interval, globalChannelList);
        }
    } catch (ex) {
        log.LogDetails("Error", "Dashboard.ProcessMiniDashboard()", ex, false);
    }
}

function OnDashboardIntervalChange(arg) {
    try {
        ProcessMiniDashboard(true, this.dataItem(arg.item).value);
    } catch (ex) {
        log.LogDetails("Error", "Dashboard.OnDashboardIntervalChange()", ex, false);
    }
}

function OpenDashboard(channel) {
    try {
        var param = "agentId=" + global_AgentID + "&profile=" +
            global_UserProfileForAgent + "&channel=" + channel + "&channelList=" + globalChannelList;
        param = ToEncodedString(param);
        var url = dashboardUrl + "?" + param;
        var h = screen.height;
        var w = screen.width;
        window.open(url, "1",
            "menubar=no,resizable=0,location=no,scrollbars=no,width=" + w + ",height=" + h);
    } catch (ex) {
        log.LogDetails("Error", "Dashboard.OpenDashboard()", ex, false);
    }
}