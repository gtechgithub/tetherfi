﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "DynamicData.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}
// ----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------

//document ready 
$(document).ready(function () {
    console.log('dynamic data loaded');
});

//----------------------------------------------------------------------------------
//AddDynamicFields
function AddDynamicFields(type) {
    try {
        let objType;
        let appendId;
        if (type == "voice") {
            objType = voiceObj;
            appendId = "voice_dynamic_fields_INTID";
        } else if (type == "chat") {
            objType = chatObj;
            appendId = "chat_dynamic_fields_INTID";
        }
        $("#" + appendId).html("");
        $.each(objType, function (text, val) {
            let splitVal = val.split(',');
            let value = splitVal[0];
            let className = splitVal[1];
            AddDynamicDivs("dynamic_data_template", appendId, text, value + "_INTID", className);
        });
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicFields()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------
//AddDynamicDivs
function AddDynamicDivs(templateId, appendId, text, value, className) {
    try {
        let t = $("#" + templateId).html(), //template divs
            e = $("#" + appendId), //to be appended to
            n = Handlebars.compile(t), //initialize handlebars for the template divs       
            context = {
                label: text,
                id: value,
                name: text,
                class: className
            }, //add context data
            s = n(context); //execute the template with handlebar and context
        e.append(s), altair_md.inputs(e), $(window).resize(); //append the element, init altair_md.inputs and resize the window
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AddDynamicDivs()", ex, false);
    }
}
//----------------------------------------------------------------------------------

//----------------------------------------------------------------------------------
//AssignDynamicValues
function AssignDynamicValues(data, type) {
    try {
        let intid = data.InteractionID;
        if (GetTabReferenceObj(intid) !== undefined) {
            if (GetTabReferenceObj(intid).type == "voice" && type == "voice") {
                //No IVR
            } else if (GetTabReferenceObj(intid).type == "chat" && type == "chat") {
                $("#hfTextChatUCID" + intid).val(data.TextChatServerSessionID);
                let parse = JSON.parse(data.JsonData);
				let cif = parse.eCif;
                 let scName = parse.eCustName; // Customer Name
                 let custSeg = parse.eCustSeg; // Customer segment
                 let custSubSeg = parse.eCustSubSeg;
                 let lang = parse.pLang; //customer language
                 let authType = parse.eAuthLevel; // customer authtype
                 let callStatus = parse.eAuthStatus; // customer call status
                 let intent = parse.pTopic; //customer intent
                 let regNo1 = parse.eMobileNo; // customer registered number
                 let vaChatId = parse.vachatid; // kasisto id
                 let custEntType = ""; // customer entry type
                 let queueTime = parse.QUEUE_TIME; // queue time from customer
                 let eEmail = parse.eEmail;
                 let kcin = parse.eKCIN;

                 document.getElementById("textChatName" + intid).value = scName;
                 document.getElementById("textChatCIF" + intid).value = cif;
                 document.getElementById("textChatSegment" + intid).value = custSeg;
                 document.getElementById("textChatSubSegment" + intid).value = custSubSeg;
                 document.getElementById("textChatLang" + intid).value = lang;
				 //document.getElementById("textChatEmail" + intid).value = eEmail;
                 document.getElementById("textChatIntent" + intid).value = intent;
                 document.getElementById("textChatRegPhone1" + intid).value = regNo1;
                 document.getElementById("textChatQueueTime" + intid).value = queueTime + " seconds";
                 let colorCode = GetColorCode(queueTime);
                 document.getElementById('textChatQueueTime' + intid).style.color = colorCode;
                 //document.getElementById("textChatChannel" + intid).value = parse.pChannel;
				 //document.getElementById("textChatStatus" + intid).value = callStatus;
                 //document.getElementById("textchatVAChatSessionID" + intid).value = vaChatId;
				 
				 $("#divTabHeader" + intid).text(scName.replace(/ +/g, ""));
                 $("#hfTextChatCIF" + intid).val(cif);
                 $("#hfTextChatCustEntType" + intid).val(custEntType);
                 //$("#hfTextChatKcin" + intid).val(kcin);
                 $("#hfRegPhone" + intid).val(regNo1);
				 
                 
                 $("#divTabHeader" + intid).text(scName.replace(/ +/g, ""));
				 
				 var callStatusIcon = "error";
                var callStatusIconType = "danger";
                var authTypeIcon = "error";
                var authTypeIconType = "danger";

                if (callStatus == "AUTHENTICATED") {
                    callStatusIcon = "done";
                    callStatusIconType = "success";
                }
                if (authType == "2FA") {
                    authTypeIcon = "done";
                    authTypeIconType = "success";
                }

                //should be changed because now for all status we are appening "error" icon and "success" color
                //should be dynamic based on the server response/ since its a new change server is responding with 
                //only status text not the type [refer 'setUUIData' function in tmac_ui.js]
                $('#textCallStatus' + data.InteractionID)
                    .html("<span class='uk-text-" + callStatusIconType + " uk-text-bold uk-text-small'><i class='material-icons uk-text-" +
                    callStatusIconType + "'>" + callStatusIcon + "</i> " +
                    callStatus + "</span>");

                $('#textChatAuthType' + data.InteractionID)
                    .html("<span class='uk-text-" + callStatusIconType + " uk-text-bold uk-text-small'><i class='material-icons uk-text-" +
                    authTypeIconType + "'>" + authTypeIcon + "</i> " +
                    authType + "</span>");
				
                GetTabReferenceObj(intid).OtherData.VAChatSessionID = parse.vachatid;
                GetTabReferenceObj(intid).OtherData.CIF = cif;
				$("#hfTextChatKcin" + intid).val(cif);
				GetChatReferenceObj(intid).customerName = scName.split(' ')[0];
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "DynamicData.AssignDynamicValues()", ex, false);
    }
}

function HandleCallbackEvent(event){
	var parse = JSON.parse(event.JsonData);
            //var arr = [];
            //arr = parse.eCin.split('/');
            //var cin = arr[0]; // Customer CIN
            custom_getTextChatData(event.InteractionID, parse.eCif, event.TextChatSessionID);
            //Update VASessionID in custom table for BIP
            custom_UpdateVasessionIdForTextChat(event.InteractionID, event.TextChatSessionID, event.VAChatSessionID);
}