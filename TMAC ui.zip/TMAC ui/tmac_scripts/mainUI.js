﻿var version_mainUI = "3.0.07.06";
try {
    global_addVersion("mainUI", version_mainUI);
} catch (e) {
}


var call_log_out = false;
var logout_button_clicked = false;

window.onerror = function (e) {
    return true;
};

$(function () {
    $(window).bind('beforeunload', beforePageUnload);
    $(window).bind('unload', onPageUnload);
});

function beforePageUnload() {
    call_log_out = false;
    if (logout_button_clicked)
        call_log_out = false;
    else if (global_AgentForcedLogoffEventFlag)
        call_log_out = false;
    else {
        call_log_out = true;
        return 'Are you sure you want to Logout?';
    }
}

function onPageUnload() {
    if (call_log_out) {
        Logout(global_DeviceID);
    }
}

function logout_click() {
    var ret = confirm('Are you sure you want to Logout?');
    if (ret) {
        logout_button_clicked = true;
        Logout(global_DeviceID);
    }
}


function bindEnterClickButtons() {

    //make call
    $(document.getElementById('makecallDialog')).keypress(function (e) {
        var key = e.which;
        if (key == 13) {
            $('#btndialogmakecall').click();
            e.preventDefault();
        }
    });

    //transfer call
    $(document.getElementById('Transferdialog')).keypress(function (e) {
        var key = e.which;
        if (key == 13) {
            $('#btnTranferMCall').click(); e.preventDefault();
        }
    });

    //conference call
    //Confdialog
    $(document.getElementById('Confdialog')).keypress(function (e) {
        var key = e.which;
        if (key == 13) {
            $('#btnConfMCall').click(); e.preventDefault();
        }
    });


}


$(document).ready(function () {
    console.log('main js loaded');

    var autologin = getQueryStringValue("autologin");
    if (autologin != "1") {
        loadMainScreen();
        popoversetup();
    }
	
	
});


function getQueryStringValue(key) {
    return unescape(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + escape(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}

function popoversetup() {
    var height = $(window).height();
    //$('#iframe_CustomerSearch').css('height', height * 0.9 | 0);
    $('#iframe_CustomerSearch_INTID').css('height', (height * 0.9) - 80);

    //            $('[data-toggle="popover"]').popover({
    //                title: '  Menu ',
    //                content: 'Loading...',
    //                "html": "true",
    //                "data-placement": 'bottom'
    //            });


    $('html').click(function (e) {
        $('[data-toggle="popover"]').popover('hide');
        $('.popover').css('display', 'none');
        try {
            $('#auxcodelist').css('display', 'none');
        } catch (e) {

        }
    });

    $('#menupopOver').popover({
        title: '  Menu ',
        content: 'Loading...',
        "html": "true",
        "data-placement": 'bottom',
        trigger: 'manual'
    }).click(function (e) {
        $(this).popover('toggle');
        try {
            $('#auxcodelist').css('display', 'block');
        } catch (e) {

        }
        e.stopPropagation();
    });


    if (tmac_ui_show_wallboard_pop) {
        $('#ui_tmac_agent_details').popover({
            title: '  Wallboard ',
            content: 'Loading...',
            "html": "true",
            "data-placement": 'bottom',
            trigger: 'manual'
        }).click(function(e) {
            $(this).popover('toggle');
            try {
                bindWalloardPop();
                ; // $('#auxcodelist').css('display', 'block');
            } catch(e) {

            }
            e.stopPropagation();
        });

    }
}

function loadMainScreen() {
    setupUI();


    intilizeComponents();
    var loginData;

    if (window.global_autologin) {
        popoversetup();
        loginData = getSuccessfullyLoggedInData();
    } else
        loginData = opener.getSuccessfullyLoggedInData();


    try {
        window.accessRole = loginData.data.Data.AccessRole;
    } catch (e) {

    }

    try {
        if (tmac_supervisor_window_enabled) {
            if (loginData.data.Data.UserProfileForAgent == "S") {
                $("#supervisor_link_div").css("display", "block");
                $("#supervisor_link_btn").css("display", "block");
            } else {
                $("#supervisor_link_div").css("display", "none");
                $("#supervisor_link_btn").css("display", "none");
            }
        }
    } catch (e) {

    }

    //config_show_workbench_for_supervisor_only
    try {
        if (config_show_workbench_for_supervisor_only) {
            if (loginData.data.Data.UserProfileForAgent == "S") {
                $("#workbench_link_div").css("display", "block");
                $("#div_text_queue").css("display", "block");
                $("#div_text_queue_extra").css("display", "block");
                
            } else {
                $("#workbench_link_div").css("display", "none");
                $("#div_text_queue").css("display", "none");
                $("#div_text_queue_extra").css("display", "none");
				
				// Set Messenger Width to 80% for non suoervisor/Agents
				// $("#tmac_im_main_div").css("width", "80%");
            }
        }
    } catch (e) {

    }


    if (!ui_config_workbench_enabled) {
        $("#div_text_queue").css("display", "none");
    }
    
    //set web sock related data for main screen
    try {

        
        
        global_successfullyLoggedInData.tmac_ws_authcode = loginData.tmac_ws_authcode;
        global_successfullyLoggedInData.tmac_ws_url_listString = loginData.tmac_ws_url_listString;

        tmac_ws_connect();
    } catch (e) {

    }
    
    successfullyLoggedIn(loginData.data, loginData.global_DeviceID, loginData.global_LanID);

    try {
        GetTMACVersion();
    } catch (e) {

    }

    //add agent data tab
    if (ui_config_show_agent_window && ui_config_show_agent_window_before_main)
        openAgentDataWindow();
    

    if (!ui_config_change_ui || (ui_config_change_ui && ui_config_add_main_tab)) {
        addTab('main', 'divMainTabHeader', 'divMainTabBody', !(ui_config_show_agent_window && 
            ui_config_show_agent_window_before_main) && true);

        //set the tab header name
        //set tab header details
        var tabName = 'Main';

        $('#divCustomerName' + 'main').text(tabName);

        //show close button
        try {
            setCallControlStatus('main', false, false, false, false, false, false, true);
        } catch (e) {
        }
    }

    //add agent data tab
    if (ui_config_show_agent_window && !ui_config_show_agent_window_before_main)
        openAgentDataWindow();
    
    bindEnterClickButtons();

    //show the server name
    $("#divServerName").html(global_server_name);


    try {
        if (tmac_cherrypick_enabled) {
            if (loginData.data.Data.UserProfileForAgent == "S") {
                $("#cherrypick_link_div").css("display", "block");
                $("#cherrypick_link_btn").css("display", "block");
            } else {
                $("#cherrypick_link_div").css("display", "none");
                $("#cherrypick_link_btn").css("display", "none");
            }
        } else {
            $("#cherrypick_link_div").css("display", "none");
            $("#cherrypick_link_btn").css("display", "none");
        }
    } catch (e) {

    }

    //2017-06-19 change ui components based on access roles
    loadAccessRoleBasedUi();
}



function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
}

function intilizeComponents() {

    $("#tmac_tabs").tabs({
        activate: function (event, ui) {
            var activeTabID = $(this).tabs('option', 'active');
            var selector = '#tmac_tabs > ul > li';
            activeTabID = $(selector).eq(activeTabID).attr('id');

            tabSelected(activeTabID);
        }
    });

    //alert(ui_window_width);
    //var wWidth = $(document).width();
    var maxWidth = ui_window_width * 0.9;
    //var flag = ui_config_change_ui;

    //alert(maxWidth);
    $("#AlertMessageDialog").dialog({
        autoOpen: false,
        width: (ui_config_change_ui && maxWidth < 600) ? maxWidth : 600,
        show: 'fade',
        hide: 'drop',
        position: {
            my: 'top',
            at: 'top',
            of: $('#divMainScreenWallboard')
        }
    });

    $(function () {
        $('#tabs_transfer').tabs();
    });

    $(function () {
        $('#tabs_MakeCall').tabs();
    });



    $("#confirmDialog").dialog({
        autoOpen: false,
        width: (ui_config_change_ui && maxWidth < 190) ? maxWidth : 190,
        show: 'fade', hide: 'drop'
    });

    $("#makecallDialog").dialog({
        autoOpen: false,
        width: (ui_config_change_ui && maxWidth < 510) ? maxWidth : 510,
        show: 'fade', hide: 'drop'
    });

    $("#Transferdialog").dialog({
        autoOpen: false,
        width: (ui_config_change_ui && maxWidth < 550) ? maxWidth : 550,
        show: 'fade', hide: 'drop'
    });

    $("#Confdialog").dialog({
        autoOpen: false,
        width: (ui_config_change_ui && maxWidth < 550) ? maxWidth : 550,
        show: 'fade', hide: 'drop'
    });

    $("#AgentNotificDialog").dialog({
        autoOpen: false,
        width: (ui_config_change_ui && maxWidth < 380) ? maxWidth : 380,
        show: 'fade', hide: 'drop'
    });

    $("#divSMSComposeDialog").dialog({
        autoOpen: false,
        width: (ui_config_change_ui && maxWidth < 510) ? maxWidth : 510,
        show: 'fade', hide: 'drop'
    });



    try {
        $("#div_conf_mute_window").dialog({
            autoOpen: false,
            width: (ui_config_change_ui && maxWidth < 190) ? maxWidth : 190,
            show: 'fade', hide: 'drop'
        });
    } catch (e) {

    }

    try {
        $("#div_chat_filetransfer").dialog({
            autoOpen: false,
            width: (ui_config_change_ui && maxWidth < 510) ? maxWidth : 510,
            show: 'fade', hide: 'drop'
        });
    } catch (e) {

    }

    // make Messenger Dragable
    try {
        $("#tmac_im_main_div").draggable();

        $("#tmac_im_main_div").draggable({ cancel: "div.tmac_im_Contents" });

    } catch (e) {

    }

    //div_ccl_commentsDialog
    try {
        $("#div_ccl_commentsDialog").dialog({
            autoOpen: false,
            width: (ui_config_change_ui && maxWidth < 190) ? maxWidth : 190,
            show: 'fade', hide: 'drop'
        });
    } catch (e) {

    }
}

////search for a customer in LMS
//function searchCustomer() {
//    loadCustomerDataGrid();
//}


//--------------------------------------Wallboard refresh---------------------------------------------
function refreshWallboard(data) {

    if (data != null) {
        //bind wallboard data
        loadWallboardGrid(data.Skills);
        if (tmac_ui_show_wallboard_pop) {
            try {
                loadWallboardGrid_pop(data.Skills);
            } catch (e) {

            }
        }

        if (tmac_ui_show_wallboard_main) {
            try {
                loadWallboardGrid_main(data.Skills);
            } catch (e) {

            }
        }
    }
}

//bind wallboard data
function loadWallboardGrid(skills) {

   
    var grid = $('#wallboardGrid');
    var currentPage = grid.getGridParam('page');
    if (currentPage == undefined || currentPage < 1)
        currentPage = 1;


    var scrollPos = grid.closest(".ui-jqgrid-bdiv").scrollTop();

    $('#wallboardGrid').jqGrid('GridUnload');

    $("#wallboardGrid").jqGrid({
        caption: 'Wallboard',
        data: skills,
        datatype: 'local',
        colNames: ['Skill', 'Staffed', 'Avail', 'CIQ'],
        colModel: [
                    { name: 'SkillName', index: 'SkillName', width: 170 },
                    { name: 'AgentsStaffed', index: 'Code', width: 50 },
                    { name: 'AgentAvailable', index: 'Value', width: 50 },
                    { name: 'CallsInQueue', index: 'Display', width: 50 }
                ],
        pager: '#pager-wallboard',
        rowNum: 30,
        rowList: [30], //[10, 50, 100],
        sortname: 'SkillName',
        sortorder: 'asc',
        autowidth: true,
        shrinkToFit: false,
        localReader: { repeatitems: true },
        height: ui_config_change_ui ? ui_config_wallboard_height : 500, //500
        loadonce: true
    });

    $('#wallboardGrid').trigger('reloadGrid', [{ page: currentPage}]);
    grid = $('#wallboardGrid');
    grid.closest(".ui-jqgrid-bdiv").scrollTop(scrollPos);

}


////bind LMS customer data to grid
//function loadCustomerDataGrid() {

//    //dummy data start
//    var custArray = new Array();
//    var cust1 = {};
//    cust1.RoomNumber = "1021";
//    cust1.FirstName = "Sam";
//    cust1.LastName = "Weera";
//    cust1.VIPCode = "VIP1";
//    custArray[0] = cust1;

//    var cust2 = {};
//    cust2.RoomNumber = "1023";
//    cust2.FirstName = "Harman";
//    cust2.LastName = "John";
//    cust2.VIPCode = "VIP2";
//    custArray[1] = cust2;
//    //dummy data end


//    var grid = $('#customerDataGrid');
//    var currentPage = grid.getGridParam('page');
//    if (currentPage == undefined || currentPage < 1)
//        currentPage = 1;


//    var scrollPos = grid.closest(".ui-jqgrid-bdiv").scrollTop();

//    $('#customerDataGrid').jqGrid('GridUnload');

//    $("#customerDataGrid").jqGrid({
//        caption: 'Customers',
//        data: custArray,
//        datatype: 'local',
//        colNames: ['RoomNumber', 'FirstName', 'LastName', 'VIPCode'],
//        colModel: [
//                    { name: 'RoomNumber', index: 'RoomNumber', width: 210 },
//                    { name: 'FirstName', index: 'FirstName', width: 50 },
//                    { name: 'LastName', index: 'LastName', width: 50 },
//                    { name: 'VIPCode', index: 'VIPCode', width: 50 }
//                ],
//        pager: '#pager-customerDataGrid',
//        rowNum: 10,
//        rowList: [20], //[10, 50, 100],
//        sortname: 'RoomNumber',
//        sortorder: 'asc',
//        autowidth: true,
//        shrinkToFit: false,
//        localReader: { repeatitems: true },
//        height: 200,
//        loadonce: true
//    });

//    $('#customerDataGrid').trigger('reloadGrid', [{ page: currentPage}]);
//    grid = $('#customerDataGrid');
//    grid.closest(".ui-jqgrid-bdiv").scrollTop(scrollPos);

//}




//--------------------------------------Agent aux codes loaded---------------------------------------------
function auxCodesLoaded() {

    if (global_AUXCodes != null) {
        //bind aux codes to dropdown list
        //set the first as empty

        removeNameFromList(global_AUXCodes, "Logout", 110);
        //removeNameFromList(global_AUXCodes, "ACW", 111);

        /*
        $('#ddlAUXCode').append('<option value="-100"></option>');
        $.each(global_AUXCodes, function (i, val) {

        if (val.Display == 1) {
        $('#ddlAUXCode').append('<option value="' + val.Value + '">' + val.Name + '</option>');
        }
        });*/

        //$('#ddlAUXCode').selectmenu('refresh', true);
        window.global_LastAgentStat = {};
        window.global_LastAgentStat.Status = "Default";
        agentStatusChange(window.global_LastAgentStat);






        //new aux UI
        loadAuxDiv(global_AUXCodes, "Default");

        //divAuxCodeHide();
        divAuxStatReceivedFromServer("Default");
    }
}


function loadAuxDiv(data, currentStat) {



    var count = data.length;
    var intI = count;
    //debugger;
    if (intI != 0) {
        //var aUmsg = "";
        var newdropDownstring = "";
        //aUmsg += "<table  onmouseleave='return divAuxCodeHide();' cellpadding=0 cellspacing=0  style='font-size:10pt; border:1px solid #eea236; width:260px; cursor: pointer; color:#000000; margin-left:-110px; margin-top:35px; text-align:left; ' >";
        var i = 0;

        $.each(data, function (k, arrayItem) {
            //show only display=1 aux codes
            if (arrayItem.Display == "1") {
                if ((currentStat == "ACW") || arrayItem.Name != currentStat) {

                    //                    if (i % 2 == 0) {
                    //                        aUmsg += "<tr>";
                    //                        aUmsg += '<td id="tdAux' + arrayItem.Value + '" onmouseover="return auxRowMouseOver(' + arrayItem.Value + ');"  onmouseout="return auxRowMouseOut(' + arrayItem.Value + ');" onclick="return divAuxCodeSelected(\'' + arrayItem.Value + '\',\'' + arrayItem.Name + '\');" class="auxTableRow"> ' + arrayItem.Name;
                    //                        aUmsg += "</td></tr>";
                    //                    } else {
                    //                        aUmsg += "<tr>";
                    //                        aUmsg += '<td id="tdAux' + arrayItem.Value + '" onmouseover="return auxRowMouseOver(' + arrayItem.Value + ');" onmouseout="return auxRowMouseOut(' + arrayItem.Value + ');" onclick="return divAuxCodeSelected(\'' + arrayItem.Value + '\',\'' + arrayItem.Name + '\');" class="auxTableAlternateRow"> ' + arrayItem.Name;
                    //                        aUmsg += "</td></tr>";
                    //                    }
                    //                    i++;

                    //newdropDownstring += '<li><a class="popover-style-text" href="#" onclick="return divAuxCodeSelected(\'' + arrayItem.Value + '\',\'' + arrayItem.Name + '\');">' + arrayItem.Name + '</a></li>';
                    newdropDownstring += '<a class="list-group-item" href="#" onclick="return divAuxCodeSelected(\'' + arrayItem.Value + '\',\'' + arrayItem.Name + '\',\'' + arrayItem.Code + '\');">' + arrayItem.Name + '</a>';
                }
            }
        });
        //aUmsg += "</table>";
        //$("#divAuxCodes").append().html(AUmsg);
        //$("#divAuxCodes").html(AUmsg);


        var tp = '<div id="auxcodelist"  class="list-group" onmousedown="return false;">' +
            newdropDownstring +
            '</div>';
        //alert(tp);
        //        var test = '<div class="list-group">' +
        //            '<a href="#" class="list-group-item disabled">First item</a>' +
        //            '<a href="#" class="list-group-item">Second item</a>' +
        //            '<a href="#" class="list-group-item">Third item</a>' +
        //            '</div>';
        $("#menupopOver").attr('data-content', tp);
        //$("#menupopOver1").attr('data-content', test);




    }

    return false;
}

function divAuxStatReceivedFromServer(name) {
    $('#divAuxStatus').text(name);

    loadAuxDiv(global_AUXCodes, name);
}

function divAuxCodeSelected(id, name, code) {

    var oldName = $('#divAuxStatus').text();

    var ret = divAuxCodeChanged(id, name, oldName, code);
    if (ret) {
        $('#divAuxStatus').text(name);
        divAuxCodeHide();
    }
}

function divAuxCodeHide() {
    //$('#divAuxCodes').css("display", "none");

    // $('#divAuxCodes').css("visibility", "hidden");
}

function auxRowMouseOver(id) {
    //alert('auxRowMouseOver:' + id);
    $('#tdAux' + id).css("color", "#cb0101");
    $('#tdAux' + id).css("font-weight", "bold");
    //alert(document.getElementById('tdAux' + id));
    //alert(document.getElementById('tdAux' + id).style.color);

    //document.getElementById('tdAux' + id).style.color = 'red';
}

function auxRowMouseOut(id) {
    //alert('auxRowMouseOut:' + id);

    $('#tdAux' + id).css("color", "black");
    $('#tdAux' + id).css("font-weight", "normal");
    //document.getElementById('tdAux' + id).style.color = 'black';

}

function divAuxStatusClicked() {
    //debugger;
    //    if ($('#divAuxCodes').css("visibility") == "hidden") {
    //        //$('#divAuxCodes').css("display", "inline");
    ////        $('#divAuxCodes').css("position", "absolute");
    ////        $('#divAuxCodes').css("z-index", "10");
    //        $('#divAuxCodes').css("visibility", "visible");
    //    }
    //    else {
    //        //$('#divAuxCodes').css("display", "none");
    //        $('#divAuxCodes').css("visibility", "hidden");
    //    }

}

//-------------- Connectivity Status -------------------------
function setConnectivityStatus(status) {


    var date = new Date();

    try {
        date = moment(date).format("YYYY/MM/DD, HH:mm:ss");
        //ui_tmac_clock_span
        $('#ui_tmac_clock_span').text(date);
    } catch (e) {

    }

    try {
        if (document.getElementById('divConnectivityStatus') == null) {
            return;
        }
        //status - 0,1,2
        if (status == 0) {

            document.getElementById('divConnectivityStatus').style.color = "white";
        }
        else if (status == 1) {
            document.getElementById('divConnectivityStatus').innerHTML = 'Online';
            document.getElementById('divConnectivityStatus').style.color = "green";
        }
        else if (status == 2) {
            document.getElementById('divConnectivityStatus').innerHTML = 'Offline';
            document.getElementById('divConnectivityStatus').style.color = "red";
        }
    }
    catch (e) { }
}


//--------------------------------------Agent status change---------------------------------------------
function agentStatusChange(data) {
    //update the status list with new status
    //reset the status timer
    if (data != null) {

        //set the last agent status. This value will be used after aux code loading is completed

        try {
            window.global_LastAgentStat = data;
            sec = 0, min = 0, hour = 0;
            //set the timer
            window.global_status_timer_date = new Date();
        } catch (e) {

        }

        //2017-03-30 enable logout button for all except oncall
        try {
            if (tmac_enable_logout_for_all_status) {
                if (global_LastAgentStat.Status.indexOf("On Call") >= 0) {
                    disableLogoutButton();
                } else {
                    enableLogoutButton();
                }

            }
        } catch (e) {

        }
        
        divAuxStatReceivedFromServer(data.Status);
    }
}

function divAuxCodeChanged(id, type, oldName, code) {

    if (type == "ACW") {
        ChangeStatus(global_DeviceID, 'acw', id);
        disableLogoutButton();
    }
    else if (type == "Available") {
        //global_LogoutFlag = false;
        ChangeStatus(global_DeviceID, 'available', id);
        disableLogoutButton();
        //global_InteractionTabs.forEach(closeAllTabs);
        //closeAllTabs();
    }
    else if (type == "Logout" || type.indexOf('Logout') >= 0 || code == "logout") {
        if (global_LastAgentStat.Status.indexOf("On Call") >= 0) {
            //do nothing
            //agentStatusChange(global_LastAgentStat);
            return false;
        }
        else {
            //global_LogoutFlag = true;
            ChangeStatus(global_DeviceID, 'aux', id);
            enableLogoutButton();
        }
    }
    else {
        //global_LogoutFlag = false;
        ChangeStatus(global_DeviceID, 'aux', id);
        disableLogoutButton();
    }

    //2017-03-30 enable logout button for all except oncall
    try {
        if (tmac_enable_logout_for_all_status) {
            if (global_LastAgentStat.Status.indexOf("On Call") >= 0) {
                disableLogoutButton();
            } else {
                enableLogoutButton();
            }

        }
    } catch (e) {

    }
    
    return true;
};


//---------------------------------------------- Disable Logout Button ------------------------------------------------------
function disableLogoutButton() {
    $('#btnLogout').attr('disabled', 'disabled');
    $('#btnLogout').fadeTo("fast", 0.33);
}

//---------------------------------------------- Enable Logout Button ------------------------------------------------------
function enableLogoutButton() {
    window.global_enableLogout = true;
    $('#btnLogout').removeAttr('disabled', 'disabled');
    $('#btnLogout').fadeTo("fast", 1);
}


//--------------------------------------Agent notification---------------------------------------------
function agentNotification(data) {
    //setup skill marquee
    window.marqueeText = ""; //clear marquee text               

    setupMarqueeData(data.Message);
    if (data.Message == "....") {
        window.marqueeText = 'No broadcast to display';
        document.getElementById('txtagentNotification').innerHTML = window.marqueeText;
        document.getElementById("marquee").innerHTML = window.marqueeText;
        $("#marquee").val(window.marqueeText);
        return;
    }
    document.getElementById("marquee").innerHTML = window.marqueeText;
    $("#marquee").val(window.marqueeText);

    document.getElementById('txtagentNotification').innerHTML = window.marqueeText;
    if (window.global_LoginFlag) {
        window.global_LoginFlag = false;
    }
    else {
        if (data.Message != "....") {
            $("#tdNotificationMessage").html('<img src="../Content/Images/alert.png" height="10px" width="10px" />');
        }
    }

    checkPageFocus("Broadcast:" + data.Message);
    
}

//-------------------------agent non-broadcast notification----------------------------------------------
var tmac_im_id   = 0;

function agentNonBroadcastNotification(event) {

    try {
        switch (event.Type) {
        case "IM":
             
                tmac_im_id = tmac_im_id + 1;
//                var div = '<div>' +
//                            '<div>' + event.FromAgentName + ' :<br> ' + event.Message + '</div> ' +
//                            '<div>' +
//                                '<textarea id="txt_im_' + tmac_im_id + '" cols="20" rows="2"></textarea>' +
//                                '<input  type="button" value="Reply" onclick="tmac_im_send(' + event.FromAgentId + ',' + tmac_im_id + ');" />' +
//                            '</div>    ' +
//                          '</div>';


          
            
            var div = ' <div>' +
                ' <div style="border-top: 1px solid #ccc;  margin-top: 3px;">' +
                '   <span style="color: green;font-weight: bold">' + event.FromAgentName + ' :</span> ' + event.Message +
                ' <a href="#" onclick="tmac_im_show_reply_div(' + tmac_im_id + ')">&nbsp;reply...</a> ' +
                ' </div>' +
                ' <div style="display:none;"  id="div_im_reply' + tmac_im_id + '">' +
                '      <textarea id="txt_im_' + tmac_im_id + '" rows="2" style="width: 100%;"></textarea>' +
                '       <button type="button" onclick="tmac_im_send(' + event.FromAgentId + ',' + tmac_im_id + ');" value="Reply" class="btn btn-success" style="width: 100%;height: 25px;">Reply</button>' +
                '        </div>' +
                ' </div>';
                //alertMessageDialog(event.FromAgentName + " says:" + event.Message, "danger");
                $("#tmac_im_main_div").css("display", "block");
                tmac_im_show_hide();
                $("#tmac_im_data_div").html($("#tmac_im_data_div").html() + div);

                //create IM ui
                checkPageFocus("IM from " + event.FromAgentName);
            
                break;
            case "InteractionIM":
                try {
                    if (config_show_tab_interactionim) {
                        var h = '<marquee style="color: Red;">' + event.FromAgentName +
                        ":" + event.Message + '</marquee>';

                        $("#divInteractionIM" + event.InteractionID).css("display", "block");
                        $("#divInteractionIM" + event.InteractionID).html(h);
                        $("#divInteractionIM" + event.InteractionID).click({ msg: event }, function (e12) {
                            //alert(e12.data.msg);
                            alertMessageDialog(e12.data.msg.FromAgentName + ":" + e12.data.msg.Message);
                        });

                    }
                } catch (e11) {

                }
                
                break;
        case "Info":
            if (event.Message == "LoadInteractionHistory") {
                //load history on demand
            }
            break;
        }
    } catch(e) {
    }
}

//-------------------------------------setup skill marquee data---------------------------------------------
function setupMarqueeData(message) {
    if (message == "....") {
        message = 'No broadcast to display';
    }
    window.marqueeText = window.marqueeText + " " + message;
}


//-----------------------------------------------show agent notificaiton dialog------------------------------------------------
function openStatusDialog() {
    $("#tdNotificationMessage").html('');
    $("#AgentNotificDialog").dialog("open");
}


//-----------------------------------------------open the make call pop-up------------------------------------------------
function openMakeCallDialog(defaultNumber) {

    document.getElementById("txtMakeCallNumber").value = "";
    //loadAgentListGrid("makeCallagentListGrid", "pager-makeCallagentList", "txtMakeCallNumber");
    $("#makecallDialog").dialog("open");
    $('#makeCallagentListGrid').trigger('reloadGrid');

    if (defaultNumber == undefined || defaultNumber == "") {
    } else {
        document.getElementById("txtMakeCallNumber").value = defaultNumber;
    }

    //$("#hdnCallType").val("MakeCall");
}

//-----------------------------------------------close the make call pop-up------------------------------------------------
function closeMakeCallDialog() {
    $("#makecallDialog").dialog("close");
}

//--------------------------------------agent list loaded---------------------------------------------
function agentListLoaded() {

    if (global_AgentList != null) {
        //bind agent list to makecall, transfer, conference windows
        loadAgentListGrid("makeCallagentListGrid", "pager-makeCallagentList", "txtMakeCallNumber");
        loadAgentListGrid("transCallagentListGrid", "pager-transCallagentList", "txtNumberTrans");
        loadAgentListGrid("confCallagentListGrid", "pager-confCallagentList", "txtNumberConf");
    }
}

//--------------------------------------favourite list loaded---------------------------------------------
function favouriteListLoaded() {

    if (global_FavouriteSkills != null) {
        //bind favourite list grid
        loadFavListGrid();
    }
}


//--------------------------------------speed dial list loaded---------------------------------------------
function speedDialListLoaded() {

    if (global_SpeedDial != null) {
        //bind speed dial list
        loadSpeedDialGrid("speedDialMakeCallGrid", "pager-speedDialMakeCallGrid", "txtMakeCallNumber");
        loadSpeedDialGrid("speedDialGrid", "pager-speedDial", "txtNumberTrans");

        //TODO
        //speed dial should generate two grids in makecall window and trnasfer window
    }
}

//--------------------------------------Intent list loaded---------------------------------------------
function intentListLoaded() {

    if (global_Intents != null) {
        //do nothing
    }
}

//-----------------------------------------------bind agent list data (generic method)------------------------------------------------
function loadAgentListGrid(gridName, pagerName, textBox) {
    $('#' + gridName).jqGrid('GridUnload');
    $('#' + gridName).jqGrid({
        caption: 'AgentList',
        datatype: 'local',
        colNames: ['FirstName', 'LastName', 'ID', 'Status', 'Profile'],
        colModel: [
                     { name: 'FirstName', index: 'FirstName', width: 150 },
                    { name: 'LastName', index: 'LastName', width: 150 },
                    { name: 'LoginID', index: 'LoginID', width: 100 },
                    { name: 'Status', width: 90, search: false },
                    { name: 'Profile', index: 'Profile', width: 100, hidden:true }
                ],
        pager: '#' + pagerName,
        rowNum: 10,
        rowList: [10, 50, 100],
        sortname: 'Name',
        sortorder: 'asc',
        autowidth: true,
        shrinkToFit: false,
        ignoreCase: true,
        localReader: { repeatitems: true },
        //height: 180,
        onSelectRow: function (id) {
            agentListGridItemSelected(id, gridName, textBox);
        }
    });

    $('#' + gridName).jqGrid('navGrid', '#' + pagerName, { del: false, add: false, edit: false, search: true, refresh: false }, {}, {}, {}, { width: 370 });

    if (global_AgentList != undefined) {
        $('#' + gridName).jqGrid('addRowData', '', global_AgentList);
        //for (var i = 0; i <= global_AgentList.length; i++)
        //    $('#' + gridName).jqGrid('addRowData', i + 1, global_AgentList[i]);
    }

    $('#' + gridName).trigger('reloadGrid');

    $('#' + gridName).jqGrid('filterToolbar', { autosearch: true, searchOnEnter: false, defaultSearch: "cn" });
}

//------------------------------------------agent item selected from agent list (generic method)----------------------------------------
function agentListGridItemSelected(id, gridName, textBox) {


    //btnsendImInMakeCallDialog
    try {
        if (gridName == "makeCallagentListGrid") {
            $("#btnsendImInMakeCallDialog").css("display", "none");
            $("#hfImAgentName").val("");
            $("#hfImAgentId").val("");
        }
    } catch (e) {

    }
    
    try {
        $('#favListGridItemSelect').val('null');
    } catch (e) {

    }
    
    var rowId = $('#' + gridName).jqGrid('getGridParam', 'selrow');
    var rowData = jQuery('#' + gridName).getRowData(rowId);
    var agentid = rowData['LoginID'];

    var object = {};
    object.rowid = rowId;
    object.grid = $('#' + gridName);
    object.txtBox = $("#" + textBox);
    object.gridName = gridName;
    

    //commandManager.js
    GetAgentStatus(global_DeviceID, agentid, object);
}




//---------------------------------------------------------------Speed Dial Generic List---------------------------------------------------------------------------
function loadSpeedDialGrid(gridName, pagerName, textBox) {
    $('#' + gridName).jqGrid('GridUnload');


    $("#" + gridName).jqGrid({
        data: global_SpeedDial,
        caption: 'Speed List',
        datatype: 'local',
        colNames: ['Name', 'Number'],
        colModel: [
                    { name: 'Name', index: 'Name', width: 250 },
                    { name: 'Number', index: 'Number', width: 240 }
                ],
        pager: '#' + pagerName,
        rowNum: 10,
        rowList: [10, 50, 100],
        sortname: 'Name',
        sortorder: 'asc',
        autowidth: true,
        shrinkToFit: false,
        ignoreCase: true,
        localReader: { repeatitems: true },
        height: 180,
        onSelectRow: function (id) {
            speedDialListGridItemSelected(id, gridName, textBox);
        }
    });

    $('#' + gridName).jqGrid('navGrid', '#' + pagerName, { del: false, add: false, edit: false, search: true, refresh: false }, {}, {}, {}, { width: 370 });

    //for (var i = 0; i <= global_SpeedDial.length; i++)
    //    $("#" + gridName).jqGrid('addRowData', i + 1, global_SpeedDial[i]);

    $('#' + gridName).trigger('reloadGrid');

    $('#' + gridName).jqGrid('filterToolbar', { autosearch: true, searchOnEnter: false, defaultSearch: "cn" });
}


//----------------------------------------------item selected from speed dial list-------------------------------------
function speedDialListGridItemSelected(id, gridName, textBox) {
    var rowId = $("#" + gridName).jqGrid('getGridParam', 'selrow');
    var rowData = jQuery("#" + gridName).getRowData(rowId);
    var num = rowData['Number'];
    $("#" + textBox).val(num);



}
//-----------------------------------------------------------------------------------------------------------------------




//------------------------------------------bind favourite vdn list grid----------------------------------------
function loadFavListGrid() {
    $('#favListGrid').jqGrid('GridUnload');


    $("#favListGrid").jqGrid({
        caption: 'Favourite',
        data: global_FavouriteSkills,
        datatype: 'local',
        colNames: ['Name', 'VDN', 'Skill', 'Staff', 'Avail', 'CIQ'],
        colModel: [
                      { name: 'Name', index: 'Name', width: 150 },
                    { name: 'VDN', index: 'VDN', width: 100 },
                    { name: 'ID', index: 'ID', width: 90 },
                    { name: 'Staff', width: 50, search: false },
                    { name: 'Avail', width: 50, search: false },
                    { name: 'CIQ', width: 50, search: false }
                ],
        pager: '#pager-favList',
        rowNum: 10,
        rowList: [10, 50, 100],
        sortname: 'Name',
        sortorder: 'asc',
        autowidth: true,
        shrinkToFit: false,
        ignoreCase: true,
        localReader: { repeatitems: true },
        height: 180,
        onSelectRow: function (id) {
            favListGridItemSelected(id);
        }
    });

    $('#favListGrid').jqGrid('navGrid', '#pager-favList', { del: false, add: false, edit: false, search: true, refresh: false }, {}, {}, {}, { width: 370 });
    //for (var i = 0; i <= global_FavouriteSkills.length; i++)
    //   $("#favListGrid").jqGrid('addRowData', i + 1, global_FavouriteSkills[i]);

    $('#favListGrid').trigger('reloadGrid');
    $('#favListGrid').jqGrid('filterToolbar', { autosearch: true, searchOnEnter: false, defaultSearch: "cn" });
}


//---------------------------------------------item selected from favourite skill list----------------------------------------------------
function favListGridItemSelected(id) {
    var rowId = $("#favListGrid").jqGrid('getGridParam', 'selrow');
    var rowData = jQuery("#favListGrid").getRowData(rowId);
    var skill = rowData['ID'];

    //clear the number text box
    $("#txtNumberTrans").val('');
    $('#favListGridItemSelect').val('favItemSelect');
    //commandManager.js
    GetQueueStatus(global_DeviceID, skill, rowId);
}



//------------------------------------------get agent status completed. Show agent status data on grid----------------------------------------
function getAgentStatusDone(object, agentmodel) {
    // alert(data.ResultMessage);
    var rowData = object.grid.jqGrid('getRowData', object.rowid);
    var data = agentmodel.AgentStatusInPbx;

    var canSendIm = false;
    if (object.gridName == "makeCallagentListGrid") {
        if (agentmodel.LoginID == null || agentmodel.LoginID == undefined || agentmodel.LoginID == null) {
            //agent not logged in to tmac
            canSendIm = false;
        } else {
            if (im_initiate_to_supervisor_only) {
                if (agentmodel.Profile == "S") {
                    canSendIm = true;
                } else {
                    canSendIm = false;
                }
            } else {
                canSendIm = true;
            }
        }
    }
    
    rowData.Status = data;

    var canSelect = true;
    if (data.indexOf('On Call') >= 0 && (window.global_tranfer_channel == 'chat' || 
        window.global_tranfer_channel == 'chatconf')) {
        rowData.Status = data;
        //object.txtBox.val(rowData.LoginID);
        canSelect = false;
    }
    else if (data == 'Not Logged in') {
        rowData.Status = 'Not Logged in';
        //object.txtBox.val(rowData.LoginID);
        canSelect = false;
    }
    else if (data.indexOf("Error") >= 0) {
        rowData.Status = 'Not Logged in';
        canSelect = false;

    } else if (data == "") {
        rowData.Status = 'Not Logged in';
        canSelect = false;
    }

    object.grid.jqGrid('setRowData', object.rowid, rowData);
    if (canSelect) {
        object.txtBox.val(rowData.LoginID);
    }

    //can initiate im
    if (canSendIm) {
        //can inititate im based on pbx state
        if (canSelect || (!canSelect && im_can_send_in_not_loggedin_state)) {
            //btnsendImInMakeCallDialog
            $("#btnsendImInMakeCallDialog").css("display", "inline-block");
            $("#hfImAgentName").val(rowData.FirstName + " " + rowData.LastName);
            $("#hfImAgentId").val(rowData.LoginID);

        } else {
            $("#btnsendImInMakeCallDialog").css("display", "none");
            
        }
    } else {
        $("#btnsendImInMakeCallDialog").css("display", "none");        
    }

}

//----------------------------------------------get skill status completed. show skill status data on grid-----------------------------
function getQueueStatusDone(data, object) {
    if (data.Skill != null) {
        var rowData = $('#favListGrid').jqGrid('getRowData', object);
        rowData.Staff = data.Skill.AgentsStaffed;
        rowData.Avail = data.Skill.AgentAvailable;
        rowData.CIQ = data.Skill.CallsInQueue;
        $('#favListGrid').jqGrid('setRowData', object, rowData);
        $("#txtNumberTrans").val(rowData.ID);
    }
}



//UI SETUP USING CONFIGURATION
function setupUI() {

    if (!ui_config_change_ui)
        return;

    $("#bodyfullscreen").css("width", ui_config_bodyfullscreen_width);

    $("#toggleFullScreen").css("display", ui_config_toggleFullScreen_display);

    if (global_toggleWallboardEnabled) {
        $("#toggleWallboard").css("display", "block");
    } else {
        $("#toggleWallboard").css("display", "none");
    }

    //global_toggleWallboardEnabled

    if (!ui_config_dnd_enabled) {
        if (ui_config_dnd_cos_wakeup_disable_type == "hide") {
            $("#dnd_link_btn").css("display", "none");
            $("#dnd_link_div").css("display", "none");
        } else {
            $("#dnd_link_btn").attr("disabled", true);
            //$("#dnd_link_div").attr("disabled", true);

            $('#dnd_link_div').children().attr('disabled', true);
            $('#dnd_link_div').css("opacity", "0.2");
            $('#dnd_link_div').css("pointer-events", "none");
        }

    }
    if (!ui_config_cos_enabled) {
        if (ui_config_dnd_cos_wakeup_disable_type == "hide") {
            $("#cos_link_btn").css("display", "none");
            $("#cos_link_div").css("display", "none");
        } else {
            $("#cos_link_btn").attr("disabled", true);
            //$("#cos_link_div").attr("disabled", true);
            $('#cos_link_div').children().attr('disabled', true);
            $('#cos_link_div').css("opacity", "0.2");
            $('#cos_link_div').css("pointer-events", "none");
        }

    }
    if (!ui_config_wakeup_enabled) {
        if (ui_config_dnd_cos_wakeup_disable_type == "hide") {
            $("#wakeup_link_btn").css("display", "none");
            $("#wakeup_link_div").css("display", "none");
        } else {
            $("#wakeup_link_btn").attr("disabled", true);
            // $("#wakeup_link_div").attr("disabled", true);
            $('#wakeup_link_div').children().attr('disabled', true);
            //pointer-events
            $('#wakeup_link_div').css("opacity", "0.2");
            $('#wakeup_link_div').css("pointer-events", "none");

        }

    }
    if (!ui_config_failedwakeup_enabled) {
        $("#failedwakeup_link_btn").css("display", "none");
        $("#failed_wakeup_link_div").css("display", "none");
    }
    if (!ui_config_ldap_enabled) {
        $("#ldap_link_btn").css("display", "none");
        $("#ldap_link_div").css("display", "none");
    }
    if (!ui_config_reminder_enabled) {
        $("#reminder_link_btn").css("display", "none");

    }
    if (!ui_email_enabled) {
        $("#divMainScreenServiceButtons").css("display", "none");
        $("#workbench_link_div").css("display", "none");
    } else {
        if (ui_titlebar_show_email_shortcut) {
            $("#btnMenuComposeEmail").css("display", "block");
        } else {
            $("#btnMenuComposeEmail").css("display", "none");
        }
    }

    //    var ui_config_dnd_enabled = false; //dnd_link_btn,dnd_link_div
    //    var ui_config_cos_enabled = false; //cos_link_btn,cos_link_div
    //    var ui_config_wakeup_enabled = false; //wakeup_link_btn,failedwakeup_link_btn,wakeup_link_div,failed_wakeup_link_div
    //    var ui_config_ldap_enabled = false; //ldap_link_btn,ldap_link_div
    //    var ui_config_reminder_enabled = false; //reminder_link_btn
    //    var ui_email_enabled = false; //divMainScreenServiceButtons,workbench_link_div

    //    var ui_div_to_style = "";
    //    var ui_div_middle = "";

    $("#div_top").css("float", ui_div_top_style_float);
    $("#div_middle").css("float", ui_div_middle_style_float);

    //ui_div_top_style_width
    $("#div_top").css("width", ui_div_top_style_width);
    $("#div_middle").css("width", ui_div_middle_style_width);
    //ui_div_middle_style_display
    $("#div_middle").css("display", ui_div_middle_style_display);
    //div_main_tab_extra_buttons
    //ui_div_main_tab_extra_buttons_display
    $("#div_main_tab_extra_buttons").css("display", ui_div_main_tab_extra_buttons_display);


    //hide avaya logo
    if (ui_hide_logo)
        $("#ui_tmac_logo").css("display", "none");

    if (ui_config_show_agent_details_in_titlebar) {
        $("#ui_tmac_agent_details").css("display", "none");
    }

    //resize the window
    if (ui_change_size) {
        window.resizeTo(ui_window_width, ui_config_window_height);
    }

    //add wallboard as a tab
    if (ui_add_wallboard_as_tab)
        addTab("Wallboard", "divMainScreenWallboardHead", "divMainScreenWallboard", true, false);

    //set the main div height
    $("#div_main_div").css("height", ui_config_main_div_height);

    //div_ui_agent_scripts
    if (!ui_agent_script_enabled) {
        $("#div_ui_agent_scripts").css("display", "none");
    }

    //div_ui_fax_compose
    if (!ui_fax_enabled) {
        $("#div_ui_fax_compose").css("display", "none");
    }

    if (!ui_config_show_sms_compose) {
        $("#div_ui_sms_compose").css("display", "none");
    } else {
        if (ui_titlebar_show_sms_shortcut)
            $("#btnMenuComposeSMS").css("display", "block");
        else
            $("#btnMenuComposeSMS").css("display", "none");
    }


    if (!ui_enable_crm_config) {
        $("#div_crm_config").css("display", "none");
    }

    //title bar size
    //$("#divMainScreenTitleBar .btn-group a").css("height","50px"); 

    if (ui_tmac_change_titlebar_style) {
        $("#divMainScreenTitleBar .btn-group a").css("font-size", ui_tmac_titlebar_fontsize);
        $("#divMainScreenTitleBar .btn-group a span").css("font-size", ui_tmac_titlebar_fontsize);
        $("#divMainScreenTitleBar .btn-group a").css("padding-top", ui_tmac_titlebar_paddingtop);
        $("#divMainScreenTitleBar .btn-group a").css("height", ui_tmac_titlebar_height);
    }

    if (ui_tmac_remove_titlebar_reminderbutton_label) {
        $("#reminder_link_btn span").html("&nbsp;");
    }
    if (ui_tmac_remove_titlebar_backoffice_label) {
        $("#ldap_link_btn span").html("&nbsp;");
    }


    //tmac_ui_tmac_tabs_top
    $("#tmac_tabs").css("top", tmac_ui_tmac_tabs_top);

    try {
        if (tmac_ui_show_wallboard_main) {
            $("#div_wallboard_main").css("display", "block");
            $("#div_wallboard_main_table").css("width", "25%");
        } else {
            $("#div_wallboard_main").css("display", "none");
            $("#div_wallboard_main_table").css("width", "0px");
            
        }
    } catch (e) {

    }


    try {
        if (!tmac_supervisor_window_enabled) {
            $("#supervisor_link_div").css("display", "none");
            $("#supervisor_link_btn").css("display", "none");
        }
    } catch (e) {

    }
}


//show/hide features for voice tab
function configure_voice_tab(intid) {

    //check if ui dynamic config is supported
    if (!ui_config_change_ui)
        return;

    //show/hide intent
    if (!ui_config_show_voice_intent) {
        $("#ui_div_voice_intent" + intid).css("display", "none");
    }

    //show/hide history
    if (!ui_config_show_voice_history) {
        //ui_div_voice_history_INTID
        $("#ui_div_voice_history" + intid).css("display", "none");
    }

    //show/hide queue time
    //ui_div_voice_queue_INTID
    if (!ui_config_show_voice_queuetime) {
        $("#ui_div_voice_queue" + intid).css("display", "none");
    }


    try {
        if (ui_show_ivr_call_data) {
            $("#divIVRCallData" + intid).css("visibility", "visible");
            $("#divIVRCallData" + intid).css("display", "block");
        } else {
            $("#divIVRCallData" + intid).css("display", "none");
            $("#divIVRCallData" + intid).css("visibility", "hidden");
        }
    } catch (e) {

    }


    try {
        //ui_div_workcode_display
        //div_workcode_INTID
        $("#div_workcode" + intid).css("display", ui_div_workcode_display);

    } catch (e) {

    }


    try {
        //ui_div_callcontrolbox_position
        //div_callcontrolbox_INTID
        $("#div_callcontrolbox" + intid).css("position", ui_div_callcontrolbox_position);
        $("#div_callcontrolbox" + intid).css("left", ui_div_callcontrolbox_left);
        $("#div_callcontrolbox" + intid).css("top", ui_div_callcontrolbox_top);
        
        //div_call_control_container_INTID
        if (ui_div_callcontrolbox_position == "fixed") {
            $("#div_call_control_container" + intid).removeClass();
        }

    } catch (e) {

    }

    //min-call-toolbar-image
    if (ui_div_callcontrolbox_change_button_size) {
        $("#div_callcontrolbox" + intid + " .min-call-toolbar-image").css("width", ui_div_callcontrolbox_button_size);
        $("#div_callcontrolbox" + intid + " .min-call-toolbar-image").css("height", ui_div_callcontrolbox_button_size);
        $("#div_callcontrolbox" + intid + " .min-call-toolbar-image").css("background-size", ui_div_callcontrolbox_button_size + " " + ui_div_callcontrolbox_button_size);
        //.min-call-toolbar-a
        //$("#div_callcontrolbox" + intid + " .min-call-toolbar-a").css("border-bottom-color", "transparent!important");
    }


    try {
        createTransferDropdown(intid);
    } catch (e) {

    }

    try {
        if (ui_div_queuetime_change_style) {
            $("#ui_div_voice_queue" + intid).css("position", ui_div_queuetime_position);
            $("#ui_div_voice_queue" + intid).css("left", ui_div_queuetime_left);
            $("#ui_div_voice_queue" + intid).css("top", ui_div_queuetime_top);
            $("#ui_div_voice_queue" + intid).css("color", ui_div_queuetime_color);
        }
    } catch (e) {

    }


    try {

        $("#div_ivr_extradata" + intid).css("display", ui_div_ivr_extradata_display);

    } catch (e) {

    }
    //ui_div_callcontrolbox_button_size


    if (ui_cc_show_tpin) {
        $("#btnTPINTrans" + intid).css("display", "block");
    }
    else {
        $("#btnTPINTrans" + intid).css("display", "none");
    }

    if (ui_cc_show_otp) {
        $("#btnOtpTrans" + intid).css("display", "block");
    }
    else {
        $("#btnOtpTrans" + intid).css("display", "none");
    }

    if (ui_cc_show_ivr) {
        $("#btnIVRTrans" + intid).css("display", "block");
    }
    else {
        $("#btnIVRTrans" + intid).css("display", "none");
    }

    if (ui_cc_show_mainmenu) {
        $("#btnMainmenuTrans" + intid).css("display", "block");
    }
    else {
        $("#btnMainmenuTrans" + intid).css("display", "none");
    }


    try {
        $("#div_ivr_extradata" + intid).css("position", tmac_ui_div_ivr_extradata_position);
        $("#div_ivr_extradata" + intid).css("top", tmac_ui_div_ivr_extradata_top);
        $("#div_ivr_extradata" + intid).css("left", tmac_ui_div_ivr_extradata_left);
    } catch (e) {

    }


    try {
        if (!tmac_voice_tab_show_icon) {
            $("#ui_div_voice_tab_head_left" + intid).css("background", "none");
            $("#divCustomerName" + intid).css("padding-left", "0px");
        }
    } catch (e) {

    }
}

function open_voice_tab_data_window(event) {

    /*
    //2016-04-19
    if (event.EventName == "OutgoingCallEvent") {
        if (last_camp_call_data != null && last_camp_call_data.enabled == 1) {
            //open campaing url
            //loadIFrame("iframe_GenericTab" + event.InteractionID, url);
          
            //            loadIFrame("iframe_CustomerDataVoiceTab" + event.InteractionID, last_camp_call_data.url);
            //            var as = "https://202.150.214.54/SurveyApplicationNew/Survey/?agentid=" + global_AgentID + "&intentname=" + last_camp_call_data.queueitemdata.Data +
            //			 "&customerid=" + last_camp_call_data.queueitemdata.ID + "&callid=" + global_AgentID + "_" + event.InteractionID;
            //            alert(as);

            //            window.open(as, global_AgentID + "_" + event.InteractionID, "menubar=no,location=no,scrollbars=no,width=" + screen.width + ",height=" + (screen.availHeight - 33));

            //            last_camp_call_data = null;
            return;
        }
    }*/

    if (open_voice_datawindow_enabled) {
      
        //commonui.js
        openVoiceTabServiceWindow(event.InteractionID, event.PhoneNumber, event);
        
    } else {
        //divServiceWindowContainerDiv_INTID
        $("#divServiceWindowContainerDiv" + event.InteractionID).css("display", "none");
    }
}


var toggleToLeft = false;
function hideWallboardPanel() {
    //ui_div_top_style_width

    if (toggleToLeft) {
        toggleToLeft = false;
        $("#div_top").css("width", ui_div_top_style_width);
        $("#div_middle").css("width", ui_div_middle_style_width);
        $("#div_middle").css("display", "block");

        $("#toggleWallboard i").removeClass();
        //fa fa-chevron-left fa-1x
        $("#toggleWallboard i").addClass("fa fa-chevron-left fa-1x");

    } else {
        toggleToLeft = true;
        $("#div_top").css("width", "100%");
        $("#div_middle").css("width", "0");

        $("#div_middle").css("display", "none");

        $("#toggleWallboard i").removeClass();
        //fa fa-chevron-left fa-1x
        $("#toggleWallboard i").addClass("fa fa-chevron-right fa-1x");
    }
}


function openTextWorkQueue() {
    openTextWorkBench();
    //window.open(tmac_utils_url + "Queue.aspx?AgentID=" + global_AgentID);
}

var text_workbench;
//open workbench window
function openTextWorkBench() {

    //add new tab to show workbench
    //mainUI.Js
    addTab('text_workbench', 'divTexWorkBenchHeader', 'divTexWorkBenchBody', true);


    //set the tab header name
    //set tab header details
    var tabName = 'Text Queue';

    $('#divCustomerName' + 'text_workbench').text(tabName);

    //show close button
    try {
        setCallControlStatus('text_workbench', false, false, false, false, false, false, true);
    }
    catch (e) { }


    //902 = work bench

    //var intid = 902;
    //load the serviceWindow.html into iframe
    var url = tmac_utils_url + "Queue.aspx?AgentID=" + global_AgentID; // "workbench.htm";
    loadIFrame("iframe_TexWorkBench" + "text_workbench", url);

    //add this iframe to iframe list
    text_workbench = document.getElementById("iframe_TexWorkBench" + "text_workbench").contentWindow;
}




function loadWallboardPop(data, currentStat) {

    var tp = '<div id="wbdropdown"  class="list-group" style="width:600px;" onmousedown="return false;">' +
            $("#divMainScreenWallboard").html() +
            '</div>';

    $("#ui_tmac_agent_details").attr('data-content', tp);
}


var lastWallboardData = null;

function bindWalloardPop() {
    if (lastWallboardData != null)
        loadWallboardGrid_pop(lastWallboardData);
}

function loadWallboardGrid_pop(skills) {
    lastWallboardData = skills;
    var grid = $('#wallboardGrid_pop');
    var currentPage = grid.getGridParam('page');
    if (currentPage == undefined || currentPage < 1)
        currentPage = 1;


    var scrollPos = grid.closest(".ui-jqgrid-bdiv").scrollTop();

    $('#wallboardGrid_pop').jqGrid('GridUnload');

    $("#wallboardGrid_pop").jqGrid({
        caption: '',
        data: skills,
        datatype: 'local',
        colNames: ['Skill', 'Stf', 'Avl', 'CIQ'],
        colModel: [
                    { name: 'SkillName', index: 'SkillName', width: 150 },
                    { name: 'AgentsStaffed', index: 'Code', width: 30 },
                    { name: 'AgentAvailable', index: 'Value', width: 30 },
                    { name: 'CallsInQueue', index: 'Display', width: 30 }
                ],
        pager: '#pager-wallboardGrid_pop',
        rowNum: 10,
        rowList: [10], //[10, 50, 100],
        sortname: 'SkillName',
        sortorder: 'asc',
        autowidth: false,
        shrinkToFit: true,
        localReader: { repeatitems: true },
        height: ui_config_change_ui ? ui_config_wallboard_height : 500, //500
        loadonce: true
    });

    $('#wallboardGrid_pop').trigger('reloadGrid', [{ page: currentPage}]);
    grid = $('#wallboardGrid_pop');
    grid.closest(".ui-jqgrid-bdiv").scrollTop(scrollPos);

}


function loadWallboardGrid_main(skills) {
    //lastWallboardData = skills;
    var grid = $('#wallboardGrid_main');
    var currentPage = grid.getGridParam('page');
    if (currentPage == undefined || currentPage < 1)
        currentPage = 1;


    var scrollPos = grid.closest(".ui-jqgrid-bdiv").scrollTop();

    $('#wallboardGrid_main').jqGrid('GridUnload');

    $("#wallboardGrid_main").jqGrid({
        caption: '',
        data: skills,
        datatype: 'local',
        colNames: ['Skill', 'Stf', 'Avl', 'CIQ'],
        colModel: [
                   { name: 'SkillName', index: 'SkillName', width: 160 },
                    { name: 'AgentsStaffed', index: 'Code', width: 40 },
                    { name: 'AgentAvailable', index: 'Value', width: 40 },
                    { name: 'CallsInQueue', index: 'Display', width: 40 }
                ],
        pager: '#pager-wallboardGrid_main',
        rowNum: 10,
        rowList: [10], //[10, 50, 100],
        sortname: 'SkillName',
        sortorder: 'asc',
        autowidth: true,
        shrinkToFit: false,
        localReader: { repeatitems: true },
        height: ui_config_change_ui ? ui_config_wallboard_height : 500, //500
        loadonce: true
    });

    $('#wallboardGrid_main').trigger('reloadGrid', [{ page: currentPage}]);
    grid = $('#wallboardGrid_main');
    grid.closest(".ui-jqgrid-bdiv").scrollTop(scrollPos);

}


function tmac_im_send(toagent, messageid) {
    var message = $("#txt_im_" + messageid).val();
    $("#div_im_reply" + messageid).css("display", "none");

    var agentname = toagent;

    try {
        var toagentObj = $.grep(global_AgentList, function (e) { return e.LoginID == toagent; });
        agentname = toagentObj[0].FirstName + " " + toagentObj[0].LastName;
    } catch (e1) {

    }

    tmac_SendIMToAgent("tmac_im_sendDone", agentname + ":" + message, toagent, message);
}

function tmac_im_sendDone(data, message) {
    //var div = '<div>Me:' + message + '</div>';

    $("#tmac_im_main_div").css("display", "block");
    tmac_im_show_hide();
    var div = '   <div style="border-top: 1px solid #ccc;  margin-top: 3px;"><span style="color: blue;font-weight: bold">Me -> </span>' + message + '</div>';
    $("#tmac_im_data_div").html($("#tmac_im_data_div").html() + div);
}


function tmac_im_send_data(toagent, message) {

    var agentname = toagent;

    try {
        var toagentObj = $.grep(global_AgentList, function (e) { return e.LoginID == toagent; });
        agentname = toagentObj[0].FirstName + " " + toagentObj[0].LastName;
    } catch (e1) {

    }

    tmac_SendIMToAgent("tmac_im_send_dataDone", agentname + ":" + message, toagent, message);
}

function tmac_im_send_dataDone(data, message) {

    //var div = '<div>Me:' + message + '</div>';
    $("#tmac_im_main_div").css("display", "block");
    tmac_im_show_hide();
    
  
    var div = '   <div style="border-top: 1px solid #ccc;  margin-top: 3px;"><span style="color: blue;font-weight: bold">Me -> </span>' + message + '</div>';
    
    $("#tmac_im_data_div").html($("#tmac_im_data_div").html() + div);
}

function tmac_im_show_hide() {
    
        $("#tmac_im_data_div").css("height", "180px");
        var sh = $("#tmac_im_data_div").scrollHeight;

        $("#tmac_im_data_div").scroll(sh);
		$("#OpenMssenger").css("display", "none");
    
    //tmac_im_data_div
}

function tmac_im_show_hide_main() {
    /*if ($("#tmac_im_data_div").height() != "0") {
        $("#tmac_im_data_div").css("height", "0px");
    } else {
        $("#tmac_im_data_div").css("height", "180px");
    }*/
	
	// Hide the Messenger and make Messenger Icon visible
	 $("#tmac_im_main_div").css("display", "none");
    $("#OpenMssenger").css("display", "block");
    //tmac_im_data_div
}

function tmac_im_show_reply_div(id) {
    $("#div_im_reply" + id).css("display", "block");
}

function OpenMessenger() {
	// Make visible Messenger and hide IM Icon
    $("#tmac_im_main_div").css("display", "block");
    $("#OpenMssenger").css("display", "none");

}



//-----------------------------------------------dial a call using existing tab------------------------------------------------
function makeCallFromInteraction(intid) {

    var phone = $("#hf_voice_phone" + intid).val();
    if (!tmac_interaction_makecall_autodial) {
        try {
            openMakeCallDialog(phone);
        } catch (e) {

        }
        return;
    }
    
    if (phone === "" || phone === undefined) {
        return;
    }
    
    MakeCall(global_DeviceID, phone, "customMakeCall", intid);

}


 

function im_initiate_message() {

    try {


        //hide make call dialog
        closeMakeCallDialog();
        $("#btnsendImInMakeCallDialog").css("display", "none");
        

        var toAgentName = $("#hfImAgentName").val();
        var toAgent = $("#hfImAgentId").val();
        if (toAgent == undefined || toAgent == "") {
            return;
        }

        tmac_im_id = tmac_im_id + 1;
      
        var div = ' <div>' +
            ' <div style="border-top: 1px solid #ccc;  margin-top: 3px;">' +
            '   <span style="color: green;font-weight: bold">' + toAgentName + ' :</span> ' +
            ' </div>' +
            ' <div style="display:block;"  id="div_im_reply' + tmac_im_id + '">' +
            '      <textarea id="txt_im_' + tmac_im_id + '" rows="2" style="width: 100%;"></textarea>' +
            '       <button type="button" onclick="tmac_im_send(' + toAgent + ',' + tmac_im_id + ');" value="Send" class="btn btn-success" style="width: 100%;height: 25px;">Send</button>' +
            '        </div>' +
            ' </div>';
        //alertMessageDialog(event.FromAgentName + " says:" + event.Message, "danger");
        $("#tmac_im_main_div").css("display", "block");
        tmac_im_show_hide();
        $("#tmac_im_data_div").html($("#tmac_im_data_div").html() + div);

        //create IM ui

    } catch(e) {
    }
}



function loadAccessRoleBasedUi() {

    //agent only
    //agent+cherry pick
    //agent+supervisor
    //agent+supervisor+cherry pick

    if (accessRole == "AgentSuperCherry") {
        $("#supervisor_link_div").css("display", "block");
        $("#supervisor_link_btn").css("display", "block");

        $("#cherrypick_link_div").css("display", "block");
        $("#cherrypick_link_btn").css("display", "block");
    }
    else if (accessRole == "AgentSuper") {
        $("#supervisor_link_div").css("display", "block");
        $("#supervisor_link_btn").css("display", "block");

        $("#cherrypick_link_div").css("display", "none");
        $("#cherrypick_link_btn").css("display", "none");
    }
    else if (accessRole == "AgentCherry") {
        $("#supervisor_link_div").css("display", "none");
        $("#supervisor_link_btn").css("display", "none");

        $("#cherrypick_link_div").css("display", "block");
        $("#cherrypick_link_btn").css("display", "block");

    }
    else if (accessRole == "Agent") {

        $("#supervisor_link_div").css("display", "none");
        $("#supervisor_link_btn").css("display", "none");

        $("#cherrypick_link_div").css("display", "none");
        $("#cherrypick_link_btn").css("display", "none");
    }
}

function showDefaultTitleBar() {

    try {
        document.title = global_AgentID + "/" + global_DeviceID + " - " + global_AgentName;
    } catch (e) {

    }
}


var externalPopWindow;
function checkPageFocus(msg) {

    try {
        if (document.hasFocus()) {
            showDefaultTitleBar();

        } else {

            document.title = msg;
            var w = 400;
            var h = 200;
            var left = (screen.width) - (w);
            var top = (screen.height - 33) - (h);
            externalPopWindow = window.open("", "_blank", 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);

            externalPopWindow.document.write("<p>" + msg + "</p>");
            setTimeout(function () {
                externalPopWindow.close();
            }, 10000);
        }
    } catch (e) {

    }
}