﻿var version_tmac_connect_protocol = "3.1.08.0805";

$.holdReady(true);

function getQueryStringValue(key) {
    return unescape(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + escape(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}

var tmacconnectprotocol = "asmx"; //asmx , webapi , ws
var tmac_send_protocol_to_popup = false;
var protocol = getQueryStringValue("protocol");

if (protocol != "") {
    if (protocol == "ws" || protocol == "webapi" || protocol == "asmx") {
        window.tmacconnectprotocol = protocol;
        tmac_send_protocol_to_popup = true;
    }
}
//alert("prot:" + window.tmacconnectprotocol);
loadingCompleted = true;
$.holdReady(false);


//this is the first document.ready to load
$(document).ready(function () {
    console.log('tmac connect protocols loaded');

});

var tmac_websock;
var tmac_websock_url = 'ws://localhost:10029/';
var tmac_websock_isopen = false;
var tmac_websock_opening = false;
var tmac_websock_method_call_objects = {};
var tmac_websock_method_call_id = 0;
var tmac_websock_autoconnect = false;

var tamc_webapi_url = "http://localhost:11141/api/TMAC/ProcessCommand";

var tmac_authcode = "samansmanasamanamsanamnsmanasmana";

var tmac_local_auth = true;
var tmac_wss_urls_for_local_auth = "wss://43.245.61.180:25002/,ws://43.245.61.180:25003/";

var tmac_asmx_url_list = ("https://w01gccreapp1a.reg1.1bank.dbs.com:444/Tetherfi_TMACProxy_IN/TmacProxy.asmx/,https://w01gccreapp2a.reg1.1bank.dbs.com:444/Tetherfi_TMACProxy_IN/TmacProxy.asmx/").split(',');
