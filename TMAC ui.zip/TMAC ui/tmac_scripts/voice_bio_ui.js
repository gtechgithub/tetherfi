﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "VoiceBioUI.js";
var file_version = "3.1.07.18";
var changedBy = "Sirajuddin"
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}

//-------------------------------------------------EVENTS--------------------------------------------------------------------
function VoiceBioInteraction(event) {
    try {
        let intid = event.InteractionID;
        let nric = event.Item.CustomerIdentifier;

        //set NRIC/Personal ID/CIN
        if (nric == "")
            $("#e_Nric" + intid).html('<span class="uk-text-danger uk-text-bold">NA</span>');
        else
            isDummyVBData ? $("#e_Nric" + intid).text(dummyNRIC) : $("#e_Nric" + intid).text(nric);
        //$("#e_Nric" + intid).text(nric)

        //append phone number for both screens
        isDummyVBData ? $("#e_Cli" + intid).text(dummyCLI) : $("#e_Cli" + intid).text(event.Item.PhoneNumber);
        isDummyVBData ? $("#v_Cli" + intid).text(dummyCLI) : $("#v_Cli" + intid).text(event.Item.PhoneNumber);
        //$("#e_Cli" + intid).text(event.Item.PhoneNumber);
        //$("#v_Cli" + intid).text(event.Item.PhoneNumber)

        //add loader div as the UI changes happen in vb status event
        $(".an-loader").removeClass("uk-display-none");

        //enable the enroll button if the manual verified checkbox is checked and vb status is enough audio
        $('#manualVarified' + intid).change(function () {
            if (this.checked === true) {
                $("#btnEnroll" + intid).removeClass("disabled");
            } else
                $("#btnEnroll" + intid).addClass("disabled");
        });
        //updating NRIC on enter key for enrollment screen CIN input
        $("#e_Nric_text" + intid).keypress(function (e) {
            var nric = this.value + e.key;
            if (e.keyCode == 13) {
                if ($('#e_Nric_text' + intid).val().toLowerCase() == GetVBReferenceObj(global_activeTabInteractionID).customerIdentifier.toLowerCase()) {
                    log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction(): e_Nric_text on keypress event", "Entered NRIC is similar", true);
                    return false;
                }
                var nric = this.value;
                if (nric.length == 9) {
                    var patt = /^[a-zA-Z]+[0-9]{7}[$A-Za-z]+/g;
                    var res = patt.test(nric);
                    if (res) {
                        setTimeout(function () {
                            let nric = $('#e_Nric_text' + intid).val();
                            UpdateVBNric(intid, nric);
                        }, 100);
                    }
                    else {
                        log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction(): e_Nric_text on keypress event", "Entered NRIC is invalid", true);
                    }
                }
                else {
                    log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction(): e_Nric_text on keypress event", "Entered NRIC is invalid", true);
                }
                return false;
            }
        });
        $("#v_Nric_text" + intid).keypress(function (e) {
            var nric = this.value + e.key;
            if (e.keyCode == 13) {
                if ($('#v_Nric_text' + intid).val().toLowerCase() == GetVBReferenceObj(global_activeTabInteractionID).customerIdentifier.toLowerCase()) {
                    log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction(): e_Nric_text on keypress event", "Entered NRIC is similar", true);
                    return false;
                }
                var nric = this.value;
                if (nric.length == 9) {
                    var patt = /^[a-zA-Z]+[0-9]{7}[$A-Za-z]+/g;
                    var res = patt.test(nric);
                    if (res) {
                        setTimeout(function () {
                            let nric = $('#v_Nric_text' + intid).val();
                            UpdateVBNric(intid, nric);
                        }, 100);
                    }
                    else {
                        log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction(): e_Nric_text on keypress event", "Entered NRIC is invalid", true);
                    }
                }
                else {
                    log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction(): e_Nric_text on keypress event", "Entered NRIC is invalid", true);
                }
                return false;
            }
        });
        //save the reference
        SaveVBReference(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction()", ex, false);
    }
}


function VoiceBioCallConnected(event) {
    try {
        $(".an-loader").addClass("uk-display-none");
        $("#div_enrollment" + event.InteractionID).css("pointer-events", "none");
        $("#div_enrollment" + event.InteractionID).parent().css("cursor", "not-allowed");
        $("#div_enrollment" + event.InteractionID).removeClass("uk-display-none");

        $("#btnReject" + event.InteractionID).addClass("disabled");
        $("#btnThirdParty" + event.InteractionID).addClass("disabled");
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.VoiceBioCallConnected()", ex, false);
    }
}
function VoiceBioCallDisconnected(event) {
    try {
        //if the loader is shown and call disconencted before vb status event then hide loader and close tab
        $(".an-loader").addClass("uk-display-none");
        //close the interaction tab
        CloseUITab(event.InteractionID, false);
        //remove the reference
        RemoveVBReference(event.InteractionID);
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.VoiceBioCallDisconnected()", ex, false);
    }
}
function VoiceBioStatusChange(event) {
    try {
        //Based on data, change the labels and buttons
        let intid = event.InteractionID;
        //custom json data
        let data = JSON.parse(event.JsonData)[0];
        if (extraLogs.VoiceBioEvents)
            log.LogDetails("Error", "VoiceBioUI.VoiceBioStatusChange()", JSON.stringify(data), false);
        if (data.sessionId != "" && data.resultCode != "SYS_ERROR") {
            let sessionData = data.sessionData;
            //vb reference is removed after call disconnect, post disconnect vb events are rejected
            if (GetVBReferenceObj(intid) !== undefined) {
                //once the session found then remove the grey background and enable the div
                $("#div_enrollment" + intid).css("pointer-events", "all");
                $("#div_enrollment" + intid).parent().css("cursor", "auto");
                $("#card_enrollment" + intid).removeClass("md-bg-grey-400");
                //disable reject and third party button if the NRIC is empty
                if (sessionData.identifier == "") {
                    $("#btnReject" + intid).addClass("disabled");
                    $("#btnThirdParty" + intid).addClass("disabled");
                }
                if (data.enrolStatus !== undefined && data.enrolStatus.status == "NOT_ENROLED") {
                    //show enrollment screen
                    $("#div_verification" + intid).addClass("uk-display-none");
                    $("#div_enrollment" + intid).removeClass("uk-display-none");
                    if (GetVBReferenceObj(intid).notEnrolled === voiceBioNoficationLimit.notEnrolled) {
                        //show notification if the tmac not in focus
                        ShowNotification("Enroll Status", "No");
                        //update the reference
                        ++GetVBReferenceObj(intid).notEnrolled;
                    }
                    //set vb enroll status to "NO" and make the label red
                    if (!GetVBReferenceObj(intid).isEnrolled && !GetVBReferenceObj(intid).isOptedOut) {
                        $("#vb_enroll_status" + intid).removeClass("uk-badge-success");
                        $("#vb_enroll_status" + intid).removeClass("uk-badge-warning");
                        $("#vb_enroll_status" + intid).addClass("uk-badge-danger");
                        $("#vb_enroll_status" + intid).text("NO");
                    }
                    //set NRIC
                    isDummyVBData ? $("#e_Nric" + intid).text(dummyNRIC) : $("#e_Nric" + intid).text(sessionData.identifier);
                    //$("#e_Nric" + intid).text() == "" ? $("#e_Nric" + intid).text(sessionData.identifier) : "";

                    //set if the enroll VB status is "ENOUGH_AUDIO" and make the label green
                    if (data.enrolAudioStatus !== undefined && data.enrolAudioStatus.status == "ENOUGH_AUDIO") {
                        if (GetVBReferenceObj(intid).enoughAudio === voiceBioNoficationLimit.enoughAudio) {
                            // Enable reject and third party button on enough audio 
                            $("#btnReject" + intid).removeClass("disabled");
                            $("#btnThirdParty" + intid).removeClass("disabled");
                            //show notification if the tmac not in focus
                            ShowNotification("VB Status", "Enough Audio");
                            //update the reference
                            ++GetVBReferenceObj(intid).enoughAudio;
                        }
                        //enable checkbox only if the nric is not empty
                        if (sessionData.identifier != "" && !GetVBReferenceObj(intid).isEnrolled)
                            $("#manualVarified" + intid).removeAttr("disabled", "disabled");
                        $("#vb_status" + intid).removeClass("uk-badge-info");
                        $("#vb_status" + intid).addClass("uk-badge-success");
                        $("#vb_status" + intid).text("Enough Audio")
                    }
                    else if (data.enrolAudioStatus !== undefined && data.enrolAudioStatus.status == "IN_PROGRESS") {
                        $("#vb_status" + intid).removeClass("uk-badge-success");
                        $("#vb_status" + intid).addClass("uk-badge-info");
                        $("#vb_status" + intid).text("Collecting Audio")
                    }
                    //check if this caller is rejected before
                    let rejectCount = 0;
                    let lastValue = "";
                    let lastRejectDateTime = "";
                    $.each(data.sessionHistory, function (i, val) {
                        if (val.type == "session-enrol-request") {
                            if (val.value == "accept") {
                                return false;
                            }
                            if (val.value == "decline") {
                                if (rejectCount === 1)
                                    return true;
                                else
                                    return false;
                            }
                            else if (val.value == "delete") {
                                //set vb enroll status to "OPT-OUT" and make the label orange
                                if (rejectCount === 0 && !GetVBReferenceObj(global_activeTabInteractionID).isEnrolled) {
                                    $("#vb_enroll_status" + intid).removeClass("uk-badge-success");
                                    $("#vb_enroll_status" + intid).removeClass("uk-badge-danger");
                                    $("#vb_enroll_status" + intid).addClass("uk-badge-warning");
                                    $("#vb_enroll_status" + intid).html("Opted Out on <br/>" + moment(val.dateTime, "YYYY-MMM-DDTHH:mm:ss.SSSZ").format("DD MMM YYYY HH:mm"));
                                    return false;
                                }
                            }
                        }
                        else if (val.type == "reasonForNonEnrolment") {
                            if (val.value == "userDeclined") {
                                ++rejectCount;
                                lastValue = "userDeclined";
                                lastRejectDateTime = moment(val.dateTime, "YYYY-MMM-DDTHH:mm:ss.SSSZ").format("DD MMM YYYY HH:mm");
                                return true;
                            }
                            else if (val.value == "thirdParty") {
                                lastValue = "thirdParty";
                                return false;
                            }
                        }
                    });
                    //append if rejected once/twice
                    if (!GetVBReferenceObj(intid).isEnrolled) {
                        if (rejectCount == 1) {
                            $("#declined" + intid).removeClass("uk-text-primary");
                            $("#declined" + intid).addClass("uk-text-warning");
                            $("#declined" + intid).text("Once");

                            $("#vb_declined_date" + intid).removeClass("uk-badge-primary");
                            $("#vb_declined_date" + intid).addClass("uk-badge-warning");
                            $("#vb_declined_date" + intid).text(lastRejectDateTime);
                        }
                        else if (rejectCount == 2) {
                            $("#declined" + intid).removeClass("uk-text-primary");
                            $("#declined" + intid).addClass("uk-text-danger");
                            $("#declined" + intid).text("Twice (Don't offer)");

                            $("#vb_declined_date" + intid).removeClass("uk-badge-primary");
                            $("#vb_declined_date" + intid).addClass("uk-badge-danger");
                            $("#vb_declined_date" + intid).text(lastRejectDateTime);
                            DisableAllVBButtons();
                            if (GetVBReferenceObj(intid).rejectedTwice === voiceBioNoficationLimit.rejectedTwice) {
                                ShowNotification("Rejected", "Enrollment has been rejected twice");
                                ++GetVBReferenceObj(intid).rejectedTwice;
                            }
                        }
                    }
                    if (GetVBReferenceObj(intid).isThirdParty) {
                        $("#manualVarified" + global_activeTabInteractionID).attr("disabled", "disabled");
                    }
                }
                else if (data.enrolStatus !== undefined && data.enrolStatus.status == "ENROLED" && !GetVBReferenceObj(global_activeTabInteractionID).isEnrolled) {
                    //show verification screen
                    $("#div_enrollment" + intid).addClass("uk-display-none");
                    $("#div_verification" + intid).removeClass("uk-display-none");

                    if (!GetVBReferenceObj(intid).isOptedOut) {
                        //set vb enroll status to "YES" and make the label green
                        $("#vb_enroll_status" + intid).removeClass("uk-badge-warning");
                        $("#vb_enroll_status" + intid).removeClass("uk-badge-danger");
                        $("#vb_enroll_status" + intid).addClass("uk-badge-success");
                        $("#vb_enroll_status" + intid).text("YES");
                    }

                    //set NRIC
                    isDummyVBData ? $("#v_Nric" + intid).text(dummyNRIC) : $("#v_Nric" + intid).text(sessionData.identifier);
                    //$("#v_Nric" + intid).text() == "" ? $("#v_Nric" + intid).text(sessionData.identifier) : "";

                    if (GetVBReferenceObj(intid).enrolled === voiceBioNoficationLimit.enrolled) {
                        //show notification if the tmac not in focus
                        ShowNotification("Enroll Status", "Yes");
                        //update the reference
                        ++GetVBReferenceObj(intid).enrolled;
                    }
                    //not verified
                    if (data.authenticationStatus !== undefined && data.authenticationStatus.status == "NOT_AUTHENTICATED") {
                        //disable opt out button 
                        $("#btnDeleteEnrollment" + intid).addClass("uk-disable-i");
                        //change the icon to cross
                        $("#verified_icon" + intid).html("clear");
                        //change the color of icon to red by removing if green so
                        $("#verified_icon" + intid).removeClass("md-color-green-700");
                        $("#verified_icon" + intid).addClass("md-color-red-700");
                        //change the color of div to red by removing green or grey if so
                        $("#card_verification" + intid).removeClass("md-bg-grey-700");
                        $("#card_verification" + intid).removeClass("md-bg-green-700");
                        $("#card_verification" + intid).addClass("md-bg-red-700");
                        if (GetVBReferenceObj(intid).enoughAudio === voiceBioNoficationLimit.enoughAudio) {
                            //show notification if the tmac not in focus
                            ShowNotification("VB Verified", "No", "voice_bio_failed");
                            //update the reference
                            ++GetVBReferenceObj(intid).enoughAudio;
                        }
                    }
                    //verified
                    else if (data.authenticationStatus !== undefined && data.authenticationStatus.status == "AUTHENTICATED") {
                        //enable opt out button
                        $("#btnDeleteEnrollment" + intid).removeClass("uk-disable-i");
                        //change the icon to done
                        $("#verified_icon" + event.InteractionID).html("done");
                        //change the color of icon to green by removing if red so
                        $("#verified_icon" + intid).removeClass("md-color-red-700");
                        $("#verified_icon" + intid).addClass("md-color-green-700");
                        //change the color of div to green by removing red or grey if so
                        $("#card_verification" + intid).removeClass("md-bg-grey-700");
                        $("#card_verification" + intid).removeClass("md-bg-red-700");
                        $("#card_verification" + intid).addClass("md-bg-green-700");
                        if (GetVBReferenceObj(intid).authenticated === voiceBioNoficationLimit.authenticated) {
                            //show notification if the tmac not in focus
                            ShowNotification("VB Verified", "Yes", "voice_bio_success");
                            //update the reference
                            ++GetVBReferenceObj(intid).authenticated;
                        }
                    }
                    //append last enrolled time if present
                    $.each(data.sessionHistory, function (i, val) {
                        if (val.type == "session-enrol-request" && val.value == "accept") {
                            let dateTime = moment(val.dateTime, "YYYY-MMM-DDTHH:mm:ss.SSSZ").format("DD MMM YYYY HH:mm");
                            $("#last_enrolled" + intid).text(dateTime);
                            return false;
                        }
                    });
                }
            }
            else {
                log.LogDetails("Error", "VoiceBioUI.VoiceBioStatusChange()", "VB reference not found", false);
            }
        }
        else if (data.resultCode == "ValidSoftError") {
            ShowNotify("Error in ValidSoft Connection", "danger", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.VoiceBioStatusChange()", ex, false);
    }
}
//---------------------------------------------------------------------------------------------------------------------------

//-------------------------------------------------CALL METHODS--------------------------------------------------------------
function CheckAgentStaffed() {
    try {
        custom_CheckAgentStaffed();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CheckAgentStaffed()", ex, false);
    }
}
function UpdateVBNric(intid, nric) {
    try {
        $(".an-loader").removeClass("uk-display-none");
        custom_UpdateVBNric(intid, nric);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.UpdateVBNric()", ex, false);
    }
}
function EnrollCustomer(intid) {
    try {
        GetVBReferenceObj(intid).isEnrolled = true;
        custom_EnrollCustomer(intid);
        DisableButton("#btnEnroll" + intid);
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.VoiceBioStatusChange()", ex, false);
    }
}
function OptOutEnrollment(intid) {
    try {
        UIkit.modal.confirm("Are you sure this customer wants to Opt-Out?",
            function () {
                GetVBReferenceObj(intid).isOptedOut = true;
                custom_OptOutEnrollment(intid);
                DisableButton("#btnDeleteEnrollment" + intid);
            });
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.OptOutEnrollment()", ex, false);
    }
}
function RejectEnrollment(intid) {
    try {
        custom_RejectEnrollment(intid);
        DisableButton("#btnReject" + intid);
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.OptOutEnrollment()", ex, false);
    }
}
function ThirdPartyEnrollment(intid) {
    try {
        custom_ThirdPartyEnrollment(intid);
        DisableButton("#btnThirdParty" + intid);
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.ThirdPartyEnrollment()", ex, false);
    }
}
//---------------------------------------------------------------------------------------------------------------------------

//-------------------------------------------------CALL METHOD DONE----------------------------------------------------------
function CheckAgentStaffedDone(data, obj) {
    try {
        if (data == 1) {
            $(".an-loader").addClass("uk-display-none");
            Login(global_LanID, voiceBioStationId, "", false, false, "");
        }
        else {
            ShowNotify("Agent not logged in to any station, Please login to AIC", "danger", null, "top-center");
            $(".an-loader").removeClass("uk-display-none");
            setTimeout(function () { CheckAgentStaffed(); }, 3000);

        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CheckAgentStaffed()", ex, false);
    }
}
function EnrollCustomerDone(data, obj) {
    try {
        EnableButton("#btnEnroll" + global_activeTabInteractionID, '<i class="material-icons">thumb_up</i> Enroll', "tag");
        if (data != "") {
            let result = JSON.parse(data);
            if (result.resultCode == "SUCCESS") {
                GetVBReferenceObj(global_activeTabInteractionID).isEnrolled = true;
                GetVBReferenceObj(global_activeTabInteractionID).isOptedOut = false;
                ShowNotify("Customer enrolled successfully", "success", null, "top-center");
                EnrollementSuccess();
            }
            else if (result.resultCode == "ALREADY_ENROLED") {
                GetVBReferenceObj(global_activeTabInteractionID).isEnrolled = true;
                ShowNotify("Customer is already enrolled", "info", null, "top-center");
                EnrollementSuccess();
            }
            else if (result.resultCode == "SYS_ERROR") {
                GetVBReferenceObj(global_activeTabInteractionID).isEnrolled = false;
                ShowNotify("Customer Enrollment failed", "danger", null, "top-center");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.EnrollCustomerDone()", ex, false);
    }
}
function OptOutEnrollmentDone(data, obj) {
    try {
        EnableButton("#btnDeleteEnrollment" + global_activeTabInteractionID, '<i class="material-icons">delete</i>', "tag");
        if (data != "") {
            let result = JSON.parse(data);
            if (result.resultCode == "SUCCESS") {
                GetVBReferenceObj(global_activeTabInteractionID).isEnrolled = false;
                GetVBReferenceObj(global_activeTabInteractionID).isOptedOut = true;
                ShowNotify("Customer Opt-Out successfully", "success", null, "top-center");
                $("#btnDeleteEnrollment" + global_activeTabInteractionID).addClass("disabled");
                $("#btnReject" + global_activeTabInteractionID).removeClass("disabled");
                $("#btnThirdParty" + global_activeTabInteractionID).removeClass("disabled");

                //set vb enroll status to "OPT-OUT" and make the label orange
                $("#vb_enroll_status" + global_activeTabInteractionID).removeClass("uk-badge-success");
                $("#vb_enroll_status" + global_activeTabInteractionID).removeClass("uk-badge-danger");
                $("#vb_enroll_status" + global_activeTabInteractionID).addClass("uk-badge-warning");
                $("#vb_enroll_status" + global_activeTabInteractionID).html("Opted Out on <br/>" + moment(new Date()).format("DD MMM YYYY HH:mm"));

                //if the session is same and checkbox is checked then uncheck it
                if ($("#manualVarified" + global_activeTabInteractionID).is(':checked')) {
                    $("#manualVarified" + global_activeTabInteractionID).removeAttr("disabled", "disabled");
                    $("#manualVarified" + global_activeTabInteractionID).trigger("click");
                }
            }
            else if (result.resultCode == "SYS_ERROR") {
                GetVBReferenceObj(global_activeTabInteractionID).isOptedOut = false;
                ShowNotify("Customer Opt-Out failed", "danger", null, "top-center");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.OptOutEnrollmentDone()", ex, false);
    }
}
function UpdateVBNricDone(data, obj) {
    try {
        $(".an-loader").addClass("uk-display-none");
        if (data != "") {
            let result = JSON.parse(data);
            if (result.resultCode == "SUCCESS") {
                ShowNotify("NRIC updated successfully", "success", null, "top-center");
            }
            if (result.resultCode == "ALREADY_ENROLED") {
                ShowNotify("NRIC updated successfully, NRIC already enrolled", "success", null, "top-center");
            }
            else if (result.resultCode == "SYS_ERROR") {
                ShowNotify("NRIC update failed", "danger", null, "top-center");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.UpdateVBNricDone()", ex, false);
    }
}
function RejectEnrollmentDone(data, obj) {
    try {
        EnableButton("#btnReject" + global_activeTabInteractionID, '<i class="material-icons">cancel</i> Reject', "tag");
        if (data != "") {
            let result = JSON.parse(data);
            if (result.resultCode == "SUCCESS") {
                ShowNotify("Enrollment rejected successfully", "success", null, "top-center");
                DisableAllVBButtons();
            }
            else if (result.resultCode == "SYS_ERROR") {
                ShowNotify("Enrollment reject failed", "danger", null, "top-center");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.RejectEnrollmentDone()", ex, false);
    }
}
function ThirdPartyEnrollmentDone(data, obj) {
    try {
        EnableButton("#btnThirdParty" + global_activeTabInteractionID, '<i class="material-icons">transform</i> 3<sup>rd</sup> Party', "tag");
        if (data != "") {
            let result = JSON.parse(data);
            if (result.resultCode == "SUCCESS") {
                ShowNotify("Third party assigned successfully", "success", null, "top-center");
                DisableAllVBButtons();
                $("#manualVarified" + global_activeTabInteractionID).attr("disabled", "disabled");
                GetVBReferenceObj(global_activeTabInteractionID).isThirdParty = true;

            }
            else if (result.resultCode == "SYS_ERROR") {
                ShowNotify("Third party assignment failed", "danger", null, "top-center");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.ThirdPartyEnrollmentDone()", ex, false);
    }
}
//---------------------------------------------------------------------------------------------------------------------------

//-------------------------------------------------OTHER METHODS-------------------------------------------------------------
function SaveVBReference(event) {
    try {
        var vbRef = {};
        //intid
        vbRef.intid = event.InteractionID;
        //caller id
        vbRef.cli = event.Item.PhoneNumber;
        //enrolled status
        vbRef.notEnrolled = 0;
        //enrolled status
        vbRef.enrolled = 0;
        //enough audio
        vbRef.enoughAudio = 0;
        //authenticated
        vbRef.authenticated = 0;
        //not authenticated
        vbRef.notAuthenticated = 0;
        //rejected twice
        vbRef.rejectedTwice = 0;
        //is the customer enrolled
        vbRef.isEnrolled = false;
        //is the customer optedout
        vbRef.isOptedOut = false;
        //is the customer third party
        vbRef.isThirdParty = false;
        //customer identifier
        vbRef.customerIdentifier = event.Item.CustomerIdentifier;
        //push to the array for that interaction
        global_VBReference.push(vbRef);
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.VoiceBioInteraction()", ex, false);
    }
}
function GetVBReferenceObj(intid) {
    try {
        for (var i = 0; i < global_VBReference.length; i++) {
            if (global_VBReference[i] !== undefined && global_VBReference[i].intid === parseInt(intid))
                return global_VBReference[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetVBReferenceObj()", ex, false);
    }
}
function RemoveVBReference(intid) {
    try {
        for (var i = 0; i < global_VBReference.length; i++) {
            if (global_VBReference[i] !== undefined && global_VBReference[i].intid === parseInt(intid)) {
                global_VBReference.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveVBReference()", ex, false);
    }
}
function EnrollementSuccess() {
    try {
        $("#manualVarified" + global_activeTabInteractionID).attr("disabled", "disabled");
        $("#btnEnroll" + global_activeTabInteractionID).addClass("disabled");
        $("#btnReject" + global_activeTabInteractionID).addClass("disabled");
        $("#btnThirdParty" + global_activeTabInteractionID).addClass("disabled");
        $("#btnDeleteEnrollment" + global_activeTabInteractionID).removeClass("disabled");

        //set vb enroll status to "YES and make the label green
        $("#vb_enroll_status" + global_activeTabInteractionID).removeClass("uk-badge-warning");
        $("#vb_enroll_status" + global_activeTabInteractionID).removeClass("uk-badge-danger");
        $("#vb_enroll_status" + global_activeTabInteractionID).addClass("uk-badge-success");
        $("#vb_enroll_status" + global_activeTabInteractionID).text("YES");
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.EnrollementSuccess()", ex, false);
    }
}
function DisableAllVBButtons() {
    try {
        $("#btnReject" + global_activeTabInteractionID).addClass("disabled");
        $("#btnEnroll" + global_activeTabInteractionID).addClass("disabled");
        $("#btnThirdParty" + global_activeTabInteractionID).addClass("disabled");
        $("#manualVarified" + global_activeTabInteractionID).attr("disabled", "disabled");
        $("#e_Nric_text" + global_activeTabInteractionID).attr("disabled", "disabled");
    } catch (ex) {
        log.LogDetails("Error", "VoiceBioUI.DisableAllVBButtons()", ex, false);
    }
}
//---------------------------------------------------------------------------------------------------------------------------
