﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "GlobalConfig.js";
var file_version = "3.1.08.0805";

try {
    global_addVersions(filename, file_version);
} catch (e) {
    console.log(e);
}

//----------------- Enable or Disable Caller ID Text Box in Callback Body --------------------------
var globalConfig_CallerIDTextBoxEnabled = true;
//----------------- System Generated Callback CRM End Pop Up Flag --------------------------
var globalConfig_CRMCallbackEnd = true;
//----------------- Enable or Disable BargeIn functionality --------------------------
var globalConfig_IsBargeInEnabled = false;
//----------------- ACW QMS CRM Enabled --------------------------
var globalConfig_IsACWQMSCRMEnabled = false;
//----------------- Callback Set Data for VDN as per Language -------------------------
var globalConfig_IsLanguageTruncateEnabled = false;
//----------------- Prefix to be added before Dialing out -------------------------
var globalConfig_Prefix = "";
//----------------- Nice Integrtion Enabled --------------------------
var globalConfig_IsNiceIntegrtionEnabled = true;
//----------------- Digibank CallType --------------------------
var globalConfig_DigibankCallbackType = "40010";
//----------------- Digibank Callback Range --------------------------
var globalConfig_DigibankCallbackExtensionRange = "42003-42010";
var global_CallbackVDNListStart = 50001;
var global_CallbackVDNListEnd = 59999;
//----------------- Internal Number Startswith --------------------------
var globalConfig_InternalNumberStartsWith = "7";
//var globalConfig_iServeURL = "https://iservein.corp.dbs.com:8643/iniserve/?";
var globalConfig_iServeURL = "https://10.133.146.4:444/DBS_TMAC_Indo/client.html?";
//Voice on Hold Announcement Prompt
var globalConfig_VoiceOnHoldPrompt = "40001";