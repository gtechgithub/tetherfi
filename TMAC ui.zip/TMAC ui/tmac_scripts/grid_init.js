// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "GridInit.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    console.log('grid init loaded');
});
// -----------------------------------------------------------------------------------------------------------------
//-----------------------------------------------bind wallboard data------------------------------------------------
function LoadWallboardGrid() {
    try {
        if (isWallboard) {
            if (isFullTMAC) {
                $("#wallboardGrid_side").kendoGrid({
                    dataSource: {
                        data: [],
                        sort: {
                            field: "CallsInQueue",
                            dir: "desc"
                        },
                    },
                    scrollable: true,
                    sortable: true,
                    filterable: false,
                    pageable: false,
                    columns: [{
                        field: "SkillName",
                        title: "Skill",
                        width: "140px"
                    },
                    {
                        field: "AgentsStaffed",
                        title: "Stf",
                        width: "45px"
                    },
                    {
                        field: "AgentAvailable",
                        title: "Avl",
                        width: "45px"
                    },
                    {
                        field: "CallsInQueue",
                        title: "CIQ",
                        width: "50px"
                    }
                    ]
                });
                ShowKendoLoading("#wallboardGrid_side");
            }
            else {
                $("#wallboardGrid_main").kendoGrid({
                    dataSource: {
                        data: [],
                        sort: {
                            field: "CallsInQueue",
                            dir: "desc"
                        },
                    },
                    scrollable: true,
                    sortable: true,
                    filterable: false,
                    pageable: false,
                    dataBound: function (e) {
                        // get the index of the CallsInQueue cell
                        var columns = e.sender.columns
                        var columnIndex = this.wrapper.find(".k-grid-header [data-field=" + "CallsInQueue" + "]").index();
                        // iterate the data items and apply cell styles where necessary
                        var dataItems = e.sender.dataSource.view();
                        for (var j = 0; j < dataItems.length; j++) {
                            var callsInQueue = dataItems[j].get("CallsInQueue");
                            var row = e.sender.tbody.find("[data-uid='" + dataItems[j].uid + "']");
                            var cell = row.children().eq(columnIndex);
                            if (callsInQueue > ciqThresholdValue) {
                                cell.addClass("blinkCallsInQueue");
                            }
                        }
                    },
                    columns: [{
                        field: "SkillName",
                        title: "Skill",
                        width: "140px"
                    },
                    {
                        field: "AgentsStaffed",
                        title: "Stf",
                        width: "45px"
                    },
                    {
                        field: "AgentAvailable",
                        title: "Avl",
                        width: "45px"
                    },
                    {
                        field: "CallsInQueue",
                        title: "CIQ",
                        width: "50px"
                    }
                    ]
                });
                ShowKendoLoading("#wallboardGrid_main");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "GridInit.LoadWallboardGrid()", ex, false);
    }
}
// -----------------------------------------------------------------------------------------------------------------
//-----------------------------------------------bind reminder data------------------------------------------------
function LoadReminderGrid() {
    try {
        if (isFullTMAC && isReminder) {
            $("#div_reminder_grid_side").toggle(true);
            $("#reminder_grid_side").kendoGrid({
                dataSource: {
                    data: []
                },
                toolbar: kendo.template($("#remindertoolbar").html()),
                selectable: true,
                scrollable: true,
                sortable: true,
                filterable: false,
                pageable: false,
                noRecords: true,
                change: OnReminderGridChange,
                columns: [{
                    field: "ID",
                    title: "ID",
                    hidden: true
                },
                {
                    field: "AgentID",
                    title: "AgentID",
                    hidden: true
                },
                {
                    field: "Message",
                    title: "Message",
                    width: "150px"
                },
                {
                    field: "Status",
                    title: "Status"
                },
                {
                    field: "RemindDate",
                    title: "Date"
                },
                {
                    field: "RemindTime",
                    title: "Time"
                }
                ]
            });
            LoadAgentReminders("", "", "", "");
            ShowKendoLoading("#reminder_grid_side");
        }
        else if (isReminder) {
            $("#reminderGrid").toggle(true);
            $("#reminder_grid").kendoGrid({
                dataSource: {
                    data: []
                },
                toolbar: kendo.template($("#remindertoolbar").html()),
                selectable: true,
                scrollable: true,
                sortable: true,
                filterable: false,
                pageable: false,
                noRecords: true,
                change: OnReminderGridChange,
                columns: [{
                    field: "ID",
                    title: "ID",
                    hidden: true
                },
                {
                    field: "AgentID",
                    title: "AgentID",
                    hidden: true
                },
                {
                    field: "Message",
                    title: "Message",
                    width: "150px"
                },
                {
                    field: "Status",
                    title: "Status"
                },
                {
                    field: "RemindDate",
                    title: "Date"
                },
                {
                    field: "RemindTime",
                    title: "Time"
                }
                ]
            });
            LoadAgentReminders("", "", "", "");
            ShowKendoLoading("#reminder_grid");
        }
    } catch (ex) {
        log.LogDetails("Error", "GridInit.LoadReminderGrid()", ex, false);
    }
}

function OnReminderGridChange(arg) {
    try {
        $("#btnClearSelectedReminder").removeClass("disabled");
        $("#btnEditReminder").removeClass("disabled");
        $("#btnDeleteReminder").removeClass("disabled");
    } catch (ex) {
        log.LogDetails("Error", "GridInit.OnReminderGridChange()", ex, false);
    }
}
//--------------------------------------------create barge in grid----------------------------------------------------------------
function CreateBargeInGrid(mydata) {
    try {
        var grid = '#barge_in_grid';
        $(grid).kendoGrid({
            dataSource: {
                data: mydata,
                group: {
                    field: "SupervisorName"
                },
                pageSize: 10,
                sort: {
                    field: "ItemID",
                    dir: "desc"
                },
                filter: {
                    field: "SupervisorAvayaLoginID",
                    operator: "neq",
                    value: ""
                }
            },
            noRecords: true,
            height: 250,
            scrollable: true,
            selectable: true,
            pageable: {
                refresh: false,
                pageSizes: true,
                buttonCount: 5
            },
            change: BargeInGridItemSelected,
            dataBound: function () {
                $(grid).find('.k-icon.k-i-collapse').trigger('click');
            },
            columns: [{
                field: "InteractionID",
                title: " ",
                hidden: true
            },
            {
                field: "TmacServer",
                title: " ",
                hidden: true
            },
            {
                field: "SupervisorAvayaLoginID",
                title: "Supervisor ID",
                hidden: true
            },
            {
                field: "SupervisorName",
                title: "Supervisor Name",
                hidden: true
            },
            {
                field: "AgentName",
                title: "Agent Name"
            },
            {
                field: "screenName",
                title: "Customer Name",
                template: "#= data.salutation# #= screenName #"
            },
            {
                field: "CIF",
                title: "Identification"
            },
            ]
        });
    } catch (ex) {
        log.LogDetails("Error", "GridInit.CreateBargeInGrid()", ex, false);
    }
}

function BargeInGridItemSelected(arg) {
    try {
        let $grid = arg.sender; //grid ref
        let $cell = $grid.select(); // selected td
        let $row = $cell.closest('tr'); //selected tr
        if ($row !== null) {
            let rowData = $grid.dataItem($row); //selected row data
            let agentId = rowData.AgentID;
            let agentName = rowData.AgentName;
            let customerName = rowData.screenName;
            let intid = rowData.InteractionID;
            let supervisorAvayaLoginId = global_AgentID;
            let tmacServer = rowData.TmacServer;
            TextChatBargeinToServer(agentId, intid, supervisorAvayaLoginId, tmacServer);
        } else {
            ShowNotify("Select a User record to barge-in to", "danger", null, "top-center");
        }
    } catch (ex) {
        log.LogDetails("Error", "GridInit.BargeInGridItemSelected()", ex, false);
    }
}
//-----------------------------------------------create agent list grid------------------------------------------------
function LoadAgentListGrid(gridName, textBox) {
    try {
        $('#' + gridName).empty();
        $('#' + gridName).kendoGrid({
            dataSource: {
                data: global_AgentList,
                pageSize: 50
            },
            filterable: {
                mode: "row"
            },
            change: AgnetListOnChange,
            height: 250,
            noRecords: true,
            scrollable: true,
            selectable: true,
            pageable: false,
            sortable: true,
            columns: [{
                field: "FirstName",
                title: "FirstName",
                width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "LastName",
                title: "LastName",
                width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "LoginID",
                title: "ID",
                width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "Status",
                title: "Status",
                width: "100px",
                filterable: false
            },
            {
                field: "InteractionCounts",
                title: "Interaction Counts",
                width: "130px",
                filterable: false
            },
            {
                field: "AgentVoiceSkillsAsString",
                title: "AgentVoiceSkillsAsString",
                hidden: true
            },
            {
                field: "TmacServer",
                title: "TmacServer",
                hidden: true
            }
            ]
        });
    } catch (ex) {
        log.LogDetails("Error", "GridInit.LoadAgentListGrid()", ex, false);
    }
}

function AgnetListOnChange(arg) {
    try {
        let object = {};
        let $grid = arg.sender; //grid ref
        let $cell = $grid.select(); // selected td
        let $row = $cell.closest('tr'); //selected tr
        let agentid = $grid.dataItem($row).LoginID; //selected row data
        let teamid = $grid.dataItem($row).TeamID;
        let supervisorid = $grid.dataItem($row).SupervisorAvayaLoginID;
        destTmacServerName = $grid.dataItem($row).TmacServer;
        let dataItem = $grid.dataSource.data();
        let row_index;
        for (let i = 0; i < dataItem.length; i++) {
            if (dataItem[i].LoginID == agentid) {
                row_index = i;
                break;
            }
        }
        if (arg.sender.element[0].id == "makeCallagentListGrid") {
            gridName = "makeCallagentListGrid";
            textBox = "txtMakeCallNumber";
            DisableButton("#btndialogmakecall");
        } else if (arg.sender.element[0].id == "transCallagentListGrid") {
            gridName = "transCallagentListGrid";
            textBox = "txtNumberTrans";
            DisableButton("#btndialogtransfercall");
            DisableButton("#btndialogblindtransfercall");
        } else if (arg.sender.element[0].id == "confCallagentListGrid") {
            gridName = "confCallagentListGrid";
            textBox = "txtNumberConf";
            DisableButton("#btnConfMCall");
        }
        favListGridItemSelect = "";
        object.rowid = row_index;
        object.grid = $('#' + gridName);
        object.txtBox = $("#" + textBox);
        //command_manager.js
        GetAgentStatus(global_DeviceID, agentid, object,destTmacServerName);
        //Get Agent Session List
        GetAgentSessionsList("", "", agentid, "", destTmacServerName, object);
    } catch (ex) {
        log.LogDetails("Error", "GridInit.AgnetListOnChange()", ex, false);
    }
}

//get agent status completed. Show agent status data on grid
function GetGridAgentStatusDone(object, data) {
    try {
        var status = data;
        var rowItem = $(object.grid).data().kendoGrid.dataSource.data()[object.rowid];
        var agentId = rowItem.LoginID;
        rowItem.set('Status', data);
        var canSelect = true;
        if (global_CallType === "TextChatTransfer" || global_CallType === "TextChatConference") {
            if (allowedStatus.TextChat.length > 0 && allowedStatus.TextChat.indexOf(data) < 0) {
                ShowNotify(rowItem.AgentName + " is not available.", "danger", null, "top-center");
                if (global_CallType === "TextChatTransfer") {
                    EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
                    EnableButton("#btndialogblindtransfercall", "BT", "tag");
                    FadeOutButton("#btndialogtransfercall");
                    FadeOutButton("#btndialogblindtransfercall");
                }
                if (global_CallType === "TextChatConference") {
                    EnableButton("#btnConfMCall", "call_split", "icon");
                    FadeOutButton("#btnConfMCall");
                }
                return;
            }
        }
        else {
            if (allowedStatus.Voice.length > 0 && allowedStatus.Voice.indexOf(data) < 0) {
                ShowNotify(rowItem.AgentName + " is not available.", "danger", null, "top-center");
                if (global_CallType === "Transfer") {
                    EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
                    EnableButton("#btndialogblindtransfercall", "BT", "tag");
                    FadeOutButton("#btndialogtransfercall");
                    FadeOutButton("#btndialogblindtransfercall");
                }
                if (global_CallType === "Conference") {
                    EnableButton("#btnConfMCall", "call_split", "icon");
                    FadeOutButton("#btnConfMCall");
                }
                return;
            }
        }

        if (object.txtBox[0].id !== "txtNumberTrans") {
            if (data.indexOf('On Call') >= 0) {
                status = "On Call";
                canSelect = false;
                ShowNotify(rowItem.AgentName + " is on call", "danger", null, "top-center");
            } else if (data === 'Not Logged in') {
                status = "Not Logged in";
                canSelect = false;
            } else if (data.indexOf("Error") >= 0) {
                status = "Not Logged in";
                canSelect = false;

            } else if (data === "") {
                status = "Not Logged in";
                canSelect = false;
            }
            EnableButton("#btndialogmakecall", "call", "icon");
            EnableButton("#btnConfMCall", "call_split", "icon");
        } else {
            EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
            EnableButton("#btndialogblindtransfercall", "BT", "tag");
        }

        if (canSelect) {
            object.txtBox.focus();
            object.txtBox.val(agentId);
        }
    } catch (ex) {
        log.LogDetails("Error", "GridInit.GetGridAgentStatusDone()", ex, false);
    }
}

function AgentSessionsListLoaded(data, obj) {
    try {
        var rowItem = $(obj.grid).data().kendoGrid.dataSource.data()[obj.rowid];
        var count = 0;
        $.each(data[0].InteractionList, function (i, val) {
            if (val.LastStatus != "Disconnected") { count++ }
        });
        rowItem.set('InteractionCounts', count);
    } catch (ex) {
        log.LogDetails("Error", "GridInit.AgentSessionsListLoaded()", ex, false);
    }
}

function LoadPOMAgentListGrid() {
    try {
        $('#pomAgentList').kendoGrid({
            dataSource: {
                data: [],
                pageSize: 50
            },
            filterable: {
                mode: "row"
            },
            change: POMAgnetListOnChange,
            height: 250,
            noRecords: true,
            scrollable: true,
            selectable: true,
            pageable: false,
            sortable: true,
            columns: [{
                field: "destinationName",
                title: "Agent Name",
                width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "destinationValue",
                title: "Agent ID",
                width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "presence",
                title: "Status",
                width: "100px",
                filterable: false
            },
            {
                field: "state",
                title: "State",
                width: "130px",
                filterable: false
            },
            {
                field: "POMDestinationType",
                title: "POMDestinationType",
                hidden: true
            }
            ]
        });
    } catch (ex) {
        log.LogDetails("Error", "GridInit.LoadPOMAgentListGrid()", ex, false);
    }
}

function POMAgnetListOnChange(arg) {
    try {
        let $grid = arg.sender; //grid ref
        let $cell = $grid.select(); // selected td
        let $row = $cell.closest('tr'); //selected tr

        let agentName = $grid.dataItem($row).destinationName; //selected row data
        let agentid = $grid.dataItem($row).destinationValue; //selected row data
        let status = $grid.dataItem($row).presence; //selected row data

        if (status.toLowerCase() != "available") {
            ShowNotify(agentName + " is not available.", "danger", null, "top-center");

            if (global_CallType == "Transfer")
                FadeOutButton("#btnpomtransfercall");
            else if (global_CallType == "Conference")
                FadeOutButton("#btnpomconferencecall");

            return;
        }

        if (global_CallType == "Transfer")
            FadeInButton("#btnpomtransfercall");
        else if (global_CallType == "Conference")
            FadeInButton("#btnpomconferencecall");

        $("#pomTxtNumberTransConf").val(agentid);
    } catch (ex) {
        log.LogDetails("Error", "GridInit.POMAgnetListOnChange()", ex, false);
    }
}
//------------------------------------------create favourite vdn list grid----------------------------------------
function LoadFavListGrid() {
    try {
        $('#favListGrid').kendoGrid({
            dataSource: {
                data: global_FavouriteSkills,
                pageSize: 50
            },
            filterable: {
                mode: "row"
            },
            change: FavoriteListOnChange,
            height: 250,
            scrollable: true,
            selectable: true,
            pageable: false,
            sortable: true,
            columns: [{
                field: "Name",
                title: "Name",
                //width: "100px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "VDN",
                title: "VDN",
                //width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "ID",
                title: "ID",
                //width: "80px",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "Staff",
                title: "Staff",
                //width: "40px",
                filterable: false
            },
            {
                field: "Avail",
                title: "Avail",
                //width: "40px",
                filterable: false
            },
            {
                field: "CIQ",
                title: "CIQ",
                //width: "40px",
                filterable: false
            }
            ]
        });
    } catch (ex) {
        log.LogDetails("Error", "GridInit.LoadFavListGrid()", ex, false);
    }
}

function FavoriteListOnChange(arg) {
    try {
        var $grid = arg.sender; //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var skill = $grid.dataItem($row).ID; //selected row data
        var dataItem = $grid.dataSource.data();
        var row_index;
        for (var i = 0; i < dataItem.length; i++) {
            if (dataItem[i].ID == skill) {
                row_index = i;
                break;
            }
        }
        //clear the number text box
        $("#txtNumberTrans").val('');
        favListGridItemSelect = "favItemSelect";
        if (global_CallType == "TextChatTransfer")
            favListGridItemSelectForChat = "favItemSelect";
        //commandManager.js
        GetQueueStatus(global_DeviceID, skill, row_index);
    } catch (ex) {
        log.LogDetails("Error", "GridInit.FavoriteListOnChange()", ex, false);
    }
}
//get skill status completed. show skill status data on grid
function GetQueueStatusSuccess(data, object) {
    try {

        if (data.Skill !== null) {
            var rowItem = $("#favListGrid").data().kendoGrid.dataSource.data()[object.rowid];
            rowItem.set('Staff', data.Skill.AgentsStaffed);
            rowItem.set('Avail', data.Skill.AgentAvailable);
            rowItem.set('CIQ', data.Skill.CallsInQueue);
            $("#txtNumberTrans").val(rowItem.ID);
        }
    } catch (ex) {
        log.LogDetails("Error", "GridInit.GetQueueStatusSuccess()", ex, false);
    }
}
//------------------------------------------create speed dial grid----------------------------------------
function LoadSpeedDialGrid(gridName, textBox) {
    try {
        $('#' + gridName).kendoGrid({
            dataSource: {
                data: global_SpeedDial,
                pageSize: 50
            },
            modal: true,
            height: 250,
            scrollable: true,
            selectable: true,
            pageable: false,
            sortable: true,
            change: SpeedDialOnChange,
            filterable: {
                mode: "row"
            },
            columns: [{
                field: "Name",
                title: "Name",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            },
            {
                field: "Number",
                title: "Number",
                filterable: {
                    cell: {
                        operator: "contains",
                        showOperators: false
                    }
                }
            }
            ]
        });
    } catch (ex) {
        log.LogDetails("Error", "GridInit.LoadSpeedDialGrid()", ex, false);
    }
}

function SpeedDialOnChange(arg) {
    try {
        var $grid = arg.sender; //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var number = $grid.dataItem($row).Number; //selected row data
        var textBox = "";
        if (arg.sender.element[0].id == "speedDialMakeCallGrid") {
            textBox = "txtMakeCallNumber";
        } else if (arg.sender.element[0].id == "speedDialGrid") {
            textBox = "txtNumberTrans";
        }
        $("#" + textBox).focus();
        $("#" + textBox).val(number);
    } catch (ex) {
        log.LogDetails("Error", "GridInit.SpeedDialOnChange()", ex, false);
    }
}
//-----------------------------------------------create callback detail grid------------------------------------------------
function CreateCallbackDetailGrid() {
    try {
        var grid = '#callback_detail_grid';
        $(grid).kendoGrid({
            dataSource: {
                data: [],
                pageSize: 10
            },
            noRecords: true,
            scrollable: true,
            selectable: true,
            pageable: {
                refresh: false,
                pageSizes: true,
                buttonCount: 5
            },
            columns: [{
                field: "DIAL_DATETIME",
                title: "Dial DateTime"
            },
            {
                field: "ASSIGNED_DATETIME",
                title: "Assigned DateTime"
            },
            {
                field: "CALLBACK_STATUS",
                title: "Status"
            },
            {
                field: "COMMENTS",
                title: "Comments"
            }
            ]
        });

    } catch (ex) {
        log.LogDetails("Error", "GridInit.CreateCallbackDetailGrid()", ex, false);
    }
}
//--------------------------------------------create chat template grid--------------------------------------------------
function CreateChatTemplateGrid(data) {
    try {
        $("#chat_template_grid").kendoGrid({
            dataSource: {
                data: data,
                pageSize: 50
            },
            toolbar: kendo.template($("#template").html()),
            height: 250,
            scrollable: true,
            selectable: true,
            pageable: false,
            sortable: true,
            change: ChatTemplateGridSelect,
            columns: [{
                field: "Text",
                title: "Template",
                encoded: false
            },
            {
                field: "ID",
                title: "ID",
                encoded: false,
                hidden: true
            }]
        });
        //grid template combo boxes
        CreateGridComboBoxes();
    } catch (ex) {
        log.LogDetails("Error", "GridInit.CreateChatTemplateGrid()", ex, false);
    }
}

function ChatTemplateGridSelect(arg) {
    try {
        let grid = arg.sender; //grid ref
        let gridData = grid.dataItem(grid.select());
        GetChatReferenceObj(global_activeTabInteractionID).selectedTemplateId = gridData.ID;
        InsertTextAtCurrentCursorPosition("textChatMessage" + tempIntIdForChatTemplate, gridData.Text);
        $("#chat_template_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "GridInit.ChatTemplateGridSelect()", ex, false);
    }
}
//----------------------------------------------Create callback grid -------------------------------------------------------
var selectedCallbackArg;

function CreatePendingCallbackGrid(intid, data) {
    try {
        var grid = '#pending_callback_grid' + intid;

        $(grid).kendoGrid({
            dataSource: {
                data: data,
                pageSize: 10
            },
            change: OnPendingCallbackGridChange,
            noRecords: true,
            scrollable: true,
            selectable: true,
            pageable: {
                refresh: false,
                pageSizes: true,
                buttonCount: 5
            },
            columns: [{
                field: "RequestDateTime",
                title: "Request DateTime"
            },
            {
                field: "CallbackDateTime",
                title: "Callback DateTime"
            },
            {
                field: "TYPE_OF_INQUIRY",
                title: "Type of Enquiry"
            },
            {
                field: "SRNO",
                title: "SRNo",
                hidden: true
            },
            {
                field: "CALLBACK_STATUS",
                title: "Callback Status"
            },
            {
                field: "CIF",
                title: "Identification"
            },
            {
                field: "TYPE",
                title: "Type",
                hidden: true
            }
            ]
        });

        $(grid).delegate("tbody>tr", "dblclick", function () {
            var $grid = selectedCallbackArg.sender; //grid ref
            var $cell = $grid.select(); // selected td
            var $row = $cell.closest('tr'); //selected tr
            var $rowData = $grid.dataItem($row); //selected row data
            var srno = $grid.dataItem($row).SRNO; //selected row SRNO
            var type = $grid.dataItem($row).TYPE; //selected row TYPE
            var status = $grid.dataItem($row).CALLBACK_STATUS; //selected row CALLBACK_STATUS
            var dataItem = $grid.dataSource.data();
            var rowid;
            for (var i = 0; i < dataItem.length; i++) {
                if (dataItem[i].SRNO == srno) {
                    rowid = i;
                    break;
                }
            }
            if (status !== "Closed") {
                $("#btn_closecallback").removeAttr("onclick");
                $("#btn_closecallback").attr("onclick", 'CloseCallback(' + intid + ',' + srno + ',' + rowid + ')');

                $("#btn_reschedule").removeAttr("onclick");
                $("#btn_reschedule").attr("onclick", 'ScheduleCallback(' + intid + ',' + srno + ',' + type + ',' + rowid + ')');

                $("#close_callback_dialog").data("kendoWindow").center().open();
            } else {
                ShowNotify("Callback is already closed", "info", null, "top-center");
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "GridInit.CreatePendingCallbackGrid()", ex, false);
    }
}

function OnPendingCallbackGridChange(arg) {
    try {
        selectedCallbackArg = arg;
    } catch (ex) {
        log.LogDetails("Error", "GridInit.OnPendingCallbackGridChange()", ex, false);
    }
}

