﻿var version_eventHandler = "3.0.10.19";
try {
    global_addVersion("eventHandler", version_eventHandler);
} catch (e) {
}

//----------------------------------------------------------------------------------------------------------------
function handleEvent(event) {

    if (event.length > 0)
        for (var x = 0; x < event.length; x++) {
            //if ((event[x].EventName == "InteractionHistoryEvent")) {
            //    alertMessageDialog(event[x].EventName);
            //}
            try {
                try {
                    if (log_events) {
                        if (event[x].EventName != "WallboardRefreshEvent")
                            console.log(JSON.stringify(event[x]));

                    }
                } catch (e11) {

                }
                
                window[event[x].EventName](event[x]);
            } catch (e) {
                ;
            }
        }
    }

//----------------------------------------------------------------------------------------------------------------
//change of agent boradcast messages
function tmacevent_AgentNotificaitonEvent(event) {
    //show an alert on AMAC status bar
    //on alert click, show the new message
    //mainUI.js
    if (event.Broadcast)
        agentNotification(event);
    else {
        agentNonBroadcastNotification(event);
    }
}
//----------------------------------------------------------------------------------------------------------------
//agent status changed
function tmacevent_AgentStatusChangeEvent(event) {
    global_forcelogoffonreason2_cnt = 0;
    //update the status list with new status
    //reset the status timer
    //mainUI.js
    agentStatusChange(event);
}
//----------------------------------------------------------------------------------------------------------------
//ivr transfer aux wait timer elapsed
function tmacevent_AUXTimerEvent(event) {
    //show aux timer expired dialog
    //mainUI.js
    alertMessageDialog("Aux timer expired", 'danger');
}
//----------------------------------------------------------------------------------------------------------------
//call conference completed
function tmacevent_CallConferenceCompletedEvent(event) {
    //hide conference window

    changeTabReferenceStatus(event.InteractionID, 'CallConnected');    //enable drop,hold,trans,conf buttons

    //disable answer button
    //voiceUI.js
    conferenceCompleted(event);
}
//----------------------------------------------------------------------------------------------------------------
//call conference initiated
function tmacevent_CallConferenceInitiatedEvent(event) {
    //enable complete, cancel buttons on conference window
    //voiceUI.js
    conferenceInitiated();
}
//----------------------------------------------------------------------------------------------------------------
//CallConferenceLineDisconnectEvent
function tmac_CallConferenceLineDisconnectEvent(event) {
    //hide the conference window

    //enable drop,hold,trans,conf buttons

    //disable answer button
    //voiceUI.js
    conferenceLineDisconnected(event);
}
//----------------------------------------------------------------------------------------------------------------
//call conference remote party connected
function tmacevent_CallConferenceRemoteConnectedEvent(event) {
    //enable complete, cancel buttons on conference window
    //voiceUI.js
    conferenceRemoteConnected();
}
//----------------------------------------------------------------------------------------------------------------
//call connected event
function tmacevent_CallConnectedEvent(event) {
    //enable drop,hold,trans,conf buttons=

    //disable answer button
    //commonUI.js
    setCallControlStatus(event.InteractionID, false, true, true, false, true, true);

    //commonUI.js
    changeTabReferenceStatus(event.InteractionID, 'CallConnected');
}
//----------------------------------------------------------------------------------------------------------------
//call disconnected
function tmacevent_CallDisconnectedEvent(event) {
    //disable all buttons
    //commonUI.js
    setCallControlStatus(event.InteractionID, false, false, false, false, false, false, true);
    //commonUI.js
    changeTabReferenceStatus(event.InteractionID, 'CallDisconnected');
    //startBlinking(event.InteractionID);

    //check if this is an vouce out tab. Then close the tab
    try {
        if (tmac_ui_close_tab_on_out_call_discon || tmac_ui_close_tab_on_in_call_discon) {
            if (global_InteractionTabs[event.InteractionID].type == 'voice') {
                if (tmac_ui_close_tab_on_out_call_discon && global_InteractionTabs[event.InteractionID].direction == 'out') {
                    //commandManager.js
                    CloseTab(global_DeviceID, event.InteractionID);
                }
                else if (tmac_ui_close_tab_on_in_call_discon && global_InteractionTabs[event.InteractionID].direction == 'in') {
                    //commandManager.js
                    CloseTab(global_DeviceID, event.InteractionID);
                }
            }
        }
    }
    catch (e)
    { }

   
}
//----------------------------------------------------------------------------------------------------------------
//call went onhold
function tmacevent_CallHoldEvent(event) {
    //disable answer,drop,trans,conf buttons
    //enable hold button
    //commonUI.js
    setCallControlStatus(event.InteractionID, false, false, false, true, false, false);
    //commonUI.js
    changeTabReferenceStatus(event.InteractionID, 'CallHold');
    //startBlinking(event.InteractionID);
}
//----------------------------------------------------------------------------------------------------------------
//call reconnected from hold
function tmacevent_CallHoldReconnectEvent(event) {
    //enable drop,hold,trans,conf buttons
    //disable answer button
    //commonUI.js
    setCallControlStatus(event.InteractionID, false, true, true, true, true, true);
    //commonUI.js
    changeTabReferenceStatus(event.InteractionID, 'CallConnected');
    //startBlinking(event.InteractionID);
}
//----------------------------------------------------------------------------------------------------------------
//call transfer initiated
function tmacevent_CallTransferInitiatedEvent(event) {
    //enable complete, cancel buttons on transfer window
    //voiceUI.js
    transferInitiated(event.InteractionID);

    if ($('#favListGridItemSelect').val() == "favItemSelect") {

        var intId = global_transferIntID;
        //commandManager.js
        TransferComplete(global_DeviceID, intId);

        $('#favListGridItemSelect').val('null');
    }
}

//---------------------------- AES Status Event -----------------------------------------------
function tmacevent_AESStatusEvent(event) {
    if (event.Status == "Failed") {
        alertMessageDialog("There has been a glitch at the AES level and hence your current tab might not work. Kindly use your hardphone" +
        "to complete the call", 'danger');
    }
    else if (event.Status == "Reconnected") {
        alertMessageDialog("The AES level glitch has been resolved. Enjoy seamless TMAC usage! ", 'success');
    }
}

//----------------------------------------------------------------------------------------------------------------
//call transfered line disconnected
function tmacevent_CallTransferLineDisconnectEvent(event) {
    //hide the transfer window

    //enable drop,hold,trans,conf buttons

    //disable answer button
    //commonUI.js
    setCallControlStatus(event.InteractionID, false, false, false, false, false, true, true);
    //voiceUI.js
    transferLineDisconnected(event);
}
//----------------------------------------------------------------------------------------------------------------
//call transfer remote party answered the call
function tmacevent_CallTransferRemoteConnectedEvent(event) {
    //enable complete, cancel buttons on transfer window
    //voiceUI.js
    transferRemoteConnected();
}
//----------------------------------------------------------------------------------------------------------------

//ccl data recevied
function tmacevent_CCLDataEvent(event) {
    //bind data to customer details area


    //2017-10-19
    //invoke a method in service window
    try {

        serviceWindowList[event.InteractionID].CCLDataEvent(event);
    } catch (e) {

    }


    //commonUI.js
    setCCLData(event);
}

//incoming call
function tmacevent_IncomingCallEvent(event) {

    //voiceUI.js
    incomingVoiceCall(event);
}

//----------------------------------------------------------------------------------------------------------------
//interaction history received
function tmacevent_InteractionHistoryEvent(event) {
    //bind interaction history to tab
    //commonUI.js
    try {
        setInteractionHistory(event);
    } catch (e) {

    }
}

//---------------------------more interaction history received--------------------------------------------------------
function tmacevent_MoreInteractionHistoryEvent(event) {
    //bind interaction history to tab
    //commonUI.js
    setInteractionHistoryMore(event);
}

//----------------------------------intercation historty on demand received----------------------------------------------
function tmacevent_InteractionHistoryOnDemandEvent(event) {
    //commonUI.js
    try {
        setInteractionHistory(event);
    } catch (e) {

    }
}
//----------------------------------------------------------------------------------------------------------------
//IVR data received
function tmacevent_IVRDataEvent(event) {

    //bind ivr data to tab
    //2017-10-19
    //invoke a method in service window
    try {

        serviceWindowList[event.InteractionID].IVRDataEvent(event);
    } catch (e) {

    }
    //voiceUI.js
    setIVRData(event);
}
//----------------------------------------------------------------------------------------------------------------
//outgoing call created
function tmacevent_OutgoingCallEvent(event) {

    //voiceUI.js
    outboundVoiceCall(event);

}
//----------------------------------------------------------------------------------------------------------------
//UUI data recevied
function tmacevent_UUIDataEvent(event) {
    //bind UUI data to cusotmer details area
    
    //2017-10-19
    //invoke a method in service window
    try {

        serviceWindowList[event.InteractionID].UUIDataEvent(event);
    } catch (e) {

    }
    //commonUI.js
    setUUIData(event);
}
//----------------------------------------------------------------------------------------------------------------
function tmacevent_WallboardRefreshEvent(event) {

    global_forcelogoffonreason2_cnt = 0;
    //refresh wallboard
    //mainUI.js
    refreshWallboard(event);
}
//----------------------------------------------------------------------------------------------------------------

//----------------------------------------Caller intent data----------------------------------------------
function tmacevent_CallerIntentEvent(event) {

    //2017-10-19
    //invoke a method in service window
    try {

        serviceWindowList[event.InteractionID].CallerIntentEvent(event);
    } catch (e) {

    }
    
    //commonUI.js
    callerIntentReceived(event);
}



//-----------------------------------------Callback Popup----------------------------------------------
function tmacevent_ScreenPopEvent(event) {
    //load the popup
    //popUpScreen(event);
}


//2016-01-21 QUICK FIX
var global_forcelogoffonreason2_cnt = 0;

function tmacevent_AgentForcedLogoffEvent(event) {

    if (global_LogoutCommandSend)
        return;

    // Session Key expired
    window.global_AgentForcedLogoffEventFlag = true;

    if (event.Reason == "Session key expired") {
        alert("We are closing this window as you are logged in using another TMAC session.");
        window.close();
    }
    else if (event.Reason == "Agent session not available") {
        global_forcelogoffonreason2_cnt = global_forcelogoffonreason2_cnt + 1;
        if (global_forcelogoffonreason2_cnt > 5) {
            alert("We are closing this window as you are logged out from the system.");
            window.close();
        }
    }
    else {
        alert(event.Reason);
        window.close();
    }
}


//----------------------------------------------------------------------------------------------------------------
//hold timer
function tmacevent_HoldTimerEvent(event) {
    //show aux timer expired dialog
    //mainUI.js
    var color = "black";
    var msg;

    if (event.HoldTimeSeconds >= 10 && event.HoldTimeSeconds < 30)
        color = "blue";
    else if (event.HoldTimeSeconds >= 30 && event.HoldTimeSeconds < 60)
        color = "orange";
//    else if (event.HoldTimeSeconds >= 180 && event.HoldTimeSeconds < 240)
//        color = "blue";
    else if (event.HoldTimeSeconds >= 60)
        color = "red";

    msg = '<span style="font-size:16px;">Hold time is <span style="color:' + color + ';">' + event.HoldTimeString + '</span></span>';
    //alertMessageDialog(msg, 'info');

//    var open = false;

//    if (event.HoldTimeSeconds >= 59 && event.HoldTimeSeconds < 65)
//        open = true;
//    else if (event.HoldTimeSeconds >= 119 && event.HoldTimeSeconds < 125)
//        open = true;
//    else if (event.HoldTimeSeconds >= 179 && event.HoldTimeSeconds < 185)
//        open = true;
//    else if (event.HoldTimeSeconds >= 240)
//        open = true;

    var show = event.HoldTimeSeconds >= 0 && event.HoldTimeSeconds < 30;

    holdTimerAlert(event.InteractionID, msg, "info", show || (event.HoldTimeSeconds % 30 <= 5), color, event.HoldTimeSeconds, event.HoldTimeString);
}



function Custom_iServerStartEvent(event) {

    var url = "https://10.133.146.4:444/DBS_TMAC_Indo/client.html?postdata=" + event.JsonData;
    window.open(url);
}






//----------------------REMINDERS-------------------------
var reminderWindow;
var lastAutoReminderSet;

function getLastAutoReminderSet() {
    return lastAutoReminderSet;
}

function setReminderBadge(value) {
    $("#cntReminderCount").html(value);

    if (value > 0) {    
        // alertMessageDialog("You have " + value + " pending reminders.", "danger");
        blink("#cntReminderCount", 6, 500, value,' ');
    }
}


//open reminderWindow
function openReminderTab() {

    //add new tab to show reminderWindow
    //mainUI.Js
    addTab('reminderWindow', 'divReminderHeader', 'divReminderBody', true);


    //set the tab header name
    //set tab header details
    var tabName = 'Reminders';

    $('#divCustomerName' + 'reminderWindow').text(tabName);

    //show close button
    try {
        setCallControlStatus('reminderWindow', false, false, false, false, false, false, true);
    }
    catch (e) { }

    var url = "reminders.htm";
    loadIFrame("iframe_Reminders" + "reminderWindow", url);

    //add this iframe to iframe list
    reminderWindow = document.getElementById("iframe_Reminders" + "reminderWindow").contentWindow;
}


function CreateAgentReminderEvent(event) {
    //ResultCode
    //ResultMessage
    if (event.ResultCode > 0)
        alertMessageDialog("Reminder successfully created.", 'success');
    else
        alertMessageDialog("Reminder creation failed.", 'danger');
}

function DeleteAgentReminderEvent(event) {
    //ResultCode
    //ResultMessage
    if (event.ResultCode > 0) {
        alertMessageDialog("Reminder successfully deleted.", 'success');
        if (event.ResultCode == 2) {
            setReminderBadge(0);
            lastAutoReminderSet = null;
            if (reminderWindow == null || reminderWindow == undefined)
                return;
            reminderWindow.clear_auto_reminders();
        }
    } else
        alertMessageDialog("Reminder update failed.");
}

function UpdateAgentReminderEvent(event) {
    //ResultCode
    //ResultMessage
    if (event.ResultCode > 0) {
        alertMessageDialog("Reminder successfully updated.", 'success');
        if (event.ResultCode == 2) {
            setReminderBadge(0);
            lastAutoReminderSet = null;
            if (reminderWindow == null || reminderWindow == undefined)
                return;
            reminderWindow.clear_auto_reminders();
        }
    } else
        alertMessageDialog("Reminder update failed.");
}

function tmacevent_AgentReminderEvent(event) {
    if (event.Auto == "1") {
        if (event.Reminders != null) {
            setReminderBadge(event.Reminders.length);
            lastAutoReminderSet = event.Reminders;
        }
    }

    if (reminderWindow == null || reminderWindow == undefined)
        return;

    reminderWindow.AgentReminderEvent(event);

    // Auto = "0",
    //Reminders = List<AgentReminder>
    /*
    public string ID { get; set; }
    public string AgentID { get; set; }
    public string Message { get; set; }
    public string RemindDate { get; set; }
    public string RemindTime { get; set; }
    public string Status { get; set; }*/

}
//-----------------------REMINDERS END--------------------------------------------------------


//debugger;

function tmacevent_VoiceCallInitiatingEvent(event) {
    //alert('VoiceCallInitiatingEvent:' + event.ConnectionHandle);
    //show a disconnect button on makecall UI
    //ConnectionHandle 
    window.global_InitiatedCallConnectionHandle = event.ConnectionHandle;

    $("#btndisconnectDialingCall").css("visibility", "visible");
    openMakeCallDialog("");
}

function tmacevent_VoiceCallRecorderEvent(event) {
    try {
        if (ui_config_change_ui) {
            if (ui_config_show_call_record_indicator) {
                $("#ui_div_callrecord" + event.InteractionID).css("visibility", "visible");
            }
        }
    } catch (e) {

    }
}

//Tab auto close
function tmacevent_AutoCloseTabEvent(event) {
    //amacUI.js
    closeUITab(event.InteractionID);
    removeTabReference(event.InteractionID);
}



//GENERIC INTERACTIONS
function tmacevent_GenericInteractionEvent(event) {
    //alert('GenericInteractionEvent received');
    try {
        //alert(event.Item.ID);
        generic_addTab(event.InteractionID, event.Item, event.SessionID, event);
    } catch (e) {

    }
}


function tmacevent_OutgoingCallUCIDEvent(event) {
    var ucid = event.PhoneNumber;
    var intid = event.InteractionID;


    //2017-03-15
    //invoke a method in service window
    try {
         
        serviceWindowList[intid].onMakeCall(ucid);
    } catch (e) {

    }


    if (dsta_camp_url != null) {

        dsta_camp_url = dsta_camp_url + "&callid=" + ucid + "&isRandomQuestions=1";

        window.open(dsta_camp_url, global_AgentID + "_" + event.InteractionID, "menubar=no,location=no,scrollbars=no,width=" + screen.width + ",height=" + (screen.availHeight - 33));
        dsta_camp_url = null;

        return;


    }
    
    //2016-04-19
    //if (event.EventName == "OutgoingCallEvent") {
    if (last_camp_call_data != null && last_camp_call_data.enabled == 1) {
        //open campaing url
        //loadIFrame("iframe_GenericTab" + event.InteractionID, url);
        loadIFrame("iframe_CustomerDataVoiceTab" + event.InteractionID, last_camp_call_data.url);
        var as = "https://202.150.214.54/AgentScript/Survey/?agentid=" + global_AgentID + "&intentname=" +
            last_camp_call_data.queueitemdata.Data +
            "&customerid=" + last_camp_call_data.queueitemdata.ID + "&callid=" + ucid;
        //alert(as);

        window.open(as, global_AgentID + "_" + event.InteractionID, "menubar=no,location=no,scrollbars=no,width=" + screen.width + ",height=" + (screen.availHeight - 33));

        last_camp_call_data = null;
        return;
    }
    //}

}


function tmacevent_InteractionHistoryReLoadEvent(event) {
    //bind interaction history to tab
    //commonUI.js
    try {
        setInteractionHistory(event);
    } catch (e) {

    }
}


function tmacevent_SmsSurveyResultEvent(event) {
 
//    string Channel 
//    bool Success 
//    int ResultCode 
//    string TypeOfSurvey 
//    string MobileNumber

    if (event.ResultCode > 0)
        alertMessageDialog("Sms survey success", "info");
    else
        alertMessageDialog("Sms survey failed:" + event.ResultCode, "error");

}


function tmacevent_SMSSendFailedEvent(event) {
    // string PhoneNumber  
    // string Message  
    // string Channel  (SMS, Voice)
}


function tmacevent_MakeCallOnExistingTabFailed(event) {
    if (event.IsExistingInteraction)
        alertMessageDialog("Call failed", "error");
}