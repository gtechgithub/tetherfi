// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "FaxUI.js";
var file_version = "3.1.07.27";
var changedBy = "Sirajuddin"
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(e);
}

$(function () {
    GetFaxLineNumbers();
    if (isPrintFax) {
        window.onafterprint = function (arg) {
            console.log(arg);
        };
    }

    $('input[type=radio][name=fax_compose_radio]').change(function () {
        if (this.value == 'uploadFile') {
            $("#div_fax_upload").toggle();
            $("#div_fax_templates").toggle();
            $(".k-upload-files.k-reset").find("li").remove();
        }
        else if (this.value == 'selectTemplate') {
            $("#faxTemplates").data("kendoDropDownList").value("");
            $("#faxTemplates").data("kendoDropDownList").text("Select a fax template...");
            $("#div_fax_upload").toggle();
            $("#div_fax_templates").toggle();
        }
        TriggerResize();
    });

    GetFaxTemplateNames();
});

function OpenComposeFax() {
    try {
        faxInteractionId = "";
        $("#compose_fax_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.OpenComposeFax()", ex, false);
    }
}

function SendFaxToServer() {
    try {
        let faxComposeType = $('input[name=fax_compose_radio]:checked').val();
        let DNIS = $("#DNISList").data("kendoDropDownList").value();
        let faxNumber = $("#faxNumber").val();
        let faxFiles = $("#faxFiles").data("kendoUpload");
        let templateName = $("#faxTemplates").data("kendoDropDownList").value();
        if (DNIS == "") {
            log.LogDetails("Error", "FaxUI.SendFax()", "Please select a fax line", true);
            return;
        }
        else if ($.trim(faxNumber) == "") {
            log.LogDetails("Error", "FaxUI.SendFax()", "Please enter a fax number", true);
            return;
        }
        else if (faxComposeType == "uploadFile" && faxFiles.wrapper.find(".k-file").length <= 0) {
            log.LogDetails("Error", "FaxUI.SendFax()", "Please select a file", true);
            return;
        }
        else if (faxComposeType == "selectTemplate" && templateName == "") {
            log.LogDetails("Error", "FaxUI.SendFax()", "Please select a template", true);
            return;
        }
        if (faxComposeType == "uploadFile")
            $(".k-upload-selected").click();
        else if (faxComposeType == "selectTemplate")
            SendFax(faxInteractionId, null, faxNumber, DNIS, templateName, "template");
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.SendFaxToServer()", ex, false);
    }
}

function NewFaxReceived(event) {
    try {
        let intid = event.InteractionID;
        let headerTemplate = GetTabHtml("tab_header_template", intid, { icon: "print" });
        let bodyTemplate = GetTabHtml("fax_tab_template", intid, null);
        SaveTabReference("fax", intid, "new");
        AddTab(bodyTemplate, headerTemplate, intid, event.FaxNumber, true, true, false);
        if (isPrintFax) {
            $("#btnPrintFax" + intid).removeClass("uk-display-none");
        }
        if (faxLineNumbers.indexOf(parseInt(event.DNIS)) < 0) {
            $("#btnReplyFax" + intid).removeClass("md-btn-facebook");
            $("#btnReplyFax" + intid).addClass("md-btn-danger");
        }
        //Initialize the UIKit accordion for the created tab
        UIkit.accordion($('#fax_accordion' + intid), {
            collapse: false,
            showfirst: true
        });
        let fileName = event.File.replace(/^.*[\\\/]/, '');
        $("#fileName" + intid).text(fileName);
        SaveFaxReference(intid, event.DNIS, event.FaxNumber, event.SessionID, fileName);
        PreviewFax(event);
        setTimeout(function () { SetTabHeight(); });
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.NewFaxReceived()", ex, false);
    }
}

function PreviewFax(event) {
    try {
        let xhr = new XMLHttpRequest();
        xhr.responseType = 'arraybuffer';
        xhr.open('GET', event.File);
        xhr.onload = function (e) {
            $("#faxLoader" + event.InteractionID).remove();
            let tiff = new Tiff({ buffer: xhr.response });
            for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
                tiff.setDirectory(i);
                let li = document.createElement("LI"),
                    canvas = tiff.toCanvas(),
                    dataUrl = canvas.toDataURL(),
                    img = document.createElement('img');

                img.src = dataUrl;
                img.id = "file_" + event.InteractionID + "_" + i;
                img.style.width = "100%";
                img.style.height = "100%";
                li.appendChild(img);
                $("#previewFax" + event.InteractionID).append(li);

                ++GetFaxReferenceObj(event.InteractionID).pageCount;
            }
        };
        xhr.send();
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.PreviewFax()", ex, false);
    }
}

function ReplyToFax(intid) {
    try {
        faxInteractionId = intid;

        let faxRef = GetFaxReferenceObj(intid);
        let sessionID = faxRef.sessionId, DNIS = faxRef.DNIS, faxNumber = faxRef.faxNumber;

        if (faxLineNumbers.indexOf(parseInt(DNIS)) < 0) {
            log.LogDetails("Error", "FaxUI.ReplyToFax()", "Reply to Fax Line " + DNIS + " is disabled", true);
            return;
        }

        $("#DNISList").data("kendoDropDownList").value(DNIS);
        $("#DNISList").data("kendoDropDownList").readonly();

        $("#faxNumber").val(faxNumber);
        $("#faxNumber").attr("readonly", "readonly");

        $("#compose_fax_dialog").data("kendoWindow").center().open();
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.ReplyToFax()", ex, false);
    }
}

function ForwardToFax(intid) {
    try {

    } catch (ex) {
        log.LogDetails("Error", "FaxUI.ForwardToFax()", ex, false);
    }
}

function PrintFax(intid) {
    try {
        FadeOutButton("#btnPrintFax" + intid);
        //get the page count from fax reference
        let pageCount = GetFaxReferenceObj(intid).pageCount;
        //get the file name from fax reference
        let fileName = GetFaxReferenceObj(intid).fileName;
        //to store all the img id to print
        let fileIds = "";
        //get the img id's based on total count of page
        for (let i = 0; i < pageCount; i++) {
            fileIds = fileIds + "#file_" + intid + "_" + i + ",";
        }
        //slice the last comma from the ids
        fileIds = fileIds.slice(0, -1);
        //print the img containers based on ids provided
        $(fileIds).printThis({
            pageTitle: fileName        // add title to print page
        });
        setTimeout(function () {
            FadeInButton("#btnPrintFax" + intid);
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.PrintFax()", ex, false);
    }
}

function SaveFaxReference(intid, dnis, faxNumber, sessionId, fileName) {
    try {
        var faxRef = {};
        faxRef.intid = intid;
        faxRef.DNIS = dnis;
        faxRef.faxNumber = faxNumber;
        faxRef.sessionId = sessionId;
        faxRef.fileName = fileName;
        faxRef.pageCount = 0;
        //push to the array for that interaction
        global_FaxReference.push(faxRef);
    } catch (ex) {
        log.LogDetails("Error", "FaxUI.SaveFaxReference()", ex, false);
    }
}

function GetFaxReferenceObj(intid) {
    try {
        for (let i = 0; i < global_FaxReference.length; i++) {
            if (global_FaxReference[i] !== undefined && global_FaxReference[i].intid === parseInt(intid))
                return global_FaxReference[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.GetChatReferenceObj()", ex, false);
    }
}

function RemoveFaxReference(intid) {
    try {
        for (var i = 0; i < global_FaxReference.length; i++) {
            if (global_FaxReference[i] !== undefined && global_FaxReference[i].intid === parseInt(intid)) {
                global_FaxReference.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacTextChatUI.RemoveChatReference()", ex, false);
    }
}