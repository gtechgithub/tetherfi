﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "VoiceUI.js";
var file_version = "3.1.08.0805";
var changedBy = "Rahul";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------
//----------------------------------------------incoming voice call-------------------------------------------------------
function IncomingVoiceCall(event) {
    try {
        let callbackTransfer = false;
        let callbackSrno = "";
        let srno = "";
        // Initially will set 'triggerIServeLayer' to false when its Transfer or Conference 
        let data = {};
        //Check if this is a callback transfer
        if ((event.SourceTransferComment !== "") && (event.SourceTransferComment !== null)) {
            var str = "SRNO";
            var stringToFind = "?";
            var retVal = event.SourceTransferComment.indexOf(str);
            if (retVal >= 0) {
                callbackTransfer = true;
                var ret = event.SourceTransferComment.indexOf(stringToFind);
                callbackSrno = event.SourceTransferComment.substring(5, ret);
                event.SourceTransferComment = event.SourceTransferComment.substring(ret + 2, event.SourceTransferComment.length);
            }
            if (event.SourceTransferComment !== "") {
                ShowNotify('Call Transferred from ' + event.SourceAgentName + ':' + event.SourceTransferComment, "info", null, "top-center");
            }
        }
        data.InteractionID = event.InteractionID;
        data.UCID = event.UCID;
        if (event.IsAgentTransferedCall || event.IsAgentConferencedCal) {
            data.triggerIServeLayer = false;
        } else {
            data.triggerIServeLayer = true;
        }
        global_ConnectedCalls.push(data);

        if (event.IsAgentTransferedCall || event.IsAgentConferencedCall || event.CallType) {
            global_IsAgentTransferedCall = true;
            global_LastUCIDForTransferACWEnd = global_UCID[global_activeTabId];
            global_LastInteractionIDForTransferACWEnd = global_activeTabId;
        } else {
            global_IsAgentTransferedCall = false;
            global_LastUCIDForTransferACWEnd = "";
            global_LastInteractionIDForTransferACWEnd = "";
        }
        global_UCID[event.InteractionID] = event.UCID;
        global_temporaryUCID[event.InteractionID] = event.UCID;

        //check if ucid is existing in the custom table - for queuetime calculation
        if (isIServe) custom_getQueueTimeForUCID(event.InteractionID, event.UCID, "0");

        //create a new voice tab
        if (isVTM) {
            AddVoiceTab('vtm_voice_tab_body', event.InteractionID, event.PhoneNumber, callbackTransfer, event.VDNName);
        }
        else {
            AddVoiceTab('voice_tab_body', event.InteractionID, event.PhoneNumber, callbackTransfer, event.VDNName);
        }

        //Initialize the UIKit accordion for the created tab
        UIkit.accordion($('#voice_accordion' + event.InteractionID), {
            collapse: false,
            showfirst: true
        });

        let containsPipe = event.UUI.indexOf("|");
        //If srno is present then its callback call else voice call
        if (event.UUI !== "" && event.UUI !== null && (!event.IsAgentTransferedCall) && containsPipe !== -1) {
            //agent|40192|mukesh|66070|PWEB|1004764
            var splitValues = event.UUI.split("|");
            if (splitValues.length > 2) {
                srno = splitValues[5];
            }
            else {
                srno = splitValues[1];
            }
            if (srno !== "") {
                srno = srno.trim();
                //Store the SRNO  in the related Interaction ID field for further processing on Connect Event
                GetTabReferenceObj(event.InteractionID).OtherData.srno = srno;
                $("#hdn_srno" + event.InteractionID).val(srno);
                $("#hdn_transfer_type" + event.InteractionID).val("Callback");
            }
        } else if (callbackTransfer) {
            GetTabReferenceObj(event.InteractionID).OtherData.srno = callbackSrno;
            GetTabReferenceObj(event.InteractionID).OtherData.isCallbackTransferRec = true;
            $("#hdn_srno" + event.InteractionID).val(callbackSrno);
            $("#hdn_transfer_type" + event.InteractionID).val("Callback");
            callbackTransfer = false;

            //update callback table with the new agent id
            //customeCommands.js
            custom_UpdateAgentIdForCallbackTransfer(callbackSrno, event.InteractionID);
        } else {
            if (isDynamicCRM) DynamicsCRMStartVoicePopUpScreen(event, true);
        }

        if (isCallbackNumber(event.PhoneNumber)) {
            if (srno !== "")
                IsCallbackCall(event.InteractionID, srno);
        } else if (event.IsAgentTransferedCall) {
            if (callbackSrno !== "") {
                IsCallbackCall(event.InteractionID, callbackSrno);
            }
        } else {
            //custom_getData(event.InteractionID, event.PhoneNumber);
        }
        SetHiddenFieldCallback(event);
        //disable initially and enable after call answer
        DisableTransferToIVR(event.InteractionID);
        //enable answer button disable drop,hold,trans,conf buttons
        SetCallControlStatus(event.InteractionID, true, false, false, "disable", false, false, false);
        GetTabReferenceObj(event.InteractionID).OtherData.CallType = event.CallType;
        if (isVoiceDataWindow && event.SubType.trim() != "") {
            OpenVoiceDataWindow(event);
        }

        ShowNotification("You have new incoming call", event.PhoneNumber);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.IncomingVoiceCall()", ex, false);
    }
}

function OpenVoiceDataWindow(event) {
    try {
        let intid = event.InteractionID;
        let type = "Service Window";
        let urlObj = GetServiceWindowURL(event);
        let url = urlObj.url;
        if (urlObj.defaultUrl) {
            url = url + "?autosearch=1&intid=" + intid + "&room=" + phone + "&sourceWindow=voicetab";
        }
        if (urlObj.type == "camp") {
            type = "Campaign";
        }
        else {
            $("#custom_frame" + intid).removeClass("uk-display-none");
        }
        $("#custom_frame" + intid).text(type);
        LoadIFrame("ui_custom_frame" + intid, url);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenVoiceDataWindow()", ex, false);
    }
}
//-------------------------------------------------- Check if the call is from Phantom Extension for Callback ---------------------------------------
function IsCallbackCall(intid, srno) {
    try {
        ChangeStatus(global_DeviceID, 'acw', '0');
        DisableCallbackDetailsButtons(event.InteractionID);
        custom_getdetailsforSrno(intid, srno);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.IsCallbackCall()", ex, false);
    }
}

function VoiceCallInitiating(event) {
    try {
        global_ConnectionHandle = event.ConnectionHandle;
        //enable the disconnect by handle button
        $("#btndisconnectSpan").removeClass("uk-display-none");
        //if the disconnect by handle is from callback then interachange the drop buttons display
        //as each button has its own purpose
        if (disconnectByHandleType == "callback" && GetTabReferenceObj(global_activeTabInteractionID) !== undefined) {
            //hide DisconnectCall button
            $("#btnDrop" + global_activeTabInteractionID).addClass("uk-display-none");
            //show DisconnectCallByHandle button
            $("#btndisconnectDial" + global_activeTabInteractionID).removeClass("uk-display-none");
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallInitiating()", ex, false);
    }
}

//----------------------------------------------outgoing voice call-------------------------------------------------------
function VoiceOutgoingCallEvent(event) {
    try {
        let data = {};
        data.InteractionID = event.InteractionID;
        data.UCID = event.UCID;
        data.triggerIServeLayer = true;
        global_ConnectedCalls.push(data);

        let phoneNumber = event.PhoneNumber;
        //check if its already existing interaction : For Callback outbound dial
        if (!event.IsExistingInteraction) {
            //create a new tab
            AddVoiceTab('voice_tab_body', event.InteractionID, phoneNumber, false, "Outgoing");
            //Initialize the UIKit accordion for the created tab
            UIkit.accordion($('#voice_accordion' + event.InteractionID), {
                collapse: false,
                showfirst: true
            });

            global_UCID[event.InteractionID] = global_OutboundUCID;
            global_temporaryUCID[event.InteractionID] = global_OutboundUCID;

            //set the call direction for this tab
            try {
                GetTabReferenceObj(event.InteractionID).direction = 'out';
                GetTabReferenceObj(event.InteractionID).OtherData.PhoneNumber = phoneNumber;
            } catch (ex) {
                log.LogDetails("Error", "VoiceUI.VoiceOutgoingCallEvent() - Inside2", ex, false);
            }
        }
        //disable initially and enable after call answer
        DisableTransferToIVR(event.InteractionID);
        //enable drop button & disable answer,hold,trans,conf buttons
        SetCallControlStatus(event.InteractionID, false, true, false, "disable", false, false);
        CloseMakeCallDialog();
        $("#btndisconnectSpan").addClass("uk-display-none");
        if (disconnectByHandleType == "callback" && GetTabReferenceObj(event.InteractionID) !== undefined) {
            $("#btnDrop" + event.InteractionID).removeClass("uk-display-none");
            $("#btndisconnectDial" + event.InteractionID).addClass("uk-display-none");
        }

        if (isDynamicCRM) DynamicsCRMStartVoicePopUpScreen(event, false);

        global_ConnectionHandle = "";

        let isInternalCallFlag = false;
        isInternalCallFlag = isInternalCall(event.PhoneNumber);
        if (isInternalCallFlag) {
            GetTabReferenceObj(event.InteractionID).OtherData.CallType = "2";
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceOutgoingCallEvent()", ex, false);
    }
}

function VoiceCallConnectedEvent(event) {
    try {
        //enable drop,hold,trans,conf buttons, disable answer button
        SetCallControlStatus(event.InteractionID, false, true, true, false, true, true);
        //enable transfer to ivr button
        EnableTransferToIVR(event.InteractionID);
        ChangeTabReferenceStatus(event.InteractionID, 'CallConnected');
        //SIP Dialer Changes - Update the assigned date and assigned time for the callback recieved
        if (GetTabReferenceObj(event.InteractionID).OtherData.srno !== null) {
            var srno = GetTabReferenceObj(event.InteractionID).OtherData.srno;
            custom_updateDataOnConnectForCallback(event.InteractionID, srno);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallConnectedEvent()", ex, false);
    }
}

function VoiceCallDisconnectedEvent(event) {
    try {
        isStatusManagerChange = true;
        global_CallType = "";
        //if the calltype is 2 then its not a acd call
        if (event.CallType == "2")
            SetCallControlStatus(event.InteractionID, false, false, false, false, false, false, true);
        else
            SetCallControlStatus(event.InteractionID, false, false, false, false, false, false, isEnableCloseTabOnDisconnect.Voice);
        //diable transfer to ivr button
        DisableTransferToIVR(event.InteractionID);
        ChangeTabReferenceStatus(event.InteractionID, 'CallDisconnected');
        $("#li_" + event.InteractionID).removeClass("li-on-call");
        //check if this is an vouce out tab. Then close the tab
        try {
            if (GetTabReferenceObj(event.InteractionID).type == 'voice') {
                if (GetTabReferenceObj(event.InteractionID).direction == 'out') {
                    //commandManager.js
                    if (!global_isTPINTrasnferOutbound) {
                        //CloseTab(global_DeviceID, event.InteractionID);
                        ChangeStatus(global_DeviceID, 'acw', '0');
                        FadeOutButton("#btn_make_call");
                    } else if (global_isFeewaiverTrasnferOutbound) {
                        //CloseTab(global_DeviceID, event.InteractionID);
                        ChangeStatus(global_DeviceID, 'acw', '0');
                        FadeOutButton("#btn_make_call");
                        global_isFeewaiverTrasnferOutbound = false;
                    } else {
                        global_isTPINTrasnferOutbound = false;
                    }
                    if (isDynamicCRM) DynamicsCRMEndVoicePopUpScreen(event, false);
                }
                else {
                    if (isDynamicCRM) DynamicsCRMEndVoicePopUpScreen(event, true);
                }
                if (global_isTPINTransferDone) {
                    ChangeStatus(global_DeviceID, 'aux', '6');
                }
                //Check if its TPIN transfer, if yes dont start ACW Timer. 
                if (!global_isTPINTransferDone) {
                    //Start the ACW Timer for iServe
                    if (isIServe) custom_UpdateEndOfCallACWStartTime(event.InteractionID, global_UCID[global_activeTabId], global_LanID);
                } else {
                    global_isTPINTransferDone = false;
                }
                //changed 16th November - call transfer cancel issue
                global_IsAgentTransferedCall = false;
            }
        } catch (ex) {
            log.LogDetails("Error", "EventHandler.VoiceCallDisconnectedEvent() - Inside1", ex, false);
        }

        //incoming callback - upon disconnect - enable dial and disable submit
        //incoming callback - upon dial and disconnect - enable dial and enable submit
        //incoming callback transfer - upon disconnect - enable dial and enable submit
        try {
            if (GetTabReferenceObj(event.InteractionID).type.indexOf("callback") !== -1) {
                if (!GetTabReferenceObj(event.InteractionID).OtherData.isCallbackTransferInit) {
                    if (GetTabReferenceObj(event.InteractionID).OtherData.isCallbackTransferRec) {
                        EnableCallbackDialButtons(event.InteractionID);
                        EnableCallbackSubmitButtons(event.InteractionID);
                    } else if (!GetTabReferenceObj(event.InteractionID).OtherData.customMakeCallDone) {
                        EnableCallbackDialButtons(event.InteractionID);
                        DisableCallbackSubmitButtons(event.InteractionID);
                    } else {
                        EnableCallbackDialButtons(event.InteractionID);
                        EnableCallbackSubmitButtons(event.InteractionID);
                    }
                } else {
                    if (GetTabReferenceObj(object.interactionid).OtherData.isCallbackTransferComplete) {
                        DisableCallbackDialButtons(event.InteractionID);
                        DisableCallbackSubmitButtons(event.InteractionID);
                    } else {
                        EnableCallbackDialButtons(event.InteractionID);
                        EnableCallbackSubmitButtons(event.InteractionID);
                    }
                }
            }
        } catch (ex) {
            log.LogDetails("Error", "EventHandler.VoiceCallDisconnectedEvent() - Inside2", ex, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallDisconnectedEvent()", ex, false);
    }
}

function VoiceCallTransferInitiatedEvent(event) {
    try {
        //enable complete, cancel buttons on transfer window
        TransferInitiated();
        //check if this is a blind transfer to agent, skip if the transfer is to queue
        if (favListGridItemSelect == "vdnTransfer") {
            let intId = global_transferIntID;
            //blind transfer to agent need to call 'TransferComplete' programmatically
            TransferComplete(global_DeviceID, intId);
            favListGridItemSelect = "";
            //Insert into custom table, the ucid to recognise from iServe that it is a blind transfer
            if (isIServe) custom_UpdateUCIDOnBlindTransfer(intId, global_UCID[intId]);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallTransferInitiatedEvent()", ex, false);
    }
}

function AddVoiceTab(divBody, intid, phonenumber, ischatcallback, vdnname, hasCallback) {
    try {
        let tabType = "";
        var callbacktabFlag = false;
        AddDynamicFields("voice");
        // if phone number is a callback phantom extension, then use Callback Body
        //SIP Dialer - Check for Callback Call - Changed by Mukesh - 8th Aug, 2016
        if ((global_CallbackVDNListStart !== undefined && global_CallbackVDNListEnd !== undefined && isCallbackNumber(phonenumber)) || ischatcallback || hasCallback) {
            tabType = "phone_callback";
            callbacktabFlag = true;
            var callbackType = "";
            if (ischatcallback) {
                callbackType = "acallback";
            } else if (hasCallback) {
                callbackType = "pcallback";
            } else if (isCallbackNumber(phonenumber)) {
                callbackType = "scallback";
            }
            SaveTabReference(callbackType, intid, "new");
            GetTabReferenceObj(intid).OtherData.customMakeCallDone = false;
            GetTabReferenceObj(intid).OtherData.isCallbackTransferInit = false;
            GetTabReferenceObj(intid).OtherData.isCallbackTransferComplete = false;
            GetTabReferenceObj(intid).OtherData.isCallbackTransferRec = false;
        } else {
            tabType = "phone";
            callbacktabFlag = false;
            SaveTabReference('voice', intid, 'new');
        }
        //tab header content
        let headerTemplate = GetTabHtml("tab_header_template", intid, { icon: tabType });

        //tab body content
        let bodyTemplate = document.getElementById(divBody).innerHTML;

        //add a kendo tab
        AddTab(bodyTemplate, headerTemplate, intid, phonenumber, true, false, true);

        if (!callbacktabFlag) {
            //$('#txtDNIS' + intid).val(vdnname);
            $('#txtCallerID' + intid).val(phonenumber);
            $("#VoiceTabData" + intid).toggle(true);
            $("#divCallbackBody" + intid).toggle(false);
            //show/hide voice authentication panel
            $("#div_verified_status" + intid).toggle(isVoiceAuthenticationPanel);
            $("#div_tpin_status" + intid).toggle(isVoiceAuthenticationPanel);
            if (isVoiceAuthenticationPanel) {
                $("#auth_vs_label" + intid).text(voiceAuthenticationLabels.label1);
                $("#auth_tp_label" + intid).text(voiceAuthenticationLabels.label2);
            }
            //show/hide IVR transfer button
            $("#ddlTransferToIVR" + intid).toggle(ivrTransferEnabled);
            //show/hide IVR menus
            $("#ivr_menus" + intid).toggle(isIvrMenuEnabled);
        } else {
            $("#VoiceTabData" + intid).toggle(false);
            $("#divCallbackBody" + intid).toggle(true);
            $("#div_verified_status" + intid).toggle(false);
            $("#div_tpin_status" + intid).toggle(false);
            $("#ddlTransferToIVR" + intid).toggle(false);
            $("#ddl_time" + intid).kendoMaskedTextBox({
                mask: "00:00"
            });
            $("#ddl_time" + intid).data("kendoMaskedTextBox").enable(false);
            $("#ddl_time" + intid).removeClass("k-textbox");
        }

        // Lets Assign the tabs here
        if (callbacktabFlag) CreatePendingCallbackGrid(intid);

        //show and append data workcodes if configured
        if (isWorkCode) BindWorkCodes(intid);

        // When call comes, store the start time in the hidden field
        AddCallTimer(intid, "voice", "#hdn_voice_call_starttime" + intid, "#voice_call_starttime" + intid,
            "#voice_call_time_taken" + intid, "#voice_call_span_starttime" + intid, "", "", "", "", "", "");
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.AddVoiceTab()", ex, false);
    }
}

function BindWorkCodes(intid) {
    try {
        $("#workcodes_div" + intid).removeClass("uk-display-none");
        $("#workcodes" + intid).kendoMultiSelect({
            dataTextField: "Name",
            dataValueField: "Code",
            dataSource: global_WorkCodeList,
            deselect: function (arg) {
                RemoveCallWorkCode(intid, arg.dataItem.Code);
            },
            select: function (arg) {
                SetCallWorkCode(intid, arg.dataItem.Code);
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.BindWorkCodes()", ex, false);
    }
}

function TextChatCallBackEvent(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        var interactionid = event.InteractionID;
        var data = {};
        event.UCID = parse.sessionid;
        event.PhoneNumber = "";
        event.CalledDevice = parse.sessionid;
        event.InteractionID = interactionid;
        var sessionid = parse.sessionid;

        //custom textchat callback
        custom_TextChatCallback(sessionid, parse.srno, interactionid);

        //amacTextChatUI.js
        LoadCIF(interactionid, event.UCID);
        custom_LoadUCIDChatToCallback(interactionid, parse.sessionid);

        //create a new tab
        AddVoiceTab('voice_tab_body', event.InteractionID, event.PhoneNumber, true);

        //Initialize the UIKit accordion for the created tab
        UIkit.accordion($('#voice_accordion' + event.InteractionID), {
            collapse: false,
            showfirst: true
        });

        $("#hdn_transfer_type" + event.InteractionID).val("Callback");
        $("#hdn_srno" + event.InteractionID).val(parse.srno);
        global_isTextChatCallback = true;

        ChangeStatus(global_DeviceID, 'acw', '0');
        DisableCallbackDetailsButtons(event.InteractionID);
        custom_getdetailsforSrno(event.InteractionID, parse.srno);
        //custom_getdetailsforUCID(event.InteractionID, event.UCID);

        //enable answer button
        //disable drop,hold,trans,conf buttons
        SetHiddenFieldCallback(event);
        SetCallControlStatus(event.InteractionID, false, false, false, false, false, false);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TextChatCallBackEvent()", ex, false);
    }
}

function IVRTransfer(intid, type) {
    try {
        //deviceid, interactionid, type, languageid
        var languageid = $("#txtLanguage" + intid).val();
        TransferToIVR(global_DeviceID, intid, type.toLowerCase(), languageid);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.IVRTransfer()", ex, false);
    }
}

function TransferCall() {
    try {
        DisableButton("#btndialogtransfercall");
        //check if agent is transferring call to himself
        let number = $("#txtNumberTrans").val();
        let comment;
        //get the interaction id
        let intId = global_transferIntID;
        let obj = {};
        obj.buttonId = "#btndialogtransfercall";
        obj.icon = "swap_horiz";
        obj.type = "transfer";
        if (number == global_AgentID) {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Transfer to self is not allowed!", "danger", null, "top-center");
            return;
        }
        if (number === "") {
            EnableButton(obj.buttonId, obj.icon, "icon");
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }
        //check if this is a text chat transfer
        if (global_CallType == "TextChatTransfer") {
            number = $("#txtNumberTrans").val();
            comment = $("#txtCommentTrans").val();
            //check if the transfer is queue
            if (favListGridItemSelect == "favItemSelect") {
                //transfer the text chat to queue
                TransferTextChatToQueue(global_DeviceID, intId, number, true, GetChatReferenceObj(intId).chatMode, obj);
            }
            //else is chat transfer to agent
            else {
                let otherData = {};
                otherData.type = "transfer";
                otherData.mode = GetChatReferenceObj(intId).chatMode;
                //send the transfer notification
                SendTextChatTransferNotification(global_DeviceID, intId, number, comment, JSON.stringify(otherData), destTmacServerName, null);
            }
        }
        //else the transfer is voice to agent
        else {
            number = $("#txtNumberTrans").val();
            comment = $("#txtCommentTrans").val();
            var val = $("#hdn_transfer_type" + intId).val();
            if (val == "Callback") {
                var srno = $("#hdn_srno" + intId).val();
                comment = "SRNO:" + srno + "? " + comment;
                GetTabReferenceObj(intId).OtherData.isCallbackTransferInit = true;
            }
            //commandManager.js
            TransferCallCommand(global_DeviceID, intId, number, comment, obj);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCall()", ex, false);
    }
}

function TransferCallBlind() {
    try {
        DisableButton("#btndialogblindtransfercall");
        //check if this is a text chat transfer
        //get the interaction id
        let intId = global_transferIntID;
        let number = $("#txtNumberTrans").val();
        let comment = $("#txtCommentTrans").val();
        let textChatFav = "";
        let obj = {};
        //set it to 'vdnTransfer' for blind transfer of call/chat to agent
        favListGridItemSelect = "vdnTransfer";
        obj.buttonId = "#btndialogblindtransfercall";
        obj.icon = "BT";
        obj.type = "transfer";
        if (number === "") {
            EnableButton(obj.buttonId, obj.icon, "tag");
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }
        //if the transfer is chat then get the value of 'favListGridItemSelectForChat'
        if (global_CallType === "TextChatTransfer") {
            GetChatReferenceObj(intId).isTransfer = true;
            textChatFav = favListGridItemSelectForChat;
        }
        //if its chat transfer and is queue selected, transfer to queue
        if (textChatFav === "favItemSelect" && global_CallType === "TextChatTransfer") {
            //transfer the text chat to queue
            TransferTextChatToQueue(global_DeviceID, intId, number, true, GetChatReferenceObj(intId).chatMode, obj);
            //clear the value as this is a transfer to queue doest need to call transfer complete on tmacevent_CallTransferInitiatedEvent
            favListGridItemSelect = "";
        }
        //text chat blind transfer for WQ routing
        else if (global_CallType === "TextChatTransfer" && GetChatReferenceObj(intId).isNonVoiceRouting) {
            obj.type = "TextChatTransfer";
            TransferTextChatToServer(global_DeviceID, global_AgentID, intId, number, "", global_UCID[intId], number,
                "wq", destTmacServerName, "transfer", GetChatReferenceObj(intId).chatMode, obj);
        }
        //else the transfer is chat/voice to agent
        else {
            //for voice blind tranfer call TransferCallCommand
            if (global_CallType === "Transfer") {
                TransferCallCommand(global_DeviceID, intId, number, comment, obj);
            }
            //for chat blind transfer call TransferTextChatToQueue
            else {
                TransferTextChatToQueue(global_DeviceID, intId, number, true, GetChatReferenceObj(intId).chatMode, obj);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCallBlind()", ex, false);
    }
}

function CancelTransfer(cntrl) {
    try {
        if (global_CallType == "Transfer") {
            TransferCancel();
        } else {
            CancelConference();
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CancelTransfer()", ex, false);
    }
}

function TransferCancel() {
    try {
        //get the interaction id
        var intId = global_transferIntID;
        //commandManager.js
        TransferCancelCommand(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCancel()", ex, false);
    }
}

function CompleteTransfer() {
    try {
        if (global_CallType == "Transfer") {
            TransferComplete();
        } else {
            ConferenceComplete();
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CompleteTransfer()", ex, false);
    }
}

function TransferComplete() {
    try {
        //get the interaction id
        var intId = global_transferIntID;
        //commandManager.js
        TransferCompleteCommand(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferComplete()", ex, false);
    }
}

function TransferInitiated() {
    try {
        //enable complete, cancel buttons on transfer window
        //$('#btnTrCancel').toggle(true);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferInitiated()", ex, false);
    }
}

function VoiceCallTransferRemoteConnected() {
    try {
        //enable complete, cancel buttons on transfer window
        $('#btnDone').removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.VoiceCallTransferRemoteConnected()", ex, false);
    }
}

function TransferLineDisconnected(data) {
    try {
        //hide the confirm window
        HideConfirmDialog();
        //enable drop,hold,trans,conf buttons
        //disable answer button
        if (data.IsMainLine) //in connected state
            SetCallControlStatus(data.InteractionID, false, true, true, false, true, true);
        else //in hold state
            SetCallControlStatus(data.InteractionID, false, false, false, true, false, false);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferLineDisconnected()", ex, false);
    }
}

function CallConference() {
    try {
        DisableButton("#btnConfMCall");
        //get the interaction id
        let intId = global_conferenceIntID;
        let number = $("#txtNumberConf").val();
        let comment = "";
        let obj = {};
        obj.buttonId = "#btnConfMCall";
        obj.icon = "call_split";
        obj.type = "conference";
        //commandManager.js
        if (number === "") {
            EnableButton("#btnConfMCall", "call", "icon");
            ShowNotify("Invalid number", "danger", null, "top-center");
            return;
        }
        if (global_CallType == "TextChatConference") {
            obj.type = "TextChatConference";
            let otherData = {};
            otherData.type = "conf";
            otherData.mode = GetChatReferenceObj(intId).chatMode;
            SendTextChatTransferNotification(global_DeviceID, intId, number, comment, JSON.stringify(otherData), destTmacServerName, obj);
        }
        else
            ConferenceCall(global_DeviceID, intId, number, comment, obj);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CallConference()", ex, false);
    }
}

function CancelConference() {
    try {
        //get the interaction id
        var intId = global_conferenceIntID;
        //commandManager.js
        ConferenceCancel(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CancelConference()", ex, false);
    }
}

function ConferenceComplete() {
    try {
        //get the interaction id
        var intId = global_conferenceIntID;
        //commandManager.js
        ConferenceCompleteCommand(global_DeviceID, intId);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceComplete()", ex, false);
    }
}

function ConferenceInitiated() {
    try {
        //enable complete, cancel buttons on Conference window
        //$('#btnConfCancel').toggle(true);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceInitiated()", ex, false);
    }
}

function ConferenceRemoteConnected() {
    try {
        //enable complete, cancel buttons on transfer window
        $('#btnDone').removeClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceRemoteConnected()", ex, false);
    }
}

function ConferenceLineDisconnected(data) {
    try {
        //hide the transfer window
        HideConfirmDialog();
        //enable drop,hold,trans,conf buttons
        //disable answer button
        SetCallControlStatus(data.InteractionID, false, true, true, false, true, true);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceLineDisconnected()", ex, false);
    }
}

function ConferenceCompleted(data) {
    try {
        //hide the transfer window
        HideConfirmDialog();
        //enable drop,hold,trans,conf buttons
        //disable answer button
        SetCallControlStatus(data.InteractionID, false, true, true, false, true, true);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceCompleted()", ex, false);
    }
}

function OpenTransferDialog(intid) {
    try {
        EnableButton("#btndialogtransfercall", "swap_horiz", "icon");
        EnableButton("#btndialogblindtransfercall", "BT", "tag");
        GetTmacWallboardSkills();
        GetAgentListStaffed(intid, "transferCall", "#btnTrans" + intid, "swap_horiz");
        DisableButton("#btnTrans" + intid);
        global_transferIntID = intid;
        //transfer type changed to voice
        global_CallType = "Transfer";
        //remove read only for voice transfer
        $("#txtNumberTrans").removeAttr("readonly", "readonly");
        //select the first agent list tab
        $("#tabstrip_transfer").data("kendoTabStrip").select(0);
        $("#transfer_dialog").data("kendoWindow").title("Transfer Call List");
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenTransferDialog()", ex, false);
    }
}

function TransferCallEvent(event) {
    try {
        if (event.keyCode == 13) {
            TransferCall();
        } else
            ValidateChar(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.TransferCallEvent()", ex, false);
    }
}

function OpenConferenceDialog(intid) {
    try {
        GetAgentListStaffed(intid, "conferenceCall", "#btnConf" + intid, "group");
        DisableButton("#btnConf" + intid);
        global_conferenceIntID = intid;
        global_CallType = "Conference";
        $("#conference_dialog").data("kendoWindow").title("Conference Call List");
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenConferenceDialog()", ex, false);
    }
}

function ConferenceCallEvent(event) {
    try {
        if (event.keyCode == 13) {
            conferenceCall();
        } else
            ValidateChar(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.ConferenceCallEvent()", ex, false);
    }
}

function HideConfirmDialog() {
    try {
        $("#confirm_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.HideConfirmDialog()", ex, false);
    }
}

function CloseTransferDialog() {
    try {
        $("#transfer_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CloseTransferDialog()", ex, false);
    }
}

function CloseConfDialog() {
    try {
        $("#conference_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CloseConfDialog()", ex, false);
    }
}

function OpenConfirmDialog(type) {
    try {
        if (type === "transfer")
            CloseTransferDialog();
        else if (type === "conference")
            CloseConfDialog();
        else if (type == "pom")
            ClosePOMTransConfDialog();
        $("#confirm_dialog").data("kendoWindow").center().open();
        $('#btnDone').addClass('disabled');
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenConfirmDialog()", ex, false);
    }
}

function OpenMakeCallDialog() {
    try {
        DisableButton("#btn_make_call");
        GetAgentListStaffed("", "makeCall", "", "");
        global_CallType = "MakeCall";
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.OpenMakeCallDialog()", ex, false);
    }
}

function MakeCallEvent(event) {
    try {
        if (event.keyCode == 13) {
            MakeCall(global_DeviceID, '', 'makecall');
        } else
            ValidateChar(event);
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.MakeCallEvent()", ex, false);
    }
}

function CloseMakeCallDialog() {
    try {
        $("#make_call_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.CloseMakeCallDialog()", ex, false);
    }
}

function GetQueueTimeForUCID(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        if (parse.cumulativequeuetime != "0:0:0") {
            if (parse.dbQueueTime != "0:0:0") {
                var colorCode = GetColorCode(parse.dbQueueTime);
                if (parse.blindTransferFlag) {
                    document.getElementById('txtQueueTime' + event.InteractionID).value = parse.cumulativequeuetime + "s / " + parse.diffTime + "s";
                }
                //document.getElementById('txtQueueTime' + event.InteractionID).style.backgroundColor = colorCode;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.GetQueueTimeForUCID()", ex, false);
    }
}

function SetCallControlStatus(intid, answer, drop, hold, unhold, trans, conf, tabClose) {
    try {
        if (answer === false) {
            $('#btnAnswer' + intid).addClass('disabled');
        } else {
            $('#btnAnswer' + intid).removeClass('disabled');
        }

        if (drop === false) {
            $('#btnDrop' + intid).addClass('disabled');
        } else {
            $('#btnDrop' + intid).removeClass('disabled');
        }

        if (trans === false) {
            $('#btnTrans' + intid).addClass('disabled');
        } else {
            $('#btnTrans' + intid).removeClass('disabled');
        }
        if (conf === false) {
            $('#btnConf' + intid).addClass('disabled');
        } else {
            $('#btnConf' + intid).removeClass('disabled');
        }

        if (tabClose === true) {
            if (global_CallType != "Transfer") {
                EnableTabCloseButton(intid);
            }
        }

        //check if this is a callback tab. Then enable both PCN dial and CID buttons
        if (!answer && !drop && !hold && !unhold) {
            try {
                //var val = GetTabReferenceObj(intid).OtherData.isCallbackTransferInit;
                var val = GetTabReferenceObj(intid).OtherData.isCallbackTransferInit;
                if (val) {
                    EnableTabCloseButton(intid);
                    DisableCallbackSubmitButtons(intid);
                } else {
                    EnableCallbackDialButtons(intid);
                }
            } catch (ex) {
                log.LogDetails("Error", "VoiceUI.SetCallControlStatus() - Inside1", ex, false);
            }
        }

        //disable callback button
        try {
            $('#btnCallback' + intid).addClass('disabled');
        } catch (ex) {
            log.LogDetails("Error", "VoiceUI.SetCallControlStatus() - Inside2", ex, false);
        }

        try {
            if (!hold && !unhold) {
                $('#btnHold' + intid).css("display", "inline-block");
                $('#btnUnHold' + intid).css("display", "none");
                $('#btnHold' + intid).addClass('disabled');
            } else if (hold) {
                $('#btnHold' + intid).css("display", "inline-block");
                $('#btnUnHold' + intid).css("display", "none");
                $('#btnHold' + intid).removeClass('disabled');
            } else if (unhold != "disable") {
                $('#btnUnHold' + intid).css("display", "inline-block");
                $('#btnHold' + intid).css("display", "none");
                $('#btnUnHold' + intid).removeClass('disabled');
            } else {
                $('#btnUnHold' + intid).css("display", "inline-block");
                $('#btnHold' + intid).css("display", "none");
                $('#btnUnHold' + intid).addClass('disabled');
            }
        } catch (ex) {
            log.LogDetails("Error", "VoiceUI.SetCallControlStatus() - Inside3", ex, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.SetCallControlStatus()", ex, false);
    }
}

function SetIVRData(data) {
    try {
        if (data !== null) {
            var ivrLastMenus = "";
            if (data.LastMenu == "null") {
                ivrLastMenus = "";
            } else {
                ivrLastMenus = "<li><span>" + data.LastMenu + "</span></li><li><span>" + data.LastMenu_2 + "</span></li><li><span>" +
                    data.LastMenu_3 + "</span></li><li><span>" + data.LastMenu_4 + "</span></li>";
            }
            document.getElementById('divLast4IVR' + data.InteractionID).innerHTML = ivrLastMenus;
            var time = GetTimeInSeconds(data.QueueTime);
            var colorCode = GetColorCode(time);
            document.getElementById('txtQueueTime' + data.InteractionID).value = data.QueueTime + " seconds";
            document.getElementById('txtQueueTime' + data.InteractionID).style.color = colorCode;
            //$('#txtQueueTime' + data.InteractionID).attr('readonly', true);
            // Check if its TPIN Transfer. If yes do not show the cumulative queuetime and show original queuetime
            if (isIServe && !global_isTPINTransfer) {
                //Check if it is a transfer by getting the QueueTime for the current UCID
                custom_getQueueTimeForUCID(data.InteractionID, global_UCID[data.InteractionID], data.QueueTime);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.SetIVRData()", ex, false);
    }
}

function GetTimeInSeconds(queueTime) {
    try {
        var hms = queueTime;
        var a = hms.split(':');
        var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
        return seconds;
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.GetTimeInSeconds()", ex, false);
    }
}

function SetUUIData(data) {
    try {
        if (data !== null) {
            AssignDynamicValues(data, "voice");
            //$('txtAuth' + data.InteractionID).val(data.AuthType.AuthCode);
            //Changes done on 19th November - Clyde Request
            // isVerifed or Identified ?
            if ((data.AuthType.AuthCode == "A") || (data.AuthType.AuthCode == "B") || (data.AuthType.AuthCode == "C") || (data.AuthType.AuthCode == "D")) {
                //TPIN Verified
                $('#verifiedStatus' + data.InteractionID).html("<span class='uk-text-success uk-text-bold uk-text-small'><i class='material-icons uk-text-success'>done</i> TPIN Verified</span>");
            } else if ((data.AuthType.AuthCode == "F") || (data.AuthType.AuthCode == "G") || (data.AuthType.AuthCode == "H")) {
                //Identified
                $('#verifiedStatus' + data.InteractionID).html("<span class='uk-text-warning uk-text-bold uk-text-small'><i class='material-icons uk-text-warning'>error</i> Identified</span>");
            } else if (data.AuthType.AuthCode == "E") {
                //Unidentified (REGISTERED HP USED)
                $('#verifiedStatus' + data.InteractionID).html("<span class='uk-text-danger uk-text-bold uk-text-small'><i class='material-icons uk-text-danger'>error</i> Unidentified (REGISTERED HP USED)</span>");
            } else {
                $('#verifiedStatus' + data.InteractionID).html("<span class='uk-text-danger uk-text-bold uk-text-small'><i class='material-icons uk-text-danger'>error</i> Not Identified</span>");
            }
            // TPIN lock Status - Added By Ajith -Start
            try {
                var trimmedValueTPINStatus = data.OtherData;
                trimmedValueTPINStatus = $.trim(trimmedValueTPINStatus);
                trimmedValueTPINStatus = trimmedValueTPINStatus.substring(trimmedValueTPINStatus.length, trimmedValueTPINStatus.length - 1); //TPIN lock Status [A,B,C] is the 22nd char in OtherData variable
                if (trimmedValueTPINStatus !== "") {
                    if ((trimmedValueTPINStatus == "A")) {
                        //TPIN lock Status is Just Locked
                        $('#tpinlockStatus' + data.InteractionID).html("<span class='uk-text-danger uk-text-bold uk-text-small'><i class='material-icons uk-text-danger'>error</i> TPIN JUST Locked</span>");
                    } else if ((trimmedValueTPINStatus == "B")) {
                        //TPIN lock Status is PREV Locked
                        $('#tpinlockStatus' + data.InteractionID).html("<span class='uk-text-danger uk-text-bold uk-text-small'><i class='material-icons uk-text-danger'>error</i> TPIN PREV Locked</span>");
                    } else if ((trimmedValueTPINStatus == "C")) {
                        //TPIN lock Status is SYS GEN TPIN
                        $('#tpinlockStatus' + data.InteractionID).html("<span class='uk-text-success uk-text-bold uk-text-small'><i class='material-icons uk-text-success'>done</i> SYS GEN TPIN</span>");
                    } else {
                        $('#tpinlockStatus' + data.InteractionID).html("<span class='uk-text-danger uk-text-bold uk-text-small'><i class='material-icons uk-text-danger'>error</i> N/A</span>");
                    }
                }
            } catch (ex) {
                log.LogDetails("Error", "VoiceUI.SetUUIData() - Inside", ex, false);
            }
            // TPIN lock Status - Added By Ajith - End
        }
    } catch (ex) {
        log.LogDetails("Error", "VoiceUI.SetUUIData()", ex, false);
    }
}