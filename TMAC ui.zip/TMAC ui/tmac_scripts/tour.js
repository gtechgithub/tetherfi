tmac_tour = {
    init: function () {

        // This tour guide is based on EnjoyHint plugin
        // for more info/documentation please check https://github.com/xbsoftware/enjoyhint
        $('#startTour').click(function () {
            tmac_tour.run_tour();
        })
    },

    run_tour: function () {
        // initialize instance
        var enjoyhint_instance = new EnjoyHint({});

        // config
        var enjoyhint_script_steps = [
            {
                "next #header_main": 'Hello, In this short tour guide I\'ll show you<br>' +
                'some features included in TCW<br>' +
                'This is the main header.<br>' +
                'Click "Next" to proceed.'
            },
            {
                "next #full_screen_toggle": "Here you can activate fullscreen.",
                shape: 'circle',
                radius: 30,
                showSkip: false
            },
            {
                "click #btn_change_status": "Click this area to change agent status.",
                showSkip: false
            },
            {
                "click #auxstatuslist": "These are the agent status available",
                showSkip: false,
                showNext: true,
            },
            {
                "next #btn_timer": "This is the agent status timer.",
                showSkip: true
            },
            {
                "next #style_switcher_toggle": "When you click on that icon '<i class='material-icons'>settings</i>'<br>" +
                "you will activate style switcher.<br>" +
                "There you can change <span class='md-color-red-500'>c</span><span class='md-color-light-blue-500'>o</span><span class='md-color-red-500'>l</span><span class='md-color-orange-500'>o</span><span class='md-color-pink-500'>r</span><span class='md-color-light-green-500'>s</span> and few other things.",
                shape: 'circle',
                radius: 30,
                showSkip: false
            },
            {
                "next #ui_tmac_logo": "This is the TCW status. <br>" +
                "<span class='md-color-red-500'>Red</span> - Offline<br>" +
                "<span class='md-color-green-500'>Green</span> - Online<br>" +
                "<span class='md-color-orange-500'>Orange</span> - Waiting<br>",
                shape: 'circle',
                radius: 30,
                showSkip: true
            },
            {
                "next #sidebar_main": "This is the primary sidebar for agent info and reminders.<br>" +
                "Click 'Next' to find out how to close this sidebar.<br>",
                showSkip: false
            },
            {
                "next #sidebar_main_toggle": "Click this icon to close primary sidebar.",
                shape: 'circle',
                radius: 30,
                showSkip: true
            },
            {
                "click #sidebar_secondary_toggle": "Click here to see the customers list.",
                shape: 'circle',
                radius: 30,
                showSkip: false
            },
            {
                "next #customer_chatboxes": "This is the secondary sidebar where you can see all the customer you are handling.",
                showSkip: true
            },
            {
                "key #sidebar_secondary_toggle": "Click here again to close the customers list.",
                shape: 'circle',
                radius: 30,
                "skipButton": { text: "Finish" }
            },
        ];

        // set script config
        enjoyhint_instance.set(enjoyhint_script_steps);

        // run Enjoyhint script
        enjoyhint_instance.run();
    }
};

$(function () {
    tmac_tour.init();
});
