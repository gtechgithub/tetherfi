﻿var statsDiv;
var callended = false;
function startStats() {
    statsDiv = document.getElementById('statsDiv');

    // Display statistics
    setInterval(function () {
        if (callended)
            return;

        getStats(peerConn, function (stats) {
            onGettingWebRTCStats(stats, '100');
        });

    }, 1000);
}

function onGettingWebRTCStats(stats, remoteUserId) {

    var statsData = '';// 'UserID: ' + remoteUserId + '\n';
    //statsData += 'Available Send Bandwidth: ' + bytesToSize(stats.bandwidth.availableSendBandwidth);
    //statsData += '\n';
    //statsData += 'Encryption: ' + stats.encryption;
    //statsData += '\n';
    statsData += 'Codecs: ' + stats.audio.recv.codecs.concat(stats.video.recv.codecs).join(', ');
    statsData += '\n';
    statsData += 'Data Rec: ' + getbytesToSize(stats.audio.bytesReceived + stats.video.bytesReceived);
    statsData += '\n';
    statsData += 'ICE: ' + stats.connectionType.remote.candidateType.join(', ');
    statsData += '\n';
    statsData += 'Port: ' + stats.connectionType.remote.transport.join(', ');
    statsData += '\n';

    statsData += "Send Res:" + stats.resolutions.send.width + "x" + stats.resolutions.send.height;
    statsData += '\n';
    statsData += "Rec Res:" + stats.resolutions.recv.width + "x" + stats.resolutions.recv.height;

    //statsDiv.innerHTML = statsData.replace(/\n/g, '<br>');
}

function getbytesToSize(bytes) {
    var k = 1000;
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) {
        return '0 Bytes';
    }
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(k)), 10);
    return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];
}