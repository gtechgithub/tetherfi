var version = "3.1.05.31";

//list of remote streams
var remoteStreamList = [];

//webRTC audio enabled or disabled
var enableAudio = true;
var enableVideo = true;

//media constrains for peer connections (offer)
var mediaConstraints = {
    "iceRestart": true,
    "audio": enableAudio,
    "video": enableVideo
};

//media constrains for peer connections (answer)
var answerconstraints = {
    'mandatory': {
        'OfferToReceiveAudio': true,
        'OfferToReceiveVideo': true
    }
};

//ice config (STUN and TURN)
var ICE_config = {
    'iceServers': [
        {
            'url': 'turn:202.150.214.54:3579?transport=udp', //43.229.84.30
            //'url': 'turn:202.6.215.228:3579?transport=tcp',
            'credential': 'nuwan',
            'username': 'tetherfi'
        }
    ]
};

var _this;

//call recorder
var recordRTC;
///----------------------------------CONFIG END HERE--------------------------------------------
window.onload = function () {
    Log(5, "SenderJS version=" + version);
    try {
        NotifyParent("loaded", "success");
    } catch (ex) {
        Log(0, "error start: " + ex);
    }
};

//VideoConnection
function VideoConnection(comm, userType, callType, confJson) {
    Log(5, "VideoConnection: " + userType + ", " + callType);
    try {
        this.comm = comm;
        //user type sender or receiver
        this.userType = userType;
        //video type new/conf
        this.callType = callType;
        //webrtc peer connections
        this.peerConn = null;
        //local stream (captured from cam and mic)
        this.localStream;
        //remote stream (received from remote peer)
        this.remoteStream;
        //local video html control
        this.sourcevid;
        //session id
        this.localId = "";
        //default remote video screen size
        this.screenHeight = "720";
        //show or hide local video
        this.showLocalVideo = false;
        //show or hide remote video
        this.showRemoteVideo = false;
        //show or hide stats
        this.showStats = false;
        //status object
        this.statusObj = null;
        //recording enabled or not
        this.recordVideo = true;
        //answer command received or not (used for ice handshake)
        this.answerReceived = false;
        //is ice candidate list ready
        this.iceReady = false;
        //did we send ice 
        this.iceSent = false;
        //save the ice candidate event
        this.iceEvent = [];
        //save the received candidates unless we process offer or send answer
        this.receivedCandiates = [];
        //processed offer or answer flag
        this.offerAnswerProcessed = false;
        //store the received offer
        this.offer = null;
        //is bargein available
        this.bargin = "0";
        //remote video added function
        this.remoteVideoAdded = function (v, s) { };
        //offer received from remote
        this.offerReceived = function (offer, sid, localvidControl, audio, video, height, localvid, showremotevid, stat, bargin, startStream, localStream) {
            Log(5, "offerReceived:" + sid + "," + audio + "," + height + "," + localvid + "," + stat);
            //save the offer
            this.offer = offer;
            //start video call
            this.startVideoCall(sid, localvidControl, audio, video, "1080", localvid, showremotevid, stat, bargin, startStream, localStream);
        };

        //start a video call
        this.startVideoCall = function (sid, localvidControl, audio, video, height, localvid, showremotevid, stat, bargin, startStream, localStream) {
            Log(5, "startVideoCall:" + sid);
            try {
                this.bargin = bargin;
                //create local video element
                this.sourcevid = localvidControl;
                //session id
                this.localId = sid;
                //enable webrtc audio
                enableAudio = audio == "1";
                enableVideo = video == "1";
                //height of remote video display
                this.screenHeight = height;
                //enable or disable local video display
                this.showLocalVideo = localvid == "1";
                //enable,disable webrtc stats
                this.showStats = stat == "1";
                //enable or disable remote video display
                this.showRemoteVideo = showremotevid == "1";

                Log(5, "localId = " + this.localId);
                Log(5, "enableAudio = " + enableAudio);
                Log(5, "enableVideo = " + enableVideo);
                Log(5, "screenHeight = " + this.screenHeight);
                Log(5, "showLocalVideo = " + this.showLocalVideo);
                Log(5, "showStats = " + this.showStats);

                //show or hide local vieo control
                if (this.showLocalVideo) {
                    this.sourcevid.style.display = "block";
                }
                else {
                    this.sourcevid.style.display = "none";
                }
                //change media contrains based on the config provided
                mediaConstraints.audio = enableAudio;
                mediaConstraints.video = enableVideo;

                //create peer connection
                this.createPeerConnection();

                //start the straming, get usermedia/call successCallback
                if (startStream) {
                    if (localStream == null)
                        //capture media devies
                        this.getUserMedia();
                    else
                        this.successCallback(localStream, "local");
                }
            } catch (ex) {
                Log(0, "Error in startVideoCall: " + ex);
            }
        };

        //get user media (access to cam and mic)
        this.getUserMedia = function () {
            Log(5, "getUserMedia");
            try {
                _this = this;
                if (navigator.mediaDevices) {
                    navigator.mediaDevices.getUserMedia(mediaConstraints)
                        .then(function (mediaStream) {
                            _this.successCallback(mediaStream, "getUserMedia");
                        }).catch(function (error) {
                            Log(0, "mediaDevices.getUserMedia Error - " + error.name + ":" + error.message);
                        });
                }
                else {
                    navigator.webkitGetUserMedia(mediaConstraints,
                        function (mediaStream) {
                            _this.successCallback(mediaStream, "webkitGetUserMedia");
                        },
                        function (error) {
                            Log(5, "webkitGetUserMedia Error - " + error.name + ":" + error.message);
                        }
                    );
                }
            } catch (ex) {
                Log(0, "Error in getUserMedia: " + ex);
            }
        };

        //get user media success
        this.successCallback = function (stream, type) {
            Log(5, "successCallback : " + type);
            try {
                NotifyParent("initdone", "success");
                //save local stream refernece
                this.localStream = stream;
                //add the stream to peerConn
                this.peerConn.addStream(stream);
                //add local stream to local video element
                this.sourcevid.src = window.webkitURL.createObjectURL(stream);
                _this = null;
                if (userType == "receiver")
                    this.processOffer(this.offer);
            } catch (ex) {
                Log(5, "Error in successCallback: " + ex);
            }
        };

        //answer command received (offer)
        this.processAnswer = function (sdp) {
            Log(5, "processAnswer");
            try {
                this.answerReceived = true;
                //if ice is not sent, then send it now
                if (this.iceSent == false) {
                    Log(5, "processAnswer:iceSent false");
                    //if ice is ready then send ice, else ice will be sent on iceCandidateEvent
                    if (this.iceReady) {
                        Log(5, "processAnswer:iceReady true");
                        this.sendIce();
                    }
                    else {
                        Log(5, "processAnswer:iceReady false");
                    }
                }
                else {
                    Log(5, "processAnswer:iceSent true");
                }
                //set remote sdp
                this.peerConn.setRemoteDescription(new RTCSessionDescription(sdp));
            } catch (ex) {
                Log(0, "Error in processAnswer: " + ex);
            }
        };

        //offer command received (answer)
        this.processOffer = function (sdp) {
            Log(5, "processOffer");
            try {
                //set remote sdp
                this.peerConn.setRemoteDescription(new RTCSessionDescription(sdp));
                //create an offer request
                _this = this;
                this.peerConn.createAnswer(
                    function (sessionDescription) {
                        _this.setLocalAndSendMessage(sessionDescription),
                            _this = null;
                    },
                    function () {
                        _this.createOfferOrAnswerError(),
                            _this = null;
                    },
                    answerconstraints);
            } catch (ex) {
                Log(0, "Error in processOffer: " + ex);
            }
        };

        //send ice candidates to remote peer(offer, answer)
        this.sendIce = function () {
            Log(5, "sendIce");
            try {
                //if answer is already received, then send ice candidates (or if this is a receiver js then send it)
                if ((this.answerReceived || this.userType == "receiver") && this.iceReady) {
                    Log(5, "sendIce:answerReceived true");
                    this.iceSent = true;
                    for (let x = 0; x < this.iceEvent.length; x++) {
                        var event = this.iceEvent[x];
                        this.sendVideoMessage({
                            type: 'candidate',
                            label: event.candidate.sdpMLineIndex,
                            id: event.candidate.sdpMid,
                            candidate: event.candidate.candidate
                        });
                    }
                }
                else {
                    Log(5, "sendIce:answerReceived false");
                }
            } catch (ex) {
                Log(0, "Error in sendIce: " + ex);
            }
        };

        //create webRTC peer connection(offer, answer)
        this.createPeerConnection = function () {
            Log(5, "createPeerConnection");
            try {
                this.peerConn = new webkitRTCPeerConnection(ICE_config);
                this.peerConn.vConn = this;
                //event hanlders for create peer connection
                this.peerConn.onicecandidate = this.onIceCandidate;
                this.peerConn.onaddstream = this.onRemoteStreamAdded;
                this.peerConn.onremovestream = this.onRemoteStreamRemoved;
                this.peerConn.oniceconnectionstatechange = function () {
                    Log(5, "oniceconnectionstatechange:" + this.iceConnectionState);
                    if (this.iceConnectionState == 'disconnected') {
                        console.log('Disconnected');

                        if (this.recordVideo)
                            stopRecording();

                        //restart video
                        if (this.userType == "sender")
                            this.vConn.createOffer();//if this is a sender js, then reinit offer when ice disconnected (a network failure)
                    }
                }
                //add local stream to peer connection
                this.peerConn.addStream(this.localStream);
                //create offer signal
                if (this.userType == "sender")
                    this.createOffer();//create offer after creating the peer connection
            } catch (ex) {
                Log(0, "Error in createPeerConnection: " + ex);
            }
        };

        //ice candidate found. save to list and send to peer(offer, answer)
        this.onIceCandidate = function (event) {
            Log(5, "onIceCandidate");
            try {
                if (event.candidate) {
                    Log(5, "onIceCandidate:" + event.id + ":" + event.candidate.candidate);
                    let type = event.candidate.candidate.split(" ")[7];
                    if (type != 'relay')
                        return;
                    this.vConn.iceEvent.push(event);
                    if (this.vConn.iceEvent.length > 1) {
                        this.vConn.iceReady = true;
                        if ((this.vConn.answerReceived || this.vConn.userType == "receiver") && this.vConn.iceSent == false)
                            this.vConn.sendIce();
                    }
                }
                else {
                    Log(5, "end of IceCandidate");
                    this.vConn.iceReady = true;
                    if ((this.vConn.answerReceived || this.vConn.userType == "receiver") && this.vConn.iceSent == false)
                        this.vConn.sendIce();
                }
            } catch (ex) {
                Log(0, "Error in onIceCandidate: " + ex);
            }
        };

        //when remote adds a stream, hand it on to the local video element(offer, answer)
        this.onRemoteStreamAdded = function (event) {
            Log(5, "onRemoteStreamAdded");
            try {
                //assign to stream variable
                let newVideo = document.createElement("VIDEO");
                newVideo.setAttribute("autoplay", "true");
                newVideo.setAttribute("muted", "muted");
                newVideo.src = window.webkitURL.createObjectURL(event.stream);
                if (this.vConn.showRemoteVideo) {
                    newVideo.style.display = "block";
                }
                else {
                    newVideo.style.display = "none";
                }
                this.vConn.remoteVideoAdded(newVideo, event.stream);
                if (this.vConn.recordVideo) {
                    try {
                        var arrayOfStreams = [this.vConn.localStream, event.stream];
                        recordVideo(arrayOfStreams);
                    } catch (ex) {
                        Log(0, "Error in onRemoteStreamAdded - recordVideo: " + ex);
                    }
                }
                this.vConn.remoteStream = event.stream;
                window.remoteStreamList.push(event.stream);
                //start collecting stats
                if (this.vConn.showStats) {
                    this.vConn.statusObj = new VideoStats(this.vConn.peerConn, document.getElementById('statsDiv'));
                    this.vConn.statusObj.startStats();
                }
            } catch (ex) {
                Log(0, "Error in onRemoteStreamAdded: " + ex);
            }
        };

        //when remote removes a stream, remove it from the local video element(offer, answer)
        this.onRemoteStreamRemoved = function (event) {
            Log(5, "onRemoteStreamRemoved");
        };

        //create offer (offer)
        this.createOffer = function () {
            Log(5, "createOffer");
            try {
                //reset ice variables
                this.answerReceived = false;
                this.iceReady = false;
                this.iceSent = false;
                this.iceEvent = [];
                _this = this;
                //create an offer request
                this.peerConn.createOffer(
                    function (sessionDescription) {
                        _this.setLocalAndSendMessage(sessionDescription),
                            _this = null;
                    },
                    function () {
                        _this.createOfferOrAnswerError(),
                            _this = null;
                    },
                    this.mediaConstraints);
            } catch (ex) {
                Log(0, "Error in createOffer: " + ex);
            }
        };

        //sdp generated on createOffer call(offer, answer)
        this.setLocalAndSendMessage = function (sessionDescription) {
            Log(5, "setLocalAndSendMessage");
            try {
                this.offerAnswerProcessed = true;
                //manipulate sdp
                //var sdp = mungSdp(sessionDescription);
                var sdp = JSON.parse(JSON.stringify(sessionDescription));
                //set local SDP
                this.peerConn.setLocalDescription(sdp);
                //send sdp to remote
                this.sendVideoMessage(sdp);
                //process stored candidates
                for (let i = 0; i < this.receivedCandiates.length; i++) {
                    this.peerConn.addIceCandidate(this.receivedCandiates[i]);
                }
            } catch (ex) {
                Log(0, "Error in createOffer: " + ex);
            }
        };

        //create offer failed(offer, answer)
        this.createOfferOrAnswerError = function () {
            Log(0, "createOfferOrAnswerError");
        };

        //bye received from peer (offer, answer)
        this.handleBye = function () {
            Log(5, "handleBye");
            try {
                NotifyParent("bye", "");
                if (enableVideo)
                    this.localStream.getVideoTracks()[0].stop();
                if (enableAudio)
                    this.localStream.getAudioTracks()[0].stop();
                this.peerConn.close();
                this.peerConn = null;
                if (this.recordVideo)
                    stopRecording();
            } catch (ex) {
                Log(0, "Error in handleBye: " + ex);
            }
        };

        //ice candidate received from peer (offer, answer)
        this.candidateReceived = function (candidate) {
            Log(5, "candidateReceived");
            try {
                //store candidates here if offer/answer is not processed
                if (!this.offerAnswerProcessed)
                    this.receivedCandiates.push(candidate);
                else
                    this.peerConn.addIceCandidate(candidate);
            } catch (ex) {
                Log(0, "Error in candidateReceived: " + ex);
            }
        };

        //stop the video call
        this.stop = function () {
            Log(5, "stop");
            //send stop command to peer
            this.closeSession();
        };

        //close peer connection
        this.closeSession = function () {
            Log(5, "closeSession");
            try {
                if (this.showStats) {
                    this.statusObj.stopStats();
                }
                this.sendVideoMessage({ type: 'bye' });
                if (enableVideo)
                    this.localStream.getVideoTracks()[0].stop();
                if (enableAudio)
                    this.localStream.getAudioTracks()[0].stop();
                this.peerConn.close();
                this.peerConn = null;
                if (this.recordVideo)
                    stopRecording();
            } catch (ex) {
                Log(0, "error in closeSession:" + ex);
            }
        };

        //hold call
        this.hold = function () {
            Log(5, "hold");
            try {
                //mute the video
                this.muteVideo();
                this.sendVideoMessage({ type: 'hold' });
            } catch (ex) {
                Log(0, "error in hold:" + ex);
            }
        };

        //unhold call
        this.unhold = function () {
            Log(5, "unhold");
            try {
                //unmute the video
                this.unMuteVideo();
                this.sendVideoMessage({ type: 'unhold' });
            } catch (ex) {
                Log(0, "error in unhold:" + ex);
            }

        };

        //mute video
        this.muteVideo = function () {
            Log(5, "muteVideo");
            try {
                this.localStream.getVideoTracks()[0].enabled = false;
            } catch (ex) {
                Log(0, "error in muteVideo:" + ex);
            }
        };

        //unmute video
        this.unMuteVideo = function () {
            Log(5, "unMuteVideo");
            try {
                this.localStream.getVideoTracks()[0].enabled = true;
            } catch (ex) {
                Log(0, "error in unMuteVideo:" + ex);
            }
        };

        //mute audio
        this.muteAudio = function () {
            Log(5, "muteAudio");
            try {
                this.localStream.getAudioTracks()[0].enabled = false;
            } catch (ex) {
                Log(0, "error in muteAudio:" + ex);
            }
        };

        //unmute audio
        this.unMuteAudio = function () {
            Log(5, "unMuteAudio");
            try {
                this.localStream.getAudioTracks()[0].enabled = true;
            } catch (ex) {
                Log(0, "error in unMuteAudio:" + ex);
            }
        };

        //send video message
        this.sendVideoMessage = function (message) {
            Log(5, "sendVideoMessage");
            try {
                message.version = version;
                message.__localId = this.localId; //session id
                message.__user = this.userType; //sender
                message.isvideo = true; //is video
                message.isRealTime = true; //is realtime
                message.msgid = this.localId; //local id
                message.bargin = this.bargin; //is bargein
                //json message
                let mymsg = JSON.stringify(message);
                //if the type is new send video message to customer
                if (callType == "new") {
                    Log(5, "sendVideoMessage:" + mymsg);
                    try {
                        //this is for user
                        this.comm.SendAppMessage(mymsg);
                    } catch (ex) { }
                    try {
                        //this is for tmac
                        this.comm.SendTextChatAsAppMessage(global_DeviceID, this.localId, mymsg);
                    } catch (ex) { }
                }
                //if the type is conf then send video message to conference agent
                else if (callType == "conf") {
                    try {
                        this.sendAgentCommand(mymsg);
                    } catch (ex) { }
                }
            } catch (ex) {
                Log(0, "error in sendVideoMessage:" + ex);
            }
        };

        //message received from peer 
        this.onCommMessage = function (message) {
            Log(5, "sendVideoMessage");
            try {
                //parse the message
                let msg = JSON.parse(message.data);
                if (msg.type == "controlChanged" || msg.type == "drawMouse") {
                    NotifyParent("receivecommand", message.data);
                    return;
                }
                if (msg.type === 'answer') {
                    //answer command received
                    this.processAnswer(msg);
                }
                else if (msg.type === 'offer') {
                    //offer type is handled by creating new video connection
                }
                else if (msg.type === 'candidate') {
                    //candidate received
                    let candidate = new RTCIceCandidate({ sdpMLineIndex: msg.label, candidate: msg.candidate });
                    this.candidateReceived(candidate);
                }
                else if (msg.type == "receiverready" || msg.type == "connect") {
                    //receiver is ready to start webrtc peer connection
                    try {
                        let data = JSON.parse(msg.data);
                        NotifyParent("peerconnected", data.agentid + "," + data.agentname);
                    } catch (ex) { }
                    //create a peer connection
                    this.createPeerConnection();
                }
                else if (msg.type == "hold") {
                    NotifyParent("hold", "");
                }
                else if (msg.type == "unhold") {
                    NotifyParent("unhold", "");
                }
                else if (msg.type == "bye") {
                    this.handleBye();
                }
            } catch (ex) {
                Log(0, "error onCommMessage:" + ex);
            }
        };

        //send conference agent offer
        this.sendAgentCommand = function (message) {
            Log(5, "sendAgentCommand:" + message);
            try {
                this.comm.SendCommandToAgent(null, confJson.intId, confJson.agentId, confJson.agentServer, confJson.agentInteractionId, "VideoMessage", message);
            } catch (ex) {
                Log(0, "error in sendAgentCommand:" + ex);
            }
        };

        return this;
    } catch (ex) {
        Log(0, "Error in VideoConnection: " + ex);
    }
}

//Log
function Log(level, msg) {
    try {
        console.log(msg);
        msg = vConn.localId + ":" + msg;
        callbackObj.jsLog(level.toString(), msg);
    } catch (ex) {
        //console.log(ex);
    }
}

//notifyParent
function NotifyParent(command, data) {
    try {
        callbackObj.notify(vConn.localId, command, data);
    } catch (ex) {
        //Log(0, "Error in NotifyParent: " + ex);
    }
}

//recordVideo
function recordVideo(arrayOfStreams) {
    Log(5, "recordVideo");
    try {
        recordRTC = RecordRTC(arrayOfStreams, {
            type: 'video',
            mimeType: 'video/webm', // or video/webm\;codecs=h264 or video/webm\;codecs=vp9
            previewStream: function (stream) {
                // it is optional
                // it allows you preview the recording video
            }
        });
        recordRTC.startRecording();
    } catch (ex) {
        Log(0, "Error in recordVideo: " + ex);
    }
}

//stopRecording
function stopRecording() {
    Log(5, "stopRecording");
    try {
        callended = true;
        recordRTC.stopRecording(function (singleWebM) {
            document.getElementById('recordedvid').src = singleWebM;

            //var recordedBlob = recordRTC.getBlob();
            recordRTC.getDataURL(function (dataURL) {
                //
                //alert(dataURL);
                //parent.videoFileReady(intid, dataURL);
            });
        });
    } catch (ex) {
        Log(0, "Error in stopRecording: " + ex);
    }
}

//change SDP
function mungSdp_old(sdp) {
    Log(5, "mungSdp");
    try {
        //convert SDP to string
        var strsdp = JSON.stringify(sdp);
        strsdp = strsdp.replace("video 9 UDP/TLS/RTP/SAVPF 96 98", 'video 9 UDP/TLS/RTP/SAVPF 98 96');
        return JSON.parse(strsdp);
    } catch (ex) {
        Log(0, "Error in mungSdp_old: " + ex);
    }
}

//change SDP
function mungSdp(sdp) {
    Log(5, "mungSdp");
    try {
        var strsdp = JSON.stringify(sdp);
        var from = strsdp.substring(strsdp.indexOf("SAVPF") + 6, strsdp.indexOf("c=") - 4);
        var indexOf98 = from.split(' ').indexOf("98");
        var to = from.split(' ').move(indexOf98, 0).join(' ');
        return JSON.parse(strsdp.replace(from, to));
    } catch (ex) {
        Log(0, "Error in mungSdp: " + ex);
    }
}

//mungSdp_bitRate
function mungSdp_bitRate(sdp) {
    //convert SDP to string
    var strsdp = JSON.stringify(sdp);

    //set video bit rate to 256
    strsdp = strsdp.replace('a=mid:video', 'a=mid:video\\r\\nb=AS:' + '256');

    return JSON.parse(strsdp);
}

//Array.prototype.move
Array.prototype.move = function (old_index, new_index) {
    if (new_index >= this.length) {
        let k = new_index - this.length;
        while ((k--) + 1) {
            this.push(undefined);
        }
    }
    this.splice(new_index, 0, this.splice(old_index, 1)[0]);
    return this; // for testing purposes
};

//sendCommandFromOuterApp
function sendCommandFromOuterApp(msgStr) {
    let message = JSON.parse(msgStr);
    sendMessageForWebRTC(message);
}

//utils method
function getParentParameterByName(name, url) {
    if (!url) url = parent.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    let regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
