// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TmacConfigurations.js";
var file_version = "3.1.08.07";
var changedBy = "Sirajuddin";
try {
    //need not add in versioning as this is invoked before CommonUI.
    //global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}
// ----------------------------------------------------------------------------------

$(function () {
    try {
        console.log("Tmac configurations js loaded");
        $("#favicon").attr("href", "assets/img/" + favionIcon + ".png");
        var logo_height = (parseInt(tmac_header_footer_height.substring(0, 2)) - 5) + "px";
        //header a tag height
        $("#header_main .uk-navbar .uk-navbar-nav > li > a").css("height", tmac_header_footer_height);
        //header a element line height
        $("#header_main .uk-navbar .uk-navbar-nav > li > a").css("line-height", tmac_header_footer_height);
        //header logo element line height
        $(".main_logo_top").css("line-height", tmac_header_footer_height);
        //header logo element a tag line height
        $(".main_logo_top>a").css("line-height", tmac_header_footer_height);
        //header logo element img tag max height
        $(".main_logo_top>a img").css("max-height", logo_height);
        //main header height
        $("#header_main").css("height", tmac_header_footer_height);
        //body padding top for header
        $("body").css("padding-top", tmac_header_footer_height);
        //sidebar top, bottom
        $("#sidebar_main").css("top", tmac_header_footer_height);
        $("#sidebar_main").css("bottom", tmac_header_footer_height);
        //footer line height
        $("#footer").css("line-height", tmac_header_footer_height);
        //footer uk-grid height
        $("#footer .uk-grid").css("height", tmac_header_footer_height);
        //sidebar secondary height
        $("#sidebar_secondary").css("top", tmac_header_footer_height);
        //enable/disable features
        $("#sidebar_main_toggle").toggle(isFullTMAC);
        //enable/disable tmac screen toggle button
        $("#tmac_screen_toggle").toggle(isTmacScreenToggle);

        //full tmac configurations
        if (isFullTMAC) {
            $("#sidebar_main_toggle").removeClass("uk-hidden-small");
            $("#side_agent_info_panel").toggle(true);
            $("#div_wallboardGrid_side").toggle(isWallboard);
            if (openLeftSidePanel) $("#bodyfullscreen").addClass("sidebar_main_open");
            $("#div-user-block").remove();
            if (isTour) LoadCustomJs("tmac_scripts", "tour.js");
        }
        else {
            $("#div_wallboardGrid_main").toggle(isWallboard);
        }

        if (isDashboardEnabled || isGrammerCheck) {
            LoadCustomJs("assets", "js/jquery.signalR-2.2.2.min.js");
        }

        if (isFbEnabled) {
            LoadCustomJs("tmac_scripts", "tmac_sdk/tmac_facebookApi.js");
            LoadCustomJs("tmac_scripts", "social_media/facebook_ui.js");
        }

        if (isChatEnabled) {
            if (isSanitizeHtml) LoadCustomJs("components", "sanitizeHTML/sanitize.js");
            if (isGrammerCheck) LoadCustomJs("assets", "js/jquery.highlighttextarea.min.js");
            LoadCustomJs("tmac_scripts", "tmac_sdk/tmac_textChatApi.js");
            LoadCustomJs("tmac_scripts", "tmac_text_chat_ui.js");
        }

        if (isFaxEnabled) {
            $("#compose_fax_li").removeClass("uk-display-none");
            LoadCustomJs("components", "tiffreader/tiff.min.js");
            LoadCustomJs("tmac_scripts", "fax_ui.js");
            if (isPrintFax)
                LoadCustomJs("components", "printThis/printThis.js");
        }

        //load iserver command js if enabled
        if (isIServe) {
            LoadCustomJs("tmac_scripts", "iserve_commands.js");
        }

        //load dynamic crm js if enabled
        if (isDynamicCRM) {
            LoadCustomJs("tmac_scripts", "dynamic_crm.js");
        }

        //load dashboard js if enabled
        if (isDashboardEnabled && !isFullTMAC) {
            LoadCustomJs("tmac_scripts", "dashboard.js");
            $("#dashboard_grid").toggle(true);
            $("#dashboard_interval_grid").toggle(true);
        }

        //enable scripts and features for RM
        if (isPdfEditor) {
            LoadCustomJs("components", "pdf.kit/pdf.js");
            LoadCustomJs("components", "pdf.kit/pdf.worker.js");
            LoadCustomJs("components", "pdf.kit/pdf.render.js");
            LoadCustomJs("components", "pdf.kit/draw.js");
        }

        if (isAttachement || isCamera || isVoiceNote) {
            LoadCustomJs("tmac_scripts", "file_utilities.js");
        }

        if (isVideoCall) {
            LoadCustomJs("tmac_scripts", "tetherfi_av_kit/adapter.min.js");
            LoadCustomJs("tmac_scripts", "tetherfi_av_kit/WebRtcPeerConnectionImpl.js");
            LoadCustomJs("tmac_scripts", "tetherfi_av_kit/WebRtcPeerConnectionApi.js");
            LoadCustomJs("tmac_scripts", "tetherfi_av_kit/WebRtcConnector.js");
        }

        if (isAgentChat) {
            //enable agent list for agent chat
            $("#agentListCard").toggle(true);
            LoadCustomJs("tmac_scripts", "agent_chat.js");
            $("#sidebar_secondary_toggle").removeClass("uk-hidden-small uk-hidden-medium uk-hidden-large");
        }

        if (isSupervisor) {
            LoadCustomJs("tmac_scripts", "agent_chat.js");
        }

        if (isCustomerChat) {
            //enable customer list for customer chat
            $("#customerListCard").toggle(true);
            LoadCustomJs("tmac_scripts", "customer_chat.js");
            $("#sidebar_secondary_toggle").removeClass("uk-hidden-small uk-hidden-medium uk-hidden-large");
        }

        //enable scripts and features for VTM
        if (isVTM) {
            LoadCustomJs("tmac_scripts", "vtm_ui.js");
            $("#div-vtm-agent-info").removeClass("uk-display-none");
        }

        //configurations for Voice bio
        if (isVoiceBio) {
            $("#fontsCSS").attr("href", "assets/css/fonts/verdana_vb.css");
            LoadCustomJs("tmac_scripts", "voice_bio_ui.js");
            $(".card-user-block").addClass("voice-bio-card");
            $("#style_switcher_toggle").remove();
            $("#tmac_utils").remove();
            $("#tmac_help").removeClass("uk-display-none");
            $("header").remove();
            $("footer").remove();
            $("body").css("padding-top", "0px");
        }

        if (isInteractionHistory) {
            LoadCustomJs("tmac_scripts", "interacton_history.js");
        }

        if (isVoiceDataWindow) {
            if (voiceDataWindowType == "campaign")
                LoadCustomJs("tmac_scripts", "camp_ui.js");
        }

        //configuration for POM
        if (isPOM) {
            LoadCustomJs("tmac_scripts", "pom_ui.js");
            $("#agent_type_li").removeClass("uk-display-none");
        }

        //enable/disable blind transfer button
        if (isBlindTransfer) {
            $("#btndialogblindtransfercall").removeClass("uk-display-none-important");
        }
    } catch (ex) {
        console.log(ex);
    }
});

function LoadCustomHTML(folderName, fileName, loadTo) {
    try {
        var url = "";
        if (folderName != "")
            url = folderName + "/" + fileName;
        else
            url = fileName;
        $("#" + loadTo).load(url, function () {
            console.log(fileName + " loaded dynamically");
        });
    } catch (ex) {
        console.log(ex);
    }
}

function LoadCustomJs(folderName, fileName) {
    try {
        var url = folderName + "/" + fileName;
        var script = document.createElement('script');
        script.src = url;
        script.type = "text/javascript";
        script.onload = console.log(fileName + " loaded dynamically");
        document.body.appendChild(script);
    } catch (ex) {
        console.log(ex);
    }
}