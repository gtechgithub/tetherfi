﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "TmacUI.js";
var file_version = "3.1.08.0804";
var changedBy = "Chirag";
try {
    global_addVersions(filename, file_version);
} catch (ex) {
    console.log(ex);
}

// ----------------------------------------------------------------------------------
$(document).ready(function () {
    console.log('tmac ui loaded');
    DisplayCurrentStatusLoop();
});
// ----------------------------------------------------------------------------------

function AddMainTab(divHeader, divBody, intid, tabName, isActive) {
    try {
        SaveTabReference(intid, intid, 'new');
        //tab header content
        var tempTabHeaderContent = document.getElementById(divHeader).innerHTML;
        //tab body content
        var tempTabContent = document.getElementById(divBody).innerHTML;
        //add a kendo tab
        AddTab(tempTabContent, tempTabHeaderContent, intid, tabName, isActive, false, false);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddMainTab()", ex, false);
    }
}

//add a kendo tab
function AddTab(tempTabContent, tempTabHeaderContent, intid, phonenumber, active, isClose, isRealTime) {
    try {
        //set interaction id for voice tab
        var tabContent = tempTabContent.replace(/_INTID/g, intid);

        //set interaction id for voice tab header
        var tabHeaderContent = tempTabHeaderContent.replace(/_INTID/g, intid);
        var lastIndex = tabstrip.items().length;
        //adding a kendo tab
        if (intid == "main")
            tabstrip.append({
                text: tabHeaderContent,
                encoded: false,
                content: tabContent
            });
        //if dashboard and the first tab
        else if (intid == "dashboard" && lastIndex === 0)
            tabstrip.append({
                text: tabHeaderContent,
                encoded: false,
                content: tabContent
            });
        else
            tabstrip.insertAfter({
                text: tabHeaderContent,
                encoded: false,
                content: tabContent
            }, tabstrip.items()[lastIndex - 1]);
        //gettting the item added to change the tab div id
        var item = tabstrip.contentElements[tabstrip.contentElements.length - 1];
        item.setAttribute("intid", intid);
        //changing tab body id for manual tab removal
        item.id = "div_" + intid;
        //setting tab header id
        tabstrip.tabGroup.children().last().attr("id", "li_" + intid);
        //tab header reference to be changed as the body id changed
        tabstrip.tabGroup.children().last().attr('aria-controls', "div_" + intid);
        if (active || lastIndex == 0) {
            //index of the new added tab
            lastIndex = tabstrip.items().length;
            //set the newly added tab active
            tabstrip.select(lastIndex - 1);
        } else {
            if (!isNaN(intid) && GetTabReferenceObj(intid).type == "chat") {
                var bgColor = $(".k-tabstrip-items.k-reset").css("background-color");
                $("#li_" + intid).addClass("blink_chattab");
                GetChatReferenceObj(intid).isBlink = true;
            }
        }
        //to enable/disable close on load
        if (isClose) {
            EnableTabCloseButton(intid);
        }
        //Increase the global tab counter 
        global_tabCount++;
        global_openTabs[global_tabCount] = intid;
        if (!isNaN(intid)) {
            //bind the intent list for this tab
            BindIntentList(intid);
        }
        if (isRealTime) {
            //change on call tab
            $("#li_" + intid).addClass("li-on-call");
        }
        //set tab header details
        $('#divTabHeader' + intid).text(phonenumber);
        SetTabHeight();
        //Resize the window
        ResizeWindow(false);
        try {
            $("#scrollTop" + intid).click(function () {
                $("#div_" + intid).animate({
                    scrollTop: 0
                }, 600);
                $(this).addClass("uk-display-none");
                return false;
            });
        } catch (ex) {
            log.LogDetails("Error", "TmacUI.AddTab() - No Scroll button!", ex, false);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddTab()", ex, false);
    }
}

function AddCallTimer(intid, type, $hdn_elm, $starttime_elm, $timetaken_elm, $span_starttime_elm, $chat_agent_timetaken_elm,
    $span_agent_timetaken_elm, $hdn_agent_time_taken_start, $hdn_agent_time_taken_end, $freeze_auto_resoponse, confType) {
    try {
        let timeTakeCounter = 0;
        //add timer
        var date = new Date();
        // When call comes, store the start time in the hidden field
        $($hdn_elm).val(date);
        try {
            date = moment(date).format("DD/MM/YYYY, HH:mm:ss");
            $($starttime_elm).html(date);
        } catch (ex) {
            log.LogDetails("Error", "TmacUI.AddCallTimer() - Inside1", ex, false);
        }
        try {
            //if auto timer then on click is not required
            if (!autoTimerForTimeTaken) {
                $($timetaken_elm).click(function (e) {
                    try {
                        let callstartedAt = moment($($hdn_elm).val());
                        let callendAt = moment(new Date());
                        $($span_starttime_elm).text(moment().hour(0).minute(0).second(callendAt.diff(callstartedAt, 'seconds')).format('HH:mm:ss'));
                    } catch (ex) {

                    }
                });
            }
            else {
                //change the title and start timer
                $($timetaken_elm).attr("title", "View time taken");
                GetTabReferenceObj(intid).tabTimer = setInterval(function () {
                    $($span_starttime_elm).text(moment().hour(0).minute(0).second(timeTakeCounter++).format('HH:mm:ss'));
                }, 1000);
            }
        } catch (ex) {
            log.LogDetails("Error", "TmacUI.AddCallTimer() - Inside2", ex, false);
        }
        if (type === "chat") {
            //if auto timer then on click is not required
            if (!autoTimerForTimeTaken) {
                $($chat_agent_timetaken_elm).click(function (e) {
                    let callstartedAt = $($hdn_agent_time_taken_start).val() === "" ? moment($($hdn_elm).val()) : moment($($hdn_agent_time_taken_start).val());
                    let callendAt = $($hdn_agent_time_taken_end).val() === "" ? moment(new Date()) : moment($($hdn_agent_time_taken_end).val());
                    $($span_agent_timetaken_elm).text(moment().hour(0).minute(0).second(callendAt.diff(callstartedAt, 'seconds')).format('HH:mm:ss'));
                });
            }
            else {
                //if the conftype is silent then its a silent bargeIn so we need not to show this timer
                if (confType != "silent") {
                    //change the title and start timer
                    $($chat_agent_timetaken_elm).attr("title", "View time taken");
                    StartChatTimeTakenTimer(intid, $span_agent_timetaken_elm);
                }
                //hide the timer if its a chat silent bargeIn
                else {
                    $("#div_agent_time_taken" + intid).hide();
                }
            }
            $($freeze_auto_resoponse).click(function (e) {
                FreezeTextChatAutoResponse(global_DeviceID, intid);
                DisableButton("#btnTextChat_FreezeAutoResponse" + intid);
            });
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddCallTimer()", ex, false);
    }
}

function StartChatTimeTakenTimer(intid, $span_agent_timetaken_elm) {
    try {
        GetChatReferenceObj(intid).timeTakenToReply = setInterval(function () {
            try {
                $($span_agent_timetaken_elm).text(moment().hour(0).minute(0).second(GetChatReferenceObj(intid).timeTakenCounter++).format('HH:mm:ss'));
            } catch (ex) {
                console.log(ex);
            }
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.StartChatTimeTakenTimer()", ex, false);
    }
}

function CloseUITab(intid, module) {
    try {
        if (!GetTabReferenceObj(intid)) {
            return;
        }		
        //previous tab
        var prevItem = tabstrip.select().prev();

        //next tab
        var nextItem = tabstrip.select().next();

        //remove the tab header
        $("#li_" + intid).remove();

        //remove tab body
        $("#div_" + intid).remove();

        //global tab count
        global_tabCount--;

        if (module) {
            ChangeStatus(global_DeviceID, 'available', '0');
        }

        //if the global_tabCount is less than 0 make it 0
        if (global_tabCount < 0)
            global_tabCount = 0;

        //issue is with kendo tab.. Need to get it fixed//
        if (global_tabCount <= 2 && parseInt($('.k-tabstrip-items.k-reset').css('margin-right')) > 0) {
            $('.k-tabstrip-items.k-reset').css('margin', '0px');
            $(".k-button.k-button-icon.k-bare.k-tabstrip-prev").remove();
            $(".k-button.k-button-icon.k-bare.k-tabstrip-next").remove();
        }

        if (nextItem.length) //if next tab is there then go to that tab else prev tab
            tabstrip.select(nextItem);
        else if (prevItem.length) //if previous tab is there then go to that tab else first tab
            tabstrip.select(prevItem);
        else
            tabstrip.select(tabstrip.tabGroup.children().first());

        //if the tab is a chat tab remove the chat tab reference
        if (GetTabReferenceObj(intid).type == "chat") {
            RemoveChatReference(intid);
        }

        //make the window ibar if the supervisor is closed
        if ((isExpandCollapseOnIframes.Supervisor || isExpandCollapseOnIframes.Workbench) && !isFullTMAC && intid == "supervisor") {
            ResizeWindow(false);
        }

        //remove the tab reference after removing the tab
        RemoveTabReference(intid);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseUITab()", ex, false);
    }
}

function SetColorCodes(data) {
    try {
        global_QueueTimeColor = data;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetColorCodes()", ex, false);
    }
}

function GetColorCode(queueTime) {
    try {
        for (var i = 0; i < global_QueueTimeColor.length; i++) {
            if (queueTime >= global_QueueTimeColor[i].startTime && queueTime <= global_QueueTimeColor[i].endTime) {
                return global_QueueTimeColor[i].colorCode;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetColorCode()", ex, false);
    }
}

function SetInteractionHistory(data) {
    try {
        if (data !== null && isInteractionHistory) {
            //generate interaction history tree
            AddInteraction(data.History, data.InteractionID);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetInteractionHistory()", ex, false);
    }
}

function OpenHistoryInFrame(para, cnt) {
    if (cnt == undefined || cnt == null)
        cnt = 0;
    //ui_div_voice_history_frame_INTID ui_div_history_frame_INTID
    var historyParams = JSON.parse(para);
    if (historyParams.Channel == "Email") {
        //wait for sometime for tab to get generated
        if (global_InteractionTabs[historyParams.InteractionID] != undefined) {
            loadHistoryFrame(historyParams);
        } else {
            if (cnt < 10) {//10 max tries (10 seconds wait)
                setTimeout(function () {
                    OpenHistoryInFrame(para, cnt + 1);
                }, 1000);
            }
        }
    } else {
        LoadHistoryFrame(historyParams);
    }
}

function LoadHistoryFrame(historyParams) {
    try {
        var url = ih_iframe_url + "?cif=" + historyParams.CIF + "&nric="
            + historyParams.NRIC + "&email=" + historyParams.EmailID + "&phone=" + historyParams.PhoneNumber + "&servername=" + _tmacServer + "&font=" + localStorage.getItem("font_family");
        LoadIFrame("ui_history_frame" + historyParams.InteractionID, url);
        $("#ui_history_frame" + historyParams.InteractionID).toggle(true);
        //$("#div_history" + historyParams.InteractionID).toggle(false);
        $("#div_history" + historyParams.InteractionID).remove();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadHistoryFrame()", ex, false);
    }
}

function SetInteractionHistoryMore(data) {
    try {
        if (data !== null) {
            //generate interaction history tree
            AddMoreInteractions(data.History, data.InteractionID);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetInteractionHistoryMore()", ex, false);
    }
}

function SetCCLData(data) {
    try {
        if (data !== null) {
            if (data.CallerName !== "")
                var callerName = data.CallerName;
            //document.getElementById('txtName' + data.InteractionID).innerHTML = data.CallerName;
            //document.getElementById('txtNRIC' + data.InteractionID).innerHTML = data.NRIC;
            //document.getElementById('txtCIF' + data.InteractionID).innerHTML = data.CIF;
            //document.getElementById('divCustomerName' + data.InteractionID).innerHTML = callerName.substring(0, 7);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetCCLData()", ex, false);
    }
}

function RefreshWallboard(data) {
    try {
        if (data !== null && isWallboard) {
            //bind wallboard data
            if (isFullTMAC) {
                $('#wallboardGrid_side').data('kendoGrid').dataSource.data(data.Skills);
                HideKendoLoading("#wallboardGrid_side");
            }
            else {
                $('#wallboardGrid_main').data('kendoGrid').dataSource.data(data.Skills);
                HideKendoLoading("#wallboardGrid_main");
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RefreshWallboard()", ex, false);
    }
}

function AgentNotification(data) {
    try {
        if (data.Type == "InteractionIM") {
            let t = $("#InteractionIMTemplate").html(), //template divs
                e = $("#InteractionIM" + data.InteractionID), //to be appended before/after/to
                n = Handlebars.compile(t), //initialize handlebars for the template divs     
                context = {
                    message: data.Message,
                }, //add context data
                s = n(context); //execute the template with handlebar and context
            e.prepend(s), $(window).resize(); //append the element, init altair_md.inputs and resize the window
            ShowNotification("IM from " + data.FromAgentName, data.Message);
            log.LogDetails("Info", "TmacUI.AgentNotification()", "IM from " + data.FromAgentName + ": " + data.Message, true);
            //$("#scrollTop" + data.InteractionID).removeClass("uk-display-none");
        }
        else if (data.Type == "Broadcast") {
            marqueeText = ""; //clear marquee text               
            SetupMarqueeData(data.Message);
            $("#marquee").text(marqueeText);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentNotification()", ex, false);
    }
}

function SetupMarqueeData(message) {
    if (message == "....") {
        message = 'No broadcast to display';
    }
    marqueeText = marqueeText + " " + message;
}

function AgentLoginSuccess() {
    try {
        //close the parent winodw (login window)
        if (opener && !isVoiceBio)
            opener.loginDone();
        //add agent id and station id to the document title
        if (labelOnTitle)
            document.title = titleName + " - A: " + global_AgentID + ' / S: ' + global_DeviceID;
        else
            document.title = titleName + " - " + global_AgentID + '/' + global_DeviceID;
        //set main tab agent details
        if (agentStationOnMain) {
            $("#agentname").text(global_AgentName + "/" + global_DeviceID);
        }
        else {
            $("#agentname").text(global_AgentName);
        }
        //set main and sidebar agent profile details
        if (global_UserProfileForAgent === "S") {
            if (isFullTMAC) $("#agentprofile_side").html("Supervisor");
            else if (agentProfileOnMain) $("#agentProfile").html("Supervisor");
        }
        if (global_UserProfileForAgent === "A") {
            if (isFullTMAC) $("#agentprofile_side").html("Agent");
            else if (agentProfileOnMain) $("#agentProfile").html("Agent");
        }
        //set sidebar agent details
        if (isFullTMAC) {
            $("#agentid_side").text(global_AgentID);
            $("#agentname_side").text(global_AgentName);
            $("#agentstation_side").html(global_DeviceID);
            setInterval(function () {
                var randomNumber = Math.floor(Math.random() * (5 - 1 + 1)) + 1;
                $("#span_quotes").text(quotesList[randomNumber]);
            }, 10000);
            if (isTour) $("#welcome_sub_message").removeClass("uk-display-none");
        }

        if (isVTM) {
            $("#vtm-agent-info").text(global_AgentName + " (" + global_AgentID + "/" + global_DeviceID + ")");
        }

        //Disable the Logout Button
        FadeOutButton("#main_logout_btn");
        //get the list of callback, textchat VDN
        if (!global_ReloadDone) {
            custom_getVDNList(0, "callback");
        }
        custom_getVDNList(0, "textchat");
        custom_getVDNList(0, "ibgdnis");
        //Get Popup URLs
        custom_getPopUpURL(0, "callback");
        custom_getPopUpURL(0, "QMS");
        custom_getPopUpURL(0, "ACW");
        custom_getPopUpURL(0, "MSDChatAccept");
        custom_getPopUpURL(0, "MSDChatClose");
        custom_getPopUpURL(0, "MSDCallbackAccept");
        custom_getPopUpURL(0, "MSDCallbackClose");
        custom_getPopUpURL(0, "MSDInboundVoice");
        custom_getPopUpURL(0, "MSDOutboundVoice");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentLoginSuccess()", ex, false);
    }
}

function AgentStatusChange(data) {
    try {
        //update the status list with new status
        //reset the status timer
        if (data !== null) {
            statusTimeCounter = 0;
            //if close tab on status is enabled, then close the tab
            if (isCloseTabsOnTSC) {
                //check if last status was ACW, then only close the tab
                if (global_LastAgentStat && global_LastAgentStat.Status.indexOf("ACW") >= 0 || data.Source === "change"
                    //global_LastAgentStat.Status.indexOf("On Call") >= 0 && data.Source !== "change" ||
                ) {
                    //if the new status is on call/acw/error then skip
                    if (
                        !(data.Status.indexOf('On Call') >= 0 ||
                            data.Status.indexOf('ACW') >= 0 ||
                            data.Status.indexOf('Error') >= 0 ||
                            skipCloseTabStatus.indexOf(data.Status) >= 0)
                    ) {
                        //get tabs to close, execpt static tabs and configured tab types
                        $.each(global_InteractionTabs, function (i, t) {
                            if (skipCloseTabType.indexOf(t.type) && !t.isStatic) {
                                RemoveGlobalTimeoutReference(t.intid);
                                CloseTab(t.intid);
                            }
                        });
                    }
                }
            }
            //set the last agent status. This value will be used after aux code loading is completed
            global_LastAgentStat = data;
            //DivAuxStatReceivedFromServer(data.Status, data.Source);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentStatusChange()", ex, false);
    }
    
}
function AuxCodesLoaded() {
    try {
        if (global_AUXCodes !== null) {
            //bind aux codes to dropdown list
            //set the first as empty
            RemoveNameFromList(global_AUXCodes, "Logout", 110);
            RemoveNameFromList(global_AUXCodes, "ACW", 111);
            RemoveNameFromList(global_AUXCodes, "6 - TPIN", 6);
            global_LastAgentStat = {};
            global_LastAgentStat.Status = initialStatus;
            AgentStatusChange(global_LastAgentStat);
            //new aux ui
            LoadAuxDiv(global_AUXCodes, initialStatus);
            DivAuxStatReceivedFromServer(initialStatus);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AuxCodesLoaded()", ex, false);
    }
}

function RemoveNameFromList(nameList, name, value) {
    try {
        for (var i = nameList.length - 1; i >= 0; i--) {
            if (nameList[i].Name == name && nameList[i].Value == value) {
                nameList.splice(i, 1);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveNameFromList()", ex, false);
    }
}

function DivAuxStatReceivedFromServer(status, source) {
    try {
        if (status !== "") {
            var type = "warning";
            var iconType = "offline_bolt";
            if (status === "ACW" || status === "PendingNotReady") {
                iconType = "group_work";
            }
            else if (status === "Available" || status === "Preview" || status === "Ready" || status === "Idle") {
                type = "success";
                iconType = "check_circle";
            }
            else if (status.indexOf("Logout") >= 0) {
                type = "danger";
                iconType = "settings_power";
            }
            //status icon change
            $("#divAuxStatusType").html('<i class="material-icons md-20 uk-text-' + type + '">' + iconType + '</i> ');

            //change the ui status
            $('#divAuxStatus').text(status);
            $('#divAuxStatus').removeClass("loading");

            if (agentStatusOnMain) {
                $("#agentStatus").text(status);
                $('#agentStatus').removeClass("loading");
            }
            //if status is blinking then remove it
            if (isBlinkStatus) $("#btn_change_status").removeClass("blink_status");
            //process the agent status change
            ProcessAgentStatusChange(status, source);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DivAuxStatReceivedFromServer()", ex, false);
    }
}

function ProcessAgentStatusChange(status, source) {
    try {
        //if this is pom ui and if OnPOMLoginSuccess/OnPOMLoginFailed received then only enable status
        if (isPOM && pomLoginFlag) FadeInButton("#btn_change_status");
        status = status.toLowerCase();
        switch (status) {
            case initialStatus.toLowerCase():
                FadeOutButton("#main_logout_btn");
                FadeOutButton("#btn_make_call");
                break;

            case "not logged in":
                global_AgentForcedLogoffEventFlag = true;
                LogoffAlert("Agent Manually logged out from hardphone!", true, 3000);
                if (isVoiceBio) ShowNotLoggedInScreen();
                break;

            case "available":
            case "acw":
            case "pendingnotready":
                FadeOutButton("#main_logout_btn");
                FadeOutButton("#btn_make_call");
                break;

            case global_outboundName.toLowerCase():
                if (!isPOM || isPOM && agentType === "ACD")
                    FadeInButton("#btn_make_call");
                FadeOutButton("#main_logout_btn");
                break;

            case "logout":
                FadeInButton("#main_logout_btn");
                break;

            default:
                if (status.indexOf("on call") >= 0) {
                    //if there is a only single dont disable make call button on change status to outbound 
                    if (status !== global_outboundName && global_ChatReference.length === 0) FadeOutButton("#btn_make_call");

                    //blink the status on call if configured
                    if (isBlinkStatus) $("#btn_change_status").addClass("blink_status");

                    //disable status change on call if configured
                    if (isDisableStatusOnCall) FadeOutButton("#btn_change_status");
                }
                else if (logoutAux === "" || status === logoutAux.toLowerCase()) {
                    FadeInButton("#main_logout_btn");
                }
        }
        LoadAuxDiv(global_AUXCodes, status);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ProcessAgentStatusChange()", ex, false);
    }
}
function LoadAuxDiv(data, currentStat) {
    try {
        let count = data.length;
        let intI = count;
        if (intI !== 0) {
            var newdropDownString = "";
            $.each(data, function (k, arrayItem) {
                if (arrayItem.Display == 1) {
                    let type = "warning";
                    let iconType = "offline_bolt";
                    if (arrayItem.Name != currentStat) {
                        if (arrayItem.Name === "ACW") {
                            iconType = "group_work";
                        }
                        else if (arrayItem.Name === "Available") {
                            type = "success";
                            iconType = "check_circle";
                        }
                        else if (arrayItem.Name.indexOf("Logout") >= 0) {
                            type = "danger";
                            iconType = "settings_power";

                        }
                        newdropDownString += '<li><a class="uk-dropdown-close" href="#" onclick="return DivAuxCodeSelected(\'' +
                            arrayItem.Value + '\',\'' + arrayItem.Name + '\');"><i class="material-icons md-20 uk-text-' + type + '">' + iconType + '</i> ' + arrayItem.Name + '</a></li>';
                    }
                }
            });
            $("#auxstatuslist").html(newdropDownString);
        }
        return false;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadAuxDiv()", ex, false);
    }
}

function DivAuxCodeSelected(id, name) {
    try {
        var oldName = $('#divAuxStatus').text();
        $('#divAuxStatus').text(name);
        if (agentStatusOnMain) $("#agentStatus").text(name);
        DivAuxCodeChanged(id, name, oldName);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DivAuxCodeSelected()", ex, false);
    }
}

function DivAuxCodeChanged(id, type, oldName) {
    try {
        //disable logout button initially
        FadeOutButton("#main_logout_btn");
        //disable makecall button initially
        FadeOutButton("#btn_make_call");
        // Clear all the flags 
        global_isTPINTransfer = false;
        global_isTPINTrasnferOutbound = false;
        global_isFeewaiverTrasnferOutbound = false;
        switch (type.toLowerCase()) {
            case "acw":
                ChangeStatus(global_DeviceID, 'acw', id);
                break;
            case "available":
                ChangeStatus(global_DeviceID, 'available', id);
                break;
            case global_outboundName.toLowerCase():
                ChangeStatus(global_DeviceID, 'aux', id);
                if (isEnableVoiceOnSingleChat)
                    FadeInButton("#btn_make_call");
                break;
            default:
                ChangeStatus(global_DeviceID, 'aux', id);
                if (logoutAux != "" && type == logoutAux)
                    FadeInButton("#main_logout_btn");
                else if (logoutAux == "")
                    FadeInButton("#main_logout_btn");
                break;
        }
        //if the status on call disable make call button
        if (global_LastAgentStat.Status.indexOf("On Call") >= 0) {
            //if there is only a single chat dont disable make call button on change status to outbound
            if (type !== global_outboundName && global_ChatReference.length !== 1) {
                FadeOutButton("#btn_make_call");
            }
            FadeOutButton("#main_logout_btn");
        } else {
            if (isCloseTabsOnTSC)
                CloseAllTabs();
        }
        if (agentType == "AutoDialer") CheckPOMAgentStatus(type);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DivAuxCodeChanged()", ex, false);
    }
}

function GetUcidForAcwEndOfCall() {
    try {
        var globalUcid;
        // Lets store all the Connected UCID and INTID
        var global_connectUCID_final = [];
        var global_connectINIT_final = [];
        var array = $.grep(global_ConnectedCalls, function (n, i) {
            return n.triggerIServeLayer == true;
        });

        $.each(array, function (n) {
            global_connectUCID_final[this.InteractionID] = this.UCID;
            global_connectINIT_final[this.InteractionID] = this.InteractionID;
        });
        // If its more that one tabs are opened
        if (global_tabCount > 1) {
            // Iterate with open tabs
            for (var i = 1; i <= global_tabCount; i++) {
                globalUcid = global_UCID[global_openTabs[i]];
                if (jQuery.inArray(globalUcid, global_connectUCID_final) != -1) {
                    // lets match the interactionid
                    var intid = global_openTabs[i];
                    if (jQuery.inArray(intid, global_connectINIT_final) != -1) {
                        global_openTabsUCID[i] = globalUcid;
                    } else {
                        global_openTabsUCID[i] = -1;
                    }
                } else {
                    global_openTabsUCID[i] = -1;
                }
            }
            return global_openTabsUCID;
        } else {
            globalUcid = global_UCID[global_activeTabId];
            if (jQuery.inArray(globalUcid, global_connectUCID_final) != -1) {
                return globalUcid;
            } else {
                return -1;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetUcidForAcwEndOfCall()", ex, false);
    }
}

function LoadAgentListGrids() {
    //LoadAgentListGrid("makeCallagentListGrid", "txtMakeCallNumber");
    //LoadAgentListGrid("transCallagentListGrid", "txtNumberTrans");
    //LoadAgentListGrid("confCallagentListGrid", "txtNumberConf");
}

function AgentListLoaded(obj) {
    try {
        if (global_AgentList !== null) {
            //bind agent list to makecall, transfer, conference windows
            if (obj.dialogName == "makeCall") {
                EnableButton("#btn_make_call", "call", "icon")
                $("#make_call_dialog").data("kendoWindow").center().open();
                //grid filter is not working with this approach of loading the grid data
                //$('#makeCallagentListGrid').data('kendoGrid').dataSource.data(global_AgentList);
                //so initial approach of creating the grid is used now
                LoadAgentListGrid("makeCallagentListGrid", "txtMakeCallNumber");
                document.getElementById("txtMakeCallNumber").value = "";
                //reload the speeddial list grid
                $('#speedDialMakeCallGrid').data('kendoGrid').dataSource.read();
                //focus the textbox
                setTimeout(function () {
                    $("#txtMakeCallNumber").focus();
                }, 500);
            }
            else if (obj.dialogName == "transferCall") {
                EnableButton(obj.buttonName, obj.icon, "icon");
                //enable/disable favorite skill gird
                if (isFavouriteSkillTab) {
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[1]).attr("style", "display:inline-block");
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[1]).children(".k-link").text(favouriteSkillTabName);
                    if (global_CallType == "TextChatTransfer" && GetChatReferenceObj(obj.intid).isNonVoiceRouting) $('#favListGrid').data("kendoGrid").hideColumn("VDN");
                }
                else
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[1]).attr("style", "display:none");
                //enable/disable speed dial gird
                if (isSpeedDialTab) {
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[2]).attr("style", "display:inline-block");
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[2]).children(".k-link").text(speedDialTabName);
                }
                else
                    $($("#tabstrip_transfer").data("kendoTabStrip").items()[2]).attr("style", "display:none");
                //hide the consult/speeddial list tranfer tab if its a chat tranfer
                if (isSpeedDialOnTextChat)
                    tabstrip_transfer.tabGroup.children().last().show();
                else
                    tabstrip_transfer.tabGroup.children().last().hide();
                $("#transfer_dialog").data("kendoWindow").center().open();
                document.getElementById("txtNumberTrans").value = "";
                document.getElementById("txtCommentTrans").value = "";
                //grid filter is not working with this approach of loading the grid data
                //$('#transCallagentListGrid').data('kendoGrid').dataSource.data(global_AgentList);
                //so initial approach of creating the grid is used now
                LoadAgentListGrid("transCallagentListGrid", "txtNumberTrans");
                //reload the favorite grid
                $('#favListGrid').data('kendoGrid').dataSource.read();
                //focus the textbox
                setTimeout(function () {
                    $("#txtNumberTrans").focus();
                }, 500);
            }
            else if (obj.dialogName == "conferenceCall") {
                EnableButton(obj.buttonName, obj.icon, "icon");
                $("#conference_dialog").data("kendoWindow").center().open();
                document.getElementById("txtNumberConf").value = "";
                //grid filter is not working with this approach of loading the grid data
                //$('#confCallagentListGrid').data('kendoGrid').dataSource.data(global_AgentList);
                //so initial approach of creating the grid is used now
                LoadAgentListGrid("confCallagentListGrid", "txtNumberConf");
                //focus the textbox
                setTimeout(function () {
                    $("#txtNumberConf").focus();
                }, 500);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentListLoaded()", ex, false);
    }
}

function CallbackTimer(data) {
    try {
        //remove object from the array
        RemoveGlobalTimeoutReference(data.intid)
        //eisable the callback Dial button
        DisableCallbackDialButtons(data.intid);
        //enable the callback submit button
        EnableCallbackSubmitButtons(data.intid);
        //For DBS HK prefix 9 and dial out, for DBS IN prefix 90 and dial out
        MakeCall(data.deviceid, data.number, 'customMakeCallCallerId', data.intid);
        //GetTabReferenceObj(data.intid).OtherData.customMakeCallDone = true;
        GetTabReferenceObj(data.intid).OtherData.customMakeCallDone = true;
        ChangeTabReferenceStatus(data.intid, 'MakeCall');
        //disable the close tab button
        $('#btnCloseTab' + data.intid).toggle(false);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CallbackTimer()", ex, false);
    }
}

//Start the Timer when Callback tab Created
function StartcallbackTimer(deviceid, intid, autoDialAfter, number) {
    try {
        // add 10 seconds to the current time for execution
        var dialTime = new Date();
        dialTime.setSeconds(dialTime.getSeconds() + autoDialAfter);
        var object = {};
        object.executeTime = dialTime;
        object.methodName = 'CallbackTimer';
        object.deviceid = deviceid;
        object.intid = intid;
        object.number = number;
        global_timeoutFunctions.push(object);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.StartcallbackTimer()", ex, false);
    }
}

function PerformInfiniteActions() {
    global_timeoutFunctions.forEach(ExecuteTimer);
}

function SetTimer() {
    try {
        setInterval(function () {
            try {
                $("#divTimer").text(moment().hour(0).minute(0).second(statusTimeCounter++).format('HH:mm:ss'));
            } catch (ex) {
                console.log(ex);
            }
        }, 1000);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetTimer()", ex, false);
    }
}

function ExecuteTimer(value, index, ar) {
    try {
        var dte = new Date();
        //check if execution time is greater than current time
        if (value.methodName == "CallbackTimer") {
            if (dte > value.executeTime) {
                window[value.methodName](value);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ExecuteTimer()", ex, false);
    }
}

function BindIntentList(intid) {
    try {
        $('#ddlIntent' + intid).append('<option value="-100">How can I help you?</option>');
        $.each(global_Intents, function (i, val) {
            $('#ddlIntent' + intid).append('<option value="' + val + '">' + val + '</option>');
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.BindIntentList()", ex, false);
    }
}

function CallerIntentReceived(data) {
    try {
        //bind the new intent to intent dropdown
        $("#ddlIntent" + data.InteractionID).length > 0 ? $("#ddlIntent" + data.InteractionID).val(data.IntentName) : "";
        //change the intent status button depending on received status
        //enable/disable intnet dropdown based on received intent status
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CallerIntentReceived()", ex, false);
    }
}

function onIntentChange(intid) {
    try {
        var newintent = $('#ddlIntent' + intid).val();
        UpdateIntent(global_DeviceID, intid, newintent);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.onIntentChange()", ex, false);
    }
}

function OpenIntent(intid) {
    try {
        var newintent = $('#ddlIntent' + intid).val();
        OpenIntent(global_DeviceID, intid, newintent);
        $('#ddlIntent' + intid).attr('disabled', 'disabled');
        $('#imgIntent' + intid).attr('disabled', 'disabled');
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenIntent()", ex, false);
    }
}

function SetHiddenFieldCallback(event) {
    try {
        $('#hfUCID' + event.InteractionID).val(event.UCID);
        $('#hfcallerID' + event.InteractionID).val(event.PhoneNumber);
        $('#hfcalledDevice' + event.InteractionID).val(event.CalledDevice);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetHiddenFieldCallback()", ex, false);
    }
}

function SetddlStatusChangeValues(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        $('#startDate' + event.InteractionID).val(parse.date);
        $('#ddl_time' + event.InteractionID).val(parse.HH + ":" + parse.MM);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetddlStatusChangeValues()", ex, false);
    }
}

function SetSubmitValues(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        if (parse.submitResult == "RescheduleRequest success") {
            log.LogDetails("Success", "TmacUI.SetSubmitValues()", "Callback request successfully rescheduled", true);
        } else if (parse.submitResult == "Schedule success") {
            log.LogDetails("Success", "TmacUI.SetSubmitValues()", "Callback request successfully scheduled", true);
        } else if (parse.submitResult == "Record Successfully updated") {
            log.LogDetails("Success", "TmacUI.SetSubmitValues()", "Callback request successfully closed", true);
        } else {
            log.LogDetails("Warning", "TmacUI.SetSubmitValues()", parse.submitResult, true);
            return;
        }
        //Close the tab after displaying the result
        if (global_isTextChatCallback || globalConfig_CRMCallbackEnd) {
            try {
                //Send Callback CRM pop up for reschedule and closed callbacks only
                if (parse.submitResult != "Schedule success") {
                    //DynamicsCRMEndCallbackPopUpScreen(event.InteractionID, parse.submitResult, parse.status);
                }
            } catch (ex) { }
            var sessionid = $('#hfUCID' + event.InteractionID).val();

            //get cif
            var cif = $('#hfCIF' + event.InteractionID).val();
        }
        if ((parse.submitResult == "Record Successfully updated") || (parse.submitResult == "RescheduleRequest success") ||
            (parse.submitResult == "Schedule success")) {
            CloseTab(event.InteractionID);

            ChangeStatus(global_DeviceID, 'available', '0');
        }
        global_voiceCallHasCallback = false;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetSubmitValues()", ex, false);
    }
}

function SetUserData(event) {
    try {
        if (global_hasgetDataEventDetails) {
            //add the callback tab
            AddVoiceTab('voice_tab_body', event.InteractionID, '', '', '', true);
            //disable all the controls
            SetCallControlStatus(event.InteractionID, false, false, false, false, false, false);
            //Initialize the UIKit accordion for the created tab
            UIkit.accordion($('#voice_accordion' + event.InteractionID), {
                collapse: false,
                showfirst: true
            });
            $('#callControlDiv' + event.InteractionID).toggle(false);
            //disable callbak dial buttons
            DisableCallbackDialButtons(event.InteractionID);
        }
        var parse = JSON.parse(event.JsonData);
        $('#lbl_CallerID' + event.InteractionID).val(parse.detail.CALLERID);

        // set the Caller ID text box read only or not based on the Global Config file
        if (!globalConfig_CallerIDTextBoxEnabled) {
            $('#lbl_CallerID' + event.InteractionID).attr('readonly', true);
        }
        //change the tab header to show caller id
        $('#divCustomerName' + event.InteractionID).text(parse.detail.CALLERID);
        $('#hfAgentID' + event.InteractionID).val(parse.detail.ASSIGNED_TO);

        $('#lbl_PCN' + event.InteractionID).val(parse.detail.PREFFERRED_CONTACTNO);
        if (parse.detail.AGENT_NAME !== "") {
            $('#lbl_assignedTo' + event.InteractionID).val(parse.detail.AGENT_NAME);
        } else {
            $('#lbl_assignedTo' + event.InteractionID).val(global_AgentID);
        }
        $('#lbl_RDT' + event.InteractionID).val(parse.detail.requestDateTime);
        if (globalConfig_CRMCallbackEnd || globalConfig_IsLanguageTruncateEnabled) {
            //disable submit button until callback auto dial is done
            if (!global_hasgetDataEventDetails) {
                DisableCallbackSubmitButtons(event.InteractionID);
            }
        }
        if (globalConfig_IsLanguageTruncateEnabled) {
            if (parse.detail.TYPE_OF_INQUIRY !== "") {
                var typeOfEnquiry = parse.detail.TYPE_OF_INQUIRY;
                var typeOfEnquiryPrefix = typeOfEnquiry.substring(0, 1);
                typeOfEnquiry = typeOfEnquiry.substring(2, typeOfEnquiry.length);
                if (typeOfEnquiryPrefix == 'E') {
                    $('#lbl_typeofenquiry' + event.InteractionID).val(typeOfEnquiry + " {English}");
                } else if (typeOfEnquiryPrefix == 'C') {
                    $('#lbl_typeofenquiry' + event.InteractionID).val(typeOfEnquiry + " {Cantonese}");
                } else if (typeOfEnquiryPrefix == 'M') {
                    $('#lbl_typeofenquiry' + event.InteractionID).val(typeOfEnquiry + " {Mandarin}");
                } else {
                    $('#lbl_typeofenquiry' + event.InteractionID).val(typeOfEnquiry);
                }
            } else {
                $('#lbl_typeofenquiry' + event.InteractionID).val(parse.detail.TYPE_OF_INQUIRY);
            }
        } else {
            $('#lbl_typeofenquiry' + event.InteractionID).val(parse.detail.TYPE_OF_INQUIRY);
        }
        $('#lbl_CQWT' + event.InteractionID).val(parse.detail.QUEUE_WAIT_TIME + " seconds");
        $('#lbl_NOCA' + event.InteractionID).val(parse.detail.NO_CALLBACK_ATTEMPTS);
        if (parse.detail.NO_CALLBACK_ATTEMPTS === "0") {
            DisableCallbackDetailsButtons(event.InteractionID);
        }
        $('#hfSRNO' + event.InteractionID).val(parse.detail.SRNO);
        $('#hfCBUCID' + event.InteractionID).val(parse.detail.UCID);
        $('#hfTYPE' + event.InteractionID).val(parse.detail.TYPE);
        //CIF
        $('#hfCIF' + event.InteractionID).val(parse.detail.CIF);
        $('#lbl_CIF' + event.InteractionID).val(parse.detail.CIF);
        //Pending callback count
        $('#lbl_CallbackCount' + event.InteractionID).val(parse.detail.CallbackCount);
        $('#lblCurrentStat' + event.InteractionID).text(parse.detail.CALLBACK_STATUS);
        var autoDialAfter = parse.detail.autoDialAfter;
        if (parse.detail.countValue > 2) {
            var select = document.getElementById('ddl_status' + event.InteractionID);
            select.options[select.options.length] = new Option('Unsuccessful', 'Unsuccessful');
        }
        var comments = parse.detail.COMMENTS;
        if (comments !== "") {
            $('#txtComments' + event.InteractionID).val(parse.detail.COMMENTS);
        }
        if (global_isTextChatCallback || globalConfig_CRMCallbackEnd) {
            //load interaction history for this callback
            //CreateInteractionHistoryGrid(event.InteractionID, "");
            LoadInteractionHistoryOnDemand(global_DeviceID, event.InteractionID, parse.detail.CIF, '', parse.detail.CALLERID);
        }
        //if agent initiated callback or customer initiated callback, update dial date and dial time 
        //for that srno in callback requests table
        if (global_isTextChatCallback) {
            custom_updateDialDateTimeForCallback(event.InteractionID, parse.detail.SRNO);
        }
        if (!global_hasgetDataEventDetails) {
            if (!global_isTextChatCallback) {
                try {
                    //var val = GetTabReferenceObj(event.InteractionID).OtherData.isCallbackTransferRec;
                    var val = GetTabReferenceObj(event.InteractionID).OtherData.isCallbackTransferRec;
                    if (val) {
                        //do nothing
                    } else {
                        StartcallbackTimer(global_DeviceID, event.InteractionID, autoDialAfter, parse.detail.PREFFERRED_CONTACTNO);
                    }
                } catch (ex) {
                    log.LogDetails("Error", "TmacUI.SetUserData() - Inside", ex, false);
                }
            } else {
                global_isTextChatCallback = false;
            }
        }
        global_hasgetDataEventDetails = false;
        //launch the CRM
        //intid,cif,ucid,chatsessionid
        if (parse.detail.CIF === null) {
            parse.detail.CIF = "";
        }
        if (global_voiceCallHasCallback) {
            //do nothing
        } else {
            custom_GetVASessionIDForCallback(event.InteractionID, parse.detail.CIF, parse.detail.UCID, parse.detail.SRNO);
        }
        SetPendingCallbackGridValues(event);
        //disable the close tab button
        $('#btnCloseTab' + event.InteractionID).toggle(false);
        //if (GetTabReferenceObj(event.InteractionID).OtherData.isCallbackTransferRec) {
        if (GetTabReferenceObj(event.InteractionID).OtherData.isCallbackTransferRec) {
            DisableCallbackDialButtons(event.InteractionID);
            DisableCallbackSubmitButtons(event.InteractionID);
        }
        $("#li_" + event.InteractionID).removeClass("li-on-call");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetUserData()", ex, false);
    }
}

function GetVDNList(event) {
    try {
        var parse = JSON.parse(event.JsonData);

        if (parse.modulename == "callback") {
            var str = parse.detail;
            //Changed by Mukesh - 8th Aug,2016
            //SIP Dialer - Callback Extensions now will be range eg. 1000-1500
            var indices = 0;
            for (var i = 0; i < str.length; i++) {
                if (str[i] === "-") {
                    indices = i;
                }
            }
            //global_CallbackVDNListStart = str.substring(0, indices);
            //global_CallbackVDNListEnd = str.substring((indices + 1), str.length);
        } else if (parse.modulename == "textchat") {
            global_TextChatVDNList = parse.detail;
        } else if (parse.modulename == "ibgdnis") {
            global_IBGDNISList = parse.detail;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetVDNList()", ex, false);
    }
}

function GetPopUpURL(event) {
    try {
        var parse = JSON.parse(event.JsonData);

        if (parse.modulename == "callback") {
            global_CallbackPopUpURL = parse.detail;
        } else if (parse.modulename == "QMS") {
            global_QMSPopUpURL = parse.detail;
        } else if (parse.modulename == "ACW") {
            global_ACWPopUpURL = parse.detail;
        }
        if (parse.modulename == "MSDChatAccept") {
            global_MSDChatAcceptPopUpURL = parse.detail;
        } else if (parse.modulename == "MSDChatClose") {
            global_MSDChatClosePopUpURL = parse.detail;
        } else if (parse.modulename == "MSDCallbackAccept") {
            global_MSDCallbackAcceptPopUpURL = parse.detail;
        } else if (parse.modulename == "MSDCallbackClose") {
            global_MSDCallbackClosePopUpURL = parse.detail;
        } else if (parse.modulename == "MSDInboundVoice") {
            global_MSDInboundVoicePopUpURL = parse.detail;
        } else if (parse.modulename == "MSDOutboundVoice") {
            global_MSDOutboundVoicePopUpURL = parse.detail;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetPopUpURL()", ex, false);
    }
}

function SetCallbackDetailGridValues(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        dataToBind = parse.detail;
        var $kendoGrid = $('#callback_detail_grid').data('kendoGrid');
        $kendoGrid.dataSource.data(dataToBind);
        $kendoGrid.refresh();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetCallbackDetailGridValues()", ex, false);
    }
}

function Getdata(event) {
    try {
        var parse = JSON.parse(event.JsonData);
        var srno = parse.srno;
        if (srno !== "") {
            global_hasgetDataEventDetails = true;
            var existingCallbackForCustomerTabId = existingCallbackForCustomerTabId + 1;
            custom_getdetailsforSrno(existingCallbackForCustomerTabId, srno);
        } else {
            //do nothing
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.Getdata()", ex, false);
    }
}

function SaveTabReference(type, intid, status) {
    try {
        var tabRef = {};
        tabRef.direction = 'in';
        tabRef.type = type; //voice,callback,chat
        tabRef.intid = intid;
        tabRef.status = status;
        tabRef.CRMWindowData = {};
        tabRef.OtherData = {};
        tabRef.firstSelect = true;
        tabRef.isActive = false;
        tabRef.tabTimer = null;
        tabRef.isStatic = type === "main" || type === "supervisor" || type === "workbench";
        global_InteractionTabs.push(tabRef);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SaveTabReference()", ex, false);
    }
}

function RemoveTabReference(intid) {
    try {
        for (var i = 0; i < global_InteractionTabs.length; i++) {
            if (global_InteractionTabs[i].intid === parseInt(intid) || (isNaN(intid) && global_InteractionTabs[i].intid == intid)) {
                global_InteractionTabs.splice(i, 1);
                break;
            }
        }
        disconnectByHandleType = "";
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveTabReference()", ex, false);
    }
}

function ChangeTabReferenceStatus(intid, status) {
    try {
        GetTabReferenceObj(intid).status = status;
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ChangeTabReferenceStatus()", ex, false);
    }
}

function GetTabReferenceObj(intid) {
    try {
        for (var i = 0; i < global_InteractionTabs.length; i++) {
            if (global_InteractionTabs[i] !== undefined && (global_InteractionTabs[i].intid === parseInt(intid) || (isNaN(intid) && global_InteractionTabs[i].intid == intid)))
                return global_InteractionTabs[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetTabReferenceObj()", ex, false);
    }
}

//------------------------------------------------------------------------
//TODO:: To move these chat releated methods to tmac_text_chat_ui js 
//currently there is a check for this in main_ui OnTabStripActivate and OnTabStripSelected methods
//need to optimise the check in above mentioned methods and move these 3 methods.
function SaveChatReference(intid) {
    try {
        var chatRef = {};
        //intid
        chatRef.intid = intid;
        //agent
        chatRef.isAgent = "";
        //customer
        chatRef.isCustomer = "";
        //save the agent name
        chatRef.agentName = "";
        //save the customer name
        chatRef.customerName = "";
        //save the customer/agent name for label reference
        chatRef.labelName = "";
        //customer typing flag
        chatRef.isTyping = false;
        //typing user
        chatRef.typingUser = "";
        //chat disconnected flag
        chatRef.isDisconnected = false;
        //tab blink for chat session
        chatRef.isBlink = false;
        //chat active for the session
        chatRef.isActive = false;
        //chat transfer flag
        chatRef.isTransfer = false;
        //chat conference flag
        chatRef.isConference = false;
        //hyperlink array to send to the customer
        chatRef.hyperLinks = [];
        //for the reply text
        chatRef.replyText = "";
        //if for agent reply or for customer reply
        chatRef.replyUser = "";
        //text, image, photo, audio, files
        chatRef.replyType = "";
        //reply text span id
        chatRef.replyTextId = "";
        //selected template
        chatRef.selectedTemplateId = "";
        //chat timer time taken to reply
        chatRef.timeTakenToReply = null;
        //chat timer time taken to reply counter
        chatRef.timeTakenCounter = 0;
        //chat mode
        chatRef.chatMode = "";
        //routing type
        chatRef.isNonVoiceRouting = false;
        //push to the array for that interaction
        global_ChatReference.push(chatRef);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SaveChatReference()", ex, false);
    }
}

function GetChatReferenceObj(intid) {
    try {
        for (let i = 0; i < global_ChatReference.length; i++) {
            if (global_ChatReference[i] !== undefined && global_ChatReference[i].intid === parseInt(intid))
                return global_ChatReference[i];
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetChatReferenceObj()", ex, false);
    }
}

function RemoveChatReference(intid) {
    try {
        for (var i = 0; i < global_ChatReference.length; i++) {
            if (global_ChatReference[i] !== undefined && global_ChatReference[i].intid === parseInt(intid)) {
                global_ChatReference.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveChatReference()", ex, false);
    }
}
//------------------------------------------------------------------------

function CloseAllTabs() {
    try {
        var myArray = [];
        var intid = "";
        for (var i = 0; i < global_InteractionTabs.length; i++) {
            intid = global_InteractionTabs[i].intid;
            if (!isNaN(intid)) {
                RemoveGlobalTimeoutReference(intid);
                CloseTab(intid);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseAllTabs()", ex, false);
    }
}

function RemoveGlobalTimeoutReference(intid) {
    try {
        for (var i = 0; i < global_timeoutFunctions.length; i++) {
            if (global_timeoutFunctions[i].intid === parseInt(intid)) {
                global_timeoutFunctions.splice(i, 1);
                break;
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RemoveGlobalTimeoutReference()", ex, false);
    }
}

function CloseOutgoingVoiceTab(event) {
    //check if this is an voice out tab. Then close the tab
    try {
        if (GetTabReferenceObj(event.InteractionID).type == 'voice') {
            //if (GetTabReferenceObj(event.InteractionID).type == 'voice') {
            if (GetTabReferenceObj(event.InteractionID).direction == 'out') {
                CloseTab(event.InteractionID);
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseOutgoingVoiceTab()", ex, false);
    }
}

//this function returns bool value by evaluating whether the input is a callback acd call or not
function isCallbackNumber(number) {
    try {
        if ((number >= global_CallbackVDNListStart) && (number <= global_CallbackVDNListEnd)) {
            return true;
        } else {
            return false;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.isCallbackNumber()", ex, false);
    }
}

function isInternalCall(callerid) {
    try {
        if (callerid !== "" && callerid !== null) {
            //if length is equal to 5, station number, then return true
            if (callerid.length == '5') {
                return true;
            }
            //if length is equal to 9, check if first digit is 7(internal dbs - configurable), 
            //if yes then return true else return false
            else if (callerid.length == '9') {
                var val = callerid.substring(0, 1);
                if (val == globalConfig_InternalNumberStartsWith) {
                    return true;
                }
                return false;
            }
        } else {
            return false;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.isInternalCall()", ex, false);
    }
}

function ShowRecentAlerts() {
    try {
        //clear the content first
        $("#div_recent_alerts").html("");
        //loop the recentAlerts
        for (var i = recentAlerts.length; i >= 0; i--) {
            //append each items
            $("#div_recent_alerts").append(recentAlerts[i]);
        }
        //append no alert message
        AppendNoAlerts();
        //popup the modal
        UIkit.modal("#recent_alerts_dialog").show();
        $("#btnrecentalerts i").text("notifications");
        $("#btnrecentalerts i").removeClass("wiggle");
        $("#recentAlertCount").text(0);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ShowRecentAlerts()", ex, false);
    }
}

function ClearAlerts() {
    try {
        //clear the contents
        $("#div_recent_alerts").html("");
        //clear the array
        recentAlerts = [];
        //append no alert message
        AppendNoAlerts();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ClearAlerts()", ex, false);
    }
}

function AppendNoAlerts() {
    try {
        //if the list is empty append no alert message
        if (recentAlerts.length === 0) {
            var alertManagerHtml = '<span class="uk-text-bold uk-text-primary">No recent alerts</span>';
            $("#div_recent_alerts").append(alertManagerHtml);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AppendNoAlerts()", ex, false);
    }
}

function OnSkillListChange(arg) {
    try {
        //dataitem
        var dataItem = this.dataItem(arg.item);
        //slected item
        selectedItem = dataItem.SkillID;
        //agent list grid
        var grid = $('#transCallagentListGrid');
        if (selectedItem)
            grid.data("kendoGrid").dataSource.filter({
                field: "AgentVoiceSkillsAsString",
                operator: "contains",
                value: selectedItem
            }); //filter the selected item
        else
            grid.data("kendoGrid").dataSource.filter({}); //empty if not found
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnSkillListChange()", ex, false);
    }
}

function RefreshTransCallagentListGrid() {
    try {
        var grid = $('#transCallagentListGrid').data("kendoGrid");
        grid.dataSource.filter([]);
        $('#transfer_skill_list').data("kendoDropDownList").text("Select skill..");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.RefreshTransCallagentListGrid()", ex, false);
    }
}

function OnConsultTransferTypeSelected(arg) {
    try {
        let type = this.dataItem(arg.item).value;
        let intid = "";
        if (type == "Agent") {
            $("#pomTxtNumberTrans").attr("disabled", "disabled");
        }
        else {
            $("#pomTxtNumberTrans").removeAttr("disabled", "disabled");
        }

        if (global_CallType == "Transfer")
            intid = global_transferIntID;
        else if (global_CallType == "Conference")
            intid = global_conferenceIntID;

        GetConsultDestinationAgentsList(intid, type);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OnConsultTransferTypeSelected()", ex, false);
    }
}

function SetPendingCallbackGridValues(event) {
    try {
        var intId = event.InteractionID;
        var grid = '#pending_callback_grid' + intId;
        var parse = JSON.parse(event.JsonData);
        if (parse.cifData.length > 0) {
            var $kendoGrid = $(grid).data('kendoGrid');
            $kendoGrid.dataSource.data(parse.cifData);
            var functionname = "CloseMultipleRequest(" + intId + ")";
            var closeallbuttonid = "closeallcallback" + intId;
            $(grid + " .k-pager-info").after("<button href='javascript: void(0)' onclick='" + functionname + "' class='k-button' id=" +
                closeallbuttonid + " style='float: right; height: 30px;'>Close All</button>");
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.SetPendingCallbackGridValues()", ex, false);
    }
}

function CloseCallback(intid, srno, rowid) {
    try {
        // call the server side code and close this record
        var comments = $('#txtComments' + intid).val();
        custom_closeRequest(intid, srno, comments);
        $("#close_callback_dialog").data("kendoWindow").close();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseCallback()", ex, false);
    }
}

function ScheduleCallback(intid, srno, type, rowid) {
    try {
        // call the server side code and close this record
        // call popupp window for reschedule
        $("#hfmultipleCallbackScheduleRequestType").val(type);
        $("#close_callback_dialog").data("kendoWindow").close();
        $("#schedule_multiple_callback_dialog").data("kendoWindow").center().open();
        $("#hfmultipleCallbackScheduleRequestSrno").val(srno);
        $("#hfmultipleCallbackScheduleRowId").val(rowid);
        var prefNumber = $("#hfRegPhone" + intid).val();
        $("#multipleCallbackSchedulePrefNumber").val(prefNumber);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ScheduleCallback()", ex, false);
    }
}

function CloseMultipleRequest(intid) {
    try {
        var comments = $('#txtComments' + intid).val();
        var myGrid = $("#pending_callback_grid" + intid).data('kendoGrid');
        var gridData = myGrid.dataSource.data();
        var array = "";
        // iterate one by one rows
        for (var i = 0; i < gridData.length; i++) {
            // Do Close call back either one by one or just pass selRowIds single shot
            if (i === 0) {
                array = gridData[i].SRNO;
            } else {
                array = array + "," + gridData[i].SRNO;
            }
        }
        if (array.split(',').length > 0) {
            custom_closeRequest(intid, array, comments);
        } else {
            log.LogDetails("Error", "TmacUI.CloseMultipleRequest()", "Please select the callbacks to be closed", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseMultipleRequest()", ex, false);
    }
}

function CloseRequest(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        if (parse.submitResult == "Record Successfully updated") {
            log.LogDetails("info", "TmacUI.CloseRequest()", "Callback request successfully closed", true);
            var srno = parse.srnoSuccess;
            var srnoList = srno.split(",");
            var $grid = $("#pending_callback_grid" + event.InteractionID).data().kendoGrid;
            var dataItem = $grid.dataSource.data();
            for (var i = 0; i < srnoList.length; i++) {
                var rowid;
                for (var j = 0; j < dataItem.length; j++) {
                    if (dataItem[j].SRNO == srnoList[i]) {
                        rowid = j;
                        break;
                    }
                }
                var rowItem = $grid.dataSource.data()[rowid];
                rowItem.set('CALLBACK_STATUS', 'Closed');
            }
            //if  there is only one cllback request then disable closall button after closing the request
            if (srnoList.length === 1) {
                $('#closeallcallback' + event.InteractionID).toggle(false);
            }
        } else if (parse.submitResult == "Record update failed") {
            log.LogDetails("Error", "TmacUI.CloseRequest()", "Callback request failed to close", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CloseRequest()", ex, false);
    }
}

function ScheduleCallbackComplete(event) {
    try {
        //Parse the received JSON string
        var parse = JSON.parse(event.JsonData);
        if (parse.submitResult == "RescheduleRequest success") {
            log.LogDetails("Error", "TmacUI.ScheduleCallbackComplete()", "Callback request successfully rescheduled", true);
            $("#btnscheduleCallback" + parse.srno).prop("disabled", true);
            $("#btnCloseCallback" + parse.srno).prop("disabled", true);
        } else if (parse.submitResult == "RescheduleRequest failed") {
            log.LogDetails("Error", "TmacUI.CloseRequest()", "Callback request failed", true);
        } else {
            log.LogDetails("Warning", "TmacUI.ScheduleCallbackComplete()", parse.submitResult, true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ScheduleCallbackComplete()", ex, false);
    }
}

function LoadReminderEvent(event) {
    try {
        var grid;
        if (isFullTMAC) {
            HideKendoLoading("#reminder_grid_side");
            if (event.Reminders !== null) {
                grid = $('#reminder_grid_side').data('kendoGrid');
                grid.dataSource.data(event.Reminders);
                grid.dataSource.sort({ field: "ID", dir: "desc" });
            }
        }
        else {
            HideKendoLoading("#reminder_grid");
            if (event.Reminders !== null) {
                grid = $('#reminder_grid').data('kendoGrid');
                grid.dataSource.data(event.Reminders);
                grid.dataSource.sort({ field: "ID", dir: "desc" });
            }
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadReminderEvent()", ex, false);
    }
}

function OpenAddReminderDialog() {
    try {
        $("#add_reminder_dialog").data("kendoWindow").title("Set Reminder");
        ResetReminder();
        $("#btnUpdateReminder").toggle(false);
        $("#btnSetReminder").css("display", "inline-block");
        $("#add_reminder_dialog").data("kendoWindow").center().open();
        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenAddRemiderDialog()", ex, false);
    }
}

function AddReminder() {
    try {
        let message = $("#txtReminder").val();
        let date = $("#reminderDate").val();
        let time = $("#reminderTime").val();
        if ($.trim(message) == "") {
            log.LogDetails("Error", "TmacUI.AddReminder()", "Please enter the message", true);
            return;
        }
        if ($.trim(date) == "") {
            log.LogDetails("Error", "TmacUI.AddReminder()", "Please select a date", true);
            return;
        }
        if ($.trim(time) == "") {
            log.LogDetails("Error", "TmacUI.AddReminder()", "Please enter the time", true);
            return;
        }
        var re = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/;
        if (!re.test(time)) {
            ShowNotify("Please enter a valid time", "danger", null, "top-center");
            return false;
        }
        let inputDateTime = moment(date + " " + time, "DD/MM/YYYY HH:mm:ss");
        let validateDate = inputDateTime.isBefore(moment(new Date()));
        if (validateDate) {
            ShowNotify("Reminder datetime should be greater than today", "danger", null, "top-center");
            return false;
        }
        let reminderDate = inputDateTime.format("YYYY") + inputDateTime.format("MM") + inputDateTime.format("DD");
        let reminderTime = inputDateTime.format("HH") + inputDateTime.format("mm") + inputDateTime.format("ss");
        //add remider to the server
        CreateAgentReminder(reminderDate, reminderTime, message);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AddRemider()", ex, false);
    }
}

function ResetReminder() {
    try {
        $("#txtReminder").val("");
        $("#reminderDate").val("");
        $("#reminderTime").val("");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ResetReminder()", ex, false);
    }
}

function OpenEditReminderDialog() {
    try {
        $("#add_reminder_dialog").data("kendoWindow").title("Edit Reminder");
        ResetReminder();
        $("#btnDeleteReminder").addClass("disabled");
        if (isFullTMAC) {
            $grid = $("#reminder_grid_side").data("kendoGrid");
        }
        else {
            $grid = $("#reminder_grid").data("kendoGrid");
        }
        var $cell = $grid.select();
        var $row = $cell.closest('tr'); //selected tr
        var rowData = $grid.dataItem($row); //selected row data
        $("#txtReminder").val(rowData.Message);
        $("#reminderDate").val(moment(rowData.RemindDate, "DD/MM/YYYY").format("DD/MM/YYYY"));
        $("#reminderTime").val(rowData.RemindTime);
        $("#txtReminder").attr("readonly", "readonly");
        $("#btnSetReminder").toggle(false);
        $("#btnUpdateReminder").css("display", "inline-block");
        $("#add_reminder_dialog").data("kendoWindow").center().open();
        TriggerResize();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenAddRemiderDialog()", ex, false);
    }
}

function EditReminder() {
    try {
        if (isFullTMAC) {
            $grid = $("#reminder_grid_side").data("kendoGrid");
        }
        else {
            $grid = $("#reminder_grid").data("kendoGrid");
        }
        var $cell = $grid.select();
        var $row = $cell.closest('tr'); //selected tr
        var rowData = $grid.dataItem($row); //selected row data
        var obj = {};
        obj.status = "edit";
        //**----TO DO-----**
        //Edit reminder is not present now
        //Server side change or delete and add new
        //**----TO DO-----**
        DisableButton("#btnEditReminder");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.EditRemider()", ex, false);
    }
}

function DeleteReminder() {
    try {
        UIkit.modal.confirm("Are you sure to delete this reminder?",
            function () {
                if (isFullTMAC) {
                    $grid = $("#reminder_grid_side").data("kendoGrid");
                }
                else {
                    $grid = $("#reminder_grid").data("kendoGrid");
                }
                var $cell = $grid.select();
                var $row = $cell.closest('tr'); //selected tr
                var rowData = $grid.dataItem($row); //selected row data
                var obj = {};
                obj.status = "delete";
                UpdateAgentReminder(rowData.ID, "delete", rowData.Message, obj);
                DisableButton("#btnDeleteReminder");
            },
            function oncancel() { });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DeleteRemider()", ex, false);
    }
}

function StartReminderThread(event) {
    try {
        globalReminderList = event.Reminders;
        //check for the reminders once then start the thread for every 1 min
        CheckForReminders();
        //if the thread is not started then start else leave as one thread already running
        if (!isReminderThreadStarted)
            isReminderThreadStarted = true;
        setInterval(function () {
            CheckForReminders();
        }, 60000);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.StartReminderThread()", ex, false);
    }
}

function CheckForReminders() {
    try {
        $.each(globalReminderList, function (i, val) {
            if (val.Status == "New") {
                var dateTime = new Date(val.RemindDate + " " + val.RemindTime);
                var momentDateTime = moment(new Date(dateTime), "DD/MM/YYYY HH:mm").format("YYYYMMDDHHmm");
                var momentNowDateTime = moment(new Date(), "DD/MM/YYYY HH:mm").format("YYYYMMDDHHmm");
                if (parseInt(momentDateTime) <= parseInt(momentNowDateTime)) {
                    if (parseInt(momentDateTime) < parseInt(momentNowDateTime))
                        ShowReminder(val.ID, val.Message, val.RemindDate + " " + val.RemindTime + ":00", "old");
                    else
                        ShowReminder(val.ID, val.Message, val.RemindDate + " " + val.RemindTime + ":00", "new");
                    UpdateAgentReminder(val.ID, "Completed", val.Message, null);
                }
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.CheckForReminders()", ex, false);
    }
}

function ShowReminder(id, message, dateTime, type) {
    try {
        var title = "";
        if (type == "new")
            title = "You have a new reminder: " + dateTime;
        else
            title = "You had a reminder @ " + dateTime;
        $("<div id='reminderWindow" + id + "' />").appendTo(document.body).kendoWindow({
            minWidth: 350,
            draggable: true,
            resizable: true,
            title: title,
            scrollable: false,
            modal: false,
            actions: ["Close"],
            deactivate: function () {
                this.destroy();
            }
        }).data("kendoWindow").center().open().content("<span class='onboarding_welcome_message'>" + message + "</span>");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ShowReminder()", ex, false);
    }
}

function ClearSelectedReminder() {
    try {
        if (isFullTMAC) {
            $grid = $("#reminder_grid_side").data("kendoGrid").clearSelection();
        }
        else {
            $grid = $("#reminder_grid").data("kendoGrid").clearSelection();
        }
        $("#btnClearSelectedReminder").addClass("disabled");
        $("#btnEditReminder").addClass("disabled");
        $("#btnDeleteReminder").addClass("disabled");
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ClearSelected()", ex, false);
    }
}

function LoadChatUserList() {
    try {
        if (isAgentChat)
            agent_chat.agentlist();
        else
            customer_chat.get_customerlist();
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LoadChatUserList()", ex, false);
    }
}

function GetMyLanId() {
    try {
        $.ajax({
            type: "POST",
            data: null,
            url: "Login.aspx/GetMyLanID",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (user) {
                //Login(user.d.split('\\')[1], voiceBioStationId, "", false, false, "");
                Login("saman", voiceBioStationId, "", false, false, "");
            },
            error: function (xhr, status, error) {
                console.log(xhr.responseText);
            }
        });
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetMyLanId()", ex, false);
    }
}

function GetServiceWindowURL(event) {
    try {
        //campaign manager
        if (event.SubType.toLowerCase() == "camp") {
            var obj = {};
            obj.type = "camp";
            obj.url = campSelectorUrl + event.SubTypeData +
                "&agentID=" + global_AgentID + "&extension=" + global_DeviceID + "&ucid=" +
                event.UCID + "&skill=" + event.Queue +
                "&intid=" + event.InteractionID;
            obj.defaultUrl = false;
            return obj;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.GetServiceWindowURL()", ex, false);
    }
}

function OpenSupportDoc() {
    try {
        window.open(supportDocUrl, "_blank", "menubar=no,resizable=0,location=no,scrollbars=no,width=" + screen.width / 2 + ",height=" + screen.height).moveTo(0, 0);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenSupportDoc()", ex, false);
    }
}

function ToggleTmacScreen() {
    try {
        window.resizeTo(screen.width, screen.height);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.ToggleTmacScreen()", ex, false);
    }
}

function AgentCommandEvent(event) {
    try {
        switch (event.Name) {
            case "VideoMessage":
                break;
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.AgentCommandEvent()", ex, false);
    }
}

function OpenIframeTab(type) {
    try {
        let icon = "";
        let url = "";
        let lType = type.toLowerCase();
        switch (lType) {
            case "supervisor":
                icon = "people";
                url = supervisorLink + "?supervisorid=" + global_AgentID + "&supervisornumber=" + global_DeviceID + "&teamid=" + global_TeamID;
                break;
            case "workbench":
                icon = "library_books";
                url = workbenchLink + "?agentId=" + global_AgentID + "&theme=" + localStorage.getItem("altair_theme") + "&font=" + localStorage.getItem("font_family");
                break;
        }

        if (GetTabReferenceObj(lType) === undefined) {
            SaveTabReference(lType, lType, 'new');
            //tab header content
            var tempTabHeaderContent = GetTabHtml("tab_header_template", lType, { icon: icon });
            //tab body content
            var tempTabContent = GetTabHtml("iframe_template", lType, null);
            //add a kendo tab
            AddTab(tempTabContent, tempTabHeaderContent, lType, lType, true, true, false);
            LoadIFrame(lType + "_iframe", url);

            switch (lType) {
                case "supervisor":
                    if (isExpandCollapseOnIframes.Supervisor)
                        window.resizeTo(screen.width, screen.height);
                    break;
                case "workbench":
                    if (isExpandCollapseOnIframes.Workbench)
                        window.resizeTo(screen.width, screen.height);
                    break;
            }
        }
        else {
            log.LogDetails("Error", "TmacUI.OpenWorkbench()", type + " window is already opened", true);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.OpenWorkbench()", ex, false);
    }
}

function LogoffAlert(message, forcedlogoff, timer) {
    try {
        var modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>' + message + '<br/><img class=\'uk-margin-top\' src=\'assets/img/spinners/spinner.gif\' alt=\'\'>');
        setTimeout(function () {
            if (forcedlogoff)
                window.close();
            //modal.hide();
        }, timer);
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.LogoffAlert()", ex, false);
    }
}

function DisplayCurrentStatusLoop() {
    try {
        if (changeStatusTimeOut && changeStatusTimeOut > 0) {
            setInterval(function () {
                DivAuxStatReceivedFromServer(global_LastAgentStat.Status, global_LastAgentStat.Source);
            }, changeStatusTimeOut);
        }
    } catch (ex) {
        log.LogDetails("Error", "TmacUI.DisplayCurrentStatusLoop()", ex, false);
    }
}