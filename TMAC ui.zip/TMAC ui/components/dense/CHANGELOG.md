Changelog
=====

This is a changelog for [Dense](http://dense.rah.pw).

Version 0.1.0 - upcoming
-----

* Initial release.
