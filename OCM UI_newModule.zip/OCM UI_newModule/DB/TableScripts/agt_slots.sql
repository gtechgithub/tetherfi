

/****** Object:  Table [dbo].[agt_slots]    Script Date: 22-07-2020 23:49:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[agt_slots](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[orgunit] [int] NULL,
	[slotgroup] [varchar](50) NULL,
	[slottype] [varchar](50) NULL,
	[slotdescription] [varchar](300) NULL,
	[startofweek] [date] NULL,
	[endofweek] [date] NULL,
	[fromtime] [time](0) NOT NULL,
	[totime] [time](0) NOT NULL,
	[monday] [int] NOT NULL,
	[tuesday] [int] NOT NULL,
	[wednesday] [int] NOT NULL,
	[thursday] [int] NOT NULL,
	[friday] [int] NOT NULL,
	[saturday] [int] NOT NULL,
	[sunday] [int] NOT NULL,
	[lastchangedon] [datetime] NULL,
	[lastchangedby] [varchar](50) NULL,
 CONSTRAINT [PK_agt_slots_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Index [IX_N_agt_slots_startofweek_endofweek]    Script Date: 22-07-2020 23:50:07 ******/
CREATE NONCLUSTERED INDEX [IX_N_agt_slots_startofweek_endofweek] ON [dbo].[agt_slots]
(
	[startofweek] ASC,
	[endofweek] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE [dbo].[agt_slots] ADD  CONSTRAINT [DF_agt_slots_monday]  DEFAULT ((0)) FOR [monday]
GO

ALTER TABLE [dbo].[agt_slots] ADD  CONSTRAINT [DF_agt_slots_tuesday]  DEFAULT ((0)) FOR [tuesday]
GO

ALTER TABLE [dbo].[agt_slots] ADD  CONSTRAINT [DF_agt_slots_wednesday]  DEFAULT ((0)) FOR [wednesday]
GO

ALTER TABLE [dbo].[agt_slots] ADD  CONSTRAINT [DF_agt_slots_thursday]  DEFAULT ((0)) FOR [thursday]
GO

ALTER TABLE [dbo].[agt_slots] ADD  CONSTRAINT [DF_agt_slots_friday]  DEFAULT ((0)) FOR [friday]
GO

ALTER TABLE [dbo].[agt_slots] ADD  CONSTRAINT [DF_agt_slots_saturday]  DEFAULT ((0)) FOR [saturday]
GO

ALTER TABLE [dbo].[agt_slots] ADD  CONSTRAINT [DF_agt_slots_sunday]  DEFAULT ((0)) FOR [sunday]
GO


