﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "SlotScheduler.js",
        Version: "3.2.9.1804",
        LastModifiedDateTime: "20-07-2020 08:30:00 AM",
        LastModifiedBy: "prathik",
        Description: "new module"
    });
});


function onSlotSchedulerEdit(e) {
    genericEdit(e);
    bindingOrgUnit(e);
    if (e.model.isNew() == false) {

        if ($("#SlotType").data("kendoDropDownList") != undefined) {
            $("#SlotType").data("kendoDropDownList").readonly();
        }

        if ($("#SlotGroup").data("kendoDropDownList") != undefined) {
            $("#SlotGroup").data("kendoDropDownList").readonly();
        }
        
        $("#StartOfWeek").data("kendoDatePicker").readonly();
        $("#EndOfWeek").data("kendoDatePicker").readonly();
        $("#StartOfWeek").data("kendoDatePicker").enable(false);
        $("#EndOfWeek").data("kendoDatePicker").enable(false);

        if ($("#FromTime").data("kendoTimePicker") != undefined) {
            $("#FromTime").data("kendoTimePicker").readonly();
            $("#FromTime").data("kendoTimePicker").enable(false);
        }
        if ($("#ToTime").data("kendoTimePicker") != undefined) {
            $("#ToTime").data("kendoTimePicker").readonly();
            $("#ToTime").data("kendoTimePicker").enable(false);
        }
    }
   
        
}

function onSlotSchedulerSave(e) {
   
    var fromTime = $("#FromTime").data("kendoTimePicker");
    var toTime = $("#ToTime").data("kendoTimePicker");

 

    e.model.FromTime = kendo.toString(fromTime.value(), "HH:mm:ss");
    e.model.ToTime = kendo.toString(toTime.value(), "HH:mm:ss");

    if (e.model.FromTime == null || e.model.FromTime == "") {
        toaster("Enter a FromTime", "error");
        e.preventDefault();
        return;
    }
    if (e.model.ToTime == null || e.model.ToTime == "") {
        toaster("Enter a ToTime", "error");
        e.preventDefault();
        return;
    }
    var time1 = moment(e.model.FromTime, 'HH:mm:ss');
    var time2 = moment(e.model.ToTime, 'HH:mm:ss');
    if (time1.isAfter(time2)) {
        toaster("FromTime is greater than ToTime", "error");
        e.preventDefault();
        return;
    }
    if (time1.isSame(time2)) {
        toaster("FromTime is same as ToTime", "error");
        e.preventDefault();
        return;
    }

    if (e.model.SlotType != "Default") {
        var StartOfWeekpicker = $("#StartOfWeek").val();
        var EndOfWeekpicker = $("#EndOfWeek").val();
        if (StartOfWeekpicker == "" || StartOfWeekpicker == null) {
            toaster("Enter Valid Start Date", "error");
            e.preventDefault();
            return;
        }
        if (EndOfWeekpicker == "" || EndOfWeekpicker == null) {
            toaster("Enter Valid End Date", "error");
            e.preventDefault();
            return;
        }
        e.model.StartOfWeek = $("#StartOfWeek").val();
        e.model.EndOfWeek = $("#EndOfWeek").val();
        var tempStartOfWeek = moment(e.model.StartOfWeek, 'YYYY-MM-DD');
        var tempEndOfWeek = moment(e.model.EndOfWeek, 'YYYY-MM-DD');

        if (moment(tempStartOfWeek, "YYYY-MM-DD", true).isValid() == false) {

            e.preventDefault()
            toaster("Start Date is not in proper format", "error");
            return;

        }
        if (moment(tempEndOfWeek, "YYYY-MM-DD", true).isValid() == false) {
            e.preventDefault()
            toaster("End Date is not in proper format", "error");
            return;
        }
        if (moment(tempStartOfWeek).isAfter(tempEndOfWeek)) {
            toaster("Start Date is greater than End Date", "error");
            e.preventDefault();
            return;
        }

    //if (moment(e.model.StartOfWeek, "YYYY-MM-DD").isBefore(moment(getPresentDate().trim(), "YYYY-MM-DD"))) {
    //    toaster("Start Date is less than Current Date", "error");
    //    e.preventDefault();
    //    return;
    //}

    //if (moment(e.model.EndOfWeek, "YYYY-MM-DD").isBefore(moment(getPresentDate().trim(), "YYYY-MM-DD"))) {
    //    toaster("End Date is less than Current Date", "error");
    //    e.preventDefault();
    //    return;
    //}
    }

   
    modifyValid(e);
    var tempFromTime = e.model.FromTime;
    var tempToTime = e.model.ToTime;
    e.model.FromTime = moment(tempFromTime, 'HH:mm:ss').format('HH:mm:ss');
    e.model.ToTime = moment(tempToTime, 'HH:mm:ss').format('HH:mm:ss');

    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {


        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
}


function getPresentDate() {
    var d = new Date();
    var month = d.getMonth() + 1;
    var day = d.getDate();

    var output = (('' + day).length < 2 ? '0' : '') + day + '/' + (('' + month).length < 2 ? '0' : '') + month + '/' + d.getFullYear();
    return output;
}

function onSlotTypeChange(e)
{
    if ($("#SlotType").data("kendoDropDownList").value() == "Default") {
        $("#StartOfWeek").data("kendoDatePicker").readonly();
        $("#EndOfWeek").data("kendoDatePicker").readonly();
        $("#StartOfWeek").data("kendoDatePicker").enable(false);
        $("#EndOfWeek").data("kendoDatePicker").enable(false);
    }
    else {
        $("#StartOfWeek").data("kendoDatePicker").enable(true);
        $("#EndOfWeek").data("kendoDatePicker").enable(true);
    }
   
}

//kendo scheduler adding extra column and data
function onSchedulerDataBound(e) {

    var view = e.sender.view();


    startDate = view.startDate();

    endDate = view.endDate();

    var scheduler = e.sender,
        schedulerHeader = scheduler.element.find(".k-scheduler-header table tbody tr:eq(0)"),
        datas = scheduler.dataSource.data();
    // add custom column header, do more append for more column
    $(".k-scheduler-tools+.k-scheduler-navigation").css("clear", "none");
    if (scheduler.view().title === "Agenda") {
        $('.k-scheduler-table tr:first th').filter(function () {
            return this.textContent.trim() === "Description"
        }).remove();
        schedulerHeader.append("<th>Description</th>");
        $('.k-scheduler-table tr:first th:eq(2)').text('Slot Occupancy');
        $('.k-scheduler-table tr th:eq(2), .k-scheduler-table tr td:eq(2)').css("width", "7%");

        // add custom column for each data
        datas.forEach(function (data) {
            var uid = data.uid;
            timeData = data.description;
            if (data.occupied == data.total) {
                $('.k-task[data-uid="' + uid + '"] ').parent().css("background-color", "#65fa43");
            }
            else if (parseInt(data.occupied) / parseInt(data.total) < 1 && parseInt(data.occupied) / parseInt(data.total) > 0) {
                $('.k-task[data-uid="' + uid + '"] ').parent().css("background-color", "#FFDAB9");
            }

            $(".k-task[data-uid='" + uid + "']").parent()
                .after("<td>" + timeData + "</td>");
        });
    }
    else {
        $('.k-event-template').css('text-align', 'center');
    }
}
