ALTER TABLE [dbo].[OCM_AgentInteractionReport]
ADD [CIF] varchar(19),[RegisteredMobileNo] varchar(20)
