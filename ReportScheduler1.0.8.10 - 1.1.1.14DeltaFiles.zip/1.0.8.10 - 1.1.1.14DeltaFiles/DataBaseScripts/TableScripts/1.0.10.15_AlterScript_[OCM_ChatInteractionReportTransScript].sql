Alter table OCM_ChatInteractionReportTransScript alter column [InteractionText] nvarchar(500)
Alter table OCM_ChatInteractionReportTransScript alter column [FirstName] nvarchar(50)
Alter table OCM_ChatInteractionReportTransScript alter column  [LastName] nvarchar(50)