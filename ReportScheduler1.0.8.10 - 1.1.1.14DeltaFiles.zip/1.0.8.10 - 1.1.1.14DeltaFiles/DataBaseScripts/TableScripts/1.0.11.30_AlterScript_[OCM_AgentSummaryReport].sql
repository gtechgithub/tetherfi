
Alter table [dbo].[OCM_AgentSummaryReport]
Add [TotalFax] int null

Alter table [dbo].[OCM_AgentSummaryReport]
Add [TotalFaxTime] varchar(14) null