﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "tmactransferlist.js",
       Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Added channel in Blind Transfer"
    });
});

function onTmacConsultTransferSave(e) {
    var Name = $("#Name").val();
    var Value = $("#Value").val();
    var Type = $("#Type").val();

    if (Name == "") {
        e.preventDefault();
        toaster("Please provide a valid Name", "error");
        return;
    }
    if (Value == "") {
        e.preventDefault();
        toaster("Please provide a valid Value", "error");
        return;
    }
    if (Type == "") {
        e.preventDefault();
        toaster("Please provide a valid Type", "error");
        return;
    }
    duplicateValidate(e, "Value", "Value")
    duplicateValidate(e, "Name","Name")
    modifyValid(e);
}

function onTmacBlindTransferListEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        if ($("#SkillName").data("kendoDropDownList") !== undefined) {
            onSkillChange(e);
            $("#SkillId").data("kendoNumericTextBox").enable(false);  
        }
    }
}

function onSkillChange(e) {
    try {
        var channelValue = e.model.Channel;
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'TmacTransferList/GetSkillList',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { channel: channelValue },
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data != null) {
                    try {
                        if (e.model.SkillName !== "") {
                            $("#SkillName").data("kendoDropDownList").text(e.model.SkillName);
                            $("#SkillName").data("kendoDropDownList").value(e.model.SkillId);
                            $("#SkillId").data("kendoNumericTextBox").value(e.model.SkillId);
                        }
                    } catch (e) { }
                }
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function onTmacTransferListEdit(e) {
    genericEdit(e);
}

function onTmacBlindTransferListSave(e) {
    if ($("#SkillName").data("kendoDropDownList") !== undefined) {
        if (e.model.SkillName != "" && e.model.SkillName != "Select" && e.model.SkillName != null) {
            e.model.SkillId = $("#SkillName").data("kendoDropDownList").value();
            e.model.SkillName = $("#SkillName").data("kendoDropDownList").text();
        }
        else
        {
            e.model.SkillId = "";
            e.model.SkillName = "";
        }
    }
   
    var fieldNames = new Array();
    var fieldValues = new Array();

    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
        
    duplicateValidate(e, "SkillId", "SkillId")
    duplicateValidate(e, "SkillName", "SkillName")
    modifyValid(e);
}

function OnBlindTransferSkillName(e) {
    $("#SkillId").data("kendoNumericTextBox").enable(true);
    var SkillId = $("#SkillName").data("kendoDropDownList").value();
    $("#SkillId").data("kendoNumericTextBox").value(SkillId);
    $("#SkillId").data("kendoNumericTextBox").enable(false);
}

function channelID() {
    return {
        channel: $("#Channel").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}