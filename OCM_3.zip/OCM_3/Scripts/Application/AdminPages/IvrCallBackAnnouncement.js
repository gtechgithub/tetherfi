﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrCallBackAnnouncement.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 12:30:00 PM",
        LastModifiedBy: "Shreenitha",
        Description: "Added mandatory check and duplicate check from json while create/edit"
    });
});


var editfieldNames = new Array();
var editfieldValues = new Array();

$("#modifyreasonwindow").hide();

function onSave(e) {
    e.model.StartTime = $("#StartTime").val();
    e.model.EndTime = $("#EndTime").val();

    e.model.WaveFile = $("#waveFile").val();
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].s == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

    var StartDate = $("#StartTime").val().toString();
    var EndDate = $("#EndTime").val().toString();

    if (moment(StartDate, "HH:mm:ss", true).isValid() == false || moment(EndDate, "HH:mm:ss", true).isValid() == false) {

        e.preventDefault()
        toaster("Time is not in proper format", "error");
        return;

    }
    var beginningTime = moment(StartDate, 'HH:mm:ss');
    var endTime = moment(EndDate, 'HH:mm:ss');
    console.log(beginningTime.diff(endTime));
    if (beginningTime.diff(endTime) == 0) {
        e.preventDefault()
        toaster("Start Time and End Time cannot be same", "error");
        return;
    }
    else if (beginningTime.isAfter(endTime) == true) {
        e.preventDefault()
        toaster("End Time should be greater than Start Time", "error");
        return;
    }

    modifyValid(e);
    $(".k-upload-selected").trigger("click");
}
function attachClickHandler(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#waveFile"));
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='Callbackvalidation']").html("");
        control.val(fileInfo.name);
    }
}

function onWavFileUpload(e) {
    e.data = { functionality: $("#functionality").val(), language: $("#Language").val(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

function onWavFileRemove(e) {
    $("#waveFile").val("")
}

function onGridEditRow(e) {
    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }
    if (e.model.isNew() == false) {
        $("#waveFile").html(e.model.WaveFile);
        $("#waveFile").val(e.model.WaveFile);
        $("#ModifyReasonGroup").show();
        $("#callbackWavefileTag").css("visibility", "visible");
        $("#callbackWavefileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.WaveFile + '">' + e.model.WaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
    }
    if (e.model.isNew() == true) {

        $("#callbackWavefileTag").css("visibility", "hidden");
        $("#ModifyReasonGroup").hide();
    }
}

function onChange(arg) {
    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    var str = String(selectedData[0].match(/.wav/g));
    if (str == ".wav") {
        var $grid = arg.sender; //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var url = $grid.dataItem($row).WaveFile;
        if (url == "") {
            toaster("There is no Wav File to Play", "error");
            return;
        }
        else {
            var link = url;
            //window.open(link, 'Wav', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=1,width=300,height=150,left = 650,top = 375');//opns the wavw file
        }
    }
    else {
        toaster("Select a Wav File", "info");
        return;
    }
}