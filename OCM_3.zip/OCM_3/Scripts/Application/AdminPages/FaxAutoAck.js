﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "FaxAutoAck.js",
        Version: "3.2.7.20",
        LastModifiedDateTime: "20-07-2019 12:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Module hierarchy applied."
    });
});

function onFaxAutoAckEdit(e) {
    try {
        genericEdit(e);
        bindingOrgUnit(e);
        if (e.model.isNew() == false) {
            $("#ModifyReasonGroup").show();
            $(e.container).find('input[name="Name"]').attr("readonly", true);
            $("#DNIS").data("kendoDropDownList").enable(false);
            $("#Type").data("kendoDropDownList").enable(false);
        }
        if (e.model.isNew() == true) {
            $("#ModifyReasonGroup").hide();
        }
    } catch (e11) {
        console.log("Exception in FaxAutoAckEdit: " + e11);
    }
}

//Below function is called when clicked on Save/Update
function onFaxAutoAckSave(e) {
    if (e.model.DNIS == "" || e.model.DNIS == null) {
        toaster("Please select the Fax Line", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Type == "" || e.model.Type == null) {
        toaster("Please select the Type", "error");
        e.preventDefault();
        return;
    }
    if ((e.model.Name.replace(/ /g, '')) == "") {
        toaster("Please enter the Name", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Enabled == "" || e.model.Enabled == null) {
        toaster("Please select the Ack Status", "error");
        e.preventDefault();
        return;
    }
    if (e.model.TemplateContent == "" || e.model.TemplateContent == null) {
        toaster("Please select the Template Content", "error");
        e.preventDefault();
        return;
    }
    validateOrgUnit(e);
    modifyValid(e);
}