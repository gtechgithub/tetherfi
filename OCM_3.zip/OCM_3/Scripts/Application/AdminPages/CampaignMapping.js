﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "CampaignMapping.js",
        Version: "11.25",
        LastModifiedDateTime: "23-11-2018 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added new js file"
    });
});

function editCampaignMapping(e) {
    genericEdit(e);
}

function onSaveCampaignMapping(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("CampaignName");
    fieldNames.push("CampaignName");

    fieldValues.push(e.model.TeamName);
    fieldValues.push(e.model.CampaignName);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    // if (e.model.isNew() == true) {
    duplicateValidate(e, "CampaignName", "CampaignName");
    // }
    modifyValid(e);
}