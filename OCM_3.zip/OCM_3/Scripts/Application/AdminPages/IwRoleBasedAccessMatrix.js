﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IwRoleBasedAccessMatrix.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Added flowconnector, returnnode, action columns "
    });
});

function onGridDetailExpand(e) {
    var flowName = e.sender.dataItem(e.masterRow).flowName;

    $("#gridIWRoleAccessDetails_" + flowName).data("kendoGrid").dataSource.data([]);
    $("#gridIWRoleAccessDetails_" + flowName).data("kendoGrid").dataSource.add(e.sender.dataItem(e.masterRow));
}
function gridDataBound(e) {
    enableDisableGridAutoResize = 1;
    onDataBound(e);
}
function onIWRoleMatrixMainGridChange(arg) {
    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    console.log(selectedData);
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_uid = $row.attr('data-uid'); //uid of selected row
    var cell_index = $cell.index(); //cell index 0 based
    var row_index = $row.index(); //row index 0 based
    var RoleName = $grid.dataItem($row).RoleName; //selected row data
    var RoleType = $grid.dataItem($row).RoleType; //selected row data
    var colName = $("#grid").find('th').eq(cell_index).text()//selected column name
    $("#searchDForm").html('');
    set = false;
    console.log(RoleName);
    console.log(RoleType);
    $("#roleName").val(RoleName);
    $("#roleType").val(RoleType);

    var grid = $("#gridIWRoleAccessDetails").data("kendoGrid");
    grid.dataSource.data("");
    if (selectedData != null) {
        $('#popupDrill').modal('show');
        $('#autoCompleteTextbox').val("");
        $("#gridIWRoleAccessDetails").data("kendoGrid").dataSource.filter({});
        grid.dataSource.read();
        $("#DrillPopupFooter").hide();
        $("#searchDFormTemplate").hide();
        $("#DrillReportNameLbl").html("<h3 align='center'> IW Role Based Access Matrix For Role: <span class='theme-color'>" + RoleName + "</span> & Role Type :<span class='theme-color'>" + RoleType + "</span> </h3>");
    }
    if (selectedData == null) {
        toaster("There are no records to show", "info");
        return;
    }
}
function onIWRoleMatrixADatabound(e) {
    e.sender.items().each(function () {
        var dataItem = e.sender.dataItem(this);
        
        if ($('#roleType').val() === "Checker") {
            $(this).find('input[id="add"]').attr("disabled", true);
            $(this).find('input[id="importCallFlow"]').attr("disabled", true);
            $(this).find('input[id="delete"]').attr("disabled", true);
            $(this).find('input[id="versionControl"]').attr("disabled", true);
            $(this).find('input[id="copy"]').attr("disabled", true);
            $(this).find('input[id="build"]').attr("disabled", false);

            $(this).find('input[id="moduleAccess"]').attr("disabled", false);
            $(this).find('input[id="setupNode"]').attr("disabled", false);
            $(this).find('input[id="announcement"]').attr("disabled", false);
            $(this).find('input[id="entryPoint"]').attr("disabled", false);
            $(this).find('input[id="menu"]').attr("disabled", false);
            $(this).find('input[id="assignmemt"]').attr("disabled", false);
            $(this).find('input[id="conditional"]').attr("disabled", false);
            $(this).find('input[id="disconnect"]').attr("disabled", false);
            $(this).find('input[id="agent"]').attr("disabled", false);
            $(this).find('input[id="exitPoint"]').attr("disabled", false);
            $(this).find('input[id="promptAndCollect"]').attr("disabled", false);
            $(this).find('input[id="flowconnector"]').attr("disabled", false);
            $(this).find('input[id="returnnode"]').attr("disabled", false);
            $(this).find('input[id="action"]').attr("disabled", false);
        }
        else if ($('#roleType').val() === "Previewer") {
            $(this).find('input[id="add"]').attr("disabled", true);
            $(this).find('input[id="delete"]').attr("disabled", true);
            $(this).find('input[id="edit"]').attr("disabled", false);
            $(this).find('input[id="copy"]').attr("disabled", true);
            $(this).find('input[id="importCallFlow"]').attr("disabled", true);
            $(this).find('input[id="realtimeView"]').attr("disabled", false);
            $(this).find('input[id="build"]').attr("disabled", true);
            $(this).find('input[id="versionControl"]').attr("disabled", true);
            $(this).find('input[id="moduleAccess"]').attr("disabled", true);
            $(this).find('input[id="setupNode"]').attr("disabled", true);
            $(this).find('input[id="announcement"]').attr("disabled", true);
            $(this).find('input[id="entryPoint"]').attr("disabled", true);
            $(this).find('input[id="menu"]').attr("disabled", true);
            $(this).find('input[id="assignmemt"]').attr("disabled", true);
            $(this).find('input[id="conditional"]').attr("disabled", true);
            $(this).find('input[id="disconnect"]').attr("disabled", true);
            $(this).find('input[id="agent"]').attr("disabled", true);
            $(this).find('input[id="exitPoint"]').attr("disabled", true);
            $(this).find('input[id="promptAndCollect"]').attr("disabled", true);
            $(this).find('input[id="flowconnector"]').attr("disabled", true);
            $(this).find('input[id="returnnode"]').attr("disabled", true);
            $(this).find('input[id="action"]').attr("disabled", true);
        }

        if ($("#iw").data("kendoDropDownList").value() == "Voice") {
            $(this).find('input[id="action"]').attr("disabled", true);
        }
    });
    enableDisableGridAutoResize = 0;
    onDataBound(e);
}

var modifyReason = "";
function onSaveAccessChanges(e) {
    e.data = {
        value: $('#modifyReason').val()
    };
    e.sender._data[0].ModifyReason = modifyReason;
}

function onSaveChanges() {
    var grid = $("#gridIWRoleAccessDetails").data("kendoGrid");
    var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

    if (dirtyItems.length > 0) {
        $('#popupDrill').modal('hide');
        $("#ModifyReasonUser").val("");
        $("#modifyreasonwindowforUser").show();
        var wdw = $("#myWindowUser").data("kendoWindow");
        wdw.center().open();
    }
    else {
        toaster("No rows has been changed", "error");
    }
}

$('.k-grid-save-changes').hide();

function saveChangeYes() {
    $('#modifyReason').val($("#ModifyReasonUser").val());
    if ($.trim($('#modifyReason').val()) == "") {
        toaster("Please enter the modify reason", "error");
        return;
    }
    else {
        $(".k-grid-save-changes").trigger("click");
        $("#myWindowUser").data("kendoWindow").close();
        $('#grid').data('kendoGrid').dataSource.read();
    }
}

function saveChangeNo() {
    $("#myWindowUser").data("kendoWindow").close();
}

function syncGrid(e) {
    if (e.type == "update" || e.type == "delete" || e.type == "create") {
        e.sender.read();
        $('.k-grid-update').html('<span class="k-icon k-i-check"></span> Save');
    }
}
function getParam() {
    return {
        modifyReason: $('#modifyReason').val(),
        roleName: $('#roleName').val(),
        roleType: $('#roleType').val(),
        iwappname: $('#iwappname').val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function iwchange() {
    $("#iwappname").val($("#iw").data("kendoDropDownList").value());
    $("#grid").data("kendoGrid").dataSource.read();
}
function onAutoCompleteSelectDrill(e) {
    var fieldValue = this.options.dataTextField;
    var filterValue = e.dataItem[fieldValue];
    if (e.sender._oldText == "") {
        $("#gridIWRoleAccessDetails").data("kendoGrid").dataSource.filter({});
    } else {
        $("#gridIWRoleAccessDetails").data("kendoGrid").dataSource.filter({ operator: "contains", field: this.options.dataTextField, value: filterValue });
    }
}

function onAutoCompleteChangeDrill(e) {
    if (e.sender._oldText == "") {
        $("#gridIWRoleAccessDetails").data("kendoGrid").dataSource.filter({});
    }
}

function genericRequestAccessgrid(e) {
    let isSuccess = false;
    $("#modifyReason").val("");
    $("#ModifyReasonUser").val("");
    if (e.type === "update") {
        $("#grid").data("kendoGrid").dataSource.read();

        message = e.response.Errors;

        var y = message.hasOwnProperty("Success");

        if (y == true) {
            for (var i = 0; i < message.Success.errors.length; i++) {
                toaster(message.Success.errors[i], "success");
                isSuccess = true;
            }
        }

        var x = message.hasOwnProperty("Failure");

        if (x == true) {
            for (var i = 0; i < message.Failure.errors.length; i++) {
                let msgs = message.Failure.errors[i];
                if (isSuccess)
                    setTimeout(function () {
                        toaster(msgs, "error");
                    }, 3500);
                else
                    toaster(message.Failure.errors[i], "error");
            }
        }
    }
}
$(function () {
    $('#gridIWRoleAccessDetails').on('click', '.chkbx', function () {
        var checked = $(this).is(':checked');
        var grid = $('#gridIWRoleAccessDetails').data().kendoGrid;
        var dataItem = grid.dataItem($(this).closest('tr'));
        var mystring = $(this).data('bind');
        mystring = mystring.replace('checked: ', '');
        dataItem.set(mystring, checked);
    });
});
//Go's to Agent Setting module to edit/add new agent
function openRoleManagement() {
    window.location = window.ApplicationPath + 'RoleManagement' + '/Index';
}