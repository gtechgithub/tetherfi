﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "AdhocOptionEnhancement.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 12:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Version Changed."
    });
});


function onWavFileUpload(e) {
    e.data = { functionality: $("#Functionality").val(), language: $("#Language").val(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

function onWavFileRemoveforPromotionName(e) {
    console.log('onWavFileRemoveforPromotionName');
    $("#PromotionNameWavFile").val("");
}

function onWavFileRemoveforPromotionDetails(e) {
    $("#PromotionDetailsWavFile").val("");
}

function onGridAddRow(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Promotion Number");
    fieldNames.push("Promotion Description");
    fieldNames.push("Language");
    fieldNames.push("Direct Transfer Enabled");
    fieldNames.push("Intent");
    fieldNames.push("Status");

 
    fieldValues.push(e.model.PromotionNumber);
    fieldValues.push(e.model.PromotionDescription);
    fieldValues.push(e.model.Language);
    fieldValues.push(e.model.DirectTransferEnabled);
    fieldValues.push(e.model.Intent);
    fieldValues.push(e.model.Status);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    if (CheckForDupplicate(e, this.dataSource.data()) == true) {
        if ($("#PromotionNameWavFile").val().indexOf(".wav") > 0) {
            e.model.PromotionNameWavFile = $("#PromotionNameWavFile").val();
            $(".k-upload-selected").trigger("click");
        }
        else {
            toaster("Please upload only wav file!", "error");
            e.preventDefault();
            return;
        }
        if ($("#PromotionDetailsWavFile").val().indexOf(".wav") > 0) {
            e.model.PromotionDetailsWavFile = $("#PromotionDetailsWavFile").val();
            $(".k-upload-selected").trigger("click");
        }
        else {
            toaster("Please upload only wav file!", "error");
            e.preventDefault();
            return;
        }
        //duplicateValidate(e, "PromotionNumber", "PromotionNumber");
        modifyValid(e);
        $(".k-upload-selected").trigger("click");
    }
}

function onGridEditRow(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#Language").data("kendoDropDownList").readonly();
        var numerictextbox = $("#PromotionNumber").data("kendoNumericTextBox");
        numerictextbox.enable(false);
        $("#languageLbl").html("Language");
        $("#functionalityLbl").html("Promotion Number");
        $("#ModifyReasonGroup").show();
        $("#PromotionNameWavFileTag").css("visibility", "visible");
        $("#PromotionNameWavFileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.PromotionNameWavFile + '">' + e.model.PromotionNameWavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#PromotionDetailsWavFileTag").css("visibility", "visible");
        $("#PromotionDetailsWavFileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.PromotionDetailsWavFile + '">' + e.model.PromotionDetailsWavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#waveFile").html(e.model.WaveFile);
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
        $("#PromotionNameWavFileTag").css("visibility", "hidden");
        $("#PromotionDetailsWavFileTag").css("visibility", "hidden");
    }
}

function attachClickHandlerforPromotionName(e) {
    console.log(e.files[0].name);

    var wrapper = this.wrapper;
    var validExt = "wav";
    readFileAfterDelegate = setPromotionNameValues;
    readFile(e, wrapper, validExt);
}

function attachClickHandlerforPromotionDetails(e) {
    console.log(e.files[0].name);

    var wrapper = this.wrapper;
    var validExt = "wav";
    readFileAfterDelegate = setPromotionDetailsValues;
    readFile(e, wrapper, validExt);
}

function setPromotionNameValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validationforPromotionName']").html("");
        $("#PromotionNameWavFile").val(fileInfo.name);
    }
}


function setPromotionDetailsValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validationforPromotionDetails']").html("");
        $("#PromotionDetailsWavFile").val(fileInfo.name);
    }
}

function CheckForDupplicate(e, obj) {
    //e.model.EndDateTime = $('#EndDateTime').val();
    //e.model.StartDateTime = $('#StartDateTime').val();
    var currentPromotionNumber = e.model.PromotionNumber;
    var currentLanguage = e.model.Language;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].PromotionNumber === currentPromotionNumber && obj[t].Language === currentLanguage) {
            count++;
            if (count === 2) {
                return false;
            }
        }
    }
    return true;
}