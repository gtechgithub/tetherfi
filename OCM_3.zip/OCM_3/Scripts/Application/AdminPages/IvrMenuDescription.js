﻿function editMenuDesc(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="MenuId"]').attr("readonly", true);
        $("#menuLbl").html("Menu Id");
    }
}

function saveMenuDesc(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("MenuId");
    fieldNames.push("MenuName");
    fieldNames.push("Intent");

    fieldValues.push(e.model.MenuId);
    fieldValues.push(e.model.MenuName);
    fieldValues.push(e.model.Intent);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    if (e.model.isNew() == true) {
        duplicateValidate(e, "MenuId", "MenuId");
    }    
    modifyValid(e);
}