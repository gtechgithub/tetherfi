﻿function onChatServerSelect(e) {
    $("#testwin").data("kendoWindow").close();
    if (e.dataItem.Value != "" && e.dataItem.Value != null) {
        if (sessionStorage.getItem(e.dataItem.Value) != -1 && sessionStorage.getItem(e.dataItem.Value) != null) {
            $("#defaultMessage").css('display', 'none');
            $("#credentialMessage").css('display', 'none');
            $("#tGrid").css('display', '');
            $("#chatServerIp").val(sessionStorage.getItem(e.dataItem.Value));
            $("#grid").data("kendoGrid").dataSource.read();
            $("#chatConfigurationSearch").css('display', '');
            $("#chatConfigurationClearSearch").css('display', '');
        }
        else {
            $("#defaultMessage").css('display', 'none');
            $("#credentialMessage").css('display', '');
            $("#tGrid").css('display', 'none');
            $("#openWindowButton").kendoButton();
            if ($("#previouslySelectedServer").val().trim() == "") {
                $("#previouslySelectedServer").val(e.dataItem.Text);
            }
            else
                $("#previouslySelectedServer").val(e.dataItem.Text);

            $("#chatServerIp").val(e.dataItem.Value);
            //$("#testwin").data("kendoWindow").open().center();
            $("#primaryTextButton").kendoButton();
            $("#textButton").kendoButton();
        }


    }
    else {
        $("#tGrid").css('display', 'none');
        $("#credentialMessage").css('display', 'none');
        $("#defaultMessage").css('display', '');
        $("#chatConfigurationSearch").css('display', 'none');
        $("#chatConfigurationClearSearch").css('display', 'none');
        $("#testwin").data("kendoWindow").close();
    }
}

function onServerCredentialInput() {
    if ($("#serverUsername").val().trim() == "") {
        toaster("Enter Server Username", "error");
        return;
    }
    if ($("#serverPassword").val().trim() == "") {
        toaster("Enter Server Password", "error");
        return;
    }
    $.ajax({
        url: window.ApplicationPath + 'ChatConfigurations/ValidateServerCredentials',
        type: 'POST',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { "serverIp": $("#chatServerIp").val(), "serverUserName": $("#serverUsername").val(), "serverPassword": $("#serverPassword").val() },
        datatype: 'json',
        success: function (result) {
            if (result.toLowerCase() == "ok") {
                sessionStorage.setItem($("#chatServerIp").val(), $("#chatServerIp").val() + "," + $("#serverUsername").val() + "," + $("#serverPassword").val());
                $("#testwin").data("kendoWindow").close();
                $("#chatServerIp").val($("#chatServerIp").val() + "," + $("#serverUsername").val() + "," + $("#serverPassword").val());
                toaster("Authentication Successful", "success");
                $("#credentialMessage").css('display', 'none');
                $("#tGrid").css('display', '');
                $("#grid").data("kendoGrid").dataSource.read();
                $("#defaultMessage").css('display', 'none');
                $("#chatConfigurationSearch").css('display', '');
                $("#chatConfigurationClearSearch").css('display', '');
            }
            else {
                toaster("Response from Server: " + result, "error");
            }
        },
        error: function (result) {
            console.log(result);
        }
    });
}

function chatServerInfo() {
    return {
        serverIp: $("#chatServerIp").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    }
}

function onOpenWindowClick() {
    $("#testwin").data("kendoWindow").open().center();
}

function onClearCredentials() {
    $('#serverUsername').val('');
    $('#serverPassword').val('');
}

function onChatConfigurationsSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Chat Configuration Value");

    fieldValues.push(e.model.ChatValue);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    modifyValid(e);
}