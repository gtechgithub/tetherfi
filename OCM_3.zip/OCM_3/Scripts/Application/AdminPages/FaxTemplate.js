﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "FaxTemplate.js",
       Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Added different preview function for maker/checker and passed ismakerchecker value AutoACK upload method.Module hierarchy applied "
    });
});

var fileNames = "";

//This function will be called when clicked on Edit
function onFaxTemplateEdit(e) {

    genericEdit(e);
    bindingOrgUnit(e);
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="TemplateName"]').attr("readonly", true);
        $("#TemplateType").data("kendoDropDownList").readonly();
        if (e.model.TemplateType != 0) {
            $("#editorblock").show();
            $("#uploadblock").hide();
            var content = bindTemplate(e.model)
            $("#editor").data("kendoEditor").value(content);
        }
        else {
            $("#editorblock").hide();
            $("#uploadblock").show();
            $("#iconFiles").val(e.model.FileName);
            $("#iconFiles").css("visibility", "visible");
            $("#iconFiles").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">png/html</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.FileName + '">' + e.model.FileName + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        }
    }
    else {
        $("#editorblock").show();
        $("#uploadblock").hide();
    }
}

//this function will be called when icon or html is uploaded
function onPdfFileUpload(e) {
    
    e.files[0].name = $("#iconFiles").val();
    e.files[0].rawFile.name = $("#iconFiles").val();
    e.data = {
        filename: $("#iconFiles").val(), isMakerChecker: $("#isMakerChecker").val() };     
}

var fileUpload = "";
function attachClickHandler(e) { 
    readFile(e, this.wrapper, "pdf", $("#iconFiles"));
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validationforPdfFile']").html("");
        control.val(fileInfo.name);
    }
}

function onPdfRemove(e) {
    //$("#iconFiles").val("");
}


//This function will be called when clicked on save
function onFaxTemplateSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Template Name");
    fieldNames.push("Template Type");
  
    fieldValues.push(e.model.TemplateName);
    fieldValues.push(e.model.TemplateType);
  
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }

    duplicateValidate(e, "TemplateName", "Template Name")

    if (e.model.TemplateType != 0) {
       
        var editor = $("#editor").data("kendoEditor");
        if (editor.value() == "") {
            toaster("Please fill the content", "error");
            e.preventDefault();
            return false;
        }
        else {
            e.model.Content = editor.value();
            e.model.FileName = e.model.TemplateName + ' ' + $("#TemplateType").data("kendoDropDownList").text()  + '.html';
        }
    }
    else {
        if ($("#iconFiles").val().indexOf(".pdf") > 0) {
            e.model.FileName = e.model.TemplateName + ' ' + $("#TemplateType").data("kendoDropDownList").text()  + '.pdf';
            $("#iconFiles").val(e.model.TemplateName + ' ' + $("#TemplateType").data("kendoDropDownList").text() + '.pdf');
            $(".k-upload-selected").trigger("click");
        }
        else {
            toaster("Please fill the content", "error");
            e.preventDefault();
            return;
        }
    }
    validateOrgUnit(e);
    modifyValid(e);
}

function bindTemplate(e) {
    try {
        var faxedit = $("#tGrid");
        kendo.ui.progress(faxedit, true);
        var res;
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FaxTemplate/BindTemplate',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "templateName": e.TemplateName, "fileName": e.FileName },
            dataType: "json",
            async: false,
            success: function (returneddata) {
                res = returneddata.html;
            },
            error: function (msg) {
                console.log(msg);
                return "";
            },
        })
        kendo.ui.progress(faxedit, false);
        return res;
    } catch (e) {
        return "";
    }
}

//this function will be called when clicked on preview
function previewTemplate(e) {
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var validation = true;
    if (data.TemplateName == "" && data.TemplateName == null) {
        toaster("There is no file to preview", "info");
        e.preventDefault();
        validation = false;
    }
    else {
        toaster("Please wait until previewing", "info");
    }
    if (validation) {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FaxTemplate/PreviewTemplate',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "templateName": data.TemplateName, "fileName": data.FileName, "templateType": data.TemplateType, "folderName": "FaxTemplateMaker" },
            dataType: "json",
            success: function (returneddata) {
                console.log(returneddata)

                if (returneddata.length > 0) {
                        var div = "";
                        //div += "<div id='pdf'><iframe src='" + returneddata + data.FileName + "' width='100%' height='500'></iframe></div>";
                        div += "<embed src='" + returneddata + data.FileName + "' width='100%' height='500' alt='pdf'>";
                        //div += "<object data='" + returneddata + data.FileName + "' type='application/ pdf'> <embed src='" + returneddata + data.FileName + "' width='100%' height='500' type='application/ pdf'> </object>";
                        $("#tifPreview").html("");
                        $("#tifPreview").append(div);
                        $('#popupPreview').modal('show');
                }
                else {
                    toaster("There is some error in previewing the template", "error");
                }
            },
            error: function (msg) {
                console.log(msg);
                toaster(msg.d, "error");
            },
        })
    }
}

//this function will be called when clicked on preview from checker db
function previewCheckerTemplate(e) {
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var validation = true;
    if (data.TemplateName == "" && data.TemplateName == null) {
        toaster("There is no file to preview", "info");
        e.preventDefault();
        validation = false;
    }
    else {
        toaster("Please wait until previewing", "info");
    }
    if (validation) {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FaxTemplate/PreviewTemplate',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "templateName": data.TemplateName, "fileName": data.FileName, "templateType": data.TemplateType,"folderName":"FaxTemplate" },
            dataType: "json",
            success: function (returneddata) {
                console.log(returneddata)

                if (returneddata.length > 0) {
                    var div = "";
                    //div += "<div id='pdf'><iframe src='" + returneddata + data.FileName + "' width='100%' height='500'></iframe></div>";
                    div += "<embed src='" + returneddata + data.FileName + "' width='100%' height='500' alt='pdf'>";
                    //div += "<object data='" + returneddata + data.FileName + "' type='application/ pdf'> <embed src='" + returneddata + data.FileName + "' width='100%' height='500' type='application/ pdf'> </object>";
                    $("#tifPreview").html("");
                    $("#tifPreview").append(div);
                    $('#popupPreview').modal('show');
                }
                else {
                    toaster("There is some error in previewing the template", "error");
                }
            },
            error: function (msg) {
                console.log(msg);
                toaster(msg.d, "error");
            },
        })
    }
}

function onChangeTemplateType(e) {
    if ($("#TemplateType").data("kendoDropDownList").value() == 0) {
        $("#editorblock").hide();
        $("#uploadblock").show();
    }
    else {
        $("#uploadblock").hide();
        $("#editorblock").show();
    }
}


var insertImage = kendo.ui.editor.ImageCommand.fn.insertImage;
kendo.ui.editor.ImageCommand.fn.insertImage = function (img, range) {
    var imgsrc = this;
    toDataURL(imgsrc.attributes.src, function (dataUrl) {
        imgsrc.attributes.src = dataUrl;
        insertImage.call(imgsrc, img, range);
    })
    return true;
}

function onImportSelect(e) {
    var file = e.files[0];
    var errors = file.validationErrors;
    if (errors) {
        var localization = e.sender.options.localization;
        for (var i = 0; i < errors.length; i++) {
            toaster(localization[errors[i]], "error");
        }
    }
}

function onImportError(e) {
    toaster("The Document Processing Library fails to convert the input file stream to html", "info");
}

function toDataURL(url, callback) {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onload = function () {
        var fileReader = new FileReader();
        fileReader.onloadend = function () {
            callback(fileReader.result);
        }
        fileReader.readAsDataURL(httpRequest.response);
    };
    httpRequest.open('GET', url);
    httpRequest.responseType = 'blob';
    httpRequest.send();
}