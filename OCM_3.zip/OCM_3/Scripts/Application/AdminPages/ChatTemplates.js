﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "ChatTemplates.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 08:30:00 PM",
        LastModifiedBy: "Prathik,Shruthi",
        Description: "Added Channel and implemented module hierarchy"
    });
});

function onDepartmentSave(e) {
    var fieldNames = new Array();

    var fieldValues = new Array();

    fieldNames.push("Name");
    fieldNames.push("Enabled");
    fieldNames.push("Channel");

    fieldValues.push(e.model.Name);
    fieldValues.push($("#Enabled").val());
    fieldValues.push(e.model.Channel);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "Name", "Name")
    validateOrgUnit(e);
    modifyValid(e);
}

function onDepartmentEdit(e) {
    if (e.model.isNew() == false) {
        // $(e.container).find('input[name="Name"]').attr("readonly", true);
    }
    genericEdit(e);
    bindingOrgUnit(e);
}

function onGroupSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    e.model.DepartmentName = $("#DepartmentName").data("kendoDropDownList").text();
    e.model.DepartmentID = $("#DepartmentName").data("kendoDropDownList").value();

    fieldNames.push("Department Name");
    fieldNames.push("Name");
    fieldNames.push("Enabled");

    fieldValues.push(e.model.DepartmentName);
    fieldValues.push(e.model.Name);
    fieldValues.push($("#Enabled").val());

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "Name", "Name")
    modifyValid(e);
}

function onGroupEdit(e) {
    if (e.model.isNew() == false) {
        $("#DepartmentName").data("kendoDropDownList").text(e.model.DepartmentName);
        $("#DepartmentName").data("kendoDropDownList").value(e.model.DepartmentID);
        //$("#DepartmentName").data("kendoDropDownList").readonly();
        // $(e.container).find('input[name="Name"]').attr("readonly", true);
    }
    genericEdit(e);
    
}

function filtergroup() {
    return {
        id: $("#DepartmentName").data("kendoDropDownList").value(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function onChatTemplatesEdit(e) {
    if (e.model.isNew() == false) {
        $("#DepartmentName").data("kendoDropDownList").text(e.model.DepartmentName);
        $("#DepartmentName").data("kendoDropDownList").value(e.model.DepartmentId);
        $("#GroupName").data("kendoDropDownList").text(e.model.GroupName);
        $("#GroupName").data("kendoDropDownList").value(e.model.GroupId);
        // $("#DepartmentName").data("kendoDropDownList").readonly();
        //$("#GroupName").data("kendoDropDownList").readonly();
    }
    genericEdit(e);
}

function CheckForDupplicate(e, obj) {
    var departmentName = e.model.DepartmentName;
    var groupName = e.model.GroupName;
    var name = e.model.Name;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].DepartmentName === departmentName && obj[t].GroupName === groupName && obj[t].Name === name) {
            count++;
            if (count === 2) {
                return false;
            }
        }
    }
    return true;
}

function onChatTemplatesSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;
    var isStartTime = false;
    var isEndTime = false;
    
    e.model.DepartmentName = $("#DepartmentName").data("kendoDropDownList").text();
    e.model.GroupName = $("#GroupName").data("kendoDropDownList").text();

    e.model.DepartmentId = $("#DepartmentName").data("kendoDropDownList").value();
    e.model.GroupId = $("#GroupName").data("kendoDropDownList").value();

    for (i = 0; i < field.length; i++) {
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
            if (field[i].PropertyName == "StartTime") {
                isStartTime = true;
            }
            if (field[i].PropertyName == "EndTime") {
                isEndTime = true;
            }
        }
    }
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    if (isStartTime == true && isEndTime == true) {
        var startTime = $("#StartTime").data("kendoTimePicker");
        var endTime = $("#EndTime").data("kendoTimePicker");

        if (startTime._old == null && startTime._oldText != "") {
            toaster("Enter a Valid Start Time", "error");
            e.preventDefault();
            return;
        }

        if (endTime._old == null && endTime._oldText != "") {
            toaster("Enter a Valid End Time", "error");
            e.preventDefault();
            return;
        }

        e.model.StartTime = kendo.toString(startTime.value(), "HH:mm:ss");
        e.model.EndTime = kendo.toString(endTime.value(), "HH:mm:ss");

        if (e.model.StartTime == null || e.model.StartTime == "") {
            toaster("Enter a Start Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.EndTime == null || e.model.EndTime == "") {
            toaster("Enter a End Time", "error");
            e.preventDefault();
            return;
        }
        var time1 = moment(e.model.StartTime, 'HH:mm:ss');
        var time2 = moment(e.model.EndTime, 'HH:mm:ss');
        if (time1.isAfter(time2)) {
            toaster("Start Time is greater than End Time", "error");
            e.preventDefault();
            return;
        }
        if (time1.isSame(time2)) {
            toaster("Start Time is same as End Time", "error");
            e.preventDefault();
            return;
        }
    }

    if (CheckForDupplicate(e, this.dataSource.data()) === false) {
        toaster("Duplicate record. Department Name, Group Name,Name combination should be unique.", "error");
        e.preventDefault();
        return;
    }


    modifyValid(e);
}
function channelID() {
    return {
        channel: $("#Channel").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}