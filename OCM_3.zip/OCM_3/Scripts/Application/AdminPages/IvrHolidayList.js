﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrHolidayList.js",
        Version: "3.2.5.31",
        LastModifiedDateTime: "31-05-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Validation for Start Date,Start Time, End Date and End Time"
    });
});


var editfieldNames = new Array();
var editfieldValues = new Array();

function onAnnouncedHolidayFilter(e) {
    var value = this.value(),
    grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({});
        grid.dataSource.filter({ field: "AnnouncedHoliday", operator: "eq", value: value });
    }
    else {
        grid.dataSource.filter({});
    }
}

function onIvrHolidayListEdit(e) {
    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }

    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $("#StartDate").data("kendoDatePicker").readonly();
        $("#EndDate").data("kendoDatePicker").readonly();
        $("#StartDate").data("kendoDatePicker").enable(false);
        $("#EndDate").data("kendoDatePicker").enable(false);

        if ($("#StartTime").data("kendoTimePicker") != undefined) {
            $("#StartTime").data("kendoTimePicker").readonly();
            $("#StartTime").data("kendoTimePicker").enable(false);
        }
        if ($("#EndTime").data("kendoTimePicker") != undefined) {
            $("#EndTime").data("kendoTimePicker").readonly();
            $("#EndTime").data("kendoTimePicker").enable(false);
        }
        if ($("#VDN").data("kendoNumericTextBox") != undefined) {
            $("#VDN").data("kendoNumericTextBox").readonly();
            $("#VDN").data("kendoNumericTextBox").enable(false);
        }
    }
        
        $("#enddateLbl").html("End Date");
        $("#startdateLbl").html("Start Date");
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }
 }


function onIvrHolidayListSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    if ($("#StartTime").data("kendoTimePicker") != undefined) {
        e.model.StartTime = $("#StartTime").val();
    }
    if ($("#EndTime").data("kendoTimePicker") != undefined) {
        e.model.EndTime = $("#EndTime").val();
    }
    if ($("#StartDate").data("kendoDatePicker") != undefined) {
        e.model.StartDate = $("#StartDate").val();
    }
    if ($("#EndDate").data("kendoDatePicker") != undefined) {
        e.model.EndDate = $("#EndDate").val();
    }

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].s == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }
    if ($("#VDN").data("kendoNumericTextBox") != undefined) {
        if ($("#VDN").val() == 0) {
            toaster("Enter a VDN greater than 0", "error");
            e.preventDefault();
            return;
        }
        if ($("#VDN").val().toString().length < 4) {
            e.preventDefault();
            toaster("VDN Length is less than 4", "error");
            return;
        }
    }
    if (e.model.AnnouncedHoliday == "" || e.model.AnnouncedHoliday == null) {
        toaster("Enter an Announced Holiday", "error");
        e.preventDefault();
        return;
    }

    var startdatepicker = $("#StartDate").val();
    var enddatepicker = $("#EndDate").val();
    if (startdatepicker == "" || startdatepicker == null) {
        toaster("Enter Valid Start Date", "error");
        e.preventDefault();
        return;
    }
    if (enddatepicker == "" || enddatepicker == null) {
        toaster("Enter Valid End Date", "error");
        e.preventDefault();
        return;
    }
    e.model.StartDate = $("#StartDate").val();
    e.model.EndDate = $("#EndDate").val();
    var tempstartdate = moment(e.model.StartDate, 'DD-MM-YYYY');
    var tempenddate = moment(e.model.EndDate, 'DD-MM-YYYY');
    
    if (moment(tempstartdate, "DD/MM/YYYY", true).isValid() == false) {

        e.preventDefault()
        toaster("Start Date is not in proper format", "error");
        return;

    }
    if (moment(tempenddate, "DD/MM/YYYY", true).isValid() == false)
    {
        e.preventDefault()
        toaster("End Date is not in proper format", "error");
        return;
    }
    if (moment(tempstartdate).isAfter(tempenddate)) {
        toaster("Start Date is greater than End Date", "error");
        e.preventDefault();
        return;
    }

    if (moment(e.model.StartDate, "DD/MM/YYYY").isBefore(moment(getPresentDate().trim(), "DD/MM/YYYY"))) {
        toaster("Start Date is less than Current Date", "error");
        e.preventDefault();
        return;
    }
    
    if (moment(e.model.EndDate, "DD/MM/YYYY").isBefore(moment(getPresentDate().trim(), "DD/MM/YYYY"))) {
        toaster("End Date is less than Current Date", "error");
        e.preventDefault();
        return;
    }
    
    validPeriod(e, "StartDate", "EndDate", "VDN");
    

    if ($("#StartTime").data("kendoTimePicker") != undefined)
    {
        var startTime = $("#StartTime").data("kendoTimePicker");
        var endTime = $("#EndTime").data("kendoTimePicker");

        if (startTime._old == null && startTime._oldText != "") {
            toaster("Enter a Valid Start Time", "error");
            e.preventDefault();
            return;
        }

        if (endTime._old == null && endTime._oldText != "") {
            toaster("Enter a Valid End Time", "error");
            e.preventDefault();
            return;
        }

        e.model.StartTime = kendo.toString(startTime.value(), "HH:mm:ss");
        e.model.EndTime = kendo.toString(endTime.value(), "HH:mm:ss");

        if (e.model.StartTime == null || e.model.StartTime == "") {
            toaster("Enter a Start Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.EndTime == null || e.model.EndTime == "") {
            toaster("Enter a End Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.StartDate == e.model.EndDate) {
            var time1 = moment(e.model.StartTime, 'HH:mm:ss');
            var time2 = moment(e.model.EndTime, 'HH:mm:ss');
            if (time1.isAfter(time2)) {
                toaster("Start Time is greater than End Time", "error");
                e.preventDefault();
                return;
            }
            if (time1.isSame(time2)) {
                toaster("Start DateTime is same as End DateTime", "error");
                e.preventDefault();
                return;
            }
        }
    }
    
    modifyValid(e)
}
function validPeriod(e, start, end,vdn) {
    var vdnname = null;
    var startdate = e.model[start];
    var enddate = e.model[end];
    if ($("#VDN").data("kendoNumericTextBox") != undefined) {
        vdnname = e.model[vdn];
    }
    var currentID = e.model.uid;
    var count = 0;
    var id = e.sender.element[0].id;
    var data = $('#' + id).data('kendoGrid').dataSource._data;
    item = data.length;
    for (t in data) {
        var valid = true;
        if ($("#VDN").data("kendoNumericTextBox") != undefined) {
            if (((data[t][start] <= startdate && data[t][end] >= startdate) ||
                (data[t][start] <= enddate && data[t][end] >= enddate)) &&
                data[t].uid != currentID && data[t][vdn] == vdnname) {
                valid = false;
            }
        }
        else
        {
            if (((data[t][start] <= startdate && data[t][end] >= startdate) ||
                (data[t][start] <= enddate && data[t][end] >= enddate)) &&
                data[t].uid != currentID) {
                valid = false;
            }
        }

        if (valid == false) {
            e.preventDefault();
            toaster("Record already exists between date range " + startdate + " & " + enddate , "error");
            return;
        }
    }
    return;
}

//function used to retrieve the current date
function getPresentDate() {
    var d = new Date();
    var month = d.getMonth() + 1;
    var day = d.getDate();

    var output = (('' + day).length < 2 ? '0' : '') + day + '/' + (('' + month).length < 2 ? '0' : '') + month + '/' + d.getFullYear();
    return output;
}