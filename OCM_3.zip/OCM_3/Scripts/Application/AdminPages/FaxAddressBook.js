﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "FaxAddressBook.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Module hierarchy applied"
    });
});

function onAddressBookSave(e) {
    var FaxLine = $("#FaxLine").val();
    var Name = $("#Name").val();
    var Recipient = $("#RecipientIds").data("kendoMultiSelect").value();

    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("FaxLine", "Name", "Recipient");
    fieldValues.push(FaxLine.trim(), Name.trim(), Recipient);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) !== "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "Name", "Name")
   

    var multi = $("#RecipientIds").getKendoMultiSelect(),
        multiDataItems = multi.dataItems(),
        selectedRecipient = new Array();

    for (var i = 0; i < multiDataItems.length; i += 1) {
        var currentProduct = multiDataItems[i];
        selectedRecipient.push(currentProduct.Text)
    }

    e.model.Recipients = selectedRecipient.toString();
    validateOrgUnit(e);
    modifyValid(e);
}

function onAddressBookEdit(e) {
    if (e.model.isNew() !== true) {
        $("#RecipientIds").getKendoMultiSelect().value(e.model.RecipientIds.split(','));
    }
    genericEdit(e);
    bindingOrgUnit(e);
}

function onRecipientEdit(e) {
    genericEdit(e);
    bindingOrgUnit(e);
}

function onRecipientSave(e) {
    var Name1 = $("#Name1").val().trim();
    var FaxNumber = $("#FaxNumber").val().trim();

    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Name 1", "Fax Number");
    fieldValues.push(Name1, FaxNumber);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) !== "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    
    //duplicateValidate(e, "FaxNumber", "FaxNumber")
    validateOrgUnit(e);
    modifyValid(e);
}






