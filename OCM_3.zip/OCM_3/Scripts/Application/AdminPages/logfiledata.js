﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "logfiledata.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Added versioning"
    });
});
function onLogFileTabStripSelect(e) {
    var mystring = e.contentElement.id;
    mystring = mystring.replace('t', '');
    $("#dynamicSearchParam").val(mystring);
    $('#' + $("#dynamicSearchParam").val()).data('kendoGrid').dataSource.read();

    if (mystring == "drillGrid") {
        $("#reload").attr("onclick", "ReloadGrid('drillGrid')");
    }
    else
        $("#reload").attr("onclick", "ReloadMainGrid()");
}

//Function to pass parameters to Grid's Datasource Request
function onGridReadParameters() {
    return {
        modname: $("#moduleName").val(),
        Agt: $("#folderName").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

//on click of the checkbox:
function selectRow() {
    var checked = this.checked;
    var row = $(this).closest("tr");
    var grid = $("#grid").data("kendoGrid");
    var dataItem = grid.dataItem(row);
    checkedIds[dataItem.uid] = checked; //Mark uid of that particular row as checked
}

function onLogModuleChange(e) {
    //After selecting a value from the Module dropdownlist this function is triggered
    var modname = (this.dataItem(e.item)).Value;
    $("#moduleName").val(modname);
    $("#Folder").data("kendoDropDownList").dataSource.data([]); //setting datasource of Folder Dropdownlist as blank
    if (modname != "Select") {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'LogfileData/Getagent',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "modname": modname },
            dataType: "json",
            success: function (data) {
                if (data.length == 0) {
                    $("#folderLabel").css("display", "none");
                    $("#folderDiv").css("display", "none");
                }
                else {
                    $("#folderLabel").css("display", "inline-block");
                    $("#folderDiv").css("display", "inline-block");
                    $("#Folder").data("kendoDropDownList").dataSource.data([]);
                    $.each(data, function (id, opt) {
                        var optindex = opt.lastIndexOf("\\");
                        var optval = opt.substring(optindex + 1, opt.length);
                        $("#Folder").data("kendoDropDownList").dataSource.add({ "Text": optval, "Value": optval });//Insert data in Folder dropdownlist
                    });
                    $("#Folder").data("kendoDropDownList").value("Select"); //Show Select as initial value in folder dropdownlist
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert('Failed to retrieve module.');
            }
        });
        $("#folderName").val("Select");
        loadModuleFiles(); //Function is called to load data(files) in the main grid
    }
    else {  //If select is selected in module dropdownlist then we hide folder dropdownlist and set grid datasource as default
        $("#moduleName").val(modname);
        $("#folderLabel").css("display", "none");
        $("#folderDiv").css("display", "none");
        $("#grid").data("kendoGrid").dataSource.read();
        //$("#grid").data("kendoGrid").dataSource.data([]);
    }
}

//Call Datasource event of grid
function loadModuleFiles(modname) {
    $("#grid").data("kendoGrid").dataSource.read();
}

function onLogFolderChange() {
    
    //Function used to reload the grid if a value is selected in the Folder dropdownlist
    var folderName = $("#Folder").data("kendoDropDownList").value();
    $("#folderName").val(folderName)
    if (folderName != "Select") {
        modname = folderName;
        loadModuleFiles(modname);
    }
}
function onLogDataGridDataBound(e) { //Hide Fetch Files button if there is no data in the grid
    if (e.sender.dataSource.total() > 0) {
        $("#fetchFiles").css('display', 'inline-block')
    }
    else {
        $("#fetchFiles").css('display', 'none')
    }
}

function saveLogFiles() {
    //Function used after fetch files button is clicked
    var checked = [];
    for (var i in checkedIds) {
        if (checkedIds[i]) {
            checked.push(i); //push uids if they are checked
        }
    }
    var grid = $("#grid").data("kendoGrid").dataSource.view();
    var files = "";
    var fileCount = 0;
    $("#grid").find("tbody input:input:checked").each(function () {
        //get a count of all checkboxes that are checked
        fileCount++;
    });
    var tempFileCount = fileCount; //store count temporarily
    for (var i = 0; i < grid.length; i++) {
        //For each row in the grid we are checking if the uid is checked
        if (checkedIds[grid[i].uid]) {
            //if the uid is checked then the filename of that particular uid is added
            files += grid[i].FileName;

            if (fileCount != 1) {
                //used to seperate the names in the variable using a comma
                files += ",";
                fileCount--;
            }
        }
    }
    if (files == "") {
        toaster("Please select a file to be fetched", "error");
        return false;
    }
    console.log("Fetched Files are: " + files);
    //After getting the files send it to the controller method for processing
    var moduleName = $("#Module").data("kendoDropDownList").value();
    var folderName = $("#Folder").data("kendoDropDownList").value();
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'LogfileData/FetchFiles',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { "moduleName": moduleName, "folderName": folderName, "files": files },
        dataType: "json",
        cache: false,
        success: function (data) {
            toaster("Please wait while logs are being fetched", "info")
            $("#drillGrid").data("kendoGrid").dataSource.read();
            $('#drillGrid').data('kendoGrid').refresh();
            //$("#grid").data("kendoGrid").dataSource.data([]);
            $("#Module").data("kendoDropDownList").dataSource.data([]);
            $("#Module").data("kendoDropDownList").dataSource.read();
            $("#Module").data("kendoDropDownList").select(0);
            $("#moduleName").val("");
            $("#grid").data("kendoGrid").dataSource.data([]);
            $("#grid").data("kendoGrid").dataSource.read();
            $("#folderLabel").css("display", "none");
            $("#folderDiv").css("display", "none");
        },
        error: function (data) {
            console.log(data);
            toaster("Internal Error Occurred", "error");
            $("#drillGrid").data("kendoGrid").dataSource.read();
            $('#drillGrid').data('kendoGrid').refresh();
            //$("#grid").data("kendoGrid").dataSource.read();
            //$("#grid").data("kendoGrid").dataSource.data([]);
            $("#grid").data("kendoGrid").dataSource.data([]);
            $("#Module").data("kendoDropDownList").dataSource.read();
            $("#moduleName").val("");
            $("#Module").data("kendoDropDownList").select(0);
            $("#grid").data("kendoGrid").dataSource.read();
            $("#folderLabel").css("display", "none");
            $("#folderDiv").css("display", "none");
        }
    });
}

//Function to hide the second dropdown and its label if there is no data in that dropdown
function onFolderDataBound(e) {

    if (e.sender.dataSource._data.length <= 1) {
        $("#folderLabel").css('display', 'none');
        $("#folderDiv").css('display', 'none');
    }
    else {
        $("#folderLabel").css('display', 'inline-block');
        $("#folderDiv").css('display', 'inline-block');
    }
}

function onLogModuleDataBound() {
    //this.select(0);
    //$("#moduleName").val("");
    //$("#grid").data("kendoGrid").dataSource.data([]);
    //$("#grid").data("kendoGrid").dataSource.read();
    //$("select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.add({ text: "50", value: "50" })
    //$("select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.add({ text: "100", value: "100" })
    //$("select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.add({ text: "200", value: "200" })
}

function downloadSavedLogFiles(e) {
    var tr = $(e.target).closest("tr"); //get the row for deletion
    var data = this.dataItem(tr);
    //Call Post Method and pass 
    post(window.ApplicationPath + 'LogfileData/DownloadReport', { "path": data.FilePath });
}

function post(path, params) {
    method = "post"; // Set method to post by default.

    // The rest of this code assumes you are not using a library.
    // It can be made less wordy if you use one.
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);

    for (var key in params) {
        if (params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);

            form.appendChild(hiddenField);
        }
    }
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", "__RequestVerificationToken");
    hiddenField.setAttribute("value", $("#AntiForgeryToken").val());
    form.appendChild(hiddenField);
    document.body.appendChild(form);
    form.submit();
}

function deleteSavedLogFiles(e) {
    //function to Delete file when selected in grid
    var tr = $(e.target).closest("tr"); //get the row for deletion
    var data = this.dataItem(tr); //get the row data so it can be referred later
    if (data.FilePath == null || data.FilePath == "") {
        toaster("Select a row and click Delete File", "error");
    }
    e.preventDefault();
    swal({
        title: "Alert",
        text: "Confirm to Delete Data",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then(function (willDelete) {
            if (willDelete) {
                $.ajax({
                    type: "POST",
                    url: window.ApplicationPath + 'LogfileData/DeleteReport',
                    headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                    data: { "fileName": data.FilePath },
                    dataType: "json",
                    cache: false,
                    success: function (data) {
                        if (data.result == true) {
                            toaster("Record Deleted Successfully", "success");
                            $("#drillGrid").data("kendoGrid").dataSource.read();
                            $('#drillGrid').data('kendoGrid').refresh();
                        }
                    },
                    error: function (data) {
                        console.log(data);
                        toaster("Internal Error Occurred", "error");
                        $("#drillGrid").data("kendoGrid").dataSource.read();
                        $('#drillGrid').data('kendoGrid').refresh();
                    }
                });
            }
        });
}