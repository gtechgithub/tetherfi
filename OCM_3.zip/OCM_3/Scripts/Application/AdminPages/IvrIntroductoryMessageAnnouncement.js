﻿$(document).ready(function () {
    /**
        * Define the Version
        * @returns {}
        */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrIntroductoryMessageAnnouncement.js",
         Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 12:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Applied Module hierarchy"
    });
});

var editfieldNames = new Array();
var editfieldValues = new Array();

function onWavFileUpload(e) {
    e.data = { functionality: $("#Functionality").val(), language: $("#Language").val(), module: $("#ControllerName").val(), expectedExt: $("#waveFile").val() }; //sends the extra parameter to controller
}

function startChange(e) {
    var endPicker = $("#EndDateTime").val();
    startDate = $("#StartDateTime").val();

    if (startDate) {
        startDate = new Date(startDate);
        startDate.setDate(startDate.getDate());
    }
}

function endChange(e) {
    var startPicker = $("#StartDateTime"),
            endDate = $("#EndDateTime").val();

    if (endDate) {
        $("#introstartdatepicker").datetimepicker({
            maxDate: moment(endDate.toString())
        });
    }
}

function onGridAddRow(e) {
    var StartDate = $("#StartDateTime").val().toString();
    var EndDate = $("#EndDateTime").val().toString();

    
    e.model.WaveFile = $("#waveFile").val();
    e.model.StartDateTime = StartDate;
    e.model.EndDateTime = EndDate;
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].s == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

    if (moment(StartDate, "DD/MM/YYYY H:mm:ss", true).isValid() == false
        || moment(EndDate, "DD/MM/YYYY H:mm:ss", true).isValid() == false) {

        e.preventDefault()
        toaster("Date Time is not in proper format", "error");
        return;

    }
    var validateStartDate = moment(StartDate, "DD/MM/YYYY H:mm:ss");
    var validateEndDate = moment(EndDate, "DD/MM/YYYY H:mm:ss");
    if (validateStartDate.isAfter(validateEndDate)) {

        e.preventDefault()
        toaster("Start Date is greater than End Date", "error");
        return;

    }

    if (CheckForDupplicate(e, this.dataSource.data()) === true) {
        if ($("#waveFile").val() !== "") {
            if ($("#waveFile").val().indexOf(".wav") > 0) {
                e.model.WaveFile = $("#waveFile").val();
                $(".k-upload-selected").trigger("click");
            }
            else {
                toaster("Please upload only wav file!", "error");
                e.preventDefault();
                return;
            }

        }
        else if (e.model.waveFileTag === "" || e.model.WaveFile === "") {
            toaster("Please upload a wav file!", "error");
            e.preventDefault();
            return;
        }
        if (e.model.waveFileTag !== "" && e.model.ModifyReason === null) {
            toaster("Please provide modify reason!", "error");
            e.preventDefault();
            return;
        }
    }
    else {
        toaster("Duplicate Record", "error");
        e.preventDefault();
    }
    validateOrgUnit(e);
    modifyValid(e);
}

function CheckForDupplicate(e, obj) {
    e.model.EndDateTime = $('#EndDateTime').val();
    e.model.StartDateTime = $('#StartDateTime').val();
    var currentFunctionality = e.model.Functionality;
    var currentLanguage = e.model.Language;
    var currentHotline = e.model.Hotline;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].Functionality === currentFunctionality && obj[t].Language === currentLanguage && obj[t].Hotline === currentHotline) {
            count++;
            if (count === 2) {
                return false;
            }
        }
    }
    return true;
}

function onGridEditRow(e) {
    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }
    $('#introstartdatepicker').datetimepicker({
        useCurrent: 'day',
        minDate: moment(),
        sideBySide: false,
        format: 'DD/MM/YYYY HH:mm:ss'
    });

    $('#introenddatepicker').datetimepicker({
        useCurrent: 'day',
        sideBySide: false,
        minDate: moment(),
        format: 'DD/MM/YYYY HH:mm:ss'
    });

    $('#introstartdatepicker').on('dp.change', function (e) { startChange(e); });
    $('#introenddatepicker').on('dp.change', function (e) { endChange(e); });
    $("#StartDateTime").val(e.model.StartDateTime);
    $("#EndDateTime").val(e.model.EndDateTime);
   
    if (e.model.isNew() == false) {
        $("#IntroWavefileTag").css("visibility", "visible");
        $("#IntroWavefileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.WaveFile + '">' + e.model.WaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Functionality").data("kendoDropDownList").readonly();
        $("#Language").data("kendoDropDownList").readonly();

        
        if ($(e.container).find('input[name="Hotline"]').length >= 1) {
            $(e.container).find('input[name="Hotline"]').attr("readonly", true);
        }
       
        $("#waveFile").css("visibility", "visible");
        $("#waveFile").html(e.model.WaveFile);
        $("#waveFile").val(e.model.WaveFile);
        $("#ModifyReasonGroup").show();
       
    }
    if (e.model.isNew() == true) {
        $("#waveFile").css("visibility", "hidden");
        $("#IntroWavefileTag").css("visibility", "hidden");
        $("#ModifyReasonGroup").hide();
    }
    bindingOrgUnit(e);
}

function attachClickHandler(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#waveFile"));
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validation']").html("");
        control.val(fileInfo.name);
    }
}