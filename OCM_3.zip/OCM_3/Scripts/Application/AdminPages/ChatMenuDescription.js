﻿
// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "ChatMenuDescription..js",
        Version: "12.14",
        LastModifiedDateTime: "14-12-2018 12:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Version Changed."
    });
});
function editMenuDesc(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="MenuId"]').attr("readonly", true);
        $("#menuLbl").html("Menu Id");
    }
}

function saveMenuDesc(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("MenuId");
    fieldNames.push("MenuName");
    fieldNames.push("Intent");

    fieldValues.push(e.model.MenuId);
    fieldValues.push(e.model.MenuName);
    fieldValues.push(e.model.Intent);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    if (e.model.isNew() == true) {
        duplicateValidate(e, "MenuId", "MenuId");
    }
    modifyValid(e);
}
