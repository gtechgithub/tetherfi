﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "FaxSenders.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Module hierarchy applied."
    });
});

//This function is called when clicked on Edit
function onFaxSenderEdit(e) {
    genericEdit(e);
    bindingOrgUnit(e);
    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $("#DNIS").data("kendoDropDownList").enable(false);
        $(e.container).find('input[name="DNIS"]').attr("readonly", true);
        $(e.container).find('input[name="FaxNumber"]').attr("readonly", true);
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }
}

//This function is called when clicked on Save
function onFaxSenderSave(e) {
    if (e.model.DNIS == "" || e.model.DNIS == null) {
        toaster("Please select the Fax Line", "error");
        e.preventDefault();
        return;
    }
    if ((e.model.Name.replace(/ /g, '')) == "") {
        toaster("Please enter the Name", "error");
        e.preventDefault();
        return;
    }
    if (e.model.FaxNumber == "") {
        toaster("Please enter the Fax Number", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Type == "" || e.model.Type == null) {
        toaster("Please select the Sender Type", "error");
        e.preventDefault();
        return;
    }
    validateOrgUnit(e);
    modifyValid(e);
}

function uploadFile(e) {
    $(".k-upload-selected").trigger("click");
}
function onCsvUploadSuccess(e) {
    try {
        if (e.response == "success") {
            toaster("CSV data being uploaded. Please check after a while", "success");
            e.preventDefault();
            $(".k-upload-files.k-reset").find("li").remove();
            $(".k-upload-status").remove();
            
        }
        if (e.response == "failure") {
            toaster("CSV has not been uploaded", "error");
            e.preventDefault();
            $(".k-upload-files.k-reset").find("li").remove();
            $(".k-upload-status").remove();
        }
        if (e.response == "nodata") {
            toaster("CSV either has some issues or no data to upload", "error");
            e.preventDefault();
            $(".k-upload-files.k-reset").find("li").remove();
            $(".k-upload-status").remove();
        }
        if (e.response == "Invalid") {
            toaster("Invalid Data. Please check the data in CSV!", "error");
            e.preventDefault();
            $(".k-upload-files.k-reset").find("li").remove();
            $(".k-upload-status").remove();
        }
        if (e.response == "Duplicate") {
            toaster("Success! Contained Duplicate data", "info");
            e.preventDefault();
            $(".k-upload-files.k-reset").find("li").remove();
            $(".k-upload-status").remove();
        }
        //location.reload();
        setTimeout(reload, 2000)
    } catch (e) {
        console.log(e);
    }
    //fax_showUpload();
}

function onCsvUploadSelect(e) {
    var wrapper = this.wrapper;
    var validExt = "csv";
    readFile(e, wrapper, validExt);
}

function fax_showUpload() {
    if ($("#csvupload").css("display") == "none")
        $("#csvupload").css("display", "block");
    else
        $("#csvupload").css("display", "none");
}

function reload() {
    location.reload();
}