﻿
// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "SocialMediaUserProfileMapping.js",
        Version: "3.2.7.24",
        LastModifiedDateTime: "24-07-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Applied Module hierarchy"
    });


});

var editfieldNames = new Array();
var editfieldValues = new Array();


function onGridAddRow(e) {
    e.model.Channel = $("#ChannelCode").data("kendoDropDownList").text();
    e.model.ChannelIdentifier = $("#ChannelIdentifierCode").data("kendoDropDownList").text();
    e.model.AgentName = $("#AgentID").data("kendoDropDownList").text();

    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {

        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

    
    if (CheckForDupplicate(e, this.dataSource.data()) === false) {
        toaster("Duplicate record. Customer Org Id, Channel Identifier,Customer Channel Id combination is a unique identifier", "error");
        e.preventDefault();
    }
    validateOrgUnit(e);
    modifyValid(e);
}

function CheckForDupplicate(e, obj) {
    var currentChannelIdentifierCode = e.model.ChannelIdentifierCode;
    var currentCustomerOrgId = e.model.CustomerOrgId;
    var currentCustomerChannelId = e.model.CustomerChannelId;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].ChannelIdentifierCode === currentChannelIdentifierCode && obj[t].CustomerOrgId === currentCustomerOrgId && obj[t].CustomerChannelId === currentCustomerChannelId) {
            count++;
            if (count === 2) {
                return false;
            }
        }
    }
    return true;
}

function onGridEditRow(e) {
    var editjsonfield = jsonfields.GridColumns;

    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }

    if (e.model.isNew() == false) {

        $("#ChannelCode").data("kendoDropDownList").readonly();
        $("#ChannelIdentifierCode").data("kendoDropDownList").readonly();
        $("#CustomerOrgId").attr("readonly", true);
        $("#CustomerChannelId").attr("readonly", true);
        $("#UserID").attr("readonly", true);
        $("#ModifyReasonGroup").show();
    }
    if (e.model.isNew() == true) {
       
        $("#ModifyReasonGroup").hide();
    }
    bindingOrgUnit(e);
}