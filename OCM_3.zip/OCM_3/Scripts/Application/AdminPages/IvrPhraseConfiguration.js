﻿$(document).ready(function () {
    /**
        * Define the Version
        * @returns {}
        */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrPhraseConfiguration.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Org. Unit Implemented"
    });
});

var editfieldNames = new Array();
var editfieldValues = new Array();

function onWavFileUpload(e) {
    e.data = {  functionality: $("#ControllerName").val(), language: $("#Language").val(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

function onWavFileRemove(e) {  
        $("#waveFile").val("");
}

function CheckForDupplicate(e, obj) {
   // e.model.EndDateTime = $('#EndDateTime').val();
   // e.model.StartDateTime = $('#StartDateTime').val();
    var currentFunctionality = e.model.Functionality;
    var currentLanguage = e.model.Language;
    var currentServiceID = e.model.ServiceID;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].Functionality === currentFunctionality && obj[t].Language === currentLanguage && obj[t].ServiceID === currentServiceID) {
            count++;
            if (count === 2) {
                return false;
            }
        }
    }
    return true;
}
function onGridAddRow(e) {
    e.model.WaveFile = $("#waveFile").val();
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].s == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

   // if (CheckForDupplicate(e, this.dataSource.data()) === true) {
        if ($("#waveFile").val() !== "") {
            if ($("#waveFile").val().indexOf(".wav") > 0) {
                e.model.WaveFile = $("#waveFile").val();
                $(".k-upload-selected").trigger("click");
            }
            else {
                toaster("Please upload only wav file!", "error");
                e.preventDefault();
                return;
            }
        }
        else if (e.model.waveFileTag === "" || e.model.WaveFile === "") {
            toaster("Please upload a wav file!", "error");
            e.preventDefault();
        }
        if (e.model.waveFileTag !== "" && e.model.ModifyReason === null) {
            toaster("Please provide modify reason!", "error");
            e.preventDefault();
        }
   // }
    validateOrgUnit(e);
}

function onGridEditRow(e) {
    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }

    if (e.model.isNew() == false) {
        $("#Functionality").data("kendoDropDownList").readonly();

        $("#Language").data("kendoDropDownList").readonly();
        $(e.container).find('input[name="ServiceID"]').attr("readonly", true);
        $("label[for='Functionality']").html("Functionality");
        $("label[for='Language']").html("Language");
        $("label[for='ServiceID']").html("Service ID");
        $("#ModifyReasonGroup").show();
        $("#WavefileTag").css("visibility", "visible");
        $("#WavefileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.WaveFile + '">' + e.model.WaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#waveFile").html(e.model.WaveFile);
        $("#waveFile").val(e.model.WaveFile);
        genericEdit(e);
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
        $("#WavefileTag").css("visibility", "hidden");
        genericEdit(e);
    }
    bindingOrgUnit(e);
}

function attachClickHandler(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#waveFile"));
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validation']").html("");
        control.val(fileInfo.name);
    }
}