﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "ExportScheduler.js",
          "Version": "3.2.2.28",
        LastModifiedDateTime: "27-02-2019 08:30:00 AM",
        LastModifiedBy: "Shreenitha",
        Description: "Added function to populate ReportTitle"
    });
});

function onExportSchedulerEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="Name"]').attr("readonly", true);
    }
    $("#Report").getKendoMultiSelect().value(e.model.Report.split(','));
    $("#Address").getKendoMultiSelect().value(e.model.Address.split(','));
    onFrequency($("#Frequency").val());
}

function onFrequency(Frequency) {
    var lblTime = document.getElementById('EndTimeId');
    if (Frequency == "") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (Frequency == "Daily") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (Frequency == "Weekly") {
        $("#day").css('display', '');
        $("#date").css('display', 'none');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (Frequency == "Monthly") {
        $("#day").css('display', 'none');
        $("#date").css('display', '');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (Frequency == "CustomDaily") {
        $("#startTime").css('display', 'block');
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
        lblTime.innerText = "End Time *";
    }
}

function onFrequencySelect(e) {
    var lblTime = document.getElementById('EndTimeId');
    if (e.dataItem.Value == "") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (e.dataItem.Value == "Daily") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (e.dataItem.Value == "Weekly") {
        $("#day").css('display', '');
        $("#date").css('display', 'none');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (e.dataItem.Value == "Monthly") {
        $("#day").css('display', 'none');
        $("#date").css('display', '');
        $("#startTime").css('display', 'none');
        lblTime.innerText = "Time *";
    }
    if (e.dataItem.Value == "CustomDaily") {
        $("#startTime").css('display', 'block');
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
        lblTime.innerText = "End Time *";
    }
}

function onDateSelect(e) {
    if (e.dataItem.Value == "29") {
        $.fn.modal.Constructor.prototype.enforceFocus = function () { };
        swal("Message", "The report will be scheduled on 28th of February (if it's not a leap year).\n And will be scheduled on 29th of every other month", "info");
        $('.swal-overlay').css('z-index', '10004');
        toaster("The report will be scheduled on 28th of February (if it's not a leap year).\n And will be scheduled on 29th of every other month", "info");
    }
    if (e.dataItem.Value == "30") {
        swal("Message", "The report will be scheduled on the last day of February,\n and will be scheduled on 30th of every other month", "info");
        $('.swal-overlay').css('z-index', '10004');
    }
    if (e.dataItem.Value == "31") {
        swal("Message", "The report will be scheduled on the last day of the month for months not containing 31 days", "info");
        $('.swal-overlay').css('z-index', '10004');
    }
}

function onExportSchedulerSave(e) {
    if (e.model.Name == "" || e.model.Name == null) {
        toaster("Enter a Name", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Report == "" || e.model.Report == null) {
        toaster("Select a Report", "error");
        e.preventDefault();
        return;
    }
    
    e.model.ReportTitle = loadReportTitle();

    //if (e.model.Address == ""||e.model.Address == null) {
    //    toaster("Select an Email Address", "error");
    //    e.preventDefault();
    //    return;
    //}
    if (e.model.Frequency == "" || e.model.Frequency == null) {
        toaster("Select a Schedule Frequency", "error");
        e.preventDefault();
        return;
    }

    e.model.Time = $("#Time").val();
    e.model.StartTime = $("#StartTime").val();

    if (e.model.Frequency == "Daily") {
        if (moment(e.model.Time, "HH:mm:ss", true).isValid() == false) {
            toaster("Select a Valid Daily Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.Time == "" || e.model.Time == null) {
            toaster("Select a Daily Time", "error");
            e.preventDefault();
            return;
        }
    }
    if (e.model.Frequency == "Weekly") {
        if (e.model.Day == "" || e.model.Day == null) {
            toaster("Select a Day", "error");
            e.preventDefault();
            return;
        }
        if (moment(e.model.Time, "HH:mm:ss", true).isValid() == false) {
            toaster("Select a Valid Weekly Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.Time == "" || e.model.Time == null) {
            toaster("Select a Weekly Time", "error");
            e.preventDefault();
            return;
        }
    }
    if (e.model.Frequency == "Monthly") {
        if (e.model.Date == "" || e.model.Date == null) {
            toaster("Select a Monthly Date", "error");
            e.preventDefault();
            return;
        }
        if (moment(e.model.Time, "HH:mm:ss", true).isValid() == false) {
            toaster("Select a Valid Monthly Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.Time == "" || e.model.Time == null) {
            toaster("Select a Monthly Time", "error");
            e.preventDefault();
            return;
        }
    }

    if (e.model.Frequency == "CustomDaily") {
        if (moment(e.model.StartTime, "HH:mm:ss", true).isValid()==false) {
            toaster("Select the start time", "error");
            e.preventDefault();
            return;
        }
        if (moment(e.model.Time, "HH:mm:ss", true).isValid() == false) {
            toaster("Select the End Time", "error");
            e.preventDefault();
            return;
        }
    }
    modifyValid(e);
}

function timepicker_change(e) {
    if (moment($("#Time").val(), "HH:mm:ss", true).isValid() == false) {
        toaster("Select a Valid Time", "error");
        return;
    }
}
function loadReportTitle() {
    var text = "";
    var multiDataItems = $("#Report").data("kendoMultiSelect").dataItems();
    for (var i = 0; i < multiDataItems.length; i += 1) {
        text += multiDataItems[i].Text;
        if (i != multiDataItems.length - 1) {
            text += ",";
        }
    }
    return text;
}