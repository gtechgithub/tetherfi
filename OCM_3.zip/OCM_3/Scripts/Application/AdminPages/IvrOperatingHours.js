﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrOperatingHours.js",
        Version: "3.2.3.22",
        LastModifiedDateTime: "22-03-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "added BypassPublicHoliday validation"
    });
});


function onIvrOperatingHoursEdit(e) {
    if (e.model.isNew() == false) {
        $("#VDNName").css('display', '');
        $("#WeekDay").data("kendoMultiSelect").enable(false);
        $("#SelAllBut").attr("disabled", true);
        $("#VDN").data("kendoNumericTextBox").readonly();
        $("#VDN").data("kendoNumericTextBox").enable(false);
        $(e.container).find('input[name="VdnName"]').attr("readonly", true);
        $("#VDNLabel").html("VDN");
        $("#ModifyReasonGroup").show();
    }
    else
        if (e.model.isNew() == true) {
            $("#WeekDay").data("kendoMultiSelect").enable(true);
            $("#SelAllBut").attr("disabled", false);
            $("#ModifyReasonGroup").hide();
        }
}

function onIvrOperatingHoursSave(e) {
    var multiSelect = $("#WeekDay").data("kendoMultiSelect");
    if ($("#VDN").val() == "" || $("#VDN").val() == null) {
        toaster("Enter a VDN", "error");
        e.preventDefault();
        return;
    }
    if ($("#VDN").val() == 0) {
        toaster("Enter a VDN greater than 0", "error");
        e.preventDefault();
        return;
    }
    if ($("#VDN").val().toString().length < 4) {
        e.preventDefault();
        toaster("VDN Length is less than 4", "error");
        return;
    }
    if (e.model.isNew() == true) {
        if (multiSelect.dataItems().length == 0) {
            toaster("Select a Week Day", "error");
            e.preventDefault();
            return;
        }
    }
    var startTime = $("#StartTime").data("kendoTimePicker");
    var endTime = $("#EndTime").data("kendoTimePicker");

    if (startTime._old == null && startTime._oldText != "") {
        toaster("Enter a Valid Start Time", "error");
        e.preventDefault();
        return;
    }

    if (endTime._old == null && endTime._oldText != "") {
        toaster("Enter a Valid End Time", "error");
        e.preventDefault();
        return;
    }

    e.model.StartTime = kendo.toString(startTime.value(), "HH:mm:ss");
    e.model.EndTime = kendo.toString(endTime.value(), "HH:mm:ss");

    if (e.model.StartTime == null || e.model.StartTime == "") {
        toaster("Enter a Start Time", "error");
        e.preventDefault();
        return;
    }
    if (e.model.EndTime == null || e.model.EndTime == "") {
        toaster("Enter a End Time", "error");
        e.preventDefault();
        return;
    }
    var time1 = moment(e.model.StartTime, 'HH:mm:ss');
    var time2 = moment(e.model.EndTime, 'HH:mm:ss');
    if (time1.isAfter(time2)) {
        toaster("Start Time is greater than End Time", "error");
        e.preventDefault();
        return;
    }
    if (time1.isSame(time2)) {
        toaster("Start Time is same as End Time", "error");
        e.preventDefault();
        return;
    }
    
    if ($("#BypassPublicHoliday").data("kendoDropDownList") != undefined) {
        if ($("#BypassPublicHoliday").data("kendoDropDownList").value() == "")
        {
            toaster("Please provide Bypass Public Holiday", "error");
            e.preventDefault();
            return;
        }
    }

    if (e.model.isNew() == true) {
        if (multiSelect.dataItems().length == 0) {
            toaster("Select the Days", "error")
            e.preventDefault();
            return;
        }
        if (e.model.WeekDay == null || e.model.WeekDay=="") {
            for (i = 0; i < multiSelect.dataItems().length; i++) {
                e.model.WeekDay += multiSelect.dataItems()[i].Value;
                if (i < multiSelect.dataItems().length - 1) {
                    e.model.WeekDay += ",";
                }
            }
        }
    }
    modifyValid(e);
    var tempStartTime = e.model.StartTime;
    var tempEndTime = e.model.EndTime;
    e.model.StartTime = moment(tempStartTime, 'HH:mm:ss').format('HHmmss');
    e.model.EndTime = moment(tempEndTime, 'HH:mm:ss').format('HHmmss');
    e.model.Vdn = $("Vdn").val();
}

function SelectAll() {
    var multiSelect = $("#WeekDay").data("kendoMultiSelect");
    var selectedValues = "";
    var strComma = "";
    for (var i = 0; i < multiSelect.dataSource.data().length; i++) {
        var item = multiSelect.dataSource.data()[i];
        selectedValues += strComma + item.Value;
        strComma = ",";
    }
    multiSelect.value(selectedValues.split(","));
}

function onVdnNameFilter() {
    var value = this.value(),
    grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({});
        $("#weekDay").data("kendoDropDownList").value("");
        grid.dataSource.filter({ field: "VdnName", operator: "eq", value: value });
    }
    else {
        grid.dataSource.filter({});
    }
}

function onWeekDayFilter() {
    var value = this.value(),
    grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({});
        $("#VDNNames").data("kendoDropDownList").value("");
        grid.dataSource.filter({ field: "WeekDay", operator: "eq", value: value });
    }
    else {
        grid.dataSource.filter({});
    }
}

function onIvrOperatingHoursRequestEnd(e) {
    genericRequest(e);
    $("#VDNNames").data("kendoDropDownList").dataSource.read();
    $("#weekDay").data("kendoDropDownList").dataSource.read();
}