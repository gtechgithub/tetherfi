﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "AgentBroadcast.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Duplicate record issue"
    });
});
/**
 * on edit of agent telephony validate for number,email,text;
 */
function editAgentBroadcast(e) {
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }
    onTeamTreeLoad(e)
}

/* on changing the dropdown setting value to hidden fields */
function onTeamTreeLoad(e) {
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/GetTeamTree',
            dataType: "json",
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            contentType: 'application/json',
            success: function (data) {
                if (data != null) {
                    $("#TeamName").kendoDropDownTree({
                        dataSource: {
                            schema: {
                                model: {
                                    children: "Items"
                                }
                            },
                            data: data
                        },
                        dataTextField: "Text",
                        dataValueField: "Id"
                    });

                    try {
                        if (e.model.TeamName !== "") {
                            $("#TeamName").data("kendoDropDownTree").text(e.model.TeamName);
                        }
                    } catch (e) { }
                }
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}
/**
 * on select of dropdown in Agent telephony validate  number,email,text
 */
function onSaveAgentBroadcast(e) {
    e.model.TeamName = $("#TeamName").val();
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {

        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

    var currentTeamName = $("#TeamName").data("kendoDropDownTree").text();
    var currentID = e.model.Id;
    var count = 0;
    var data = $("#grid").data("kendoGrid").dataSource._data;
    item = data.length;
    for (t in data) {
        if (data[t].TeamName == currentTeamName) {
            count++;
            if (count == 2) {
                e.preventDefault();
                toaster("This team already has a broadcast message, Kindly use edit functionality", "error");
                return;
            }
        }
        if (data[t].TeamName == currentTeamName &&
            data[t].Id != currentID) {
            e.preventDefault();
            toaster("This team already has a broadcast message, Kindly use edit functionality", "error");
            return;
        }
    }
   

    modifyValid(e)
}

/*= AgentBroadcastMessage =*/
/*=============================================<<<<<*/