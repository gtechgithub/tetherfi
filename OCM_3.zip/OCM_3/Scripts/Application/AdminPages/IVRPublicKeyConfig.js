﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IVRPublicKeyConfig.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: ""
    });
});

function onIVRPublicKeyConfigEdit(e) {
    var ServerIp = e.model.MPPServerIP; 
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'IVRPublicKeyConfig/DownloadFileFromMPPServer',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "mppip": ServerIp },
            dataType: "json",
            success: function (returneddata) {
                console.log(returneddata)
                $('#KeySetValue').val(returneddata["KeySetValue"]);
                $('#Index1').val(returneddata["Index1"]);
                $('#Index2').val(returneddata["Index2"]);
                $('#Index3').val(returneddata["Index3"]);
                $('#Index4').val(returneddata["Index4"]);
                $('#Index5').val(returneddata["Index5"]);
                $('#Index6').val(returneddata["Index6"]);
                $('#Index7').val(returneddata["Index7"]);
                $('#Index8').val(returneddata["Index8"]);
                $('#Index9').val(returneddata["Index9"]);
                $('#Index10').val(returneddata["Index10"]);
                $('#MPPServerIP').val(ServerIp);
                var Iplist = $("#MPPServerIPlist").data("kendoMultiSelect");
                Iplist.value(ServerIp);
            },
            error: function (msg) {
                console.log(msg);
                toaster("There is an issue while downloading!!!", "error");
            },
        })
}

function saveData(e)
{
    var dict = {
            "KeySetValue": $('#KeySetValue').val(),
            "Index1": $('#Index1').val(),
            "Index2": $('#Index2').val(),
            "Index3": $('#Index3').val(),
            "Index4": $('#Index4').val(),
            "Index5": $('#Index5').val(),
            "Index6": $('#Index6').val(),
            "Index7": $('#Index7').val(),
            "Index8": $('#Index8').val(),
            "Index9": $('#Index9').val(),
            "Index10": $('#Index10').val()
    };
    var mppServerIPlist = $("#MPPServerIPlist").getKendoMultiSelect().value();
    e.MPPServerIPlist = mppServerIPlist.join(',');
    return {
        dict: dict,
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function onIVRPublicKeyConfigSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }

    fieldNames.push("KeySetValue", "Index1", "Index2", "Index3", "Index4", "Index5", "Index6", "Index7", "Index8", "Index9", "Index10");
    fieldValues.push($('#KeySetValue').val(), $('#Index1').val(), $('#Index2').val(), $('#Index3').val(), $('#Index4').val(), $('#Index5').val(), $('#Index6').val(), $('#Index7').val(), $('#Index8').val(), $('#Index9').val(), $('#Index10').val())
    fieldNames.push("MPP Server IP list");
    fieldValues.push($('#MPPServerIPlist').val())

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "MPPServerIP", "MPP Server IP");
    modifyValid(e)
}
