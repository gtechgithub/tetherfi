﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "SocialMediaAccount.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: ""
    });
});

/**
 * Social Media Account editor window pop up
 */
function onSocialMediaAccountEdit(e) {
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="Name"]').attr("readonly", true);
    }
    genericEdit(e);
}

/**
 * Social Media Account create/update
 */
function onSocialMediaAccountSave(e) {

    e.model.CallbackUrl = $("#CallbackUrl").val();
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Name", "Application Id", "Active")
    fieldValues.push(e.model.Name, e.model.SocialMediaApplicationId, e.model.Active);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "Name", "Name");
    modifyValid(e)
}

/**
 * Social Media Account get call back URL bases on application type
 */
function onSocialMediaApplicationIdChange(e) {
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'SocialMediaApplication/GetCallbackUrlType',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'socialMediaApplicationId': $("#SocialMediaApplicationId").val()
            }),
            dataType: "json",
            contentType: 'application/json',
            async: false,
            success: function (data) {
                if (data != null) {
                    $("#CallbackUrl").val(data);
                }
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}