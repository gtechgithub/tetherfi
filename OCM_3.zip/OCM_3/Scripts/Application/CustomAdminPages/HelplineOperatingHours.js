﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "HelplineOperatingHours.js",
        Version: "3.2.5.20",
        LastModifiedDateTime: "20-05-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Created"
    });
});


function onHelplineOperatingHoursEdit(e) {
    if (e.model.isNew() == false) {
        $("#WeekDay").data("kendoMultiSelect").enable(false);
        $("#SelAllBut").attr("disabled", true);
        $("#HelplineName").data("kendoDropDownList").dataSource.read();
        $("#HelplineName").data("kendoDropDownList").value(e.model.HelplineID);
        $("#HelplineName").data("kendoDropDownList").readonly();
        $("#ModifyReasonGroup").show();
    }
    else
        if (e.model.isNew() == true) {
            $("#WeekDay").data("kendoMultiSelect").enable(true);
            $("#SelAllBut").attr("disabled", false);
            $("#ModifyReasonGroup").hide();
        }
}

function onHelplineOperatingHoursSave(e) {
    var multiSelect = $("#WeekDay").data("kendoMultiSelect");
    e.model.HelplineID = $("#HelplineName").data("kendoDropDownList").value();
    e.model.HelplineName = $("#HelplineName").data("kendoDropDownList").text();
    var helpline = $("#HelplineName").data("kendoDropDownList");
    if (helpline.value() == "")
    {
        toaster("Select Helpline Name", "error");
        e.preventDefault();
        return;
    }
    if (e.model.isNew() == true) {
        if (multiSelect.dataItems().length == 0) {
            toaster("Select a Week Day", "error");
            e.preventDefault();
            return;
        }
    }
    var startTime = $("#StartTime").data("kendoTimePicker");
    var endTime = $("#EndTime").data("kendoTimePicker");

    if (startTime._old == null && startTime._oldText != "") {
        toaster("Enter a Valid Start Time", "error");
        e.preventDefault();
        return;
    }

    if (endTime._old == null && endTime._oldText != "") {
        toaster("Enter a Valid End Time", "error");
        e.preventDefault();
        return;
    }

    e.model.StartTime = kendo.toString(startTime.value(), "HH:mm:ss");
    e.model.EndTime = kendo.toString(endTime.value(), "HH:mm:ss");

    if (e.model.StartTime == null || e.model.StartTime == "") {
        toaster("Enter a Start Time", "error");
        e.preventDefault();
        return;
    }
    if (e.model.EndTime == null || e.model.EndTime == "") {
        toaster("Enter a End Time", "error");
        e.preventDefault();
        return;
    }
    var time1 = moment(e.model.StartTime, 'HH:mm:ss');
    var time2 = moment(e.model.EndTime, 'HH:mm:ss');
    if (time1.isAfter(time2)) {
        toaster("Start Time is greater than End Time", "error");
        e.preventDefault();
        return;
    }
    if (time1.isSame(time2)) {
        toaster("Start Time is same as End Time", "error");
        e.preventDefault();
        return;
    }

    if ($("#BypassPublicHoliday").data("kendoDropDownList") != undefined) {
        if ($("#BypassPublicHoliday").data("kendoDropDownList").value() == "") {
            toaster("Please provide Bypass Public Holiday", "error");
            e.preventDefault();
            return;
        }
    }

    if (e.model.isNew() == true) {
        if (multiSelect.dataItems().length == 0) {
            toaster("Select the Days", "error")
            e.preventDefault();
            return;
        }
        if (e.model.WeekDay == null || e.model.WeekDay == "") {
            for (i = 0; i < multiSelect.dataItems().length; i++) {
                e.model.WeekDay += multiSelect.dataItems()[i].Value;
                if (i < multiSelect.dataItems().length - 1) {
                    e.model.WeekDay += ",";
                }
            }
        }
    }
    modifyValid(e);
    var tempStartTime = e.model.StartTime;
    var tempEndTime = e.model.EndTime;
    e.model.StartTime = moment(tempStartTime, 'HH:mm:ss').format('HHmmss');
    e.model.EndTime = moment(tempEndTime, 'HH:mm:ss').format('HHmmss');
    
}

function SelectAll() {
    var multiSelect = $("#WeekDay").data("kendoMultiSelect");
    var selectedValues = "";
    var strComma = "";
    for (var i = 0; i < multiSelect.dataSource.data().length; i++) {
        var item = multiSelect.dataSource.data()[i];
        selectedValues += strComma + item.Value;
        strComma = ",";
    }
    multiSelect.value(selectedValues.split(","));
}

//function onVdnNameFilter() {
//    var value = this.value(),
//        grid = $("#grid").data("kendoGrid");

//    if (value) {
//        grid.dataSource.filter({});
//        $("#weekDay").data("kendoDropDownList").value("");
//        grid.dataSource.filter({ field: "HelplineName", operator: "eq", value: value });
//    }
//    else {
//        grid.dataSource.filter({});
//    }
//}

//function onWeekDayFilter() {
//    var value = this.value(),
//        grid = $("#grid").data("kendoGrid");

//    if (value) {
//        grid.dataSource.filter({});
//        $("#HelplineName").data("kendoDropDownList").value("");
//        grid.dataSource.filter({ field: "WeekDay", operator: "eq", value: value });
//    }
//    else {
//        grid.dataSource.filter({});
//    }
//}

//function onHelplineOperatingHoursRequestEnd(e) {
//    genericRequest(e);
//    $("#HelplineName").data("kendoDropDownList").dataSource.read();
//    $("#weekDay").data("kendoDropDownList").dataSource.read();
//}