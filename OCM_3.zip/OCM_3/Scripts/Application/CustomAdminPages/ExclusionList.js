﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "ExclusionList.js",
         Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});


function editExclusionList(e) {
    genericEdit(e);
}
function onSaveExclusionList(e) {
    // var code = $("#Code").val();
    var name = $("#Name").val();
    var description = $("#Description").val();
    var enablePaiza = $("#EnablePaiza").data("kendoDropDownList").value();
    var enableFIT = $("#EnableFIT").data("kendoDropDownList").value();
    var enableExpress = $("#EnableExpress").data("kendoDropDownList").value();
    //if (code == "") {
    //    e.preventDefault();
    //    toaster("Please provide a valid Code", "error");
    //    return;
    //}
    if (name == "") {
        e.preventDefault();
        toaster("Please provide a valid Name", "error");
        return;
    }
    if (description == "") {
        e.preventDefault();
        toaster("Please provide a valid Description", "error");
        return;
    }
    if (enablePaiza == "") {
        e.preventDefault();
        toaster("Please provide a valid Enable Paiza", "error");
        return;
    }
    if (enableFIT == "") {
        e.preventDefault();
        toaster("Please provide a valid Enable FIT", "error");
        return;
    }
    if (enableExpress == "") {
        e.preventDefault();
        toaster("Please provide a valid Enable Express", "error");
        return;
    }
    modifyValid(e);
}

function ReloadData() {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'ExclusionList/ReloadData',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data) {
                toaster("Data Reloaded Successfully", "success");
            }
        },
        error: function () {
            e.preventDefault();
            toaster("Failed to Reload Data", "error");
            console.log('Failed to Reload Data');
            return;
        }
    });
}
