﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "RoutingLogic.js",
        Version: "3.1.8.26",
        LastModifiedDateTime: "26-08-2018 00:00:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});
function editRoutingLogic(e) {
    try {
        if (e.model.isNew() == false) {
            $(e.container).find('input[name="Intent"]').attr("readonly", true);
        }
        genericEdit(e);
    }
    catch (err) {
        console.log(err);
    }
}

function onSaveRoutingLogic(e) {
    try {
        var intent = $("#Intent").val();
        var SRCTier = $("#SRCTier").data("kendoDropDownList").value();
        var SRLTier = $("#SRLTier").data("kendoDropDownList").value();
        var ProfitTier = $("#ProfitTier").data("kendoDropDownList").value();
        var Team = $("#Team").data("kendoDropDownList").value();
        var PriorityLevel = $("#Priority").data("kendoDropDownList").value();
        var BypassIVR = $("#ByPassIVR").data("kendoDropDownList").value();
        var vdn = $("#VDN").val().length;
        if (intent == "") {
            e.preventDefault();
            toaster("Please provide a valid Intent", "error");
            return;
        }
        if (SRCTier == "") {
            e.preventDefault();
            toaster("Please provide a valid SRC Tier", "error");
            return;
        }
        if (SRLTier == "") {
            e.preventDefault();
            toaster("Please provide a valid SRL Tier", "error");
            return;
        }
        if (ProfitTier == "") {
            e.preventDefault();
            toaster("Please provide a valid Profit Tier", "error");
            return;
        }
        if (Team == "") {
            e.preventDefault();
            toaster("Please provide a valid Team", "error");
            return;
        }
        if (PriorityLevel == "") {
            e.preventDefault();
            toaster("Please provide a valid Priority Level", "error");
            return;
        }
        if (BypassIVR == "") {
            e.preventDefault();
            toaster("Please provide a valid Bypass IVR", "error");
            return;
        }
        if (vdn == "" || vdn>5 || vdn<5) {
            e.preventDefault();
            toaster("Please provide a valid VDN", "error");
            return;
        }
        duplicateValidate(e, "Intent", "Intent")
        modifyValid(e);
    }
    catch (err) {
        console.log(err);
    }
}

