﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Dashboard",
        FileName: "Fax.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "01-02-2019 08:30:00 AM",
        LastModifiedBy: "",
        Description: ""
    });
});
function getFaxRealtimeDashboardParam() {
    if ($("#faxdnisvalue").val() != null) {
        return {
            faxdnisvalue: $("#faxdnisvalue").val(),
            days: 0
        }
    }
    else {
        return {
            faxdnisvalue: '',
            days: $("#days").val()
        }
    }
}


function onFaxRealTimeGridRequestEnd() {
    faxRealTimeGridLock = false;
    setTimeout(function () {
        getFaxRealTimeGridData();
    }, realtimeoutTime)
}

function getFaxRealTimeGridData() {
    //var emaildnisvalue = $("#mailboxes").data("kendoMultiSelect").value();
    if (faxRealTimeGridLock == false && $("#selectedtabvalue").val() == "fax" && dashboardMasterLock == false) {
        //if (emaildnisvalue.length != 0) {
        faxRealTimeGridLock = true;
        console.log("Calling Fax Real Time Grid Datasource Read!");
        $("#faxRealTimeGrid").data("kendoGrid").dataSource.read();
        //}
        // }
    }
}


function getFaxDashboardData() {
    if ($("#selectedtabvalue").val() == "fax" && faxRealTimeLock == false && dashboardMasterLock == false) {
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        faxRealTimeLock = true;
        console.log("Calling Fax Real Time Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetFaxDashboardData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: getDashboardParam(),
            async: false,
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null || returneddata[0].length > 0) {
                        $("#faxReceived").html(returneddata[0].FaxReceived);
                        $("#faxSent").html(returneddata[0].FaxSent);
                        $("#faxSending").html(returneddata[0].FaxSending);
                        $("#faxSentFailed").html(returneddata[0].FaxSentFail);
                        $("#faxReceivedFailed").html(returneddata[0].FaxReceiveFail);
                        $("#faxRoute").html(returneddata[0].FaxRouted);
                        $("#faxReceiving").html(returneddata[0].FaxReceiving);
                        $("#faxAssigned").html(returneddata[0].FaxAssigned);
                    }
                } catch (e) {
                    console.log(e);
                }
                 faxRealTimeLock = false;
                 if ($("#selectedtabvalue").val() == "fax" && faxRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getFaxDashboardData();
                    }, realtimeoutTime)
                }
            },
            error: function () {
                console.log('Failed to load Fax Dashboard data');
                faxRealTimeLock = false;
                if ($("#selectedtabvalue").val() == "fax" && faxRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getFaxDashboardData();
                    }, realtimeoutTime)
                }
            }
        });
    }
}

