﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Dashboard",
        FileName: "Generic.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "27-08-2019 07:15:00 PM",
        LastModifiedBy: "Shreyas",
        Description: "Added line dashboard changes"
    });
});

//Function to resize all kendo components when page size is changed.
//Add new kendo components here
function kendoComponentResize() {
    try {
       
        if ($("#selectedtabvalue").val() == "email") {
            //Email Dashboard components resizing
            kendo.resize($("#SLGrid"));
            kendo.resize($("#piechart"));
            kendo.resize($("#chart"));
        }

        if ($("#selectedtabvalue").val() == "ivr") {
            //IVR Dashboard components resizing
            kendo.resize($("#maxTimeSpentGauge"));
            kendo.resize($("#averageTimeSpentGauge"));
            kendo.resize($("#ivrChart"));
            kendo.resize($("#ivrDetails"));
        }

        if ($("#selectedtabvalue").val() == "chat") {
            //Chat Dashboard components resizing
            kendo.resize($("chatSummaryChart"));
        }
        if ($("#selectedtabvalue").val() == "chatbot") {
            //Chatbot Dashboard components resizing
            kendo.resize($("chatbotSummaryChart"));
        }

        if ($("#selectedtabvalue").val() == "sms") {
            //SMS Dashboard components resizing
            kendo.resize($("smsSummaryChart"));
        }

        if ($("#selectedtabvalue").val() == "voicecallback") {
            //Voice Callback Dashboard components resizing
            kendo.resize($("#callbackSummaryChart"));
            kendo.resize($("#CallbackGrid"));
            $("#callbackSummaryChart").data("kendoChart").refresh();
        }

        if ($("#selectedtabvalue").val() == "chatcallback") {
            //Chat Callback Dashboard components resizing
            kendo.resize($("#chatcallbackSummaryChart"));
            kendo.resize($("#ChatCallbackGrid"));
            $("#chatcallbackSummaryChart").data("kendoChart").refresh();
        }

        if ($("#selectedtabvalue").val() == "customer") {
            //Customer Dashboard components resizing
            kendo.resize($("#customerSatisfaction"));
            kendo.resize($("#intentDashboardChart"));
            kendo.resize($("customerTouchPoint"));

            //Customer/Intent Dashboard refresh charts
            $("#customerSatisfaction").data("kendoChart").refresh();
            $("#customerTouchPoint").data("kendoChart").refresh();
            $("#intentDashboardChart").data("kendoChart").refresh();
        }
    } catch (e) {
        console.log(e);
    }
}

function onSelectDashboard(selectedtab) {
    
    //If a tab is previously selected that will be stored in the previouslyselectedtabvalue and the new tab which is newly selected is stored in selectedtabvalue hidden variable
    //This is is done so that in loadData function we can check if the same tab is clicked multiple times
    console.log("Previously Selected Tab: " + $("#previouslyselectedtabvalue").val());
    console.log("Newly Selected Tab: " + selectedtab);
    $("#previouslyselectedtabvalue").val($("#selectedtabvalue").val());
    $("#selectedtabvalue").val(selectedtab)
}

//On resizing window resize kendo components
$(window).on("resize", function () {
    kendoComponentResize();
    $("#dashboardSelector").height($(window).height() - $("#navbarheader").height() - $("#footer").height());
    $("#dashboardNavigationTabs").height($("#dashboardSelector").height() - 90);
    $("#dashboardNavigationTabs").css("max-height", $("#dashboardSelector").height() - 90);
    $(".tabs-container").height($(window).height() - $("#navbarheader").height() - $("#footer").height() - 20);
});

function onDashboardLoad() {
    //Check for enabled dashboards from web.config
    getDashboardTabs();

    //Set Dashboard Days initially to one on page load
    $("#days").val(1);
    //Make all dnis Dropdowns input readonly so that user cannot enter text
    $('.k-input').attr('readonly', "readonly");
    //Sets the Dashboard Days Numeric textbox as not read only so user can enter input manually
    $('#dashboarddays').attr('readonly', false);

    //Onclick of Email Dashboard Show button
    $("#showDashboard").click(function () {
        var chart = $("#chart").data("kendoChart");
        var grid = $("#SLGrid").data("kendoGrid");
        $("#piechart").data("kendoChart").dataSource.data("");
        chart.dataSource.data("");
        grid.dataSource.data("");
        var mailboxevalues = $("#mailboxes").data("kendoMultiSelect");
        var mailboxids = mailboxevalues.value();

        if (mailboxids.length != 0) {
            setDashboardDays();
            $("#mailboxvalues").val(mailboxids.toString());
            getEmailPieChartData();
            getEmailGridData();
            getEmailChartData();
        }
        else {
            $("#mailboxvalues").val("");
            toaster("Please select atleast one mailbox", "error");
        }
    });

    //Onclick of IVR or Voice Dashboard Show button
    $("#showIvrDashboard").click(function () {
        var ivrChart = $("#ivrChart").data("kendoChart");
        ivrChart.dataSource.data("");
        $("#totalivrcalls").html(0);
        $("#selfServicedCalls").html(0);
        $("#transferredCalls").html(0);
        $("#ivrAHT").html(0);
        $("#sec").css('display', 'none');
        $("#totalTimeSpent").html(0);
        $("#totalCallbacks").html(0);
        var gauge1 = $("#maxTimeSpentGauge").data("kendoRadialGauge").value("0");
        var gauge2 = $("#averageTimeSpentGauge").data("kendoRadialGauge").value("0");
        $("#ivrMaxTimeSpent").html("");
        $("#ivrAvgTimeSpent").html("");
        var ivrdnisvalue = $("#ivrdnis").data("kendoMultiSelect");
        //kendo.ui.progress($("#ivrChart"), false);
        var ivrdnis = ivrdnisvalue.value();
        if (ivrdnis.length != 0) {
            setDashboardDays();
            $("#ivrdnisvalue").val(ivrdnis.toString());
            kendo.ui.progress($("#ivrChart"), true);
            $("#ivrMaxTimeSpent").html("");
            $("#ivrAvgTimeSpent").html("");
            getIvrChartData();
            getIvrDashboardData();
        }
        else {
            toaster("Please select a DNIS", "error");
            $("#ivrMaxTimeSpent").html("");
            $("#ivrAvgTimeSpent").html("");
        }
    });

    //Onclick of Chat self service show button
    $("#showChatSelfDashboard").click(function () {
        var ivrChart = $("#chatselfserviceChart").data("kendoChart");
        var ivrdnisvalue = $("#chatselfservicednis").data("kendoMultiSelect");
        var ivrdnis = ivrdnisvalue.value();
        $("#totalchatselfservice").html(0);
        $("#selfservicedchat").html(0);
        $("#transferredchatself").html(0);
        $("#chatselfserviceAHT").html(0);
        $("#sec").css('display', 'none');
        $("#chatselfservicetotalTimeSpent").html(0);
        $("#totalchatselfserviceCallbacks").html(0);
        ivrChart.dataSource.data("");
        var gauge1 = $("#chatselfservicemaxTimeSpentGauge").data("kendoRadialGauge").value("0");
        var gauge2 = $("#chatselfserviceaverageTimeSpentGauge").data("kendoRadialGauge").value("0");
        $("#chatselfserviceMaxTimeSpent").html("");
        $("#chatselfserviceAvgTimeSpent").html("");
        if (ivrdnis.length != 0) {
            setDashboardDays();
            $("#ivrdnisvalue").val(ivrdnis.toString());
            //kendo.ui.progress($("#ivrChart"), true);
            $("#chatselfserviceMaxTimeSpent").html("");
            $("#chatselfserviceAvgTimeSpent").html("");
            getChatselfserviceChartData();
            getChatselfserviceDashboardData();
        }
        else {
            toaster("Please select a DNIS", "error");
            $("#ivrdnisvalue").val("");
            $("#ivrMaxTimeSpent").html("");
            $("#ivrAvgTimeSpent").html("");
        }
    });

    //Onclick of SMS Dashboard Show button
    $("#showSmsDashboard").click(function () {
        var smsSummaryChart = $("#smsSummaryChart").data("kendoChart");
        smsSummaryChart.dataSource.data("");
        var smsdnisvalue = $("#smsdnis").data("kendoMultiSelect");
        var smsdnis = smsdnisvalue.value();
        $("#smsTransferred").html(0);
        $("#smsConferenced").html(0);
        $("#smsCount").html(0);
        $("#smsAHT").html(0);
        $("#smsSec").css('display', 'none');
        $("#smspercent").css('display', 'none');
        $("#smsFCR").html(0);
        $("#smsarrowdown").css('display', 'none');
        $("#smsarrowup").css('display', 'none');
        var gauge1 = $("#smsgauge1").data("kendoRadialGauge").value("0");
        var gauge2 = $("#smsgauge2").data("kendoRadialGauge").value("0");
        $("#smsMaxTimeToReply").html("");
        $("#smsAvgTimeToReply").html("");
        //$("#max").data("kendoRadialGauge").value("0");
        //$("#smsSetColor").attr('class', 'text-navy');
        if (smsdnis.length != 0) {
            setDashboardDays();
            $("#smsdnisvalue").val(smsdnis.toString());
            $("#smsMaxTimeToReply").html("");
            $("#smsAvgTimeToReply").html("");
            getSmsDashboardData();
            getSmsChartData();
            kendo.ui.progress($("#smsSummaryChart"), true);
        }
        else {
            toaster("Please select a DNIS", "error");
            $("#smsdnisvalue").val("");
            $("#smsMaxTimeToReply").html("");
            $("#smsAvgTimeToReply").html("");
        }
    });

    //Onclick of SMS Dashboard Show button
    $("#showChatDashboard").click(function () {
        var chatSummaryChart = $("#chatSummaryChart").data("kendoChart");
        chatSummaryChart.dataSource.data("");
        var chatdnisvalue = $("#skill").data("kendoMultiSelect");
        var skill = chatdnisvalue.value();
        $("#transferedChats").html(0);
        $("#chatsConferenced").html(0);
        $("#chatCount").html(0);
        $("#chatAHT").html(0);
        $("#chatFCR").html(0);
        $("#chatCallback").html(0);
        $("#sec1").css('display', 'none');
        $("#percent").css('display', 'none');
        $("#arrowdown").css('display', 'none');
        $("#arrowup").css('display', 'none');
        if (skill.length != 0) {
            kendo.ui.progress($("#chatSummaryChart"), true);
            setDashboardDays();
            $("#chatdnisvalue").val(skill.toString());
            getChatDashboardData();
            getChatChartData();
            kendo.ui.progress($("#chatSummaryChart"), false);
        }
        else {
            toaster("Please select a Skill", "error");
            $("#chatdnisvalue").val("");
        }
    });

    //Onclick of Chatbot Dashboard Show button
    $("#showChatbotDashboard").click(function () {
        var chatbotSummaryChart = $("#chatbotSummaryChart").data("kendoChart");
        chatbotSummaryChart.dataSource.data("");
        var chatbotdnisvalue = $("#chatbotskill").data("kendoMultiSelect");
        var chatbotskill = chatbotdnisvalue.value();
        $("#transferedChats").html(0);
        $("#chatsConferenced").html(0);
        $("#chatCount").html(0);
        $("#chatAHT").html(0);
        $("#chatFCR").html(0);
        $("#chatCallback").html(0);
        $("#sec1").css('display', 'none');
        $("#percent").css('display', 'none');
        $("#arrowdown").css('display', 'none');
        $("#arrowup").css('display', 'none');
        if (chatbotskill.length != 0) {
            kendo.ui.progress($("#chatbotSummaryChart"), true);
            setDashboardDays();
            $("#chatbotdnisvalue").val(chatbotskill.toString());
            getChatbotDashboardData();
            getChatbotChartData();
            kendo.ui.progress($("#chatbotSummaryChart"), false);
        }
        else {
            toaster("Please select a Skill", "error");
            $("#chatbotdnisvalue").val("");
        }
    });

    $("#showFaxDashboard").click(function () {
        var faxdnisvalue = $("#faxDnis").data("kendoMultiSelect");
        var faxdnis = faxdnisvalue.value();
        $("#faxReceived").html(0);
        $("#faxSent").html(0);
        //$("#faxDnis").html(returneddata[0].FaxDnis);
        $("#faxSentFailed").html(0);
        $("#faxReceiveFailed").html(0);
        $("#faxRoute").html(0);
        $("#faxReceiving").html(0);
        //$("#max").data("kendoRadialGauge").value("0");
        //$("#smsSetColor").attr('class', 'text-navy');
        if (faxdnis.length != 0) {
            setDashboardDays();
            $("#faxdnisvalue").val(faxdnis.toString());
            // kendo.ui.progress($("#smsSummaryChart"), true);

            getFaxRealTimeGridData();
            getFaxDashboardData();
        }
        else {
            $("#faxdnisvalue").val("");
            toaster("Please select the Fax Line", "error");
        }
    });
}

//Check which all tabs are enabled in web.config and set them as active
function getDashboardTabs() {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'Dashboards/GetDashTabs',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        dataType: "json",
        success: function (returneddata) {
            try {
                if ((returneddata[0].Email == 0 || returneddata[0].Email == "") && (returneddata[0].Ivr == 0 || returneddata[0].Ivr == "") &&
                    (returneddata[0].Chat == 0 || returneddata[0].Chat == "") && (returneddata[0].Chatbot == 0 || returneddata[0].Chatbot == "") && (returneddata[0].Sms == 0 || returneddata[0].Sms == "") &&
                    (returneddata[0].ChatCallback == 0 || returneddata[0].ChatCallback == "") && (returneddata[0].VoiceCallback == 0 || returneddata[0].VoiceCallback == "")
                    && (returneddata[0].BcmsRealTime == 0 || returneddata[0].BcmsRealTime == "") && (returneddata[0].BcmsChatRealTime == 0 || returneddata[0].BcmsChatRealTime == "")
                    && (returneddata[0].BcmsEmailRealTime == 0 || returneddata[0].BcmsEmailRealTime == "") && (returneddata[0].Customer == 0 || returneddata[0].Customer == "") && (returneddata[0].ChatSelfService == 0 || returneddata[0].ChatSelfService == "")
                    && (returneddata[0].Fax == 0 || returneddata[0].Fax == "")) {
                    //Show no access if no tabs are enabled for the user
                    $("#dashboardLoading").css('display', 'none');
                    $("#dashboardInvalidAccess").css('display', '');
                    $("#dashboarddiv").css('display', 'none');
                    $("#dashboardSelector").css('display', 'none');
                    return;
                }
                //else we show the dashboard page
                $("#dashboardInvalidAccess").css('display', 'none');
                $("#dashboardLoading").css('display', 'none');
                $("#dashboarddiv").css('display', '');
                $("#dashboardSelector").css('display', '');
                if (returneddata[0].Email == false || returneddata[0].Email == "") {
                    $("#email").attr("style", "display:none");
                    $("#email").removeClass('active');
                }
                else {
                    $("#email").attr("style", "display:block");
                }
                if (returneddata[0].Ivr == false || returneddata[0].Ivr == "") {
                    $("#ivr").attr("style", "display:none");
                    $("#email").removeClass('active');
                }
                else {
                    $("#ivr").attr("style", "display:block");
                }
                if (returneddata[0].Chat == false || returneddata[0].Chat == "") {
                    $("#chat").attr("style", "display:none");
                    $("#email").removeClass('active');
                }
                else {
                    $("#chat").attr("style", "display:block");
                }
                if (returneddata[0].Chatbot == false || returneddata[0].Chatbot == "") {
                    $("#chatbot").attr("style", "display:none");
                    $("#email").removeClass('active');
                }
                else {
                    $("#chatbot").attr("style", "display:block");
                }
                if (returneddata[0].Sms == false || returneddata[0].Sms == "") {
                    $("#sms").attr("style", "display:none");
                }
                else {
                    $("#sms").attr("style", "display:block");
                }
                if (returneddata[0].ChatCallback == false || returneddata[0].ChatCallback == "") {
                    $("#chatcallback").attr("style", "display:none");
                    $("#chatcallback").removeClass('active');
                }
                else {
                    $("#chatcallback").attr("style", "display:block");
                }
                if (returneddata[0].VoiceCallback == false || returneddata[0].VoiceCallback == "") {
                    $("#voicecallback").attr("style", "display:none");
                    $("#voicecallback").removeClass('active');
                }
                else {
                    $("#voicecallback").attr("style", "display:block");
                }
                if (returneddata[0].BcmsRealTime == false || returneddata[0].BcmsRealTime == "") {
                    $("#bcmsrealtimequeue").attr("style", "display:none");
                    $("#bcmsrealtimequeue").removeClass('active');
                }
                else {
                    $("#bcmsrealtimequeue").attr("style", "display:block");
                }
                if (returneddata[0].BcmsChatRealTime == false || returneddata[0].BcmsChatRealTime == "") {
                    $("#chatrealtimequeue").attr("style", "display:none");
                    $("#chatrealtimequeue").removeClass('active');
                }
                else {
                    $("#chatrealtimequeue").attr("style", "display:block");
                }

                if (returneddata[0].BcmsEmailRealTime == false || returneddata[0].BcmsEmailRealTime == "") {
                    $("#emailrealtimequeue").attr("style", "display:none");
                    $("#emailrealtimequeue").removeClass('active');
                }
                else {
                    $("#emailrealtimequeue").attr("style", "display:block");
                }

                if (returneddata[0].Customer == false || returneddata[0].Customer == "") {
                    $("#customer").attr("style", "display:none");
                    $("#customer").removeClass('active');
                }
                else {
                    $("#customer").attr("style", "display:block");
                }
                if (returneddata[0].ChatSelfService == false || returneddata[0].ChatSelfService == "") {
                    $("#chatselfservice").attr("style", "display:none");
                    $("#email").removeClass('active');
                }
                else {
                    $("#chatselfservice").attr("style", "display:block");
                }

                if (returneddata[0].Fax == false || returneddata[0].Fax == "") {
                    $("#fax").attr("style", "display:none");
                }
                else {
                    $("#fax").attr("style", "display:block");
                }
                if (returneddata[0].Line == false || returneddata[0].Line == "") {
                    $("#line").attr("style", "display:none");
                }
                else {
                    $("#line").attr("style", "display:block");
                }
                //logic to set list view as active based on the values configured in web.config
                //if statements comparisons have to be in the same order of the tabs that have been created
                if (returneddata[0].Email == true) {
                    //make email dashboard class active and rest all inactive
                    $("#email").addClass('active');
                    $("#dashboardtab-1").addClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('email');
                    enableordisabledays('email');
                }
                else if (returneddata[0].Chat == true) {
                    $("#chat").addClass('active');
                    $("#dashboardtab-2").addClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#selectedtabvalue").val('chat');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    enableordisabledays('chat');
                    $("#dashboardTimeFrameType").val("days");
                    getChatDashboardData();
                    getChatChartData();
                }
                else if (returneddata[0].Chatbot == true) {
                    $("#chatbot").addClass('active');
                    $("#dashboardtab-13").addClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#selectedtabvalue").val('chat');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    enableordisabledays('chatbot');
                    $("#dashboardTimeFrameType").val("days");
                    getChatbotDashboardData();
                    getChatbotChartData();
                }
                else if (returneddata[0].Ivr == true) {
                    $("#ivr").addClass('active');
                    $("#dashboardtab-3").addClass('active');
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('ivr');
                    enableordisabledays('ivr');
                }
                else if (returneddata[0].Sms == true) {
                    $("#sms").addClass('active');
                    $("#dashboardtab-4").addClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('sms');
                    enableordisabledays('sms');
                }
                else if (returneddata[0].VoiceCallback == true) {
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#voicecallback").addClass('active');
                    $("#dashboardtab-5").addClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('voicecallback');
                    enableordisabledays('voicecallback');
                    getVoiceCallbackDashboardData();
                    getVoiceCallbackGridData();
                    getVoiceCallbackChartData();
                }
                else if (returneddata[0].ChatCallback == true) {
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#chatcallback").addClass('active');
                    $("#dashboardtab-6").addClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('chatcallback');
                    enableordisabledays('chatcallback');
                    getChatCallbackDashboardData();
                    getChatCallbackGridData();
                    getChatCallbackChartData();
                }
                else if (returneddata[0].BcmsRealTime == true) {
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#bcmsrealtimequeue").addClass('active');
                    $("#dashboardtab-7").addClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('bcmsrealtimequeue')
                    getbcmsDashboardData();
                    enableordisabledays('bcmsrealtimequeue');
                    var grid = $("#bcmsgrid").data("kendoGrid");
                    grid.dataSource.read();
                }
                else if (returneddata[0].BcmsChatRealTime == true) {
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#chatrealtimequeue").addClass('active');
                    $("#dashboardtab-9").addClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('chatrealtimequeue')
                    getbcmsChatDashboardData();
                    enableordisabledays('chatrealtimequeue');
                    var grid = $("#chatRealTimeGrid").data("kendoGrid");
                    grid.dataSource.read();
                }
                else if (returneddata[0].BcmsEmailRealTime == true) {
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").addClass('active');
                    $("#dashboardtab-10").addClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('emailrealtimequeue')
                    getbcmsEmailDashboardData();
                    enableordisabledays('emailrealtimequeue');
                    var grid = $("#emailRealTimeGrid").data("kendoGrid");
                    grid.dataSource.read();
                }
                else if (returneddata[0].Customer == true) {
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#customer").addClass('active');
                    $("#dashboardtab-8").addClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('customer')
                    enableordisabledays('customer');
                    $("#customerSatisfaction").data("kendoChart").dataSource.read();
                    $("#customerTouchPoint").data("kendoChart").dataSource.read();
                    $("#intentDashboardChart").data("kendoChart").dataSource.read();
                }
                else if (returneddata[0].ChatSelfService == true) {
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#chatselfservice").addClass('active');
                    $("#dashboardtab-11").addClass('active');
                    $("#line").removeClass('active');
                    $("#dashboardtab-14").removeClass('active');
                    $("#selectedtabvalue").val('chatselfservice');
                    enableordisabledays('chatselfservice');
                }
                else if (returneddata[0].Fax == true) {
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#fax").addClass('active');
                    $("#dashboardtab-12").addClass('active');
                    $("#selectedtabvalue").val('fax');
                    enableordisabledays('fax');
                }
                else if (returneddata[0].Line == true) {
                    $("#ivr").removeClass('active');
                    $("#dashboardtab-3").removeClass('active');
                    $("#sms").removeClass('active');
                    $("#dashboardtab-4").removeClass('active');
                    $("#email").removeClass('active');
                    $("#dashboardtab-1").removeClass('active');
                    $("#chat").removeClass('active');
                    $("#dashboardtab-2").removeClass('active');
                    $("#chatbot").removeClass('active');
                    $("#dashboardtab-13").removeClass('active');
                    $("#voicecallback").removeClass('active');
                    $("#dashboardtab-5").removeClass('active');
                    $("#chatcallback").removeClass('active');
                    $("#dashboardtab-6").removeClass('active');
                    $("#chatrealtimequeue").removeClass('active');
                    $("#dashboardtab-9").removeClass('active');
                    $("#emailrealtimequeue").removeClass('active');
                    $("#dashboardtab-10").removeClass('active');
                    $("#bcmsrealtimequeue").removeClass('active');
                    $("#dashboardtab-7").removeClass('active');
                    $("#customer").removeClass('active');
                    $("#dashboardtab-8").removeClass('active');
                    $("#chatselfservice").removeClass('active');
                    $("#dashboardtab-11").removeClass('active');
                    $("#fax").removeClass('active');
                    $("#dashboardtab-12").removeClass('active');
                    $("#line").addClass('active');
                    $("#dashboardtab-14").addClass('active');
                    $("#selectedtabvalue").val('line');
                    enableordisabledays('line');
                    getLineChartData();
                }
            } catch (e) {
                console.log(e);
            }
        },
        error: function () {
            console.log('Failed to Load dashboard tabs');
        }
    });
}

//Function used to animate data(numbers) on Dashboard
function animatingCounter(arg) {
    $(arg).each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
        }, {
                duration: 1000,
                easing: 'swing',
                step: function (now) {
                    if ($(this).text().indexOf(".") > 0) {
                        $(this).text(this.Counter.toFixed(2));
                    }
                    else
                        $(this).text(Math.ceil(now));
                }
            });
    });
}

//function to retrieve values from hidden variables and it can be used to pass parameters in ajax call
function getDashboardParam() {
    setDashboardDays();
    return {
        mailboxvalues: $("#mailboxvalues").val(),
        ivrdnisvalue: $("#ivrdnisvalue").val(),
        chatselfservicednisvalue: $("#chatselfservicednisvalue").val(),
        chatdnisvalue: $("#chatdnisvalue").val(),
        chatbotdnisvalue: $("#chatbotdnisvalue").val(),
        smsdnisvalue: $("#smsdnisvalue").val(),
        dashboardTimeFrameType: $("#dashboardTimeFrameType").val(),
        days: $("#days").val(),
        monthStartDate: $("#monthStartDate").val(),
        monthEndDate: $("#monthEndDate").val(),
        faxdnisvalue: $("#faxdnisvalue").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    }
}

//used to disable the dashboard days textbox for certain channels since days are not used there
function enableordisabledays(tab) {
    if (tab == "email") {
        $("#dashdays").css("display", "");
    }
    if (tab == "chat") {
        $("#dashdays").css("display", "");
    }
    if (tab == "chatbot") {
        $("#dashdays").css("display", "");
    }
    if (tab == "ivr") {
        $("#dashdays").css("display", "");
    }
    if (tab == "sms") {
        $("#dashdays").css("display", "");
    }
    if (tab == "voicecallback") {
        $("#dashdays").css("display", "none");
    }
    if (tab == "chatcallback") {
        $("#dashdays").css("display", "");
    }
    if (tab == "bcmsrealtimequeue") {
        $("#dashdays").css("display", "none");
    }
    if (tab == "chatrealtimequeue") {
        $("#dashdays").css("display", "none");
    }
    if (tab == "emailrealtimequeue") {
        $("#dashdays").css("display", "none");
    }
    if (tab == "customer") {
        $("#dashdays").css("display", "none");
    }
    if (tab == "chatselfservice") {
        $("#dashdays").css("display", "");
    }
    if (tab == "fax") {
        $("#dashdays").css("display", "");
    }
    if (tab == "line") {
        $("#dashdays").css("display", "none");
    }
}

function loadData(tab) {
    //Checking if the tab which is clicked previously and the one that is clicked now are not same
    //This is done so that the kendo components/ajax calls in a channel are not refreshed on the same tab click (multiple) everytime
    if (tab == "email" && $("#previouslyselectedtabvalue").val() != "email") {
        var mailboxevalues = $("#mailboxes").data("kendoMultiSelect");
        var mailboxids = mailboxevalues.value();
        if (mailboxids.length != 0) {
            setDashboardDays();
            $("#mailboxvalues").val(mailboxids.toString());
            getEmailPieChartData();
            getEmailGridData();
            getEmailChartData();
        }
    }
    if (tab == "chat" && $("#previouslyselectedtabvalue").val() != "chat") {
        setDashboardDays();
        getChatDashboardData();
        getChatChartData();
    }
    if (tab == "chatbot" && $("#previouslyselectedtabvalue").val() != "chatbot") {
        setDashboardDays();
        getChatbotDashboardData();
        getChatbotChartData();
    }
    if (tab == "ivr" && $("#previouslyselectedtabvalue").val() != "ivr") {
        var ivrChart = $("#ivrChart").data("kendoChart");
        var ivrdnisvalue = $("#ivrdnis").data("kendoMultiSelect");
        var ivrdnis = ivrdnisvalue.value();
        $("#totalivrcalls").html(0);
        $("#selfServicedCalls").html(0);
        $("#transferredCalls").html(0);
        $("#ivrAHT").html(0);
        $("#sec").css('display', 'none');
        $("#totalTimeSpent").html(0);
        $("#totalCallbacks").html(0);
        ivrChart.dataSource.data("");
        var gauge1 = $("#maxTimeSpentGauge").data("kendoRadialGauge").value("0");
        var gauge2 = $("#averageTimeSpentGauge").data("kendoRadialGauge").value("0");
        $("#ivrMaxTimeSpent").html("");
        $("#ivrAvgTimeSpent").html("");
        if (ivrdnis.length != 0) {
            setDashboardDays();
            $("#ivrdnisvalue").val(ivrdnis.toString());
            //kendo.ui.progress($("#ivrChart"), true);
            $("#ivrMaxTimeSpent").html("");
            $("#ivrAvgTimeSpent").html("");
            getIvrChartData();
            getIvrDashboardData();
        }
    }

    if (tab == "chatselfservice" && $("#previouslyselectedtabvalue").val() != "chatselfservice") {
        var ivrChart = $("#chatselfserviceChart").data("kendoChart");
        var ivrdnisvalue = $("#chatselfservicednis").data("kendoMultiSelect");
        var ivrdnis = ivrdnisvalue.value();
        $("#totalchatselfservice").html(0);
        $("#selfservicedchat").html(0);
        $("#transferredchatself").html(0);
        $("#chatselfserviceAHT").html(0);
        $("#sec").css('display', 'none');
        $("#chatselfservicetotalTimeSpent").html(0);
        $("#totalchatselfserviceCallbacks").html(0);
        ivrChart.dataSource.data("");
        var gauge1 = $("#chatselfservicemaxTimeSpentGauge").data("kendoRadialGauge").value("0");
        var gauge2 = $("#chatselfserviceaverageTimeSpentGauge").data("kendoRadialGauge").value("0");
        $("#chatselfserviceMaxTimeSpent").html("");
        $("#chatselfserviceAvgTimeSpent").html("");
        if (ivrdnis.length != 0) {
            setDashboardDays();
            $("#ivrdnisvalue").val(ivrdnis.toString());
            //kendo.ui.progress($("#ivrChart"), true);
            $("#chatselfserviceMaxTimeSpent").html("");
            $("#chatselfserviceAvgTimeSpent").html("");
            getChatselfserviceChartData();
            getChatselfserviceDashboardData();
        }
    }
    if (tab == "sms" && $("#previouslyselectedtabvalue").val() != "sms") {
        var smsdnisvalue = $("#smsdnis").data("kendoMultiSelect");
        var smsdnis = smsdnisvalue.value();
        $("#smsTransferred").html(0);
        $("#smsConferenced").html(0);
        $("#smsCount").html(0);
        $("#smsAHT").html(0);
        $("#smsSec").css('display', 'none');
        $("#smspercent").css('display', 'none');
        $("#smsFCR").html(0);
        $("#smsarrowdown").css('display', 'none');
        $("#smsarrowup").css('display', 'none');
        var gauge1 = $("#smsgauge1").data("kendoRadialGauge").value("0");
        var gauge2 = $("#smsgauge2").data("kendoRadialGauge").value("0");
        $("#smsMaxTimeToReply").html();
        $("#smsAvgTimeToReply").html();
        //$("#smsSetColor").attr('class', 'text-navy');
        if (smsdnis.length != 0) {
            setDashboardDays();
            $("#smsdnisvalue").val(smsdnis.toString());
            // kendo.ui.progress($("#smsSummaryChart"), true);
            $("#smsMaxTimeToReply").html("");
            $("#smsAvgTimeToReply").html("");
            getSmsChartData();
            getSmsDashboardData();
        }
    }
    if (tab == "voicecallback" && $("#previouslyselectedtabvalue").val() != "voicecallback") {
        getVoiceCallbackDashboardData();
        getVoiceCallbackGridData();
        getVoiceCallbackChartData();
    }
    if (tab == "chatcallback" && $("#previouslyselectedtabvalue").val() != "chatcallback") {
        getChatCallbackDashboardData();
        getChatCallbackGridData();
        getChatCallbackChartData();
    }
    if (tab == "bcmsrealtimequeue" && $("#previouslyselectedtabvalue").val() != "bcmsrealtimequeue") {
        getbcmsDashboardData();
        getBcmsRealTimeGridData();
    }
    if (tab == "chatrealtimequeue" && $("#previouslyselectedtabvalue").val() != "chatrealtimequeue") {
        getChatRealTimeGridData();
        getbcmsChatDashboardData();
    }
    if (tab == "emailrealtimequeue" && $("#previouslyselectedtabvalue").val() != "emailrealtimequeue") {
        getEmailRealTimeGridData();
        getbcmsEmailDashboardData();
    }
    if (tab == "customer" && $("#previouslyselectedtabvalue").val() != "customer") {
        $("#customerSatisfaction").data("kendoChart").dataSource.read();
        $("#customerTouchPoint").data("kendoChart").dataSource.read();
        $("#intentDashboardChart").data("kendoChart").dataSource.read();
        $("#customerSatisfaction").data("kendoChart").refresh();
        $("#customerTouchPoint").data("kendoChart").refresh();
        $("#intentDashboardChart").data("kendoChart").refresh();
    }
    if (tab == "fax" && $("#previouslyselectedtabvalue").val() != "fax") {
        var faxdnisvalue = $("#faxDnis").data("kendoMultiSelect");
        var faxdnis = faxdnisvalue.value();
        $("#faxReceived").html(0);
        $("#faxSent").html(0);
        //$("#faxDnis").html(returneddata[0].FaxDnis);
        $("#faxSentFailed").html(0);
        $("#faxReceiveFailed").html(0);
        $("#faxRoute").html(0);
        $("#faxReceiving").html(0);
        if (faxdnis.length != 0) {
            setDashboardDays();
            $("#faxDnis").val(faxdnis.toString());
            // kendo.ui.progress($("#smsSummaryChart"), true);
            getFaxDashboardData();
            getFaxRealTimeGridData();
        }
    }
    if (tab == "line" && $("#previouslyselectedtabvalue").val() != "line") {
        getLineChartDataOne();
        getLineChartDataTwo();
        getLineChartDataThree();
        getLineChartDataFour();
    }
}

function onDashboardDaysClear(e) {
    //$('#dashboardDaysNumber').data("kendoNumericTextBox").value(1);
    //$("#valueType").data("kendoDropDownList").value("");
    //$("#dashboardStartDate").data("kendoDatePicker").value("");
    //$("#dashboardEndDate").data("kendoDatePicker").value("");
    //$("#dashboardDaysNumber").data("kendoNumericTextBox").wrapper.hide();
    //$("#dashboardStartDate").data("kendoDatePicker").wrapper.hide();
    //$("#dashboardEndDate").data("kendoDatePicker").wrapper.hide();

    $('#dashboardDaysNumber').data("kendoNumericTextBox").value(0)
    $("#day_").prop("checked", true);
    $("#dashboardDaysNumber").data("kendoNumericTextBox").enable(true);
}

function onDashboardDayClick() {
    $("#quickDayWindow").data("kendoWindow").open().center();
    $("#dashboardDaysNumber").data("kendoNumericTextBox").enable(true);
    if ($("#dashboardTimeFrameType").val() == "monthToDate") {
        $('#dashboardDaysNumber').data("kendoNumericTextBox").value(0)
        $("#monthToDate_").prop("checked", true);
        $("#dashboardDaysNumber").data("kendoNumericTextBox").enable(false);
    }
    else if ($("#dashboardTimeFrameType").val() == "days") {
        $('#dashboardDaysNumber').data("kendoNumericTextBox").value($("#days").val())
        $("#day_").prop("checked", true);
        $("#dashboardDaysNumber").data("kendoNumericTextBox").enable(true);
    }
}

function onDashboardSelect() {
    try {
        $("#dashboardSelector").data("kendoWindow").open().center();
    } catch (e) {
        console.log(e);
    }
}

function onDashboardDaysChange(e) {
    var option = $("#valueType").data("kendoDropDownList").value();
    if (option == "days") {
        $("#dashboardDaysNumber").data("kendoNumericTextBox").wrapper.show();
        $("#dashboardStartDate").data("kendoDatePicker").wrapper.hide();
        $("#dashboardEndDate").data("kendoDatePicker").wrapper.hide();
    }
    else if (option == "months") {
        $("#dashboardDaysNumber").data("kendoNumericTextBox").wrapper.hide();
        $("#dashboardStartDate").data("kendoDatePicker").wrapper.show();
        $("#dashboardEndDate").data("kendoDatePicker").wrapper.show();
    }
    else if (option == "") {
        $("#dashboardDaysNumber").data("kendoNumericTextBox").wrapper.hide();
        $("#dashboardStartDate").data("kendoDatePicker").wrapper.hide();
        $("#dashboardEndDate").data("kendoDatePicker").wrapper.hide();
    }
}

function onApplyDashboardDaysSettings(e) {
    var isfalse = true;
    if (setDashboardDays() != false) {
        $("#quickDayWindow").data("kendoWindow").close();
    }
}

//function to set dashboard days whenever show button is clicked or whenever dashboard is refreshed dynamically for an interval
function setDashboardDays() {
   
    var number = $("#dashboardDaysNumber").val();

    if ($("#day_").is(":checked")) {
        if (parseInt(number) > parseInt($("#maximumDashboardDays").val())) {
            console.log(number + " days is greater than the maximum configured limit " + $("#maximumDashboardDays").val() + " days");
            toaster(number + " days is greater than the maximum configured limit of " + $("#maximumDashboardDays").val() + " days", "error");
            $('#dashboardDaysNumber').data("kendoNumericTextBox").value(1);
            return false;
        }
        else {
            $("#days").val(number);
            $("#dashboardTimeFrameType").val("days");
        }
    }
    else if ($("#monthToDate_").is(":checked")) {
        var startDate = moment(moment().startOf('month').format("YYYYMMDD"), 'YYYYMMDD');
        var endDate = moment(moment().format("YYYYMMDD"), 'YYYYMMDD');
        var monthToDays = endDate.diff(startDate, 'days') + 1;

        console.log("months to days: " + monthToDays);
        if (parseInt(monthToDays) > parseInt($("#maximumDashboardDays").val())) {
            console.log(monthToDays + "days is greater than the maximum configured limit " + $("#maximumDashboardDays").val() + " days");
            toaster(monthToDays + "days is greater than the maximum configured limit of " + $("#maximumDashboardDays").val() + " days", "error");
            $('#dashboardDaysNumber').data("kendoNumericTextBox").value(1);
            return false;
        }
        else {
            $("#days").val(monthToDays.toString());
            $("#dashboardTimeFrameType").val("monthToDate");
        }
    }
    else {
        console.log("Nothing is Checked!");
    }
}

function setDashboardContentHeight() {
    /// <summary>
    /// Function to set the panel-body height in dashboard based on the TopNavBar Footer and the tabs height
    /// </summary>

    var windowHeight = $(window).height();
    var topNavBarHeight = $("#topNavigationBar").height();
    var footerHeight = $("#footer").height();
    var dashboardTabHeight = $("#dashboardNavigationTabs").height();

    $('.panel-body').css("height", windowHeight - topNavBarHeight - footerHeight - dashboardTabHeight - 30 + "px");
}

function OnToggleFullscreen() {
    try {
        var icon = this.element.children(".k-icon");
        var dashboardId = this.element.attr("param");
        $("#footer").toggleClass("hidden");
        $("#dashboardSelector").toggleClass("hidden");
        $("#navbarheader").toggleClass("hidden");
        $("#" + dashboardId).toggleClass("dashboard-fullscreen");
        if ($("#" + dashboardId).hasClass("dashboard-fullscreen")) {
            icon.removeClass("k-i-fullscreen");
            icon.addClass("k-i-fullscreen-exit");
        }
        else {
            icon.addClass("k-i-fullscreen");
            icon.removeClass("k-i-fullscreen-exit");
        }
        $("#dashboardSelector").height($(window).height() - $("#navbarheader").height() - $("#footer").height());
        $("#dashboardNavigationTabs").height($("#dashboardSelector").height() - 90);
        $("#dashboardNavigationTabs").css("max-height", $("#dashboardSelector").height() - 90);
        $(".tabs-container").height($(window).height() - $("#navbarheader").height() - $("#footer").height() - 20);
    } catch (e) {
        console.log(e);
    }
}