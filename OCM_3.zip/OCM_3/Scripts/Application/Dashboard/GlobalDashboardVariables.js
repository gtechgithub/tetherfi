﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Dashboard",
        FileName: "GlobalDashboardVariables.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "01-02-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: ""
    });
});
////Email Dashboard Lock Variables
var emailChartLock = false;

////Email Dashboard Lock Variables
var emailGridLock = false;
var emailPieChartLock = false;

////Chat Dashboard Lock Variables
var chatLock = false; 
var chatChartLock = false;

////Chatbot Dashboard Lock Variables
var chatbotLock = false;
var chatbotChartLock = false;

////IVR Dashboard Lock Variables
var ivrLock = false;
var ivrChartLock = false;

////Chat Self-Service Dashboard Lock Variables
var chatselfserviceLock = false;
var chatselfserviceChartLock = false;

////SMS Dashboard Lock Variables
var smsLock = false;
var smsChartLock = false;

////Voice Callback Dashboard Lock Variables
var voiceCallbackLock = false;
var voiceCallbackChartLock = false;
var voiceCallbackGridLock = false;

////Chat Callback Dashboard Lock Variables
var chatCallbackLock = false;
var chatCallbackChartLock = false;
var chatCallbackGridLock = false;

////BCMS Dashboard Lock Variables
var bcmsRealTimeLock = false;
var bcmsRealTimeGridLock = false;

////BCMS Chat Realtime Dashboard Lock Variables
var bcmsChatRealTimeLock = false;
var bcmsChatRealTimeGridLock = false;

////BCMS Chat Realtime Dashboard Lock Variables
var bcmsEmailRealTimeLock = false;
var bcmsEmailRealTimeGridLock = false;

//Variable used for Timeouts (in milliseconds) in all Dashboard components/ajax calls
var timeoutTime = parseInt($("#dashboardTimeoutTime").val());

//Variable used for Timeouts (in milliseconds) in all Real Time Dashboard components/ajax calls
var realtimeoutTime = parseInt($("#realTimedashboardtimeouttime").val());

////Variable used to store for how long Dashboard has been idle
var idleTime = 0;

////Maximum Time till which Dashboard can remain idle
var maxDashboardIdleTime = (parseInt($("#maxDashboardIdleTime").val())) * 60000;

////Maximum Time till which Dashboard can be visible
var maxDashboardVisibleTime = (parseInt($("#maxDashboardVisibleTime").val())) * 60000;

////Variable used in Dashboards to stop further Dashboard Ajax Calls if Dashboard is Idle or Not Visible
var dashboardMasterLock = false;

////Fax Dashboard Lock Variables
var faxRealTimeLock = false;
var faxRealTimeGridLock = false;