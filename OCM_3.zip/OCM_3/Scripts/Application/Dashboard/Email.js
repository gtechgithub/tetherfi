﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Email.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
setTimeout(function () {
    getEmailChartData();
}, Number($("#dashboardTimeoutTime").val()));

setTimeout(function () {
    getEmailGridData();
}, Number($("#dashboardTimeoutTime").val()));

setTimeout(function () {
    getEmailPieChartData();
}, Number($("#dashboardTimeoutTime").val()));

function getEmailPieChartData() {
    var emaildnisvalue = $("#mailboxes").data("kendoMultiSelect").value();
    if (emailPieChartLock == false && $("#selectedtabvalue").val() == "email" && dashboardMasterLock == false) {
        if (emaildnisvalue.length != 0) {
            emailPieChartLock = true;
            console.log("Calling Email Pie Chart Datasource Read!");
            $("#piechart").data("kendoChart").dataSource.read();
        }
    }
}

function getEmailGridData() {
    var emaildnisvalue = $("#mailboxes").data("kendoMultiSelect").value();
    if (emailGridLock == false && $("#selectedtabvalue").val() == "email" && dashboardMasterLock == false) {
        if (emaildnisvalue.length != 0) {
            emailGridLock = true;
            console.log("Calling Email Grid Datasource Read!");
            $("#SLGrid").data("kendoGrid").dataSource.read();
        }
    }
}

function getEmailChartData() {
    var emaildnisvalue = $("#mailboxes").data("kendoMultiSelect").value();
    if (emailChartLock == false && $("#selectedtabvalue").val() == "email" && dashboardMasterLock == false) {
        if (emaildnisvalue.length != 0) {
            emailChartLock = true;
            console.log("Calling Email Chart Datasource Read!");
            $("#chart").data("kendoChart").dataSource.read();
        }
    }
}

function onChartDataBound(arg) {
    //var chart = arg.sender;
    //if (chart.dataSource.total() != 0)
    //{
    //    $("#datatype").val("piepending");
    //    $("#piechart").data("kendoChart").dataSource.read();
    //}
}

function onPieDataBound(e) {
    var view = e.sender.dataSource.view();
    $(".overlay").toggle(view.length === 0);
}

function AHTCheck(averageHandleTime) {
    if (averageHandleTime != null) {
        return averageHandleTime;
    }
    else {
        averageHandleTime = "00:00";
        return averageHandleTime;
    }
}

function SLALimitCheck(SLA, limit, Received, Completed) {
    var percentage = SLA.substring(0, SLA.indexOf('%'));

    if (percentage === 0)
        return "<div class='Kendu-Column-TextAlign-CENTER'>" + SLA + " </div>";

    if (Received > 0 && Completed == 0) {
        return "<div class='Process-Limit-Warning'>" + SLA + " </div>";
    }

    if (percentage >= limit || Received == 0) {
        return "<div class='Kendu-Column-TextAlign-CENTER'>" + SLA + " </div>";
    }
    else {
        return "<div class='Process-Limit-Warning'>" + SLA + " </div>";
    }
}

function onEmailChartRequestEnd() {
    emailChartLock = false;
    setTimeout(function () {
        getEmailChartData();
    }, timeoutTime)
}

function onEmailGridRequestEnd() {
    emailGridLock = false;
    setTimeout(function () {
        getEmailGridData();
    }, timeoutTime)
}

function onEmailPieChartRequestEnd() {
    emailPieChartLock = false;
    setTimeout(function () {
        getEmailPieChartData();
    }, timeoutTime)
}