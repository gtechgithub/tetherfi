﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "VoiceCallback.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
function getVoiceCallbackGridData() {
    if (voiceCallbackGridLock == false && $("#selectedtabvalue").val() == "voicecallback" && dashboardMasterLock == false) {
        voiceCallbackGridLock = true;
        console.log("Calling Voice Callback Dashboard Grid Datasource Read!");
        $("#CallbackGrid").data("kendoGrid").dataSource.read();
    }
}

function getVoiceCallbackChartData() {
    if (voiceCallbackChartLock == false && $("#selectedtabvalue").val() == "voicecallback" && dashboardMasterLock == false) {
        voiceCallbackChartLock = true;
        console.log("Calling Voice Callback Dashboard Chart Datasource Read!");
        $("#callbackSummaryChart").data("kendoChart").dataSource.read();
    }
}

//Function for getting Voice and Chat Callback div dashboard data
function getVoiceCallbackDashboardData() {
    if ($("#selectedtabvalue").val() == "voicecallback" && voiceCallbackLock == false && dashboardMasterLock == false) {
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        voiceCallbackLock == true;
        console.log("Calling Voice Callback Dashboard Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetCallbackDashboardData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null && $("#selectedtabvalue").val() == "voicecallback" && dashboardMasterLock == false) {
                        for (i = 0; i < returneddata.length; i++) {
                            if (returneddata[i].CallbackStatus == "AHT") {
                                if (returneddata[i].Value != "") {
                                    $("#voiceCallbacksAHT").html(returneddata[i].Value);
                                    animatingCounter("#voiceCallbacksAHT");
                                }
                                else {
                                    $("#voiceCallbacksAHT").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "ASSIGNED") {
                                if (returneddata[i].Value != "") {
                                    $("#voiceassignedCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#voiceassignedCallbacks");
                                }
                                else {
                                    $("#voiceassignedCallbacks").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "CLOSED") {
                                if (returneddata[i].Value != "") {
                                    $("#voiceclosedCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#voiceclosedCallbacks");
                                }
                                else {
                                    $("#voiceclosedCallbacks").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "DIAL" || returneddata[i].CallbackStatus == "CALLBACK" || returneddata[i].CallbackStatus == "OPEN") {
                                if (returneddata[i].Value != "") {
                                    $("#voicependingCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#voicependingCallbacks");
                                }
                                else {
                                    $("#voicependingCallbacks").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "SLA") {
                                if (returneddata[i].Value != "") {
                                    $("#voiceaverageSlaTime").html(returneddata[i].Value);
                                    animatingCounter("#voiceaverageSlaTime");
                                }
                                else {
                                    $("#voiceaverageSlaTime").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "Total Callback") {
                                if (returneddata[i].Value != "") {
                                    $("#totalvoiceDashboardCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#totalvoiceDashboardCallbacks");
                                }
                                else {
                                    $("#totalvoiceDashboardCallbacks").html(0);
                                }
                            }
                        }
                    }
                } catch (e) {
                    console.log(e);
                }
                //Setting lock as false since ajax request is complete
                voiceCallbackLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'VoiceCallback'                  
                if ($("#selectedtabvalue").val() == "voicecallback" && voiceCallbackLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getVoiceCallbackDashboardData();
                    }, timeoutTime)
                }
            },
            error: function () {
                console.log('Failed to load Voice Callback dashboard data');
                //Setting lock as false since ajax request is complete
                voiceCallbackLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'VoiceCallback'                  
                if ($("#selectedtabvalue").val() == "voicecallback" && voiceCallbackLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getVoiceCallbackDashboardData();
                    }, timeoutTime)
                }
            }
        });
    }
}

function onVoiceCallbackChartRequestEnd() {
    voiceCallbackChartLock = false;
    if ($("#selectedtabvalue").val() == "voicecallback" && voiceCallbackChartLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getVoiceCallbackChartData();
        }, timeoutTime)
    }
}

function onVoiceCallbackGridRequestEnd() {
    voiceCallbackGridLock = false;
    if ($("#selectedtabvalue").val() == "voicecallback" && voiceCallbackGridLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getVoiceCallbackGridData();
        }, timeoutTime)
    }
}