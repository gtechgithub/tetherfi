﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "globalvar.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 03:45:00 PM",
        LastModifiedBy: "Bhagyashree",
        Description: "Added a varible  'childskilldatasource' for Skill List changes"
    });
});
var sId = 1000;
var sCount = 0;
var sSearched = false;
var sIdVal = new Array();
var sAddedById = new Array();
var sAllow = false;
var formType = "";
var formTemplate = "";
var gridType = "";
var serverData = "";
var set = false;
var openedDrillSearch = false;
var fullScreen = false;
var gridHeight = 0;
var isGraph = false;

var $grid;
var $cell;
var $row;
var row_uid;
var cell_index;
var row_index;

/**
 * variables for checker
 */
var checkerDecisionType;
var windowChecker;
var requestPrevent = 0;

//variable to disable kendo grid auto resize option (0-enable, 1-disable)
//By default it will be enable, to disable just set the variable to 1 in document.ready and call the onDataBound Event in Kendo Grid Event
var enableDisableGridAutoResize = 0;

//Set the names of the report for which Advanced Search and Export Buttons are to be disabled in OCM Report Sidebar comma seperated
var disableAdvancedSearchandExportReportNames = "EmailIntervalReport,AnalysisCountGraphReport,ivrdailyreporturl,OCMAutoDialerCampaignResponseByCountReport,OCMAutoDialerCampaignResponseSummaryReport,OCMAutoDialerCampaignResponseByCentReport";

//variable in the main view to pass json fields  to your java script file
var jsonfields = "";

//Variable to be set in views when grid is inside a tabstrip etc.
var externalHeightForGrid = 0;

//Add extra height to grid if any header is not there
var addExtraHeightForGrid = 0;

//Used to store Javascript file versions
var applicationVersioning = {
    majorVersion: "3.1",
    jsFiles: [],
    jsonFiles: []
};

//variable in the main view to pass channel json fields  to your java script file
var jsonchannlecount = "";

var childdatasource = "";

//Set logged in user
var IsUserLoggedIn = false;

//used to configure admin and report grid page size
var adminpagesize = "50,100,200"
var reportpagesize = "50,100,200"

//used to allow update/delete operations to be allowed in query browser, values can be true/false
var isOperationsAllowedOnTables = true;

//variable in the main view to pass agent feature json fields  to your java script file
var jsonagentfeature = "";

var childfeaturedatasource = "";

var childskilldatasource = "";

var fileExtensionSignatures = {
    "pdf": ["37", "80", "68", "70", "45"],
    "wav": ["82", "73", "70", "70"],
    "html": ["37", "80", "68", "70", "45"],
    "jpg": ["255", "216", "255", "224"],
    "jpeg": ["255", "216", "255", "224"],
    "png": ["137", "80", "78", "71"],
    "tif": ["73", "73", "42", "0"],
    "tiff": ["73", "73", "42", "0"],
    "gif": ["71","73","70","56"],
    "bmp": ["66","77"],
    "ico": ["0", "1"],
    "exe": ["77", "90"]
};


          