﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "OCMReportsSidebar.js",
        Version: "3.2.9.1801",
        LastModifiedDateTime: "14-11-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Advanced search option is hidden when Report type is changed in Autodialer reports "
    });
});

var OCMReportsopened = false;
var OCMReportsclosed = true;

var OCMopened = false;
var OCMclosed = true;

//function used to retrieve the current date
function getCurrentDate() {
    var d = new Date();

    var month = d.getMonth() + 1;
    var day = d.getDate();
    var hour = d.getHours();
    var minutes = d.getMinutes();
    var seconds = d.getSeconds();

    var output = d.getFullYear() +
        (('' + month).length < 2 ? '0' : '') + month +
        (('' + day).length < 2 ? '0' : '') + day + ' ' + hour + minutes + seconds;
    return output;
}

function onExportButtonClick() {
    //toaster("Report Export is Initiated... Notification will be sent once Completed", "success");
    var reportName = $("#reportname").data("kendoDropDownList").value();
    var reportType = $("#reporttype").data("kendoDropDownList").value();
    //var startdate = kendo.toString($("#startdate").data("kendoDateTimePicker").value(), "yyyyMMdd HHmmss");
    var startdate = $("#startdate").val();
    //var enddate = kendo.toString($("#enddate").data("kendoDateTimePicker").value(), "yyyyMMdd HHmmss");
    var enddate = $("#enddate").val();
    //var singledate = kendo.toString($("#singledate").data("kendoDateTimePicker").value(), "yyyyMMdd HHmmss");
    var singledate = $("#singledate").val();

    var agentvalue = null;
    if (reportName.includes("OCMDirectBankingWebChatMIS") == true) {
        var agentfilter = $("#agent").data("kendoMultiSelect");
        agentvalue = agentfilter.value().toString();
    }

    if (reportType == "SingleDate") {
        if (singledate != null && singledate.trim() != "") {
            startdate = singledate.substr(0, 8);
            enddate = singledate.substr(0, 8);
            startdate += " 000000";
            enddate += " 235959";
        }
    }
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'ReportHome/ExportReport',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { "repName": reportName, "repType": reportType, "startDate": startdate, "endDate": enddate, "AgentFilter": agentvalue },
        dataType: "json",
        success: function (returneddata) {
            if (returneddata == true) {
                toaster("Report Export is Initiated... Notification will be sent once Completed", "success");
            }
            else {
                toaster("There is no record to export", "error");
            }
        },
        error: function () { }
    });
}

function onReportNameDataBound() {
    /// <summary>
    /// Function to Display the ReportName in reportNameLbl by replacing once the text/value is bound to the dropdownlist
    /// </summary>
    if ($('#reportNameLbl').length > 0) {
        var name = $("#reportNameLbl").html();
        name = name.replace("ReportName", $("#reportname").data("kendoDropDownList").text().toString());
        $("#reportNameLbl").html(name);
    }
}

function quickSearch(e) {
    /// <summary>
    /// Function to open kendo window on button click
    /// </summary>
    e.preventDefault();
    $("#quickSearchWindow").data("kendoWindow").open().center();
}

function onApplyQuickAccessSettings(e) {
    /// <summary>
    /// Function to apply startdate,enddate and datetype based on Quick Access
    /// </summary>
    /// <param name="e">Contains data related to button</param>

    e.preventDefault();

    var number = $("#number").val();
    var numberType = $("#numberType").data("kendoDropDownList").value();

    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Number");
    fieldNames.push("Type");

    fieldValues.push(number);
    fieldValues.push(numberType);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }

    var edDate = moment().format("YYYYMMDD HHmmss");
    var strtDate;
    var filter = number + numberType;
    console.log("End Date: " + edDate);
    if (filter.indexOf("sec") != -1) {
        strtDate = moment().subtract(filter.split("s")[0], 'seconds').format("YYYYMMDD HHmmss");
    }
    else if (filter.indexOf("min") != -1) {
        strtDate = moment().subtract(filter.split("m")[0], 'minutes').format("YYYYMMDD HHmmss");
    }
    else if (filter.indexOf("hr") != -1) {
        strtDate = moment().subtract(filter.split("h")[0], 'hours').format("YYYYMMDD HHmmss");
    }
    else if (filter.indexOf("day") != -1) {
        strtDate = moment().subtract(filter.split("d")[0], 'days').format("YYYYMMDD HHmmss");
    }
    else if (filter.indexOf("month") != -1) {
        strtDate = moment().subtract(filter.split("m")[0], 'months').format("YYYYMMDD HHmmss");
    }
    else if (filter.indexOf("week") != -1) {
        strtDate = moment().subtract(filter.split("w")[0], 'weeks').format("YYYYMMDD HHmmss");
    }
    else if (filter.indexOf("year") != -1) {
        strtDate = moment().subtract(filter.split("y")[0], 'years').format("YYYYMMDD HHmmss");
    }
    console.log("Start Date: " + strtDate);

    $("#selectDateRange").show();

    $("#reporttype").data("kendoDropDownList").enable(true);
    $("#reporttype").data("kendoDropDownList").value("DateRange");
    $("#selectSingleDate").hide();
    $("#reporttype").data("kendoDropDownList").text();
    $("#startdate").val(strtDate);
    $("#enddate").val(edDate);

    if (reportSearchandExportCheck($("#reportname").data("kendoDropDownList").value())) {
        $("#advanceSearch").show();
    }

    $("#quickSearchWindow").data("kendoWindow").close();
}

function onApplyQuickClear(e) {
    $('#number').data("kendoNumericTextBox").value(null);
    $("#numberType").data("kendoDropDownList").text("Select an Option");
}
function getReportUrl(reportName) {
    /// <summary>
    /// Function to make an ajax call and get the url of the report
    /// </summary>
    /// <param name="report">Contains the name of the report whose URL is to be fetched</param>
    var url = "";
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'ReportHome/GetReportUrl',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { "reportName": reportName },
        async: false,
        dataType: "json",
        success: function (returneddata) {
            console.log(returneddata);
            url = returneddata;
        },
        error: function () { }
    });
    return url;
}

function singleDateConversion(date, reportType) {
    /// <summary>
    /// Function to convert singledate to startDate to endDate
    /// </summary>
    /// <param name="date">Contains the Single Date</param>
    /// <param name="reportType">Contains the Report Type</param>

    var dates;
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'ReportHome/ConvertSingleDateForUrlReport',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { "date": date, "reportType": reportType },
        async: false,
        dataType: "json",
        success: function (returneddata) {
            console.log(returneddata);
            dates = returneddata;
        },
        error: function () { }
    });
    return dates;
}

function reportSearchandExportCheck(reportName) {
    /// <summary>
    /// Function to check if the reports advanced search, export etc. can be enabled (returns false if report is present else true)
    /// </summary>
    /// <param name="reportName">Contains the name of the report to be checked</param>
    if ($('#reportchannel').val().toLowerCase() == "dynamic")
    {
        return false;
    }
    if (reportName == "OCMRoleAccessReport" || reportName == "OCMUserListingReport" || reportName == "OCMAutoDialerCampaignResponseByCountReport" || reportName == "OCMAutoDialerCampaignResponseSummaryReport" || reportName == "OCMAutoDialerCampaignResponseByCentReport" || reportName == "IvrDailyReportUrl" || reportName == "EmailIntervalReport") {
        return false;
    }
    var reports = disableAdvancedSearchandExportReportNames.toLowerCase().split(",");
    if (reports.indexOf(reportName.toLowerCase()) > -1) {
        return false;
    } else {
        return true;
    }
}

function getReportNameForUrl(url, reportName) {
    /// <summary>
    /// Function to append the name of the External report and any other extra parameters before the date is appended
    /// </summary>
    /// <param name="url">Contains the initial url</param>
    /// <param name="reportName">Contains the name of the report</param>

    if (reportName.toLowerCase() == "analysiscountgraphreporturl") {
        url += "AnalysisGraphReport/AnalysisGraphReportView"
    }
    if (reportName.toLowerCase() == "ivrdailyreporturl") {
        url += "RealTime/RealTimeCallFlowView"
    }
    return url;
}

//$('.OCMReports-sidebar-toggle').click(function () {
function onOCMReportsSidebarClick() {
    if (OCMopened) {
        $('.OCM-sidebar-toggle').trigger('click');
    }
    if (!OCMReportsopened) {
        $("body").css({ "overflow": "hidden" });
        if ($(window).width() < 769) {
            $('body').removeClass('canvas-menu');
            $("body").removeClass("mini-navbar");
            var leftNavigationWidth = 0;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCMReports-sidebar").width(sidebarWidth);
        }
        else {
            var leftNavigationWidth = $("#leftSideNav").width() + 1;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCMReports-sidebar").width(sidebarWidth);
            //$("body").addClass("mini-navbar");
        }
        $("#OCMReports-sidebar").css("display", "block");
        $('#OCMReports-sidebar').removeClass('animated fadeOutDownBig');
        OCMReportsopened = true;
        $('#OCMReports-sidebar').addClass('sidebar-open animated fadeInDownBig');
        $("#OCMReportsli").css("background", "#2F4050");
        // $("#sideBarCollapse").fadeOut(600);
        OCMReportsclosed = false;
    }
    else if (!OCMReportsclosed) {
        $("body").css({ "overflow": "auto" });
        if ($(window).width() < 769) {
            $("body").addClass("canvas-menu");
        }
        else {
            //$("body").addClass("mini-navbar");
        }
        $('#OCMReports-sidebar').removeClass('animated fadeInDownBig');
        OCMReportsclosed = true;
        $('#OCMReports-sidebar').addClass('animated fadeOutDownBig');
        $("#OCMReportsli").css("background", "none");
        //$("#sideBarCollapse").fadeIn(200);
        OCMReportsopened = false;
        setTimeout(function () { $("#OCMReports-sidebar").css("display", "none"); }, 500);
    }

    var button = $("#reportname").data("kendoDropDownList");
    var reportName = button.value()
    if (reportName != "") {
        if (reportName == "IvrDailyReportUrl" || reportName == "OCMRoleAccessReport" || reportName == "OCMUserListingReport" || reportName == "OCMAutoDialerNotCalledListReport" || reportName == "EmailIntervalReport" || reportName == "OCMAutoDialerCampaignResponseByCountReport" || reportName == "OCMAutoDialerCampaignResponseSummaryReport" || reportName == "OCMAutoDialerCampaignResponseByCentReport") {
            $("#quickSearchButton").css('display', 'none');
        }

        if (reportSearchandExportCheck(reportName)) {
            isReportReadOnly(reportName);
            $("#advanceSearch").show();
        }
        else {
            $("#exportDiv").css('display', 'none');
            $("#advanceSearch").hide();
        }
    }
}

// Open close right sidebar
//$('.OCM-sidebar-toggle').click(function () {
function onOCMSidebarClick() {
    if ($("#adminInvalidAccess").is(":visible")) {
        //Reload Admin pages again if no access..
        LoadAdminPages();
    }

    if (OCMReportsopened) {
        $('.OCMReports-sidebar-toggle').trigger('click');
    }
    if (!OCMopened) {
        $("body").css({ "overflow": "hidden" });
        if ($(window).width() < 769) {
            $('body').removeClass('canvas-menu');
            $("body").removeClass("mini-navbar");
            var leftNavigationWidth = 0;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCM-sidebar").width(sidebarWidth);
        }
        else {
            //$("body").addClass("mini-navbar");
            var leftNavigationWidth = $("#leftSideNav").width() + 1;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCM-sidebar").width(sidebarWidth);
        }
        $("#OCM-sidebar").css("display", "block");
        $('#OCM-sidebar').removeClass('animated fadeOutDownBig');
        OCMopened = true;
        $('#OCM-sidebar').addClass('sidebar-open animated fadeInDownBig');
        $("#OCMli").css("background", "#2F4050");
        //$("#sideBarCollapse").fadeOut(600);
        OCMclosed = false;
    }
    else if (!OCMclosed) {
        $("body").css({ "overflow": "auto" });
        if ($(window).width() < 769) {
            $("body").addClass("canvas-menu");
        }
        else {
            //$("body").addClass("mini-navbar");
        }
        $('#OCM-sidebar').removeClass('animated fadeInDownBig');
        OCMclosed = true;
        $('#OCM-sidebar').addClass('animated fadeOutDownBig');
        $("#OCMli").css("background", "none");
        //$("#sideBarCollapse").fadeIn(200);
        OCMopened = false;
        setTimeout(function () { $("#OCM-sidebar").css("display", "none"); }, 500);;
    }
}

//function to get report names on selection of report channel
function onChannelNameChange() {
    var reportChannel = $("#reportchannel").data("kendoDropDownList");
    $("#channelvalue").val(reportChannel.toString());
    reportChannel = reportChannel.value(); //get value of report channel
    selectedChannel = reportChannel;
    var button = $("#reportname").data("kendoDropDownList");
    var reporttypebutton = $("#reporttype").data("kendoDropDownList");
    if (reportChannel != "") {
        button.enable(true); //enable report name dropdown

        $("#channelvalue").val(reportChannel.toString()); //to get ivr report names
        button.dataSource.read();
        button.text("Select Report Name");
    }
    else {
        button.dataSource.data("");   //reset the report name datasource
        // button.val("");
        button.text("Select Report Name");
        button.enable(false);        //disable report name dropdown when channel is not selected
        reporttypebutton.enable(false);
        $("#advanceSearch").hide();
        $("#advanced").hide();
        $("#selectSingleDate").hide();
        $("#selectDateRange").hide();
        $("#clearFilterBtnDiv").hide();
    }
    $("#quickSearchButton").css('display', 'none');
}

//set advanced search dropdown when report name is selected in sidebar
function setReportType(reportName) {
    $("#gridTypeValue").val(reportName.toString().toLocaleLowerCase() + "main");
}

//on report name change
function onReportNameChange(e) {
    try {
        if ($('#switch').is(':checked')) {
            switched = true;
            ClearAll();
            $('#switch').trigger("click");
        }
        var dataItem = this.dataItem(e.item);
        if (dataItem.Value != "") {
            if (dataItem.Value == "EmailIntervalReport") {
                $("#reportTypeDropdown").hide();
                $("#selectSingleDate").show();
                $("#advanceSearch").hide();
                $("#selectDateRange").hide();
                $("#reporttype").val("SingleDate");
                $("#reporttype").data("kendoDropDownList").value("SingleDate");
                $("#reportcampdropdown").hide();
                $("#reportagentdropdown").hide();
            }
            else if (dataItem.Value == "IvrDailyReportUrl") {
                $("#reportTypeDropdown").hide();
                $("#selectSingleDate").hide();
                $("#advanceSearch").hide();
                $("#selectDateRange").hide();
                $("#quickSearchButton").css('display', 'none');
                $("#reportcampdropdown").hide();
                $("#reportagentdropdown").hide();
            }
            else if (dataItem.Value == "OCMRoleAccessReport" || dataItem.Value == "OCMUserListingReport") {
                $("#reportTypeDropdown").hide();
                $("#selectSingleDate").hide();
                $("#advanceSearch").hide();
                $("#selectDateRange").hide();
                $("#reporttype").data("kendoDropDownList").value("");
                $('#singledatepicker').data("DateTimePicker").clear();
                $('#enddatepicker').data("DateTimePicker").clear();
                $('#startdatepicker').data("DateTimePicker").clear();
                $("#quickSearchButton").css('display', 'none');
                $("#reportcampdropdown").hide();
                $("#reportagentdropdown").hide();
            }
            else if (dataItem.Value == "OCMAutoDialerNotCalledListReport") {
                $("#reportTypeDropdown").hide();
                $("#selectSingleDate").hide();
                $("#advanceSearch").show();
                $("#selectDateRange").hide();
                $("#reporttype").data("kendoDropDownList").value("");
                $('#singledatepicker').data("DateTimePicker").clear();
                $('#enddatepicker').data("DateTimePicker").clear();
                $('#startdatepicker').data("DateTimePicker").clear();
                $("#quickSearchButton").css('display', 'none');
                $("#reportcampdropdown").hide();
                $("#reportagentdropdown").hide();
            }
            else if (dataItem.Value == "OCMAutoDialerCampaignResponseByCountReport" || dataItem.Value == "OCMAutoDialerCampaignResponseSummaryReport" || dataItem.Value  == "OCMAutoDialerCampaignResponseByCentReport") {
                $("#reportTypeDropdown").show();
                $("#reportcampdropdown").show();
                $("#reportcampid").data("kendoDropDownList").dataSource.read();
                $("#reportcampid").data("kendoDropDownList").enable(true);
                $("#advanceSearch").hide();
                $("#reportagentdropdown").hide();
            }
            else if (dataItem.Value.includes("OCMDirectBankingWebChatMIS") == true) {
                $("#reportTypeDropdown").show();
                $("#reportagentdropdown").show();
                $("#agent").data("kendoMultiSelect").dataSource.read()
                $("#quickSearchButton").css('display', '');
                $("#advanceSearch").show();
            }
            else {
                $("#reportTypeDropdown").show();
                $("#quickSearchButton").css('display', '');
                if ($("#singledate").val() != "" || $("#enddate").val() != "") {
                    $("#advanceSearch").show();
                }
                $("#reportcampdropdown").hide();
                $("#reportagentdropdown").hide();
            }
            $("#reporttype").data("kendoDropDownList").enable(true);
            setReportType(dataItem.Value);
        }
        else {
            $("#reporttype").data("kendoDropDownList").value("");
            $("#selectDateRange").fadeOut();
            $("#selectSingleDate").fadeOut();
            $("#quickSearchButton").css('display', 'none');
            $('#singledatepicker').data("DateTimePicker").clear();
            $('#enddatepicker').data("DateTimePicker").clear();
            $('#startdatepicker').data("DateTimePicker").clear();
            //$("#singledate").data("kendoDateTimePicker").value(null);
            //$("#startdate").data("kendoDateTimePicker").value(null);
            //$("#enddate").data("kendoDateTimePicker").value(null);
            $("#advanceSearch").fadeOut();
            if ($('#switch').is(':checked')) {
                clearAdvancedSearch();
            }
            $("#reporttype").data("kendoDropDownList").enable(false);
        }

        //After a report page is loaded, data will be automatically bound to the dropdowns in Reports Sidebar, so if the report name is changed, check is done to see if advanced search is enabled for that report
        if (dataItem.Value != "") {
            if ($("#reporttype").data("kendoDropDownList").value() != "") {
                if ($("#reporttype").data("kendoDropDownList").value() == "SingleDate") {
                    if ($("#singledate").val() != "") {
                        onDateChange(dataItem.Value);
                    }
                }

                if ($("#reporttype").data("kendoDropDownList").value() == "DateRange") {
                    if ($("#startdate").val() != "" && $("#enddate").val() != "") {
                        onDateChange(dataItem.Value);
                    }
                }
            }
        }
        if (dataItem.Value != "") {
            if (reportSearchandExportCheck(dataItem.Value)) {
                isReportReadOnly(dataItem.Value);
                $("#advanceSearch").show();
            }
            else {
                $("#exportDiv").css('display', 'none');
                $("#advanceSearch").hide();
            }
        }
    } catch (e) {
        console.log(e);
    }
}

//on change of combobox value
function onComboChange(e) {
    try {


        //When using combo box a unique id is set
        switched = true;
        var thisID = this.element.attr("id");
        thisID = thisID.substring(0, 4);
        var dropdown = $("#" + thisID + "Criteria").data("kendoDropDownList");
        dropdown.enable(true);
        var dataItem = this.dataItem(e.item.index());
        var val = dataItem.values.toString().toLocaleLowerCase();
        var text = dataItem.names.toString().toLocaleLowerCase();
        if (text.length >= 5 && text.substring(0, 5) == "total") {
            $("#filterTypeValue").val("number");
        }
        if (val.length >= 4 && val.substring(val.length - 4, val.length) == "time" || val.substring(val.length - 4, val.length) == "edon" || val.substring(val.length - 4, val.length) == "date" || val.substring(val.length - 6, val.length) == "atedat") {
            $("#filterTypeValue").val("datetime");
            var MaskedTextToSearch = $("#" + thisID + "MaskedTextToSearch").data("kendoMaskedTextBox");
            MaskedTextToSearch.enable();
            $("#" + thisID + "MaskedTextToSearch").data("kendoMaskedTextBox").value(null);

            $("#" + thisID + "MaskedTextToSearch").css("display", "inline-block");
            $("#" + thisID + "MaskedTextToSearch").parent().css("display", "inline-block");
            $("#" + thisID + "MaskedTextToSearch").parent().parent().css("display", "inline-block").removeClass("k-state-disabled");


            $("#" + thisID + "TextToSearch").css("display", "none");

            //if ($("#" + thisID + "MaskedTextToSearch").data('kendoMaskedTextBox') != undefined) {
            //    $("#" + thisID + "MaskedTextToSearch").data('kendoMaskedTextBox').destroy();
            //    $("#" + thisID + "MaskedTextToSearch").empty()
            //}
            if (val.substring(val.length - 8, val.length) == "datetime" || val.substring(val.length - 8, val.length) == "hangedon" || val.substring(val.length - 8, val.length) == "eratedon" || val.substring(val.length - 6, val.length) == "atedat") {
                //$("#" + thisID + "MaskedTextToSearch").kendoMaskedTextBox({ mask: " " });
                //$("#" + thisID + "MaskedTextToSearch").kendoMaskedTextBox({ mask: "00/00/0000 00:00:00", clearPromptChar: true });
                MaskedTextToSearch.setOptions({
                    mask: "00/00/0000 00:00:00"
                });
                $("#" + thisID + "MaskedTextToSearch").attr("placeholder", "dd/MM/yyyy HH:mm:ss");

            }
            else if (val.substring(val.length - 4, val.length) == "date")
            {
                MaskedTextToSearch.setOptions({
                    mask: "00/00/0000"
                });
                $("#" + thisID + "MaskedTextToSearch").attr("placeholder", "dd/MM/yyyy");
            }
            else {
                //$("#" + thisID + "MaskedTextToSearch").kendoMaskedTextBox({ mask: " " });
                //$("#" + thisID + "MaskedTextToSearch").kendoMaskedTextBox({ mask: "00:00:00" });
                //$("#" + thisID + "MaskedTextToSearch").attr("placeholder", "00:00:00");
                MaskedTextToSearch.setOptions({
                    mask: "00:00:00"
                });
                $("#" + thisID + "MaskedTextToSearch").attr("placeholder", "HH:mm:ss");
            }
        }
        else {
            $("#filterTypeValue").val("string");
            $("#" + thisID + "TextToSearch").prop("disabled", false).removeClass("k-state-disabled");
            $("#" + thisID + "TextToSearch").val("");

            $("#" + thisID + "MaskedTextToSearch").css("display", "none");
            $("#" + thisID + "MaskedTextToSearch").parent().css("display", "none");
            //$("#" + thisID + "MaskedTextToSearch").parent().parent().css("display", "none");

            $("#" + thisID + "TextToSearch").css("display", "block");
        }

        dropdown.dataSource.read();
    } catch (e) {
        console.log(e);
    }

}

//add criteria for on radio button click
function addCriteria(idValue) {
    try {
        allow = false;
        dynamicSearchFilterCount = dynamicSearchFilterCount + 1;
        id = id + 1;
        refId = refId + 1;
        var append = $("#searchForm");
        var template = $("#searchFormTemplate").html();
        var templateContent = template.replace(/_sc/g, id);
        $(templateContent).appendTo(append);
        setTimeout(function () {
            $("#" + id + "Form").removeClass("animated fadeIn");
        }, 500);
        idVal.push(id);
        $("#" + refId + "logicalRadioGroup").hide();
        $("#" + idValue + "AddButton").hide();
        if (dynamicSearchFilterCount == 1) {
            $("#" + refId + "AddButton").hide();
        }
    } catch (e) {
        console.log(e);
    }
}



//Function used to check if the report is read only or not to enable/disable and return true/false respectively
function isReportReadOnly(reportName) {
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'ReportHome/GetModuleLevelAccess',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "controller": reportName },
            dataType: "json",
            async: true,
            success: function (returneddata) {
                if (returneddata) {
                    $("#exportDiv").css('display', 'inline');
                }
                else
                    $("#exportDiv").css('display', 'none');
            },
            error: function (returneddata) {
                console.log("Error in isReportReadOnly");
            }
        });
    } catch (e) {
        console.log(e);
    }
}

//on report type change
function onReportTypeChange(e) {
    try {
        var dataItem = this.dataItem(e.item);
        if (dataItem.Value == 'SingleDate') {
            $("#selectDateRange").hide();
            $("#selectSingleDate").fadeIn();
        }
        else if (dataItem.Value == 'DateRange') {
            $("#selectSingleDate").hide();
            $("#selectDateRange").fadeIn();
            if ($("#enddate").val() != "") {
                $("#advanceSearch").fadeIn();
            }
            else {
                $("#advanceSearch").hide();
            }
        }
        else {
            $("#selectDateRange").fadeOut();
            $("#selectSingleDate").fadeOut();
            $("#advanceSearch").fadeOut();
            $('#singledatepicker').data("DateTimePicker").clear();
            $('#enddatepicker').data("DateTimePicker").clear();
            $('#startdatepicker').data("DateTimePicker").clear();
            //$("#singledate").data("kendoDateTimePicker").value(null);
            //$("#startdate").data("kendoDateTimePicker").value(null);
            //$("#enddate").data("kendoDateTimePicker").value(null);
            if ($('#switch').is(':checked')) {
                clearAdvancedSearch();
            }
            if ($("#singledate").val() != "") {
                $("#advanceSearch").fadeIn();
            }
            else {
                $("#advanceSearch").hide();
            }
        }
        if ($("#reportname").val() == "OCMAutoDialerCampaignResponseByCountReport" || $("#reportname").val() == "OCMAutoDialerCampaignResponseSummaryReport" || $("#reportname").val() == "OCMAutoDialerCampaignResponseByCentReport") {
            $("#reportcampdropdown").show();
            $("#advanceSearch").hide();
            $("#reportcampid").data("kendoDropDownList").dataSource.read();
            $("#reportcampid").data("kendoDropDownList").enable(true);
        }
    } catch (e) {
        console.log(e);
    }
}

//on date change
function onDateChange(data) {

    var singledate = $("#singledate").val();
    var singledateoutput = singledate.match(/^\d{4}((0\d)|(1[012]))(([012]\d)|3[01]) (2[0-3]|[01][0-9])[0-5][0-9][0-5][0-9]$/);
    if (singledateoutput == null) {
        $("#singledate").val(singledate + " 000000");
    }

    if (reportSearchandExportCheck($("#reportname").val()))
        $("#advanceSearch").fadeIn();
    else
        $("#advanceSearch").hide();

}

//on start date change
function onStartDateChange(e) {
}

//on end date change
function onEndDateChange(e) {

    if (reportSearchandExportCheck($("#reportname").val()))
        $("#advanceSearch").fadeIn();
    else
        $("#advanceSearch").hide();
}

//functions moved from OCMReportSidebar.cshtml
function checkJsonReport(reportName) {

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'OCMReport/IsJsonReport', //'@Url.Action("IsJsonReport", "OCMReport")',
        data: { "reportName": reportName },
        dataType: "json",
        async: false,

        success: function (data) {
            if (data == true) {
                isJsonReport = true;
                // return true;
            }
            else {
                isJsonReport = false;
                // return false;
            }
        },
        error: function () {
            isJsonReport = false;
            //return false;
            console.log('Failed to load');
        }
    });
}



