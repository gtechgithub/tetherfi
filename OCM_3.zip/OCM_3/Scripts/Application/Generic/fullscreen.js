﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "fullscreen.js",
        Version: "3.2.9.20",
        LastModifiedDateTime: "20-09-2019 08:30:00 PM",
        LastModifiedBy: "Shreyas K R",
        Description: "Fixed fullscreen toggle by adding if condition"
    });
});

/**
 * on click of expand ibox grid divison
 */
function fullscreenload(obj) {
    try {
        name = obj.id;
        var ibox = $("#" + name).closest('div.ibox');
        var button = $("#" + name).find('i');
        //if we are expanding but the body has 'fullscreen-ibox-mode' dont toggle
        //this can happen if there are 2 cards on same page
        if (button.hasClass("fa-expand") && !$('body').hasClass('fullscreen-ibox-mode')) {
            $('body').toggleClass('fullscreen-ibox-mode');
        }
        button.toggleClass('fa-expand').toggleClass('fa-compress');
        $('.fas.fa-expand').attr('title', 'Maximize');
        $('.fas.fa-compress').attr('title', 'Restore');
        ibox.toggleClass('fullscreen');
        var totalheight = $(window).height();
        if (!fullScreen) {
            fullScreen = true;
            if (isGraph) {
                $("#graphTree").height(totalheight - 78);
            }
            else {
                $(".k-grid-content").height(totalheight - 48 - 142 - gridHeight - externalHeightForGrid);
            }
            TabResize(0, "", true);
        }
        else {
            fullScreen = false;
            setTimeout(function () {
                TabResize(0, "", true);
                setGridHeight(gridHeight);
            }, 50);
        }
    } catch (e) {
        console.log(e);
    }
}

function TabResize(ext, id, isiBoxTitle) {
    try {
        var totalheight = $(window).height();
        var footer = $("#footer").height();
        var navbar = $(".navbar").height();
        var iBoxTitle = (isiBoxTitle == true) ? $(".ibox-title").height() : 0;
        var tabId = id !== "" && id !== undefined ? "#" + id + " " : ".k-tabstrip";
        var uiheight = $(".k-tabstrip ul").height() == 0 ? 29.1 : $(".k-tabstrip ul").height();
        if (fullScreen !== true) {
            console.log("Resizing Tab: " + (totalheight - footer - navbar - iBoxTitle - 20 - 50 - ext).toString() + "px");
            $(tabId).css("height", (totalheight - footer - navbar - iBoxTitle - 20 - 50 - ext).toString() + "px ");
        }
        else {
            $(tabId).css("height", (totalheight - 48 - 142 - ext).toString() + "px");
        }
        console.log("Resizing Tab Content: " + (totalheight - footer - navbar - iBoxTitle - 20 - 50 - uiheight- 35 - ext).toString() + "px");
        $(tabId + ".k-content").css("height", (totalheight - footer - navbar - iBoxTitle - 20 - 50 - uiheight - 35 - ext).toString() + "px");
    } catch (e) {
        console.log(e);
    }
}