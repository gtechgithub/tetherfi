﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "dynamicsearchapi.js",
        Version: "3.2.8.2",
        LastModifiedDateTime: "02-08-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Fixed an issue where refresh is not working after search"
    });
});

function getReportParams() {
    return {
        reportname: $("#reportNameValue").val(),
        reporttype: $("#reportTypeValue").val(),
        startdate: $("#startDateValue").val(),
        enddate: $("#endDateValue").val(),
        singledate: $("#singleDateValue").val(),
        filtervalue: $("#filterValue").val(),
        innerGridValue: $("#innerGridValue").val(),
        innerFiltervalue: $("#innerFiltervalue").val(),
        innerGridFilterValue: $("#innerGridFilterValue").val(),
        controllerName: $("#ControllerName").val(),
        isExport: $("#isExportValue").val(),
        campFilter: $("#campFilter").val(),
        agentFilter: $("#agentFilter").val(),
        drillGridOneName: $("#drillGridOneName").val(),
        drillGridTwoName: $("#drillGridTwoName").val(),
        drillGridThreeName: $("#drillGridThreeName").val(),
        drillGridInputOne: $("#drillGridInputOne").val(),
        drillGridInputTwo: $("#drillGridInputTwo").val(),
        drillGridInputThree: $("#drillGridInputThree").val(),
        drillGridInputFour: $("#drillGridInputFour").val(),
        filterDate: $("#filterDate").val(),
        interval: $("#intervalTime").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

//to add initial search
function AddSearch(newID, appendDivName, templateName) {
    try {       
        if ($("#" + appendDivName).html() == undefined || $("#" + appendDivName).html().trim() == "") {
            sAddedById = new Array();
            sAllow = false;
            sCount = 0;
            sSearched = false;
            sIdVal = new Array();
            sId = newID + 1;
            var append = $("#" + appendDivName);
            var template = $("#" + templateName).html();
            var templateContent = template.replace(/_ap/g, sId);
            $(templateContent).appendTo(append);
            setTimeout(function () {
                $("#" + sId + "sForm").removeClass("animated fadeIn");
            }, 500);
            sIdVal.push(sId);
            $("#" + sId + "slogicalRadioGroup").hide();
            //$("#" + sId + "sMaskedTextToSearch").css("display", "none");
        }     
    } catch (e) {
        console.log(e);
    }
}
//on combobox value change
function onSComboChange(e) {
    try {
        var thisID = this.element.attr("id");
        thisID = thisID.substring(0, 4);
        var dropdown = $("#" + thisID + "sCriteria").data("kendoDropDownList");
        dropdown.enable(true);
        // if (e.item != null) {
        var dataItem = this.dataItem(e.item.index());
        var val = dataItem.values.toString().toLocaleLowerCase();
        var text = dataItem.names.toString().toLocaleLowerCase();
        if (text.length >= 5 && text.substring(0, 5) == "total") {
            $("#filterTypeValue").val("number");
        }
        if (val.length >= 4 && (val.substring(val.length - 4, val.length) == "time" || val.substring(val.length - 4, val.length) == "edon" || val.substring(val.length - 4, val.length) == "date" || val.substring(val.length - 6, val.length) == "atedat")) {
            $("#filterTypeValue").val("datetime");
            var MaskedTextToSearch = $("#" + thisID + "sMaskedTextToSearch").data("kendoMaskedTextBox");
            MaskedTextToSearch.enable();
            $("#" + thisID + "sMaskedTextToSearch").data("kendoMaskedTextBox").value(null);

            $("#" + thisID + "sMaskedTextToSearch").css("display", "block");
            $("#" + thisID + "sMaskedTextToSearch").parent().css("display", "block");
            $("#" + thisID + "sMaskedTextToSearch").parent().parent().css("display", "block").removeClass("k-state-disabled");

            $("#" + thisID + "sTextToSearch").css("display", "none");

            if (val.substring(val.length - 8, val.length) == "datetime" || val.substring(val.length - 8, val.length) == "hangedon" || val.substring(val.length - 8, val.length) == "eratedon" || val.substring(val.length - 6, val.length) == "atedat") {
                //$("#" + thisID + "sMaskedTextToSearch").kendoMaskedTextBox({ mask: "00/00/0000 00:00:00" });
                MaskedTextToSearch.setOptions({
                    mask: "00/00/0000 00:00:00"
                });

                $("#" + thisID + "sMaskedTextToSearch").attr("placeholder", "dd/MM/yyyy HH:mm:ss");
            }
            else if (val.substring(val.length - 4, val.length) == "date") {
                MaskedTextToSearch.setOptions({
                    mask: "00/00/0000"
                });

                $("#" + thisID + "sMaskedTextToSearch").attr("placeholder", "dd/MM/yyyy");
            }
            else {
                MaskedTextToSearch.setOptions({
                    mask: "00:00:00"
                });

                $("#" + thisID + "sMaskedTextToSearch").attr("placeholder", "HH:mm:ss");
            }
        }
            // //if ($("#" + $("#dynamicSearchParam").val()).data("kendoGrid").dataSource.options.schema.model.fields != null) {
            //else if ($("#" + $("#dynamicSearchParam").val()).data("kendoGrid").dataSource.options.schema.model.fields[dataItem.values.toString()].type == "number") {
            //        $("#filterTypeValue").val("number");
            //        $("#" + thisID + "sTextToSearch").prop("disabled", false).removeClass("k-state-disabled");
            //        $("#" + thisID + "sTextToSearch").val("");

            //        $("#" + thisID + "sMaskedTextToSearch").css("display", "none");
            //        $("#" + thisID + "sMaskedTextToSearch").parent().css("display", "none");
            //        $("#" + thisID + "sMaskedTextToSearch").parent().parent().css("display", "none");

            //        $("#" + thisID + "sTextToSearch").css("display", "block");
            //    }
        else {
            $("#filterTypeValue").val("string");
            $("#" + thisID + "sTextToSearch").prop("disabled", false).removeClass("k-state-disabled");
            $("#" + thisID + "sTextToSearch").val("");

            $("#" + thisID + "sMaskedTextToSearch").css("display", "none");
            $("#" + thisID + "sMaskedTextToSearch").parent().css("display", "none");
            $("#" + thisID + "sMaskedTextToSearch").parent().parent().css("display", "none");

            $("#" + thisID + "sTextToSearch").css("display", "block");
        }
        //}

        dropdown.dataSource.read();
        //}
        //else {
        //    clearSearch();
        //}
    } catch (e) {
        console.log(e);
    }
}

//on change of text to search textbox
function onSTextBoxChange(e) {
    try {
        var inputID = e.id.toString().substring(0, 4);
        var button = $("#" + inputID + "sAddButton").data("kendoButton");
        if ($(e).val()) {
            button.enable(true);
        }
        else {
            button.enable(false);
        }
    } catch (e) {
        console.log(e);
    }
}

//add button to display radio buttons
function SAddButton(e) {
    var buttonID = this.element.attr("id");
    var generalID = buttonID.substring(0, 4);
    $("#" + generalID + "slogicalRadioGroup").fadeIn();
}

//add criteria for on radio button click
function SAddCriteria(idValue) {
    try {
        sAllow = false;
        sCount = sCount + 1;
        sId = sId + 1;
        var append = $("#" + formType);
        var template = $("#" + formTemplate).html();
        var templateContent = template.replace(/_ap/g, sId);
        $(templateContent).appendTo(append);
        setTimeout(function () {
            $("#" + sId + "Form").removeClass("animated fadeIn");
        }, 500);
        sIdVal.push(sId);
        $("#" + sId + "slogicalRadioGroup").hide();
        $("#" + idValue + "sAddButton").hide();
        if (sCount == 1) {
            $("#" + sId + "sAddButton").hide();
        }
    } catch (e) {
        console.log(e);
    }
}
//dynamic search button click
function GridFilterSearch(gridtype, gridname, formName, footerId) {
    try {
        var gridName = $('#dynamicSearchParam').val();
        var idValue = sIdVal[sCount];
        var columnName = $("#" + idValue + "sColumnName").data("kendoComboBox").value();
        var textToSearch = "";
        //var FormatedDate = "";
        //var CurDate = "";
        if (columnName.length >= 4 && columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "time" || columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "edon" || columnName.substring(columnName.length - 6, columnName.length).toLocaleLowerCase() == "atedat" || columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "date") {
            textToSearch = $("#" + idValue + "sMaskedTextToSearch").val();
            //CurDate = getCurrentDate().split(" ", 1)[0];
            //FormatedDate = reformatDate(CurDate);
            //function reformatDate(CurDate) {
            //    return CurDate.substring(6, 8) + "/" + CurDate.substring(4, 6) + "/" + CurDate.substring(0, 4);
            //}
            if ((textToSearch.split(" ", 2)[0] == "__/__/____" && columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "date") || (textToSearch.split(" ", 2)[0] != "__/__/____" && !moment(textToSearch.split(" ", 2)[0], "DD/MM/YYYY", true).isValid() && columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "date")) {
                textToSearch = "";
                toaster("Please enter the right Date", "error");
                $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
                setTimeout(function () {
                    $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
                }, 500);
                return;
            }
           else if ((textToSearch.split(" ", 2)[0] == "__/__/____" && textToSearch.split(" ", 2)[1] < "23:59:59") || (textToSearch.split(" ", 2)[0] != "__/__/____" && textToSearch.split(" ", 2)[1] == "__:__:__") || (textToSearch.split(" ", 2)[0] != "__/__/____" && textToSearch.split(" ", 2)[1] > "23:59:59") ||
                (textToSearch.split(" ", 2)[0] != "__/__/____" && textToSearch.split(" ", 2)[1] > new Date()) || (textToSearch.split(" ", 2)[0] != "__/__/____" && moment(textToSearch, "DD/MM/YYYY H:mm:ss")._d > new Date())) {
                textToSearch = "";
                toaster("Please enter the right Date and Time", "error");
                $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
                setTimeout(function () {
                    $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
                }, 500);
                return;
            }

            //else if ((textToSearch.split(" ", 2)[0] == "__/__/____" && columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "date") || (textToSearch.split(" ", 2)[0] != "__/__/____" && !moment(textToSearch.split(" ", 2)[0], "DD/MM/YYYY", true).isValid() && columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "date"))
            //{
            //    textToSearch = "";
            //    toaster("Please enter the right Date", "error");
            //    $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
            //    setTimeout(function () {
            //        $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
            //    }, 500);
            //    return;
            //}

            //else if (textToSearch.split(" ", 2)[0] != "__/__/____" && textToSearch.split(" ", 2)[0] > new Date()) {
            //    textToSearch = "";
            //    toaster("Please enter the right Date", "error");
            //    $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
            //    setTimeout(function () {
            //        $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
            //    }, 500);
            //    return;
            //}

            //if (textToSearch.split(" ", 2)[1] > "23:59:59" && textToSearch.split(" ", 2)[0] > FormatedDate) {
            //    textToSearch = "";
            //    toaster("Please enter the right Date and Time", "error");
            //    $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
            //    setTimeout(function () {
            //        $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
            //    }, 500);
            //    return;
            //}

            //var reg = /([0-2][0-9]\:[0-5][0-9]\:[0-5][0-9])/;
            //var msg = "Please enter the time in correct format";
           // if (columnName.length >= 8 && columnName.substring(columnName.length - 8, columnName.length).toLocaleLowerCase() == "datetime") {
                //reg = /([0-3][0-9]\-[0-1][0-9]\-[0-9]{4} [0-2][0-9]\:[0-5][0-9]\:[0-5][0-9])/;
                //var msg = "Please enter the datetime in correct format";
           // }
            //if (!(reg.test(textToSearch))) {
            //    toaster(msg, "error");
            //    $("#" + idValue + "sMaskedTextToSearch").addClass('animated shake');
            //    setTimeout(function () {
            //        $("#" + idValue + "sMaskedTextToSearch").removeClass('animated shake');
            //    }, 500);
            //    return false;
            //}
        }
        else {
            textToSearch = $("#" + idValue + "sTextToSearch").val();
        }
        if (columnName == "") {
            toaster("Please select the column name", "error");
            $("#" + idValue + "sComboDiv").addClass('animated shake');
            setTimeout(function () {
                $("#" + idValue + "sComboDiv").removeClass('animated shake');
            }, 500);
            return false;
        }
        else if (textToSearch.trim() == "") {
            toaster("Please enter the text to search or remove the filter", "error");
            $("#" + idValue + "sTextToSearch").addClass('animated shake');
            setTimeout(function () {
                $("#" + idValue + "sTextToSearch").removeClass('animated shake');
            }, 500);
            return false;
        }
        else if (logicalOperatorVal == null) {
            $("#" + idValue + "slogicalRadioGroup").fadeOut();
        }

        var inputToServer = "";
        var serachObject;
        var jsonSearchData = {
            "logic": "",
            "filters": []
        };
        var storepushdata = jsonSearchData.filters;

        for (var i = 0; i < sIdVal.length; i++) {
            var columnNameVal = $("#" + sIdVal[i] + "sColumnName").data("kendoComboBox").value();
            if ($("#" + $("#dynamicSearchParam").val()).data("kendoGrid").dataSource.options.schema.model.fields != null) {
                var datetimecheckval = $("#" + gridname + "").data("kendoGrid").dataSource.options.schema.model.fields[columnNameVal].type;
            }
            var assignmentOperatorVal = $("#" + sIdVal[i] + "sCriteria").val();
            var textToSearchVal;
            if (columnNameVal.substring(columnNameVal.length - 4, columnNameVal.length).toLocaleLowerCase() == "date") {
                if (datetimecheckval == "date") {
                    if ($("#" + sIdVal[i] + "sMaskedTextToSearch").val().trim() == "") {
                        toaster("Please enter the text to search or remove the filter", "error");
                        $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
                        setTimeout(function () {
                            $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
                        }, 500);
                        return;
                    }
                    var textToSearchVal = moment($("#" + sIdVal[i] + "sMaskedTextToSearch").val(), "dd/MM/yyyy")._i;
                }
                else {
                    if ($("#" + sIdVal[i] + "sMaskedTextToSearch").val().trim() == "") {
                        toaster("Please enter the text to search or remove the filter", "error");
                        $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
                        setTimeout(function () {
                            $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
                        }, 500);
                        return;
                    }
                    var textToSearchVal = $("#" + sIdVal[i] + "sMaskedTextToSearch").val();
                }
            }

            else if (columnNameVal.length >= 4 && columnNameVal.substring(columnNameVal.length - 4, columnNameVal.length).toLocaleLowerCase() == "time" || columnName.substring(columnName.length - 4, columnName.length).toLocaleLowerCase() == "edon" || columnName.substring(columnName.length - 6, columnName.length).toLocaleLowerCase() == "atedat") {
                if (datetimecheckval == "date") {
                    if ($("#" + sIdVal[i] + "sMaskedTextToSearch").val().trim() == "") {
                        toaster("Please enter the text to search or remove the filter", "error");
                        $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
                        setTimeout(function () {
                            $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
                        }, 500);
                        return;
                    }
                    var textToSearchVal = moment($("#" + sIdVal[i] + "sMaskedTextToSearch").val(), "DD/MM/YYYY H:mm:ss")._d;
                }
                else {
                    if ($("#" + sIdVal[i] + "sMaskedTextToSearch").val().trim() == "") {
                        toaster("Please enter the text to search or remove the filter", "error");
                        $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
                        setTimeout(function () {
                            $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
                        }, 500);
                        return;
                    }
                    var textToSearchVal = $("#" + sIdVal[i] + "sMaskedTextToSearch").val();
                }

                //msg = "Please enter the time in correct format";
                //var reg = /([0-2][0-9]\:[0-5][0-9]\:[0-5][0-9])/;
                if (columnNameVal.length >= 8 && columnNameVal.substring(columnNameVal.length - 8, columnNameVal.length).toLocaleLowerCase() == "datetime") {
                    //msg = "Please enter the datetime in correct format";
                    //reg = /([0-3][0-9]\-[0-1][0-9]\-[0-9]{4} [0-2][0-9]\:[0-5][0-9]\:[0-5][0-9])/;
                }
                //if (!(reg.test(textToSearchVal))) {
                //    toaster("Please enter the time in correct format", "error");
                //    $("#" + idValue + "sMaskedTextToSearch").addClass('animated shake');
                //    setTimeout(function () {
                //        $("#" + idValue + "sMaskedTextToSearch").removeClass('animated shake');
                //    }, 500);
                //    return false;
                //}
            }
            else {
                if ($("#" + sIdVal[i] + "sTextToSearch").val().trim() == "") {
                    toaster("Please enter the text to search or remove the filter", "error");
                    $("#" + sIdVal[i] + "sTextToSearch").addClass('animated shake');
                    setTimeout(function () {
                        $("#" + sIdVal[i] + "sTextToSearch").removeClass('animated shake');
                    }, 500);
                    return;
                }
                textToSearchVal = $("#" + sIdVal[i] + "sTextToSearch").val();
            }

            var logicalOperatorVal = $("#" + sIdVal[i] + "slogicalRadioGroup input:radio:checked").val() == null ? null : $("#" + sIdVal[i] + "slogicalRadioGroup input:radio:checked").val();
            //inputToServer = inputToServer + columnNameVal + "," + assignmentOperatorVal + "," + textToSearchVal.trim() + "," + logicalOperatorVal + ";";
            if (logicalOperatorVal == null)
                logicalOperatorVal = ""
            serachObject = {
                "logic": logicalOperatorVal,
                "filters": [
                    {
                        "field": columnNameVal,
                        "operator": assignmentOperatorVal,
                        "value": textToSearchVal
                    }]
            };
            storepushdata.push(serachObject);
            storepushdata = serachObject.filters;
        }
        var ds = $("#" + gridname + "").data("kendoGrid").dataSource;
        var dateTimeConfigFormat = $("#DateTimeFormat").val();
        if (columnName.toLocaleLowerCase().indexOf("eratedon") != -1 || columnName.toLocaleLowerCase().indexOf("hangedon") != -1 || columnName.toLocaleLowerCase().indexOf("atedat") != -1) {
            for (var i = 0; i < ds.data().length; i++) {
                ds.data()[i].LastChangedOn = kendo.toString(kendo.parseDate(ds.data()[i].LastChangedOn), dateTimeConfigFormat);
            }
        }
        ds.filter([jsonSearchData
        ]);
        console.log(ds.filter([jsonSearchData
        ]));
        sSearched = true;
        inputToServer = inputToServer.slice(0, -1);
        console.log("inputToServer : " + inputToServer);
        if (gridtype == "main") {
            $("#innerFiltervalue").val(inputToServer);
            $('#searchModel').modal('hide');
            var grid = $("#" + gridname).data("kendoGrid");
            grid.dataSource.read();
        }
        else if (gridtype == "drill") {
            var grid = $("#" + gridname).data("kendoGrid");
            grid.dataSource.data("");
            $("#innerGridFilterValue").val(inputToServer);
            BackToSearch();
            grid.dataSource.read();
        }
        else {
            var grid = $("#" + gridname).data("kendoGrid");
            grid.dataSource.data("");
            $("#innerGridFilterValue").val(inputToServer);
            DynamicBackToSearch(gridtype, formName, footerId);
            grid.dataSource.read();
        }
        if ($("#autoCompleteTextbox").data("kendoAutoComplete") != undefined) {
            $("#autoCompleteTextbox").data("kendoAutoComplete").value("");
        }
    } catch (e) {
        console.log(e);
    }
}

//to clear the ssearch filter
function SCloseButton(e) {
    try {
        var buttonId = $(e.event.target).closest(".k-button").attr("id");
        var ThisId = buttonId.substring(0, 4);
        var index = sIdVal.indexOf(parseInt(ThisId));
        var length = sIdVal.length;
        if (sIdVal.length > 1) {
            if (index > -1) {
                sIdVal.splice(index, 1);
                sAddedById.splice(index, 1);
                $("#" + ThisId + "sForm").fadeOut();
                setTimeout(function () {
                    $("#" + ThisId + "sForm").remove();
                }, 500);
                sCount = sCount - 1;
                length = sIdVal.length;
                var currId = sIdVal[sIdVal.length - 1];
                if (index <= length) {
                    $("#" + currId + "sRadioOR").removeAttr('checked');
                    $("#" + currId + "sRadioAND").removeAttr('checked');
                    $("#" + currId + "slogicalRadioGroup").hide();
                    $("#" + currId + "sAddButton").fadeIn();
                }
            }
        }
        else {
            $("#" + ThisId + "Form").addClass('animated shake');
            setTimeout(function () {
                $("#" + ThisId + "Form").removeClass('animated shake');
            }, 500);
            $("#" + ThisId + "slogicalRadioGroup").hide();
            toaster("Cannot remove this filter!", "error");
        }
        if (sAddedById.length == 1 && sIdVal.length < 2) {
            var currId = sIdVal.length - 1;
            sAddedById = new Array();
        }
        else if (index == length) {
            sAllow = true;
        }
        else {
            sAllow = false;
        }
    } catch (e) {
        console.log(e);
    }
}

//Close main grid filter popup
function closeSearch() {
    //Trigger the closeSearchMain click function since both functionality is same

    $("#" + formType).html('');
    $("#innerGridFilterValue").val("");
    // ClearSearchCriteria("grid");
}

//Clear the search filters and realod the grid with initil data
function ClearSearchCriteria(gridName) {
    try {
        //Checking if search button is clicked
        if (sSearched) {
            sSearched = false;
            //Pass blank to server for the grid reload data with initial data
            //Reload and refresh the grid
            var grid = $("#" + gridName).data("kendoGrid");
            grid.dataSource.read();
        }
        //Setting sCount to 0 for the next round of search
        sCount = 0;
        //Clearing sAddedById array for the next round of search
        sAddedById = new Array();
        //Clearing the exisiting search form division
        setTimeout(function () {
            $("#" + formType).html('');
        }, 500);
        return;
    } catch (e) {
        console.log(e);
    }
}

//Reload the main grid on refresh button click
function ReloadMainGrid() {
    $("#innerFiltervalue").val("");
    $("#autoCompleteTextbox").val("");
    $("#filterdate").val("");
    $("#" + formType).html('');
    ReloadGrid("grid");
}

//Reload the drill grid on drill kendo refresh button click
function ReloadDrillGrid(e) {
    $("#innerGridFilterValue").val("");
    ReloadGrid("drillGrid");
}

function ReloadGrid(type) {
    try {
        /*
          Set the search reference to false in the server
            Reload and the refresh the grid
         */
        $("#" + $('#dynamicSearchParam').val()).data("kendoGrid").dataSource.filter({})
        $("#" + $('#dynamicSearchParam').val()).data("kendoGrid").refresh;
    } catch (e) {
        console.log(e);
    }
}

//on click of clear search
function clearSearch() {
    try {
        //Checking if already searched or the no of filters grater than zero
        //If either of conditon is true then clear all filters
        if (sCount > 0 || sSearched) {
            sSearched = false;
            //Setting sCount to 0 for the next round of search
            sCount = 0;
            //Clearing sAddedById array for the next round of search
            sAddedById = new Array();
            //Clearing id reference array for the next round of search
            sIdVal = new Array();
            //Clearing the exisiting search form division
            $("#" + formType).html('');
            DynamicSearch(gridType);
        }
        else {
            //If not searched once or still working on the first filter don't clear
            //toaster("Cannot remove this filter!", "error");
            $("#" + formType).html('');
            DynamicSearch(gridType);
        }
    } catch (e) {
        console.log(e);
    }
}

function clearInnerSearch(gridName, gridDivName, footerId, searchFormName) {
    try {
        //Checking if already searched or the no of filters grater than zero
        //If either of conditon is true then clear all filters
        if (sCount > 0 || sSearched) {
            sSearched = false;
            //Setting sCount to 0 for the next round of search
            sCount = 0;
            //Clearing sAddedById array for the next round of search
            sAddedById = new Array();
            //Clearing id reference array for the next round of search
            sIdVal = new Array();
            //Clearing the exisiting search form division
            $("#" + formType).html('');
            DoDynamicSearch(gridName, gridDivName, footerId, searchFormName)
        }
        else {
            //If not searched once or still working on the first filter don't clear
            //toaster("Cannot remove this filter!", "error");
            $("#" + formType).html('');
            DoDynamicSearch(gridName, gridDivName, footerId, searchFormName)
        }
    } catch (e) {
        console.log(e);
    }
}

//onclick of search icon on popup grid
function DoDrillInnerSearch(e) {
    try {
        openedDrillSearch = true;
        $("#drillgridDiv").removeClass("animated fadeIn");
        $("#drillgridDiv").addClass("animated fadeOutLeftBig");
        setTimeout(function () {
            $("#drillgridDiv").hide();
            $("#drillgridDiv").removeClass("animated fadeOutLeftBig");
            $("#DrillPopupFooter").fadeIn();
            if (!set) {
                set = true;
                DynamicSearch('drill');
                $("#searchSForm").html('');
            }
            $("#searchDForm").show();
            $("#searchDForm").addClass("animated fadeIn");
        }, 500);
    } catch (e) {
        console.log(e);
    }
}

//BackToSearch for inner grid filter
function BackToSearch() {
    try {
        openedDrillSearch = false;
        $("#searchDForm").removeClass("animated fadeIn");
        $("#searchDForm").addClass("animated fadeOutLeftBig");
        setTimeout(function () {
            $("#DrillPopupFooter").hide();
            $("#searchDForm").hide();
            $("#searchDForm").removeClass("animated fadeOutLeftBig");
            $("#drillGrid").fadeIn();
            $("#drillGrid").addClass("animated fadeIn");
        });
    } catch (e) {
        console.log(e);
    }
}

function DoDynamicSearch(gridName, gridDivName, footerId, searchFormName) {
    try {
        //gridType = '';
        openedDrillSearch = true;
        $("#" + gridDivName).removeClass("animated fadeIn");
        $("#" + gridDivName).addClass("animated fadeOutLeftBig");
        setTimeout(function () {
            $("#" + gridDivName).hide();
            $("#" + gridDivName).removeClass("animated fadeOutLeftBig");
            $("#" + footerId).fadeIn();
            //if (!set) {
            set = true;
            formType = searchFormName;
            DynamicReportInnerSearch(gridName, searchFormName);
            $("#searchSForm").html('');
            // }
            $("#" + searchFormName).show();
            $("#" + searchFormName).addClass("animated fadeIn");
        }, 500);
    } catch (e) {
        console.log(e);
    }
}

function DynamicReloadGrid(name) {
    try {
        var tempReportType = "";
        if ($("#reportNameValue").val() == "AgentSummaryReport" && name == "drillgridSummary") {
            tempReportType = $("#reportTypeValue").val();
            $("#reportTypeValue").val("DateRange");
            $("#" + name).data("kendoGrid").dataSource.filter({})
            $("#" + name).data("kendoGrid").refresh;
            //$("#drillgridSummary").data("kendoGrid").dataSource.filter({
            //    logic: "and",
            //    filters: [
            //        { field: "AgentId", operator: "contains", value: $("#callBackParam").val() }
            //        //{ field: "CreatedDateTime", operator: "isgreaterequal", value: loginDateTime },
            //        //{ field: "CreatedDateTime", operator: "islesserequal", value: logoutDateTime }
            //    ]
            //});
            $("#reportTypeValue").val(tempReportType);
        }
        else if ($("#reportNameValue").val() == "CallWorkReport" || $("#reportNameValue").val() == "OCMDirectBankingWebChatMISReportServiceQualityQuestions" || $("#reportNameValue").val() == "OCMDirectBankingWebChatMISReportServiceQualityChatNature" || $("#reportNameValue").val() == "OCMDirectBankingWebChatMISReportServiceQuality" || $("#reportNameValue").val() =="OCMDirectBankingWebChatMISReportByTimeProductivity")
        {
            $("#innerGridFilterValue").val("");
            $("#searchDForm").html('');
            $("#" + name).data("kendoGrid").dataSource.filter({})
            $("#" + name).data("kendoGrid").refresh;
        }
        else {
            $("#innerGridFilterValue").val("");
            $("#interval").data("kendoComboBox").text("");
            /*
              Set the search reference to false in the server
                Reload and the refresh the grid
             */
            $("#" + name).data("kendoGrid").dataSource.filter({})
            $("#" + name).data("kendoGrid").refresh;
        }
    } catch (e) {
        console.log(e);
    }
}

function DynamicBackToSearch(gridName, formName, footerId) {
    try {
        openedDrillSearch = false;
        $("#" + formName).removeClass("animated fadeIn");
        $("#" + formName).addClass("animated fadeOutLeftBig");
        setTimeout(function () {
            $("#" + footerId).hide();
            $("#" + formName).hide();
            $("#" + formName).removeClass("animated fadeOutLeftBig");
            $("#" + gridName).fadeIn();
            $("#" + gridName).addClass("animated fadeIn");
        });
    } catch (e) {
        console.log(e);
    }
}