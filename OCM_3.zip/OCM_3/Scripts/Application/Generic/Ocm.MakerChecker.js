﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "Ocm.MakerChecker.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreenitha,Shruthi,Prathik",
        Description: "Applied Module hierarchy changes, sendForApproval, revert changes, individual approve/reject"
    });
});
var requestIdList = "";
function onCheckBoxChange(e) {
    var state = $(e).is(':checked');
    var grid = $("#grid").data("kendoGrid");
    var gridData = grid.dataItem($(e).closest("tr"));
    if (state) {
        if (requestIdList == "") {
            requestIdList += gridData.RequestId;
        }
        else {
            requestIdList += "," + gridData.RequestId;
        }
    }
    else {
        requestIdList = requestIdList.replace(gridData.RequestId, '');
        requestIdList = requestIdList.replace(',,', ',');
    }
};

function Checkerfunction(e) {
    try {
        GetSelectedRows(e);
        if ($("#requestId").val() != "") {
            $("#CheckerReason").val('')
            $("#checkerReasonTemplate").show();
            checkerDecisionType = e.event.delegateTarget.id
            windowChecker = $("#myCheckerWindow").data("kendoWindow"); //get the Window widget's instance
            windowChecker.center().open();
        }
    } catch (e) {
        console.log(e);
    }
}

function approveButton() {
    try {
        var Reason = $("#CheckerReason").val();
        if ($.trim(Reason) == "") {
            toaster("Please enter the Checker Approve/Reject Reason", "error");
            return;
        }
        else {
            GetSelectedRows();
            $.ajax({
                url: window.ApplicationPath + 'GenericChecker/' + checkerDecisionType,
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                type: 'POST',
                datatype: 'json',
                data: JSON.stringify({ comments: Reason, requestId: requestIdList, functionality: $("#ControllerName").val(), lastChangedBy: $("#windowsUsername").val() }),
                contentType: "application/json; charset=utf-8",
                success: function (result) {
                    if (checkerDecisionType == "Approve") {
                        if (result[0] != null) {
                            toaster("Record approved successfully. Request ID : " + result[0].replace(/^,|,$/g, ''), "success");
                            $("#requestId").val(result[0].replace(/^,|,$/g, ''));

                        }
                        if (result[1] != null) {
                            toaster("Record approval failed. Request ID : " + result[1].replace(/^,|,$/g, ''), "error");
                        }
                    }
                    else {
                        if (result[0] != null) {
                            toaster("Record rejected successfully. Request ID : " + result[0].replace(/^,|,$/g, ''), "success");
                            $("#requestId").val(result[0].replace(/^,|,$/g, ''));
                        }
                        if (result[1] != null) {
                            toaster("Record rejection failed. Request ID : " + result[1].replace(/^,|,$/g, ''), "error");
                        }
                    }

                    CheckForMakerUpdate();
                },
                error: function (error) {
                }
            })
            windowChecker.close();
        }
    } catch (e) {
        console.log(e);

    }
}

function rejectButton() {
    windowChecker.close();
}

function CheckForMakerUpdate() {
    try {
        var data = {};
        var allFilters = [];
        
        data.functionName = $("#ControllerName").val();
        $.ajax({
            url: window.ApplicationPath + 'GenericChecker/CheckRequestStatus',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            type: 'POST',
            datatype: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(data), // Return a javaScript Error
            success: function (userStatus) {
                if (userStatus.IsMakerChecker) {

                    $("#makeChanges").toggle(userStatus.MakeChanges);
                    $("#sendForApproval").toggle(userStatus.SendToApproval);
                    $("#undoChanges").toggle(userStatus.RevertChanges);
                    $("#Approve").toggle(userStatus.Approve);
                    $("#Reject").toggle(userStatus.Reject);

                    if (userStatus.Approve) {
                        $("#grid").data("kendoGrid").dataSource.filter({ field: "Status", operator: "eq", value: "Approval Pending" })
                    }
                    else {
                        $("#grid").data("kendoGrid").dataSource.filter({})
                    }

                    $("#grid").data("kendoGrid").dataSource.read();

                    requestIdList = "";
                } 
            },
            error: function (result) {
                toaster("Check request status failed", "", "error");
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function LoadInnerGrid(e) {
    try {
        $("#" + formType).html('');
        $('#searchModel').modal('hide');
        $('#dynamicSearchParam').val("drillGrid")
        $('#drillGrid').data('kendoGrid').dataSource.read();
        $("#gridDiv").css("display", "none");
        $("#gridDiv2").css("display", "block");
    } catch (e) {
        console.log(e);
    }
}

function LoadOuterGrid() {
    try {
        $("#" + formType).html('');
        $('#searchModel').modal('hide');
        $('#dynamicSearchParam').val("grid")
        $('#grid').data('kendoGrid').dataSource.read();
        $("#gridDiv").css("display", "block");
        $("#gridDiv2").css("display", "none");
    } catch (e) {
        console.log(e);
    }
}

function clearFilters() {
    $("form.k-filter-menu button[type='reset']").trigger("click");
};


//var myWindow = $("#makerCommentWindow");
//myWindow.kendoWindow({
//    title: "Maker Comments",
//    visible: false,
//    actions: [
//        //"Pin",
//        //"Minimize",
//        //"Maximize",
//        "Close"
//    ]
//});


function SubmitMakerComment() {
    try {
        var makerComment = $("#MakerComments").val();
        if (makerComment.trim() === "") {
            toaster("Please provide maker comments!", "error");
            return;
        }
        else {
            GetSelectedRows();
            var data = {};
            data.comments = makerComment;
            data.requestId = requestIdList; //$("#requestId").val();
            data.lastChangedBy = $("#windowsUsername").val();
            data.functionality = $("#ControllerName").val();
            $.ajax({
                url: window.ApplicationPath + 'GenericChecker/SendToApproval',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                type: 'POST',
                datatype: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(data), // Return a javaScript Error
                success: function (result) {

                    if (result[0] != null) {
                        toaster("Record submission for approval success. Request ID : " + result[0].replace(/^,|,$/g, ''), "success");
                        $("#requestId").val(result[0].replace(/^,|,$/g, ''));

                    }
                    if (result[1] != null) {
                        toaster("Record submission for approval failed. Request ID : " + result[1].replace(/^,|,$/g, ''), "error");
                    }
                    $("#taskCompleteWindow").data("kendoWindow").close();
                    requestIdList = "";
                    CheckForMakerUpdate();
                    LoadOuterGrid();


                    //if (result !== "0") {
                    //    //toaster("Record submission for approval success. Your Request ID is : " + result, "success");
                    //    toaster("Record submission for approval success", "success");
                    //    $("#requestId").val(result);
                    //    $("#taskCompleteWindow").data("kendoWindow").close();
                    //    CheckForMakerUpdate();
                    //    LoadOuterGrid();
                    //}
                    //else {
                    //    toaster("Record submission for approval failed", "error");
                    //    $("#taskCompleteWindow").data("kendoWindow").close();
                    //}
                },
                error: function (result) {
                    toaster("Record submission for approval failed", "error");
                    $("#taskCompleteWindow").data("kendoWindow").close();
                }
            });
        }
        $("#MakerComments").val("");
    } catch (e) {
        console.log(e);
    }
}

function SubmitUndoChangesMakerComment() {
    try {

        var makerComment = $("#undoChangesMakerComments").val();
        if (makerComment.trim() === "") {
            toaster("Please provide maker comments to revert changes!", "error");
            return;
        }
        else {
            GetSelectedRows();
            var data = {};
            data.comments = makerComment;
            data.requestId = requestIdList; //$("#requestId").val();
            data.lastChangedBy = $("#windowsUsername").val();
            data.functionality = $("#ControllerName").val();
            $.ajax({
                url: window.ApplicationPath + 'GenericChecker/RevertChanges',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                type: 'POST',
                datatype: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(data), // Return a javaScript Error
                success: function (result) {

                    if (result[0] != null) {
                        toaster("Record submission for revert changes success. Request ID : " + result[0].replace(/^,|,$/g, ''), "success");
                        $("#requestId").val(result[0].replace(/^,|,$/g, ''));

                    }
                    if (result[1] != null) {
                        toaster("Record submission for revert changes failed. Request ID : " + result[1].replace(/^,|,$/g, ''), "error");
                    }
                    $("#undoChangesWindow").data("kendoWindow").close();
                    requestIdList = "";
                    CheckForMakerUpdate();
                    LoadOuterGrid();
                },
                error: function (result) {
                    toaster("Record submission for revert changes failed", "error");
                    $("#undoChangesWindow").data("kendoWindow").close();
                }
            });
        }
        $("#undoChangesMakerComments").val("");
    } catch (e) {
        console.log(e);
    }
}

function gridRequestEnd(e) {
    try {
        var message = "";
        $('.k-grid-update').css('display', 'inline-block');
        requestPrevent = 0;
        if (e.type === "create") {
            gridRefresh();
            message = e.response.Errors;
            var y = message.hasOwnProperty("Success");
            if (y == true)
                toaster(message.Success.errors[0], "success");
            else
                toaster(message.Failure.errors[0], "error");
        }

        if (e.type === "update") {
            gridRefresh();
            message = e.response.Errors;
            var y = message.hasOwnProperty("Success");
            if (y == true)
                toaster(message.Success.errors[0], "success");
            else
                toaster(message.Failure.errors[0], "error");
        }

        if (e.type === "destroy") {

            gridRefresh();
        }
    } catch (e) {
        console.log(e);
    }
}

function gridRefresh() {
    try {
        var grid = $("#" + $('#dynamicSearchParam').val()).data("kendoGrid");
        grid.dataSource.read();
        CheckForMakerUpdate();
    } catch (e) {
        console.log(e);
    }
}

function TaskComplete(e) {
    GetSelectedRows(e);
    if ($("#requestId").val() != "") {
        $('MakerComments').val();
        $("#taskCompleteWindow").data("kendoWindow").center().open(); //get the Window widget's instance
    }
}

function UndoChanges(e) {
    GetSelectedRows(e);
    if ($("#requestId").val() != "") {
        $('undoChangesMakerComments').val();
        $("#undoChangesWindow").data("kendoWindow").center().open(); //get the Window widget's instance
    }
}

function GetSelectedRows(e) {

    //var reqID = "";
    //var grid = $("#grid").data("kendoGrid");
    //var rows = grid._data;
    //$.each(rows, function (i, r) {
    //    if (r.IsSelected) {
    //        if (i == 0) {
    //            reqID += r.RequestId;
    //        }
    //        else {
    //            reqID += ',' + r.RequestId;
    //        }
    //    }
    //});
    if (requestIdList == "") {
        toaster("Please select records", "error");
        $("#requestId").val("");
        e.preventDefault();
        return false;
    }
    else {
        if (requestIdList.slice(-1) == ',') {
            requestIdList = requestIdList.slice(0, -1);
        }
        if (requestIdList[0] == ',') {
            requestIdList = requestIdList.slice(1);
        }
        $("#requestId").val(requestIdList);
        return true;
    }
}

/**
 * this function is generic for all module grid refresh
 */
function genericRequest(e) {
    try {
        $('.k-grid-update').css('display', 'inline-block');
        var message = "";
        requestPrevent = 0;
        if (e.type === "create") {
            $("#" + $('#dynamicSearchParam').val()).data("kendoGrid").dataSource.read();
            message = e.response.Errors;
            var y = message.hasOwnProperty("Success");
            if (y == true)
                toaster(message.Success.errors[0], "success");
            else
                toaster(message.Failure.errors[0], "error");
        }
        if (e.type === "update") {
            $("#" + $('#dynamicSearchParam').val()).data("kendoGrid").dataSource.read();
            message = e.response.Errors;
            var y = message.hasOwnProperty("Success");
            if (y == true)
                toaster(message.Success.errors[0], "success");
            else
                toaster(message.Failure.errors[0], "error");
        }

        if (e.type === "destroy") {
            $("#" + $('#dynamicSearchParam').val()).data("kendoGrid").dataSource.read();
        }
    } catch (e) {
        console.log(e);
    }
}

function onTaskCompleteClose(e) {
    /// <summary>
    /// Function to clear Maker Comments Textbox when the task Complete Window is Closed
    /// </summary>

    $("#MakerComments").val("");
}

function onUndoChangesClose(e) {
    /// <summary>
    /// Function to clear Maker Comments Textbox when the undo changes Window is Closed
    /// </summary>

    $("#undoChangesMakerComments").val("");
}
