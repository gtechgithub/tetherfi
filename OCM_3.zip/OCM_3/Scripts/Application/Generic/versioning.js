﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "versioning.js",
        Version: "3.1.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Changes done to check major version"
    });
});

/**
 * Store all client side scripts to version manager
 * @param {} versionObj
 *      Structure should be in
 *      {
 *          Location:ModelObj
 *          FileName : xxxx.js
 *          Version : 8.15
 *          LastModifiedDateTime : DateTime
 *          LastModifiedBy: name of the developer who modified this.
 *          Description : short description about changes
 *      }
 * @returns {}
 */
function AddToFileVersionController(versionObj) {
    try {
        var checkmajorVersion = versionObj.Version.split('.');
        var fullVersion = "";
        if (checkmajorVersion.length == 4) {
            fullVersion= versionObj.Version;
        }
        else {
             fullVersion = window.applicationVersioning.majorVersion + "." + versionObj.Version;
        }
        
        // check is this file is already exists ?
        for (let i = 0; i < window.applicationVersioning.jsFiles.length; i++) {
            if (window.applicationVersioning.jsFiles[i].Location === versionObj.Location
                && window.applicationVersioning.jsFiles[i].FileName === versionObj.FileName) {
                window.applicationVersioning.jsFiles.splice(i, 1);
                break;
            }
        }

        // lets push this item again to collection
        window.applicationVersioning.jsFiles.push(versionObj);
        console.log("\n Script Loaded: " + versionObj.Location + "\\" + versionObj.FileName + "\n Script Version: " + fullVersion);
    } catch (exception) {
        console.log(exception);
    }
}

function AddJsonToFileVersionControl(versionObj) {
    try {
        var checkmajorVersion = versionObj.Version.split('.');
        var fullVersion = "";
        if (checkmajorVersion.length == 4) {
            fullVersion = versionObj.Version;
        }
        else {
            fullVersion = window.applicationVersioning.majorVersion + "." + versionObj.Version;
        }
        // check is this file is already exists ?
        for (let i = 0; i < window.applicationVersioning.jsonFiles.length; i++) {
            if (window.applicationVersioning.jsonFiles[i].Location === versionObj.Location
                && window.applicationVersioning.jsonFiles[i].FileName === versionObj.FileName) {
                window.applicationVersioning.jsonFiles.splice(i, 1);
                break;
            }
        }

        // lets push this item again to collection
        window.applicationVersioning.jsonFiles.push(versionObj);
        console.log("\n JSON Loaded: " + versionObj.Location + "\\" + versionObj.FileName + "\n JSON Version: " + fullVersion);
    } catch (exception) {
        console.log(exception);
    }
}

function GetUniqueFileLocation(isScriptFile,isJSONFile) {
    var distinctLocations = [];
    try {
        if (isScriptFile === true) {
            var files = window.applicationVersioning.jsFiles;
            for (let i = 0; i < files.length; i++) {
                if (jQuery.inArray(files[i].Location, distinctLocations) === -1) distinctLocations.push(files[i].Location);
            }
        }
        else if (isJSONFile === true) {
            var files = window.applicationVersioning.jsonFiles;
            for (let i = 0; i < files.length; i++) {
                if (jQuery.inArray(files[i].Location, distinctLocations) === -1) distinctLocations.push(files[i].Location);
            }
        }       
    } catch (exception) {
        console.log(exception);
    }
    return distinctLocations;
}

function GetFileVersions() {
    try {
        //Files
        var scriptFiles = window.applicationVersioning.jsFiles;
        var jsonFiles = window.applicationVersioning.jsonFiles;
        var majorVersion = window.applicationVersioning.majorVersion;

        // Get Unique Locations For Script Files
        var locations = GetUniqueFileLocation(true, false);

        //For Javascript Files
        $("#script-versioning-templates").html("");       
        for (let i = 0; i < locations.length; i++) {
            var t = $("#versioning-main-template").html(), //template divs
                e = $("#script-versioning-templates"), //to be appended before/after/to
                n = Handlebars.compile(t), //initialize handlebars for the template divs
                context = {
                    mainPath: locations[i],
                    subTemplateId: "scriptVersionTemplate" + "-" + i
                }, //add context data
                s = n(context); //execute the template with handlebar and context
            e.append(s);
            for (let j = 0; j < scriptFiles.length; j++) {
                var checkmajorVersion = scriptFiles[j].Version.split('.');
                var versionnumber = "";
                if (checkmajorVersion.length == 4) {
                    versionnumber = scriptFiles[j].Version;
                }
                else {
                    versionnumber = majorVersion + "." + scriptFiles[j].Version;
                }
              
                if (scriptFiles[j].Location === locations[i]) {
                    var t = $("#versioning-sub-template").html(), //template divs
                        e = $("#scriptVersionTemplate" + "-" + i), //to be appended before/after/to
                        n = Handlebars.compile(t), //initialize handlebars for the template divs
                        context = {
                            fileName: scriptFiles[j].FileName,
                            fileVersion: versionnumber
                        }, //add context data
                        s = n(context); //execute the template with handlebar and context
                    e.append(s);
                }
            }
        }

        //For JSON Files
        if (jsonFiles.length > 0) {

            // Get Unique Locations For JSON Files
            locations = GetUniqueFileLocation(false, true);

            $("#json-versioning-none").addClass("hidden");
            $("#json-versioning-templates").removeClass("hidden").html("");            
            for (let i = 0; i < locations.length; i++) {
                var t = $("#versioning-main-template").html(), //template divs
                    e = $("#json-versioning-templates"), //to be appended before/after/to
                    n = Handlebars.compile(t), //initialize handlebars for the template divs
                    context = {
                        mainPath: locations[i],
                        subTemplateId: "jsonVersionTemplate" + "-" + i
                    }, //add context data
                    s = n(context); //execute the template with handlebar and context
                e.append(s);
                for (let j = 0; j < jsonFiles.length; j++) {
                    var checkmajorVersion = jsonFiles[j].Version.split('.');
                    var versionnumber = "";
                    if (checkmajorVersion.length == 4) {
                        versionnumber = jsonFiles[j].Version;
                    }
                    else {
                        versionnumber = majorVersion + "." + jsonFiles[j].Version;
                    }
                    if (jsonFiles[j].Location === locations[i]) {
                        var t = $("#versioning-sub-template").html(), //template divs
                            e = $("#jsonVersionTemplate" + "-" + i), //to be appended before/after/to
                            n = Handlebars.compile(t), //initialize handlebars for the template divs
                            context = {
                                fileName: jsonFiles[j].FileName,
                                fileVersion: versionnumber
                            }, //add context data
                            s = n(context); //execute the template with handlebar and context
                        e.append(s);
                    }
                }
            }
        }
        else {
            $("#json-versioning-none").removeClass("hidden");
            $("#json-versioning-templates").addClass("hidden");
        }
    } catch (exception) {
        console.log(exception);
    }
}