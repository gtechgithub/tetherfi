﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "OCMSidebar.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Fixed IE no access defect"
    });
});

function receiveddata(jsondata) {
    var data = eval(jsondata);
    //Sort The data so that they are displayed in alphabetical order
    data.sort(function (a, b) { return (a.PageName > b.PageName) ? 1 : ((b.PageName > a.PageName) ? -1 : 0); });
    //tabId - used for creating navigation tabs
    var tabId = 1;
    //dataId - used for creating module tabs
    var dataId = 1;
    //tabNameList - contains the list of all uniwue tab names
    var tabNameList = new Array();

    var i = 0;
    //Getting the list of all tabs for which navigation tabs have to be created
    for (j = 0; j < data.length; j++) {
        if (j > 0) {
            if ($.inArray(data[j].TabName, tabNameList) == -1) {
                tabNameList[i] = data[j].TabName;
                i++;
            }
        }
        else {
            tabNameList[i] = data[j].TabName;
            i++;
        }
    }
    var i = 0;
    var containsHome = false;
    for (i = 0; i < tabNameList.length; i++) {
        if (tabNameList[i].toLowerCase() == "home") {
            containsHome = true;
            break;
        }
    }
    if (containsHome == true) {
        tabNameList.splice(i, 1);
        tabNameList.sort();
        tabNameList.splice(0, 0, "Home");
    }
    else {
        tabNameList.sort();
    }
    if (window.sessionStorage) {
        if (sessionStorage.getItem("previouslyselectedtab") == -1 || sessionStorage.getItem("previouslyselectedtab") == null) {
            //Check if tabs are present
            if (tabNameList.length != 0) {
                //creating tabs with count
                var newTabClass = "nav sidenav-tabs navs-" + tabNameList.length;
                for (var tab in tabNameList) {
                    document.getElementById("navTabs").className = newTabClass;
                    if (tabId == 1) {
                        //setting the first tab as active
                        var unorderedListDiv = "<li class='active' style='width:fit-content;display:inline-block;'><a data-toggle='tab' onclick='setLastTabClickedName(" + tabNameList[tab].toString() + ")' style='font-size:medium' href='#tab-" + tabId.toString() + "'>" + tabNameList[tab].toUpperCase() + "</a></li>";
                    }
                    else {
                        var unorderedListDiv = "<li style='width:fit-content;display:inline-block;'><a data-toggle='tab' onclick='setLastTabClickedName(" + tabNameList[tab].toString() + ")' style='font-size:medium' href='#tab-" + tabId.toString() + "'>" + tabNameList[tab].toUpperCase() + "</a></li>";
                    }
                    $("#navTabs").append(unorderedListDiv);
                    //create divs where modules divs will be appended to
                    if (tabId == 1) {
                        var tabDiv = "<div id='tab-" + tabId.toString() + "' class='tab-pane active'><div class='sidebar-message'><div class='wrapper wrapper-content animated fadeIn'><div id='" + tabNameList[tab].toString() + "'></div></div></div></div>";
                    }
                    else {
                        var tabDiv = "<div id='tab-" + tabId.toString() + "' class='tab-pane'><div class='sidebar-message'><div class='wrapper wrapper-content animated fadeIn'><div id='" + tabNameList[tab].toString() + "'></div></div></div></div>";
                    }
                    $("#tabContent").append(tabDiv);
                    tabId++;
                }
            }
            else {
                return false;
            }
        }
        else if (sessionStorage.getItem("previouslyselectedtab") != -1 && sessionStorage.getItem("previouslyselectedtab") != null) {
            //Check if tabs are present
            if (tabNameList.length != 0) {
                //creating tabs with count
                var newTabClass = "nav sidenav-tabs navs-" + tabNameList.length;
                for (var tab in tabNameList) {
                    document.getElementById("navTabs").className = newTabClass;
                    if (sessionStorage.getItem("previouslyselectedtab") == tabNameList[tab].toString()) {
                        var unorderedListDiv = "<li class='active' style='width:fit-content;display:inline-block;'><a data-toggle='tab' onclick='setLastTabClickedName(" + tabNameList[tab].toString() + ")' style='font-size:medium' href='#tab-" + tabId.toString() + "'>" + tabNameList[tab].toUpperCase() + "</a></li>";
                        var tabDiv = "<div id='tab-" + tabId.toString() + "' class='tab-pane active'><div class='sidebar-message'><div class='wrapper wrapper-content animated fadeIn'><div id='" + tabNameList[tab].toString() + "'></div></div></div></div>";
                    }
                    else {
                        var unorderedListDiv = "<li style='width:fit-content;display:inline-block;'><a data-toggle='tab' onclick='setLastTabClickedName(" + tabNameList[tab].toString() + ")' style='font-size:medium' href='#tab-" + tabId.toString() + "'>" + tabNameList[tab].toUpperCase() + "</a></li>";
                        var tabDiv = "<div id='tab-" + tabId.toString() + "' class='tab-pane'><div class='sidebar-message'><div class='wrapper wrapper-content animated fadeIn'><div id='" + tabNameList[tab].toString() + "'></div></div></div></div>";
                    }
                    $("#navTabs").append(unorderedListDiv);
                    $("#tabContent").append(tabDiv);
                    tabId++;
                }
            }
        }
    }

    for (i = 0; i < data.length; i++) {
        //store either controller name or url link in controller variable
        var controller = data[i].PageValue;
        var url = window.ApplicationPath + 'controller/Index'
        //if controller variable contains a url link then we directly store it in url
        if (controller.indexOf("http") != -1) {
            url = controller;
            //Check if the url ends with / if so then we remove it since it acts as an escaping character
            if (!String.prototype.endsWith("/")) {
                if (url.endsWith("-/")) {
                    url = url.slice(0, -1);
                }
            }
        }
        var iconName = data[i].PageName.split("(")[1].slice(0, -1);
        data[i].PageName = data[i].PageName.split("(")[0];
        //create div with module name and append it to the tab to which it belongs
        if (controller.indexOf("http") != -1) {
            var div1 = "<div id='" + data[i].TabName.toString() + dataId.toString() + "' class='col-lg-3 hvr-grow hvr-rectangle-out'> <div class='ibox' ><a href='" + url.replace('controller', controller) + "'><div class='ibox-content' style='padding:5px;height:50px;border-width:0px;'><center><i class='" + iconName + " font-awesome-theme-color' style='float:left;margin-right:10px'></i><h5 class='text-navy' style='color: black;font-weight: 100;font-size: 15px;margin-top:7px;float:left;'>" + data[i].PageName + "</h5 ></center></div></a></div></div>";
        }
        else {
            var div1 = "<div id='" + data[i].TabName.toString() + dataId.toString() + "' class='col-lg-3 hvr-grow hvr-rectangle-out'> <div class='ibox' ><a href=" + url.replace('controller', controller) + "><div class='ibox-content' style='padding:5px;height:50px;border-width:0px;'><center><i class='" + iconName + " font-awesome-theme-color' style='float:left;margin-right:10px'></i><h5 class='text-navy' style='color: black;font-weight: 100;font-size: 15px;margin-top:7px;float:left;'>" + data[i].PageName + "</h5 ></center></div></a></div></div>";
        }
        $("#" + data[i].TabName.toString()).append(div1);
        dataId++;
    }
}

function setLastTabClickedName(name) {
    /// <summary>
    /// Function to set previouslyselectedtab in Session Storage
    /// </summary>
    /// <param name="name"> Contains the name of the tab</param>
    if (name.id != undefined) {
        sessionStorage.setItem("previouslyselectedtab", name.id);
    }
    else
        sessionStorage.setItem("previouslyselectedtab", name);
}

function openAdminModule(type, value) {
    /// <summary>
    /// Function which opens the module in a new page or on the same page
    /// </summary>
    /// <param name="type">Contains newTab if Module has to be opened in a New Tab else none</param>
    /// <param name="value">Contains the Page Value and the Tab Name separated using |</param>
    //store either controller name or url link in controller variable
    var controller = value.split("|")[0];
    var url = window.ApplicationPath + controller + '/Index';
    //if controller variable contains a url link then we directly store it in url
    if (controller.indexOf("http") != -1) {
        url = controller;
        //Check if the url ends with / if so then we remove it since it acts as an escaping character
        if (!String.prototype.endsWith) {
            if (url.endsWith("-/")) {
                url = url.slice(0, -1);
            }
        }
        setLastTabClickedName(value.split("|")[1]);
        if (type == "newTab") {
            window.open(url, "_blank");
        }
        else
            location.href = url;
    }
    else {
        setLastTabClickedName(value.split("|")[1]);
        if (type == "newTab") {
            window.open(url, "_blank");
        }
        else
            location.href = url;
    }
}

function enterModule(e) {
    /// <summary>
    /// Function to trigger combobox select event when enter is clicked in the combobox
    /// </summary>
    /// <param name="e"></param>
    //e.preventDefault();
    if (e.keyCode == 13) {
        //alert("Inside");
        $("#moduleSelector").data("kendoComboBox").trigger("select");
    }
}

function LoadAdminPages() {
    try {
        $.ajax({
            url: window.ApplicationPath + 'ReportHome/GetAdminPages',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            type: "POST",
            data: JSON.stringify({
                'type': ''
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data.length != 0) {
                    $("#moduleSelector").data("kendoComboBox").dataSource.read({ type: "combobox" });
                    $("#adminLoadingAccess").css('display', 'none');
                    $("#navTabs").css('display', 'inline-block');
                    $("#comboAdminList").css('display', '');
                    $("#adminInvalidAccess").css('display', 'none');
                    receiveddata(data);
                }
                else {
                    $("#adminInvalidAccess").css('display', 'block');
                    $("#navTabs").css('display', 'none');
                    $("#comboAdminList").css('display', 'none');
                    $("#adminLoadingAccess").css('display', 'none');
                }
            },
            error: function () {
                console.log('Failed to load admin tabs');
                $("#adminInvalidAccess").css('display', 'block');
                $("#adminLoadingAccess").css('display', 'none');
                $("#navTabs").css('display', 'none');
                $("#comboAdminList").css('display', 'none');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function onComboBoxModuleSelect(e) {
    /// <summary>
    /// Function to redirect to a page/url when an item is selected in the combobox
    /// </summary>
    /// <param name="e"> Contains the item to navigate to</param>
    //if (e.sender.value()=="") {
    //    e.preventDefault();
    //    return;
    //}
    if (String.fromCharCode(event.which) == "&" || String.fromCharCode(event.which) == "(") {
        //Do Nothing when up and down arrows are clicked for scrolling
    }
    else {
        swal("Confirm to Navigate to " + e.sender.text() + " Module?", "", {
            icon: "warning",
            buttons: {
                cancel: "Cancel",
                catch: {
                    text: "Open in New Tab",
                    value: "newTab",
                },
                defeat: {
                    text: "Open Here",
                    value: "new",
                }
            },
        })
            .then(function (value) {
                switch (value) {
                    case "new":
                        openAdminModule("none", e.sender.value());
                        break;

                    case "newTab":
                        openAdminModule("newTab", e.sender.value());
                        break;
                }
            });
    }
}