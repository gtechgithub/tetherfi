﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "validation.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 08:30:00 AM",
        LastModifiedBy: "Prathik,Shruthi",
        Description: "Model validation for dropdown select value"
    });
});
/**
 * Validates if the Modify reason is entered or not.
 */
function modifyValid(e) {
    try {
        var currentModifyReason = e.model.ModifyReason;
        if (e.model.isNew() == false) {
            if ($.trim(currentModifyReason) == "" || $.trim(currentModifyReason) == null) {
                e.preventDefault();
                toaster("Please enter the modify reason", "error");
                return;
            }
        }
    } catch (e) {
        console.log(e);
    }
}

/**
 * Validates if the Org. Unit reason is entered or not.
 */
function validateOrgUnit(e) {
    try {
        if ($("#ModuleHierachy").val().toLowerCase() == "true") {
            var orgUnit = e.model.OrgUnit;
            if (e.model.isNew() == false) {
                if ($.trim(orgUnit) == "" || $.trim(orgUnit) == null) {
                    e.preventDefault();
                    toaster("Please choose the Org. Unit", "error");
                    return;
                }
            }
        }
    } catch (e) {
        console.log(e);
    }
}

function alphanumericonly(event) {
    try {
        var keycode;
        keycode = event.keyCode ? event.keyCode : event.which;
        if ((keycode == 32) || (keycode >= 47 && keycode <= 57) || (keycode >= 65 && keycode <= 90) || (keycode >= 97 && keycode <= 122)) {
            return true;
        }
        else {
            return false;
        }
        return true;
    } catch (e) {
        console.log(e);
    }
}

/**used for prevent two request on save*/
function requestPreventData(e) {
    $('.k-grid-update').css('display', 'none');
    requestPrevent = 1;
}

function popMedia(url) {
    window.open(url, "wav", "width=400,height=400");
}

function valAlpha(e) {
    try {
        var keyCode = (e.which) ? e.which : e.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32 || keyCode == 13)
            return false;
        return true;
    } catch (e) {
        console.log(e);
    }
}

/**
 * Validate the export to excel if its null.
 */
function validateExportExcel(arg) {
    try {
        var grid = arg.sender;
        if ($("#isExportValue").val() == "true") {
            $('#isExportValue').val("false");
            arg.preventDefault();
            return;
        }
        if (grid.dataSource.total() == 0) {
            arg.preventDefault();//prevents the excel from exporting
            toaster("There is no record to export", "error");
            //$('#export1').val("false");
            $('#isExportValue').val("false");
            return;
        }
        if (arg.data.length > 0) {
            for (i = 0; i < arg.workbook.sheets[0].rows[0].cells.length; i++) {
                //Logic to set all columns autowidth to true
                //arg.workbook.sheets[0].columns[i].width = 250;
                if ($("#reportNameValue").val() != "") {
                    if (arg.workbook.sheets[0].rows[0].cells[i].value.replace(/ /g, '').toLocaleLowerCase().indexOf('datetime') > -1 || arg.workbook.sheets[0].rows[0].cells[i].value.replace(/ /g, '').toLocaleLowerCase().indexOf('actiontime') > -1 || arg.workbook.sheets[0].rows[0].cells[i].value.replace(/ /g, '').toLocaleLowerCase().indexOf('date&time') > -1) {
                        for (j = 1; j < arg.workbook.sheets[0].rows.length; j++) {
                            try {
                                if (arg.workbook.sheets[0].rows[j].cells[i].value.toLocaleDateString() == "1/1/1") {
                                    arg.workbook.sheets[0].rows[j].cells[i] = "";
                                }
                                else {
                                    arg.workbook.sheets[0].rows[j].cells[i].format = $("#DateTimeFormat").val();
                                    arg.workbook.sheets[0].rows[j].cells[i].value = checkGridDateTime(arg.workbook.sheets[0].rows[j].cells[i].value);
                                }
                            } catch (e) {
                                console.log(e);
                            }
                        }
                    }
                }
                else {
                    if (arg.workbook.sheets[0].rows[0].cells[i].value != undefined && arg.workbook.sheets[0].rows[0].cells[i].value != "" && arg.workbook.sheets[0].rows[0].cells[i].value != null) {
                        if (arg.workbook.sheets[0].rows[0].cells[i].value.replace(/ /g, '').toLocaleLowerCase().indexOf('lastchangedon') > -1 || arg.workbook.sheets[0].rows[0].cells[i].value.replace(/ /g, '').toLocaleLowerCase().indexOf('reportgeneratedon') > -1 || arg.workbook.sheets[0].rows[0].cells[i].value.replace(/ /g, '').toLocaleLowerCase().indexOf('date') > -1 || arg.workbook.sheets[0].rows[0].cells[i].value.replace(/ /g, '').toLocaleLowerCase().indexOf('datetime') > -1) {
                            for (j = 1; j < arg.workbook.sheets[0].rows.length; j++) {
                                try {
                                    if (arg.workbook.sheets[0].rows[j].cells[i].value.toLocaleDateString() == "1/1/1") {
                                        arg.workbook.sheets[0].rows[j].cells[i] = "";
                                    }
                                    else {
                                        arg.workbook.sheets[0].rows[j].cells[i].format = $("#DateTimeFormat").val();
                                        arg.workbook.sheets[0].rows[j].cells[i].value = checkGridDateTime(arg.workbook.sheets[0].rows[j].cells[i].value);
                                    }
                                } catch (e) {
                                    console.log(e);
                                }
                            }
                        }
                    }
                }
                $('#isExportValue').val("false");
            }
        }
    } catch (e) {
        console.log(e);
    }
}
function onAutoCompleteSelect(e) {
    var fieldValue = this.options.dataTextField;
    var filterValue = e.dataItem[fieldValue];
    if (e.sender._oldText == "") {
        $("#grid").data("kendoGrid").dataSource.filter({});
    } else {
        $("#grid").data("kendoGrid").dataSource.filter({ operator: "contains", field: this.options.dataTextField, value: filterValue });
    }
}

function onAutoCompleteChange(e) {
    if (e.sender._oldText == "") {
        $("#grid").data("kendoGrid").dataSource.filter({});
    }
}

/**
 * Validate Profile of Agent Setting
 */
function Profilevalid() {
    try {
        var Profile = $("#Profile").val();
        var dropdownlist = $("#SupervisorID").data("kendoDropDownList");
        if (Profile == "Supervisor") {
            dropdownlist.dataSource.add({ "Text": "NA", "Value": "0" });
            dropdownlist.value(0);

            dropdownlist.enable(false);
        }
        else {
            dropdownlist.enable(true);
            var NA = dropdownlist.dataSource.get(NA);
            dropdownlist.dataSource.remove(NA);
        }
    } catch (e) {
        console.log(e);
    }
}

function getTooltipContentEdit(e) {
    var row = e.target.closest("tr");
    var grid = $("#grid").getKendoGrid();
    var item = grid.dataItem(row);
    return "Edit";
}

function getTooltipContentDelete(e) {
    var row = e.target.closest("tr");
    var grid = $("#grid").getKendoGrid();
    var item = grid.dataItem(row);
    return "Delete";
}

function getTooltipContentDownload(e) {
    var row = e.target.closest("tr");
    var grid = $("#grid").getKendoGrid();
    var item = grid.dataItem(row);
    return "Download";
}

function getTooltipContentDelete(e) {
    var row = e.target.closest("tr");
    var grid = $("#grid").getKendoGrid();
    var item = grid.dataItem(row);
    return "Delete";
}

function getTooltipContentVideoPlayer(e) {
    var row = e.target.closest("tr");
    var grid = $("#grid").getKendoGrid();
    var item = grid.dataItem(row);
    return "Video Preview";
}

function validateBlankFields(fieldName, fieldValue) {
    /// <summary>
    /// Function to validate if any of the fields are blank or not
    /// </summary>
    /// <param name="fieldName">Array containing names of all fields</param>
    /// <param name="fieldValue">Array containing values of all fields in order of field names</param>
    /// <returns type="string">names of the fields which are comma seperated if their corresponding values are blank else returns blank</returns>
    try {
        var result = "";
        for (i = 0; i < fieldName.length; i++) {
            if (String(fieldValue[i]).trim() == "" || fieldValue[i] == undefined || String(fieldValue[i]).trim().toLowerCase() == "select") {
                result += fieldName[i] + ", ";
            }
        }
        result = result.slice(0, -2);
        return result;
    } catch (e) {
        console.log(e);
    }
}
/**
 * Reusable validation for duplicate records
 */
function duplicateValidate(e, name, message) {
  
    var currentTeamName = e.model[name] === null ? "" : e.model[name].toString();
    var currentID = e.model.uid;
    var count = 0;
    var id = e.sender.element[0].id;
    var data = $('#' + id).data('kendoGrid').dataSource._data;
    item = data.length;
    for (t in data) {
        if (isNaN(t)) {
            return;
        }
        if (data[t].value == undefined) {
            if (data[t][name] === null) {
                continue;
            }
            if (data[t][name].toString().toLowerCase() == currentTeamName.toLowerCase()) {
                count++;
                if (count == 2) {
                    e.preventDefault();
                    toaster("Duplicate " + message, "error");
                    return;
                }
            }
            if (data[t][name].toString().toLowerCase() == currentTeamName.toLowerCase() &&
                data[t].uid != currentID) {
                e.preventDefault();
                toaster("Duplicate " + message, "error");
                return;
            }
        }
        else {
            if (data[t].items[0][name].toString().toLowerCase() == currentTeamName.toLowerCase()) {
                count++;
                if (count == 2) {
                    e.preventDefault();
                    toaster("Duplicate " + message, "error");
                    return;
                }
            }
        }
    }
}

function checkGridDateTime(DateTime) {
    /// <summary>
    /// Generic Function which converts the datetime to the format specified in web.config and if it is minimum date it will display blank
    /// </summary>
    /// <param name="DateTime">Datetime which has to be validated</param>
    var minimumDate = moment.utc("0001-01-01");
    //  if (moment.utc(DateTime).isAfter(minimumDate)) {
    if (moment.utc(DateTime) > minimumDate) {
        var configuredDate = $("#DateTimeFormat").val();
        return kendo.toString(kendo.parseDate(DateTime, configuredDate), configuredDate)
    }
    else {
        return "";
    }
}

function EncodeUrl(url) {
    try {
        //if (url.indexOf("!"))
        //    url = url.replace(/!/g, '%21');
        if (url.indexOf("#"))
            url = url.replace(/#/g, '%23');
        //if (url.indexOf("$"))
        //    url = url.replace(/$/g, '%24');
        //if (url.indexOf("&"))
        //    url = url.replace(/?/g, '%26');
        //if (url.indexOf("'"))
        //    url = url.replace(/'/g, '%27');
        //if (url.indexOf("("))
        //    url = url.replace(/\(/g, '%28');
        //if (url.indexOf(")"))
        //    url = url.replace(/\)/g, '%29');
        //if (url.indexOf("*"))
        //    url = url.replace(/\*/g, '%2A');
        //if (url.indexOf("+"))
        //    url = url.replace(/\+/g, '%2B');
        //if (url.indexOf(","))
        //    url = url.replace(/,/g, '%2C');
        //if (url.indexOf("/"))
        //    url = url.replace(/\//g, '%2F');
        //if (url.indexOf(":"))
        //    url = url.replace(/:/g, '%3A');
        //if (url.indexOf(";"))
        //    url = url.replace(/;/g, '%3B');
        //if (url.indexOf("="))
        //    url = url.replace(/=/g, '%3D');
        //if (url.indexOf("?"))
        //    url = url.replace(/\?/g, '%3F');
        //if (url.indexOf("@"))
        //    url = url.replace(/@/g, '%40');
        //if (url.indexOf("["))
        //    url = url.replace(/\[/g, '%5B');
        //if (url.indexOf("]"))
        //    url = url.replace(/]/g, '%5D');

        return url;
    } catch (e) {
        console.log(e)
    }
}