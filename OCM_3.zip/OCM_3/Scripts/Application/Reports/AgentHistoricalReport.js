﻿function onClickOfMainGrid(arg) {

    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_uid = $row.attr('data-uid'); //uid of selected row
    var cell_index = $cell.index(); //cell index 0 based
    var row_index = $row.index(); //row index 0 based
    var agentID = $grid.dataItem($row).AgentId;
    var agentName = $grid.dataItem($row).AgentName;
    var colName = $("#grid").find('th').eq(cell_index).text();//selected column name
    var menuGrid = $("#menuGrid").data("kendoGrid");
    var date1 = $("#filterdate").val();
    var date;

    var intervalDropdownTime = $("#AgentSkillBcmsReportIntervalDropdown").val();
    var startTime = "00:00";
    var intLoopCount = 0;
    var addTime;
    var addParameter = '';
    $("#interval").data("kendoComboBox").dataSource.data([]);
    if (intervalDropdownTime.indexOf("h") > -1) {
        addParameter = 'hours';
        addTime = parseInt(intervalDropdownTime.split("h")[0]);
    }
    else if (intervalDropdownTime.indexOf("m") > -1) {
        addParameter = 'minutes';
        addTime = parseInt(intervalDropdownTime.split("m")[0]);
    }
    for (startTime; moment(startTime, 'HH:mm').isBefore(moment("23:59", 'HH:mm')); startTime = kendo.toString(moment(startTime, "HH:mm").add(addTime, addParameter)._d, "HH:mm")){
        if (intLoopCount != 0 && startTime === "00:00") break;

        if (startTime.startsWith("0")) startTime = startTime.substring(1);
        if (startTime.split(":")[1].startsWith("0") && startTime.split(":")[1] != "00") startTime = startTime.split(":")[0] + ":" + startTime.split(":")[1].substring(1);

        var toStartTime = kendo.toString(moment(startTime, "HH:mm").add(addTime, addParameter)._d, "HH:mm").toString();
        if (toStartTime.startsWith("0")) toStartTime = toStartTime.substring(1);
        if (toStartTime.split(":")[1].startsWith("0") && toStartTime.split(":")[1] != "00") toStartTime = toStartTime.split(":")[0] + ":" + toStartTime.split(":")[1].substring(1);

        var endTime = startTime.toString() + "-" + kendo.toString(moment(startTime, "HH:mm").add(addTime, addParameter)._d, "HH:mm").toString();
        var endTime1 = endTime.split("-")[0];
        var endTime2 = endTime.split("-")[1];
        if (endTime1.startsWith("0") && endTime1.split(":")[1] != "00") endTime1 = endTime1.substring(1);
        if (endTime1.split(":")[1].startsWith("0") && endTime1.split(":")[1] != "00") endTime1 = endTime1.split(":")[0] + ":" + endTime1.split(":")[1].substring(1);
        if (endTime2.startsWith("0") && endTime2.split(":")[1] != "00") endTime2 = endTime2.substring(1);
        if (endTime2.split(":")[1].startsWith("0") && endTime2.split(":")[1] != "00") endTime2 = endTime2.split(":")[0] + ":" + endTime2.split(":")[1].substring(1);

        $("#interval").data("kendoComboBox").dataSource.add({ text: (startTime.toString() + "-" + toStartTime).trim(), value: endTime1 + "-" + endTime2.trim() });
        intLoopCount++;
    }

    menuGrid.dataSource.data("");
    if (selectedData != 0) {
        $("#callBackParam").val(agentID);
        $("#filterDate").val(date1);
        $("#mainMenuReportNameLbl").html("<h2>Agent Historical Detailed Report</h2><h4>OCM Reports > Agent > Agent Historical Report > Agent Historical Detailed Report<span id='date'></span></h4>Historical Report of AgentId: <span class='theme-color'>" + agentID);
        if ($("#reportTypeValue").val() == "DateRange") {
            if (date1 == "") {
                var startDate = $("#startDateValue").val();
                var yy = startDate.substr(0, 4);
                var mm = startDate.substr(4, 2);
                var dd = startDate.substr(6, 2);
                var formattedStartDate = dd + "-" + mm + "-" + yy;

                var endDate = $("#endDateValue").val();
                var yy = endDate.substr(0, 4);
                var mm = endDate.substr(4, 2);
                var dd = endDate.substr(6, 2)
                var formattedEndDate = dd + "-" + mm + "-" + yy;

                date = " from " + formattedStartDate + " to " + formattedEndDate;
            }
            else {
                var singleDate = date1
                var yy = singleDate.substr(0, 4);
                var mm = singleDate.substr(4, 2);
                var dd = singleDate.substr(6, 2);
                var formattedSingleDate = dd + "-" + mm + "-" + yy;
                date = " on " + formattedSingleDate;

            }

        }
        if ($("#reportTypeValue").val() == "SingleDate") {
            var singleDate = $("#singleDateValue").val();
            var yy = singleDate.substr(0, 4);
            var mm = singleDate.substr(4, 2);
            var dd = singleDate.substr(6, 2);
            var formattedSingleDate = dd + "-" + mm + "-" + yy;
            date = " on " + formattedSingleDate;

        }
        $("#date").html(date);
        menuGrid.dataSource.read();
        $('#popupMainDrill').modal('show');
        $("#gridDivSearch").show();
        $("#DrillPopupFooter").hide();
        $("#searchDForm").hide();
    }
    if (selectedData == 0) {
        toaster("There are no records to popup", "info");
        return;
    }
}



function onChange(arg) {

    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_uid = $row.attr('data-uid'); //uid of selected row
    var cell_index = $cell.index(); //cell index 0 based
    var row_index = $row.index(); //row index 0 based
    var agentID = $grid.dataItem($row).AgentId; //selected row data
    var agentName = $grid.dataItem($row).AgentName;
    var loginDateTime = $grid.dataItem($row).DateInt;
    //loginDateTime = parseInt(loginDateTime);
    //var logoutDateTime = $grid.dataItem($row).LogoutDateTime;
    //loginDateTime = parseInt(logoutDateTime);
    var datetime;
    var drillgrid = $("#drillgrid").data("kendoGrid");
    var intv = $("#interval").val();
    drillgrid.dataSource.data("");
    $("#callBackParam").val(agentID);
    $("#loginDateTimeValue").val(loginDateTime);
    $("#intervalTime").val(intv);
    $("#DrillReportNameLbl").html("<h2>Agent Historical Report</h2><h4>OCM Reports > Agent > Agent Historical Report <span id='datetime'></span></h4>Historical Time Interval Report of AgentId: <span class='theme-color'>" + agentID);

    if ($("#reportTypeValue").val() == "DateRange") {
        var startDate = $("#startDateValue").val();
        var yy = startDate.substr(0, 4);
        var mm = startDate.substr(4, 2);
        var dd = startDate.substr(6, 2);
        var formattedStartDate = dd + "-" + mm + "-" + yy;

        var endDate = $("#endDateValue").val();
        var yy = endDate.substr(0, 4);
        var mm = endDate.substr(4, 2);
        var dd = endDate.substr(6, 2)
        var formattedEndDate = dd + "-" + mm + "-" + yy;

        datetime = " on " + loginDateTime
    }
    if ($("#reportTypeValue").val() == "SingleDate") {
        var singleDate = $("#singleDateValue").val();
        var yy = singleDate.substr(0, 4);
        var mm = singleDate.substr(4, 2);
        var dd = singleDate.substr(6, 2);
        var formattedSingleDate = dd + "-" + mm + "-" + yy;
        //date = "on" + formattedSingleDate;
        datetime = " of " + loginDateTime
    }
    $("#datetime").html(datetime);
    drillgrid.dataSource.filter({
        logic: "and",
        filters: [
            { field: "AgentId", operator: "contains", value: agentID }
            //{ field: "CreatedDateTime", operator: "isgreaterequal", value: loginDateTime },
            //{ field: "CreatedDateTime", operator: "islesserequal", value: logoutDateTime }
        ]
    });
    drillgrid.dataSource.read();
    $("#popupDrill").modal('show');
    $("#gridSearch").show();
    $("#PopupFooter").hide();
    $("#searchDDForm").hide();
}