﻿/* -----------------------------------------------------------------------------------------------------------------
 * <copyright file=InteractionWorkflow\Logger.js  company="Tetherfi Pte. Ltd.">
 *      Tetherfi™ 
 * </copyright>
 * <author>Prakash D'souza</author>
 * <CreatedOn> 12/7/2017  12:34 AM</CreatedOn>
 * <LastModified>27/8/2017  12:21 PM</LastModified>
 * <summary>
 *      Client Logger Wrapper
 *  </summary>         
 * ---------------------------------------------------------------------------------------------------------------*/
 


/*
    File/Pharases selecting Wizard
*/

var Logger = function() {
    this.logType = {
        Success: "Success",
        Info: "Info",
        Warning: "Warning",
        Error: "Error"
    }


}
/*
    In-herit the Logger and add more features to this Object.
*/
Logger.prototype = {

    LogDetails: function(logtype, method, message, showpopup) {
        //;
        var $log = this;
        var $notify = this;
        var formatedtxt = $log.FormatLog(logtype, method, message);
        console.log(formatedtxt);
        if (showpopup) {
            switch (logtype) {
            case this.logType.Success:
                //$notify.ShowNotify('[ ' + method + ' ] ::' + message, "success", null, "top-center");
                $notify.ShowNotify(message, "success", null, "top-center");
                break;
            case this.logType.Info:
                $notify.ShowNotify(message, "info", null, "top-center");
                break;
            case this.logType.Warning:
                $notify.ShowNotify(message, "warning", null, "top-center");
                break;
            case this.logType.Error:
                $notify.ShowNotify(message, "danger", null, "top-center");
                break;
            default:
                $notify.ShowNotify(message, "", null, "top-center");
                break;
            }
        }
            /**
             * Remote Logging:  based on window.ApplicationPomConfiguration.EnableRemoteLogging
             */

        var config = window.ApplicationPomConfiguration.EnableRemoteLogging;
        var $that = this;

        switch (logtype) {
        case this.logType.Success:
            if (config.Success) $that.RemoteLogging(method, message, logtype);
            break;
        case this.logType.Info:
            if (config.Info) $that.RemoteLogging(method, message, logtype);
            break;
        case this.logType.Warning:
            if (config.Warning) $that.RemoteLogging(method, message, logtype);
            break;
        case this.logType.Error:
            if (config.Error) $that.RemoteLogging(method, message, logtype);
            break;
        default:
            $that.RemoteLogging(method, message, logtype);
            break;
        }
    },
    /*
        system current date and time
    */
    systemDateTime: function () {
        var currentdate = new Date();
        var datetime = currentdate.getDate() + "/"
            + (currentdate.getMonth() + 1) + "/"
            + currentdate.getFullYear() + " "
            + currentdate.getHours() + ":"
            + currentdate.getMinutes() + ":"
            + currentdate.getSeconds();

        return datetime;
    },

    /*
        Format the log message
    */
    FormatLog: function (type, method, message) {
        var $log = this;
        return $log.systemDateTime() + ' [' + type + '] [' + method + '] :: ' + message;
    },

    ShowNotify: function (message, status, group, pos) {
        try {
            var thisNotify = UIkit.notify({
                message: message ? message + '<a href="#" class="notify-action">X</a>' : '',
                status: status ? status : '',
                timeout: window.ApplicationUISettings.notifyTimeout,
                group: group ? group : null,
                pos: pos ? pos : 'top-center',
                onClose: function () {
                    $body.find('.md-fab-wrapper').css('margin-bottom', '');
                    // clear notify timeout (sometimes callback is fired more than once)
                    clearTimeout(thisNotify.timeout);
                }
            });
            if ((($window.width() < 768) && ((thisNotify.options.pos == 'bottom-right') || (thisNotify.options.pos == 'bottom-left') ||
                (thisNotify.options.pos == 'bottom-center'))) || (thisNotify.options.pos == 'bottom-right')) {
                var thisNotify_height = $(thisNotify.element).outerHeight();
                var spacer = $window.width() < 768 ? -6 : 8;
                $body.find('.md-fab-wrapper').css('margin-bottom', thisNotify_height + spacer);
            }

        } catch (e) {
            console.log(e);
        }
    },

    /**
     * Ajax Errors
     * @param {} xhr 
     * @param {} exception 
     * @param {} settings 
     * @returns {} 
     */
    OnAjaxError: function (xhr, exception, settings) {
        
        try {
            //responseText = jQuery.parseJSON(xhr.responseText);
            var message = //"Exception : " + exception + "\n" +
                "Url : " + settings.url + " [" + settings.type + "]" + "\n" +
                "Status : " + xhr.statusText + " [" + xhr.status + "]" + "\n" +
                "ContentType : " + settings.contentType + "\n" +
                "Message : " + xhr.responseText;
            console.log(message,this.logType.Error);

            /**
             * Remote Logging:  based on window.ApplicationPomConfiguration.EnableRemoteLogging
             */

            var config = window.ApplicationPomConfiguration.EnableRemoteLogging;
            var $that = this;

            if (config.Error) {
                // Is it a empty/undefined Error ?, just ignore it
                if (xhr.responseText === undefined) console.log(message);
                else $that.RemoteLogging(settings.url, message, this.logType.Error);
            }
           


        } catch (e) {
            console.log(xhr.responseText);
        }
    },

    /**
     * Remote logging all the Client Errors
     * @returns {} 
     */

    RemoteLogging: function (method,message,logtype) {
        var $that = this;
        var messagetoLog = "";
        messagetoLog = 'Method : ' + method + '\n';
        try {
            if (ApplicationPomConfiguration.FileInfo)
                messagetoLog += 'Callflow : ' + ApplicationPomConfiguration.FileInfo.Filename + '\n';
        } catch (e) { }

        messagetoLog += 'Message : ' + message + '\n';

        //if (message === undefined) {
        //    return;
        //}

        try {
            /*
            var jsondata = {
                'JsonObject': JSON.stringify(messagetoLog),
                'LogType': logtype,
                'FileInfo': {
                    'CurrentUserType': ApplicationPomConfiguration.FileInfo.CurrentUserType
                }
            };

            
                $.ajax({
                    url: window.ApplicationPath + "ClientLogger/LogClientLogs",
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(jsondata),
                    dataType: 'json',
                    async: true,
                    success: function(response) {
                        if (response.StatusCode !== "0") {
                            //$that.LogDetails($that.logType.Info, "RemoteLogging", response.Status, false);
                        } else {
                            //$that.LogDetails($that.logType.Error, "RemoteLogging", response.Status, false);
                        }

                    },
                
                });
            */
        } catch (exception) {
            //$that.Log.LogDetails($that.logType.Error, "RemoteLogging", exception.message, false);
            console.log("[RemoteLogging]" + exception.message);
        }
    }


}

//----------------------------------------------------------------------------------