﻿/* -----------------------------------------------------------------------------------------------------------------
 * <copyright file=InteractionWorkflow\Utilities.js  company="Tetherfi.">
 *      Tetherfi™ 
 * </copyright>
 * <author>Prakash D'souza</author>
 * <CreatedOn> 31/7/2017  12:10 PM</CreatedOn>
 * <LastModified>6/8/2017  1:44 PM</LastModified>
 * <summary>
 *     All Common methods goes here
 *  </summary>         
 * ---------------------------------------------------------------------------------------------------------------*/


$(document).ready(function () {
    /**
     * Define the Version
     * @returns {} 
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "Utilities.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Prakash",
        Description: "Get Plain text from html control., intent text replace double quote with single quote "
    });
});


var AppUtilities = function () {
    this.Log = new Logger();
}

/*
    In-herit the AppUtilites and add more features to this Object.
*/

AppUtilities.prototype = {
    Pause: function (milliseconds) {
        var dt = new Date();
        while ((new Date()) - dt <= milliseconds) { /* Do nothing */
        }
    },

    /*
        Is this current user is authorised user for system access
    */
    IsAuthorizedUser: function () {
        try {
            if (ApplicationPomConfiguration.FileInfo.IsAuthenticated === false) {
                this.Log.LogDetails(this.Log.logType.Error, "Authorization", "Utils : Current user does not have access to the callflow. ", true);
                return false;
            }
            return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "Utils : IsAuthorizedUser", exception.message, false);
            return data;
        }
    },

    /**
     * Is call flow ready to edit.
     * @returns {} 
     */
    IsReadyToEdit: function (displayReadOnlyErrormessag) {
        try {
            var isreadyToEdit = window.ApplicationPomConfiguration.IsEditable;
            if (!isreadyToEdit) {
                if (displayReadOnlyErrormessag)
                    this.Log.LogDetails(this.Log.logType.Error, "IsReadyToEdit", "Cannot edit callflow. Current callflow is in " +
                        window.ApplicationPomConfiguration.FileInfo.Currentstatus
                        + " state", true);
            }
            return isreadyToEdit;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "Utils : IsReadyToEdit", exception.message, false);
            return data;
        }
    },

    /*
    Generic method to load the kendo windo
*/
    OpenKendoPopup: function (windowctrl, windowId, windowTitle, url, titlebackgroundColor) {
       
        // Since the obj is not reference type, so will assign the specific variable
        if (windowId === "popupWindows") {
            windowctrl = WindowPopup;
        } else if (windowId === "popupWindowwidget") {
            windowctrl = windowpopupwidget;
        } else if (windowId === "popupwindowGlobalPhrase") {
            windowctrl = windowpopupGlobalPhrase;
        }

        try {
            windowctrl.close();
        } catch (e) {

        }

        try {

            $('#' + windowId).html("");
            if (windowctrl === undefined)
                windowctrl = $("#" + windowId).data("kendoWindow");
            windowctrl.refresh({
                url: window.ApplicationPath + url
            });
            //2018-08-16 : Background color disabled
            /*
                // change the title color
                $('#' + windowId).parent().find('.k-window-titlebar,.k-window-actions')
                    .css('backgroundColor', titlebackgroundColor === "" ? '#1976d2' : titlebackgroundColor);
            */

            $(".k-window-titlebar").addClass('k-window-titlebar-Custom-Background');
            $(".k-window-actions").addClass('k-window-actions-Custom-Background');
            windowctrl.title(windowTitle).center().open();

            // Re-assign the specific values back to the variables
            if (windowId === "popupWindows") {
                WindowPopup = windowctrl;
            } else if (windowId === "popupWindowwidget") {
                windowpopupwidget = windowctrl;
            } else if (windowId === "popupwindowGlobalPhrase") {
                windowpopupGlobalPhrase = windowctrl;
            }

            // Set the Icon
            // lets create a new div here to resolve title connflicts

            //var titlediv = '<div id="kendopopupTitle' + windowId + '"></div>';
            //$('.k-window-titlebar').find('.k-window-title').html(titlediv);
            //$('.k-window-titlebar').find('.k-window-title').find('#kendopopupTitle' + windowId).html('<i class="material-icons md-light">airplay</i> &nbsp;' + windowTitle);
            //$('.k-window-titlebar').find('.k-window-title').html('<i class="material-icons md-light">airplay</i> &nbsp;' + windowTitle);
            //$('.k-window-title').prepend('<i class="material-icons md-light">airplay</i> &nbsp;');


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, windowTitle, exception.message, false);
        }
    },

    /*
        Replace all the special characters and numbers
    */
    ReplaceSpecialCharactersAndSpace: function (str) {

        //$('body').html(string.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-'));
        // var rtn = str.replace(/[^a-z\s]/gi, '').replace(/[\s]/g, '');

        // allow Underscore
        var rtn = str.replace(/[^a-z_\s]/ig, '').replace(/[\s]/g, '');
        return rtn;
    },

    /*
        Replace all the special characters and numbers
    */
    CallFlowCharactersRule: function (str) {

        //$('body').html(string.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-'));
        var rtn = str.replace(/[^a-z\s]/gi, '').replace(/[\s]/g, '');

        // allow Underscore
        //var rtn = str.replace(/[^a-z_\s]/ig, '').replace(/[\s]/g, '');
        return rtn;
    },

    /**
     * Allw only specleted cahracters/numbers for DTMF
     * currently will allow 0-9, *#
     * @param {} str 
     * @returns {} 
     */
    ReplaceRequiredDTMFCharacters: function (str) {
        var rtn = str.replace(/[^0-9*#\s]/ig, '').replace(/[\s]/g, '');
        return rtn;
    },

    /*
        Sort the Data according to property and the order
        data : data to sort
        prop : property or field to sort
        asc : True (acending) False (Decending)
    */
    sortResults: function sortResults(data, prop, asc) {
        try {
            var sorteddata = data.sort(function (a, b) {
                if (asc) {
                    return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
                } else {
                    return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
                }
            });
            return sorteddata;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "Utils : SortResult", exception.message, false);
            return data;
        }
    },

    /*
        CHECKER
        based on the 'type' will enable or disable the tab/blocks in the View
    */
    CheckerBlockVisibility: function (type, blockmaker, blockchecker) {
        try {
// Maker/Checker
            if (ApplicationPomConfiguration.FileInfo.CurrentUserType.toLowerCase() === "checker") {
                $(".clsCheckerBlock").css("display", "block");

                // disable all other Controls
                $(blockmaker + " :input").attr("disabled", true);

                // enable Checker controls
                $(blockchecker + " :input").attr("disabled", false);
            } else {
                $(blockchecker).css("display", "none");
                //$(blocktoEnable).css("display", "none");
            }
            // can be editable ?
            if (window.ApplicationPomConfiguration.FileInfo !== "" && !window.ApplicationPomConfiguration.IsEditable) {
                $(".clsCheckerBlockNavigation").css('display', 'none');
            } else {
                $(".clsCheckerBlockNavigation").css('display', 'block');
            }

            // 2018-02-26 Specia case when maker and checker both
            // during Status 'CHECKERDRAFT', will show this block
            var userRoles = $("#hdnApplicationSpecialUserType").val().split(',');
            if (jQuery.inArray("MAKER", userRoles) !== -1 && jQuery.inArray("CHECKER", userRoles) !== -1) {
                if (ApplicationPomConfiguration.FileInfo.Currentstatus === "CHECKERDRAFT") {
                    $(".clsCheckerBlock").css("display", "block");

                    // disable all other Controls
                    $(blockmaker + " :input").attr("disabled", true);

                    // enable Checker controls
                    $(blockchecker + " :input").attr("disabled", false);

                    // Editable
                    $(".clsCheckerBlockNavigation").css('display', 'block');
                }
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "Utils : CheckerBlockVisibility", exception.message, false);
        }
    },

    NavigationDuringFileLock: function (type) {
        try {
            // Is Editable
            if (window.ApplicationPomConfiguration.FileInfo !== "" && !window.ApplicationPomConfiguration.IsEditable) {
                //$("#btnSaveDnis").css("display", "none");
                $(".clsNavigationButtons").css('display', 'none');
            } else {
                $(".clsNavigationButtons").css('display', 'block');
            }
            // disable the save button during checker.
            if (ApplicationPomConfiguration.FileInfo.CurrentUserType.toLowerCase() === "checker") {
                $(".clsNavigationButtons").css('display', 'none');
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "Utils : NavigationDuringFileLock", exception.message, false);
        }
    },


    /*
            Add Generic node to collection
        */
    AddGenericNodetoCollection: function (node) {
        try {
            window.ApplicationPomConfiguration.jsonDataObj.push(node);
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "widgetGetPhrases", exception.message, false);
        }
    },
    /*
     Generate a new UUID for each json elemennts
    */
    generateUUID: function () {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now();; //use high-precision timer if available
        }
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid + "-" + moment(new Date()).format("HHmmssSSS");
    },


    /*
        Check wethere given 
    */
    isNumberKey: function (evt) {

        var charCode = (evt.which) ? evt.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
        return true;
    },

    /**
     * Is DTMF Key
     * @param {} texttosurroundquotes 
     * @returns {} 
     */
    isDTMFKey: function (evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode;

        if (charCode !== 35 && charCode !== 42) {
            // allow 'E|e' for Texchat Synonyms
            if (charCode === 69 || charCode === 101) {

                try {
                    var idE = $(evt.target).attr("id").split("_")[1];
                    $("#chkMasking" + idE).attr("disabled", true).prop('checked', true);
                } catch (ex) {
                }

                return true;
            }
            // Allow H/h
            if (charCode === 72 || charCode === 104) {

                try {
                    var idH = $(evt.target).attr("id").split("_")[1];
                    $("#chkMasking" + idH).attr("disabled", true).prop('checked', true);
                } catch (ex) {
                }
                return true;
            }
            // Allow M/m
            if (charCode === 77 || charCode === 109) {

                try {
                    var idM = $(evt.target).attr("id").split("_")[1];
                    $("#chkMasking" + idM).attr("disabled", true).prop('checked', true);
                } catch (ex) {
                }
                return true;
            }
            if ((charCode < 48 || charCode > 57)) {

                return false;
            }
        }

        // lets enable checkbox
        try {
            var id = $(evt.target).attr("id").split("_")[1];
            $("#chkMasking" + id).attr("disabled", false);
        } catch (ex) {
        }

        return true;
    },

    AddSingleQuote: function (texttosurroundquotes) {
        return "'" + texttosurroundquotes.replace(/(['"])/g, "\\$1") + "'";
    },

    widgetGetPhrases: function (filetypeSelected) {
        try {
            var $that = this;
            switch (filetypeSelected) {
                case "GreetingFile":
                    return window.ApplicationCurrentPhraseList.GreetingFile.Phrases;
                case "InvalidPrompt1":
                    return window.ApplicationCurrentPhraseList.InvalidPrompt1.Phrases;
                case "InvalidPrompt2":
                    return window.ApplicationCurrentPhraseList.InvalidPrompt2.Phrases;
                case "NoInputPrompt1":
                    return window.ApplicationCurrentPhraseList.NoInputPrompt1.Phrases;
                case "NoInputPrompt2":
                    return window.ApplicationCurrentPhraseList.NoInputPrompt2.Phrases;
                case "MaxTries":
                    return window.ApplicationCurrentPhraseList.MaxTries.Phrases;
                case "Announcement1":
                    return window.ApplicationCurrentPhraseList.Announcement1.Phrases;
                case "Announcement2":
                    return window.ApplicationCurrentPhraseList.Announcement2.Phrases;
                case "Announcement3":
                    return window.ApplicationCurrentPhraseList.Announcement3.Phrases;
                case "Announcement4":
                    return window.ApplicationCurrentPhraseList.Announcement4.Phrases;
                case "Announcement5":
                    return window.ApplicationCurrentPhraseList.Announcement5.Phrases;
                case "AgentTransferAnnouncement":
                    return window.ApplicationCurrentPhraseList.AgentTransferAnnouncement.Phrases;
                case "menuoption":
                    {
                        //;
                        var leg = new Legs();
                        return leg.CurrentLegPhrase("");
                    }
                //return window.ApplicationCurrentPhraseList.menuoption.Phrases;
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "widgetGetPhrases", exception.message, false);
        }
    },

    /*
        Lists all the local files to upload. files will be taken from global collection list called 'ApplicationCurrentPhraseList'
    */
    GetLocalFilesToUpload: function () {
        var list = [];
        try {
            var $that = this;

            // lets take only local files that need to upload
            list.push(Enumerable.From($that.widgetGetPhrases("GreetingFile")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("InvalidPrompt1")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("InvalidPrompt2")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("NoInputPrompt1")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("NoInputPrompt2")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("MaxTries")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("AgentTransferAnnouncement")).Where("$.Islocal == true").ToArray());

            list.push(Enumerable.From($that.widgetGetPhrases("Announcement1")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("Announcement2")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("Announcement3")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("Announcement4")).Where("$.Islocal == true").ToArray());
            list.push(Enumerable.From($that.widgetGetPhrases("Announcement5")).Where("$.Islocal == true").ToArray());

            list.push(Enumerable.From($that.widgetGetPhrases("menuoption")).Where("$.Islocal == true").ToArray());


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetLocalFilesToUpload", exception.message, false);
        }
        return list;
    },

    /*
        Check for wether its ready to set the flow
    */
    IsValidFlowFound: function () {
        try {
            if ($.trim(window.ApplicationPomConfiguration.currentdnis).length > 0) return true
            else return false;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "IsValidFlow", exception.message, false);
        }
    },

    /*
        Read the given element position in the screen
    */
    GetElementPositin: function (element) {
        //
        try {
            var $elem = $("#" + element);
            var positionX = $elem.offset().left; //parseInt($elem.css("left"), 10);
            var positionY = $elem.offset().top; //parseInt($elem.css("top"), 10);
            return positionX + ":" + positionY;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "IsValidFlow", exception.message, false);
            return "50:50";
        }
    },

    /**
     * Get Cursor Position
     * @param {} event Event
     * @returns {} Postion LEFT RIGHT
     */
    GetCursorPosition: function (event) {
        var defaultnodePosition = window.GraphconfigSettings.DefaultNodePosition;

        var postion = {
            Top: defaultnodePosition.split(':')[0],
            Left: defaultnodePosition.split(':')[1]
        }

        //  if droppable node is above visibility on top, correct it
        if (event.pageY < 100)
            event.pageY = 100;

        //  If nodes are to be contained within canvas, correct all
        if (window.GraphconfigSettings.ContainDrag) {
            //  bottom
            if (event.pageY > $("#canvas").height())
                event.pageY = $("#canvas").height() + 50;
            //  left
            if (event.pageX < 0)
                event.pageX = 0;
            //  right
            if (event.pageX > $("#canvas").width() - 140)
                event.pageX = $("#canvas").width() - 140;
        }

        try {
            // 08/25/2017 : Added aditiona ScrollTop and ScrollLeft to handle node during user is in mid or bottm of the screen
            // when there is scrollbar
            postion.Left = event.pageX + ($("#canvas").scrollLeft());
            postion.Top = event.pageY + ($("#canvas").scrollTop()) - 100;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetCursorPosition", exception.message, false);
        }

        return postion;
    },

    GetElementPositinWithinContainer: function (element) {
        // 
        //
        try {
            // got tot he parent and get the position
            var $elem = $("#" + element);
            var positionX = $($elem).offsetParent().find($elem)[0].offsetLeft;
            var positionY = $($elem).offsetParent().find($elem)[0].offsetTop;

            // In case user drag the node to negative location, then re-set to default position
            if (positionX < 0 || positionY < 0) {
                var defaultposition = window.ApplicationPomConfiguration.DefaultNodePosition;
                var top = defaultposition.split(':')[0];
                var left = defaultposition.split(':')[1];
                if (positionX < 0) positionX = left;
                if (positionY < 0) positionY = top;
            }
            return positionX + ":" + positionY;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "IsValidFlow", exception.message, false);
            return window.ApplicationPomConfiguration.DefaultNodePosition;
            //return "50:50";
        }
    },

    /*
            Get the file details from existing list
    
        */
    GetRemotePhrase: function (language, filename) {
        //
        var collection = [];
        try {

            var $that = this;
            var phrase = Enumerable.From(ApplicationPomConfiguration.ExisitingPhrasesList.nodes).
                Where("$.Language.toLowerCase() == " + $that.AddSingleQuote(language.toLowerCase())
                    //+ " && $.Files.filename.toLowerCase() == " + $that.AddSingleQuote(filename.toLowerCase())
                ).ToArray();

            // search for specifi filename
            $.each(phrase[0].Files, function (i, val) {
                if (val.filename.toLowerCase() === filename.toLowerCase()) {
                    collection.push(val);
                }
            });


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetRemotePhrase", exception.message, false);

        }
        return collection;
    },

    /*
       Upload files to Server
       This will return 
       0  : success
       -1 : failed
   */
    UploadFiles: function (voiceTalent, dnis, filelist) {
        var $that = this;
        try {
            var filenames = [];
            var fileDetails = [];
            var uploadFiles = new FormData();
            for (var i = 0; i < filelist.length; i++) {
                for (var j = 0; j < filelist[i].length; j++) {
                    var filename = voiceTalent + "_" + dnis + "_" + filelist[i][j].Language + "_" + filelist[i][j].Filename;
                    filenames.push(filename);
                    uploadFiles.append(filename, filelist[i][j].Blob);
                    fileDetails.push({
                        Id: filename,
                        VoiceTalent: voiceTalent,
                        Dnis: dnis,
                        Language: filelist[i][j].Language,
                        Filename: filelist[i][j].Filename,
                        IsGlobalPhrase: filelist[i][j].IsGlobalPhrase === undefined ? false : filelist[i][j].IsGlobalPhrase
                    });
                }
            }

            uploadFiles.append("fileDetails", JSON.stringify(fileDetails));

            var rtnUploadstatus = {
                status: false,
                uploadedList: "",
                FailedPhraseList: ""
            };

            $.ajax({
                type: "POST",
                url: window.ApplicationPath + "Application/UploadFiles",
                data: uploadFiles,
                dataType: 'json',
                contentType: false,
                processData: false,
                async: false,
                success: function (response) {
                    //
                    var uploadstatus = false;
                    $that.Log.LogDetails($that.Log.logType.Info, "UploadFiles", "Upload Status ::" + response.Status, false);
                    if (response.StatusCode === "0") uploadstatus = true;
                    else if (response.StatusCode === "-3") uploadstatus = true;
                    else uploadstatus = false;

                    rtnUploadstatus.status = uploadstatus;
                    rtnUploadstatus.list = response.uploadedList;
                    rtnUploadstatus.FailedPhraseList = response.FailedPhraseList;

                }
            });

            return rtnUploadstatus;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GenerateCallFlowNameList", exception.message, false);
            return "-1";
        }
    },

    /**
     * Update the call flow
     * We can call this method any time when front-end needs to update the callflow contents
     * @returns {} 
     */
    UpdateCallFlow: function (callflowname) {
        try {

            var jsondata = {
                'JsonObject': JSON.stringify(window.ApplicationPomConfiguration.jsonDataObj),
                'FileInfo': {
                    'CurrentUserType': ApplicationPomConfiguration.FileInfo.CurrentUserType
                }
            };

            $.ajax({
                url: window.ApplicationPath + "Application/UpdateCallFlow?callflow=" + callflowname,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(jsondata),
                dataType: 'json',
                async: false,
                success: function (response) {


                }
            });

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "UpdateCallFlow", exception.message, false);
            return "-1";
        }

        return false;
    },

    /**
     *  Reads all the checkboxes that checked within a block
     */
    LanguagesSelected: function (control) {
        try {

            var selected = [];
            $('#' + control + ' input:checked').each(function () {
                //$('#CheckBoxContainer input:checked').each(function () {
                selected.push($(this).attr('value'));
            });

            return selected.join(",");

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "LanguagesSelected", exception.message, false);
        }
    },

    /*
        Load File picker for phrase selection. 
        Re-usable method within a menu form

    */
    OpenFilePicker: function (urlparam, title) {
        try {
            //var mode = $.trim($("#hdnSelectedDnis").val()).length > 0 ? "edit" : "add";
            var windowTitlepopup = "File selection :: " + title;
            $('#popupWindowwidget').html("");
            if (windowpopupwidget === undefined)
                window.windowpopupwidget = $("#popupWindowwidget").data("kendoWindow");
            windowpopupwidget.refresh({
                url: window.ApplicationPath + "Application/FileSelectUtility?" + urlparam
            });
            windowpopupwidget.title(windowTitlepopup).center().open();
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "OpenFilePicker", exception.message, false);
        }

    },

    /*
        Print current File status
    */
    ShowFileStatus: function () {
        try {
            var fileInfo = window.ApplicationPomConfiguration.FileInfo = result.FileInfo;


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "OpenFilePicker", exception.message, false);
        }
    },

    /*
        Check for duplicate item in the array list
    */
    DuplicateItemsInArray: function (array) {

        try {

            var recipientsArray = array.sort();

            var reportRecipientsDuplicate = [];
            for (var i = 0; i < recipientsArray.length - 1; i++) {
                if (recipientsArray[i + 1].toLowerCase() === recipientsArray[i].toLowerCase()) {
                    reportRecipientsDuplicate.push(recipientsArray[i]);
                }
            }
            return reportRecipientsDuplicate;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "DuplicateItemsInArray", exception.message, false);
            return [];

        }
    },

    /*
       Check for duplicate item within two the array list
   */
    DuplicateItemsWithinArray: function (array1, array2) {
        // 
        try {

            var duplicatearraylist = [];
            for (var i = 0; i < array1.length; i++) {
                for (j = 0; j < array2.length; j++) {
                    if (array1[i] === array2[j]) {
                        duplicatearraylist.push(array1[i]);
                    }
                }
            }
            return duplicatearraylist;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "DuplicateItemsWithinArray", exception.message, false);
            return [];

        }
    },

    /**
     *Remove all the duplicate items from the array
     * @param {} array  : given array
     * @returns {} 
     */
    RemoveDuplicatesFromArray: function(array) {
        try {
            let result = [];

            $(array).each(function (index, item) {
                // Is this exists in the final result
                if (jQuery.inArray(item, result) === -1) {
                    result.push($.trim(item));
                }
            });

           
            return result;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "RemoveDuplicatesFromArray", exception.message, false);
            return [];
        }
    },


    //open the create rules window
    OpenCreateRules: function () {
        try {
            var windowTitlepopup = "Interaction Workflow :: Create Rules";
            $('#popupWindowwidget').html("");
            if (windowpopupwidget === undefined)
                window.windowpopupwidget = $("#popupWindowwidget").data("kendoWindow");
            windowpopupwidget.refresh({
                url: window.ApplicationPath + "Widget/RulesCreationWidget"
            });
            windowpopupwidget.title(windowTitlepopup).center().open();
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "OpenCreateRules", exception.message, false);
        }
    },

    //open the create rules window
    OpenGlobalKey: function () {
        try {
            var windowTitlepopup = "Interaction Workflow :: Global Configuration";
            $('#popupWindowwidget').html("");
            if (windowpopupwidget === undefined)
                window.windowpopupwidget = $("#popupWindowwidget").data("kendoWindow");
            windowpopupwidget.refresh({
                url: window.ApplicationPath + "GlobalConfiguration/GlobalKyConfiguration"
            });
            windowpopupwidget.title(windowTitlepopup).center().open();
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "OpenGlobalKey", exception.message, false);
        }
    },

    //open the create Intent window
    OpenCreateIntent: function () {
        try {
            var windowTitlepopup = "Interaction Workflow :: Create Intent";
            $('#popupWindowwidget').html("");
            if (windowpopupwidget === undefined)
                window.windowpopupwidget = $("#popupWindowwidget").data("kendoWindow");
            windowpopupwidget.refresh({
                url: window.ApplicationPath + "Widget/IntentCreationWidget"
            });
            windowpopupwidget.title(windowTitlepopup).center().open();
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "OpenCreateIntent", exception.message, false);
        }
    },

    //open the set rules window
    OpenSetRules: function (urlparam) {
        try {
            var windowTitlepopup = "Interaction Workflow :: Set Rules";
            $('#popupWindowwidget').html("");
            if (windowpopupwidget === undefined)
                window.windowpopupwidget = $("#popupWindowwidget").data("kendoWindow");
            windowpopupwidget.refresh({
                url: window.ApplicationPath + "Widget/RulesSelectionWidget?" + urlparam
            });
            windowpopupwidget.title(windowTitlepopup).center().open();
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "OpenSetRules", exception.message, false);
        }
    },

    OpenSetSynonyms: function (urlparam) {
        try {

            var windowTitlepopup = "Interaction Workflow :: Set Synonyms";
            $('#popupWindowwidget').html("");
            if (windowpopupwidget === undefined)
                window.windowpopupwidget = $("#popupWindowwidget").data("kendoWindow");
            windowpopupwidget.refresh({
                url: window.ApplicationPath + "ChatSpecific/Synonyms?" + urlparam
            });
            windowpopupwidget.title(windowTitlepopup).center().open();
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "OpenSetRules", exception.message, false);
        }
    },

    SetFileInformation: function (data) {
        var $that = this;
        try {
            var varFlowname = data.FlowName === undefined ? "-" : data.FlowName;
            var varCurrentstatus = data.Currentstatus === undefined ? "-" : data.Currentstatus;

            var callflowType = "";
            var dinsToDisplay = "";
            if (window.ApplicationPomConfiguration.FileInfo.ApplicationType === "chat") {
                callflowType = "chat";
                dinsToDisplay = '';
            } else {
                dinsToDisplay = $that.GetSpecialRoleDnisNumbers(data);
                var isOrdertaking = $that.isOrderTakingCallflow(data.FlowName);
                callflowType = "DNIS";
                if (isOrdertaking) {
                    dinsToDisplay = data.Intent;
                    callflowType = "INTENT";
                }
                //  To seperate multiple DNIS with a whitespace
                dinsToDisplay = dinsToDisplay.replace(new RegExp(",", 'g'), ", ");
                dinsToDisplay = '[' + dinsToDisplay + ']';
            }

            // set the file  details in uI
            var filestatusclass = ApplicationPomConfiguration.IsEditable ? "uk-text-success" : "uk-text-danger";
            var usertype = window.ApplicationPomConfiguration.ShowUserRole ?
                'Role : <span class="uk-text-danger" id="spnCurrentFlowRole">' + $("#hdnApplicationSpecialUserType").val() + '</span>' : "";
            var locked = !ApplicationPomConfiguration.IsEditable ? '<i class="uk-icon-lock uk-icon-small" style="padding-left:5px;"></i>' : '';
            var flowname = '<div style="max-width: 65%; display: inline-flex;"><div class="uk-text-primary"' +
                ' style="white-space: nowrap;text-overflow: ellipsis;overflow: hidden;">FLOW NAME : ' + varFlowname + dinsToDisplay + '</div></div > ';

            var status =
                usertype + " | " + flowname + " | <span class='uk-text-primary'>FLOW STATUS : </span>" +
                '<span class="' + filestatusclass + '">' + varCurrentstatus + '</span>' + locked;

            if (varFlowname === "-") $("#fileStatus").html(usertype);
            else $("#fileStatus").html(status);

            // load all the available flow info
            var li =
                '<li>' +
                '<div class="md-list-content">' +
                '<span class="md-list-heading">USER</span>' +
                '<span class="uk-text-small uk-text-muted">' + data.PreviousUser + '</span>' +
                '</div>' +
                '</li>';
            li +=
                '<li>' +
                '<div class="md-list-content">' +
                '<span class="md-list-heading">ROLE</span>' +
                '<span class="uk-text-small uk-text-muted">' + $("#hdnApplicationSpecialUserType").val() + '</span>' +
                '</div>' +
                '</li>';

            if (callflowType !== "chat") {
                li +=
                    '<li>' +
                    '<div class="md-list-content" style="white-space:normal;">' +
                    '<span class="md-list-heading">' + callflowType + '</span>' +
                    '<span class="uk-text-small uk-text-muted uk-text-danger">' + dinsToDisplay + '</span>' +
                    '</div>' +
                    '</li>';
            }
            li +=
                '<li>' +
                '<div class="md-list-content">' +
                '<span class="md-list-heading">STATUS</span>' +
                '<span class="uk-text-small uk-text-muted">' + data.Currentstatus + '</span>' +
                '</div>' +
                '</li>';

            li +=
                '<li>' +
                '<div class="md-list-content">' +
                '<span class="md-list-heading">VERSION</span>' +
                '<span class="uk-text-small uk-text-muted">' + data.yymmdd + " " + data.VersionMajor + ':' + data.VersionMinor + '</span>' +
                '</div>' +
                '</li>';

            //li +=
            //    '<li>' +
            //    '<div class="md-list-content">' +
            //    '<span class="uk-text-small uk-text-muted"><a href="#" data-uk-tooltip="{pos:' + utils.AddSingleQuote("bottom") + '}" title="Flow file download" onclick="DownloadFile()"><i class="material-icons">file_download</i> Download</a></span>' +
            //    '</div>' +
            //    '</li>';

            $("#divFileinfo").html(li);
            //
            // Lets onload of the Page, will Hide the app features based on user access Role
            if (window.ApplicationPomConfiguration.FileInfo.CurrentUserType === "MAKER") {
                $("#btnImportCallFlow").css('display', 'block');
                $("#btnImportPackage").css('display', 'block');
            } else {
                $("#btnImportCallFlow").css('display', 'none');
                $("#btnImportPackage").css('display', 'none');
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "SetFileInformation", exception.message, false);
        }
    },

    /**
     * Get the User Role
     * @returns {} 
     */
    SetCurrentflowRole: function () {
        try {
            // will return false incase of we are not showing role status
            if (!window.ApplicationPomConfiguration.ShowUserRole) return false;
            var userRoles = $("#hdnApplicationSpecialUserType").val().split(',');

            if (userRoles.length === 1) $("#spnCurrentFlowRole").text($("#hdnApplicationSpecialUserType").val());
            else {
                // Lets check who is the current ownder of the callflow
                if ((ApplicationPomConfiguration.FileInfo.Currentstatus === "DRAFT" ||
                    ApplicationPomConfiguration.FileInfo.Currentstatus === "SAVED" ||
                    ApplicationPomConfiguration.FileInfo.Currentstatus === "SENDTOAPPROVAL")) {

                    // cAllflow owner and current ownder is same
                    if (window.ApplicationPomConfiguration.FileInfo.PreviousUser === window.ApplicationPomConfiguration.FileInfo.CurrentUser) {
                        $("#spnCurrentFlowRole").text("MAKER");
                    } else {
                        $("#spnCurrentFlowRole").text("CHECKER");
                    }
                } else {
                    $("#spnCurrentFlowRole").text("CHECKER");
                }
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetCurrentflowRole", exception.message, false);
            $("#spnCurrentFlowRole").text($("#hdnApplicationSpecialUserType").val());
        }
    },

    /**
     * Get SpecialRoleDNIS number based on maker or checker.
     * @param {} data 
     * @returns {} 
     */
    GetSpecialRoleDnisNumbers: function (data) {
        try {

            var userRoles = $("#hdnApplicationSpecialUserType").val().split(',');

            var varDnisnumber = data.Dnisnumber === undefined ? "-" : data.Dnisnumber;
            var checkerDnisNumber = data.CheckerDnisnumber === undefined ? "-" : data.CheckerDnisnumber;

            if (jQuery.inArray("MAKER", userRoles) !== -1 &&
                (ApplicationPomConfiguration.FileInfo.Currentstatus === "DRAFT" ||
                    ApplicationPomConfiguration.FileInfo.Currentstatus === "SAVED" ||
                    ApplicationPomConfiguration.FileInfo.Currentstatus === "SENDTOAPPROVAL")) {

                return varDnisnumber;
            } else {
                return checkerDnisNumber;
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetSpecialRoleDnisNumbers", exception.message, false);
        }
    },

    /**
     * Check item exits in the array
     * @param {} itemtoSearch               : Item to search
     * @param {} array                      : Array 
     * @returns {}                          : true - duplicate, false: no Duplicates
     */
    ItemExistsinaArray: function (itemtoSearch, array) {
        var returnStatus = false;
        try {

            var copyArray = array.slice();
            for (var i = 0; i < copyArray.length; i++) {
                if (itemtoSearch.toLowerCase() === copyArray[i].toLowerCase()) {
                    returnStatus = true;
                    break;
                }
            }


        } catch (ex) {

        }

        return returnStatus;
    },

    /*
        Relad the callflow
        basically, when user create/saves we need to relaod the call flow
    */
    ReloadCallFlow: function (file) {
        try {

            var dnisElementObj = new StartElement();

            // Make dnis collection empty
            // $("#ddlDNIS").empty();
            $("#ddlDNIS").data("kendoDropDownList").dataSource.data([]);

            // lets reload the file list
            dnisElementObj.GenerateCallFlowNameList("ddlDNIS");

            // set the default data and load the callflow
            if (file.length > 0) {
                $("#ddlDNIS").data("kendoDropDownList").value(file);
                // load the dnis.
                $("#btnpreview").click();
            }

            // close all the open windows
            try {
                WindowPopup.close();
                windowpopupwidget.close();

            } catch (e) {
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "ReloadCallFlow", exception.message, false);
        }

    },

    /*
        Relad the callflow for Revision
        Will load all the Approved files here, so maker can revised to specific version.
    */
    ReloadRevisonCallFlowList: function (file) {
        try {

            var dnisElementObj = new StartElement();

            // Make dnis collection empty
            // $("#ddlDNIS").empty();
            $("#ddlDNISRevision").data("kendoDropDownList").dataSource.data([]);

            // lets reload the file list
            dnisElementObj.GenerateCallFlowNameListForRevision("ddlDNISRevision");

            // set the default data and load the callflow
            if (file.length > 0) {
                $("#ddlDNIS").data("kendoDropDownList").value(file);
                // load the dnis.
                $("#btnpreview").click();
            }

            // close all the open windows
            try {
                WindowPopup.close();
                windowpopupwidget.close();

            } catch (e) {
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "ReloadCallFlow", exception.message, false);
        }

    },


    /*
           check wether array contains any duplicate values
       */
    IsArrayContainsDuplicateItems: function (array) {


        try {

            var recipientsArray = array.sort();

            var reportRecipientsDuplicate = [];
            for (var i = 0; i < recipientsArray.length - 1; i++) {
                if (recipientsArray[i + 1] == recipientsArray[i]) {
                    reportRecipientsDuplicate.push(recipientsArray[i]);
                }
            }
            return reportRecipientsDuplicate.length > 0;


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "isValidDnisWithinCallFlow", exception.message, false);
            return true;
        }

    },

    /**
     * Set the node title
     * @param {} controlId 
     * @param {} text 
     * @returns {} 
     */
    UpdateNodeTitle: function (controlId, text) {
        try {
            $("#" + controlId).text(text);
            $("#" + controlId).attr("title", text);
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "UpdateNodeTitle", exception.message, false);
        }
    },

    /**
     * Set the node title
     * @param {} controlId 
     * @param {} text 
     * @returns {} 
     */
    UpdateNodeTitleDTMFtooltip: function (parentId, data) {
        var $that = this;
        try {
            for (var i = 0; i < data.length; i++) {
                // update title
                // $("#" + data[i].NextNodeId).atte(title, $that.CustomDecodeURIComponent(data[i].Tag));
                $("#" + parentId + "_" + data[i].NextNodeId + "_dtmf").parent().attr('title', $that.CustomDecodeURIComponent(data[i].Tag));
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "UpdateNodeTitle", exception.message, false);
        }
    },

    /*
    Update the DTMF Option to the Each child node of the Menu
    */
    UpdateNodeTitleDTMF: function (parentId, data) {

        try {
            // Update all the DTMF option in the graph.
            for (var i = 0; i < data.length; i++) {
                //var text = $("#" + data[i].Option + "_nodeTitle").text() + " [" + data[i].Option + "]";
                $("#" + parentId + "_" + data[i].NextNodeId + "_dtmf").text(data[i].Option);
                // $("#" + data[i].NextNodeId + "_dtm").attr("title", text);

                // 2018-03-07 :: Masking and unmasking
                var isLegEnabled = true;
                try {
                    isLegEnabled = data[i].Enabled;
                } catch (exc) {
                }

                if (!isLegEnabled) {
                    // Add new class
                    $("#" + parentId + "_" + data[i].NextNodeId + "_dtmf").parent().addClass('md-fab-disabled').addClass('md-fab-small-disabled-dtmf');
                } else {
                    $("#" + parentId + "_" + data[i].NextNodeId + "_dtmf").parent().removeClass('md-fab-disabled').removeClass('md-fab-small-disabled-dtmf');
                }


            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "UpdateNodeTitle", exception.message, false);
        }
    },

    /**
     * Generic method to remove class from the dom obj.
     * @returns {} 
     */
    RemoveClass: function (controlId, classtoRemove) {
        try {
            $("#" + controlId).removeClass(classtoRemove);
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "RemoveClass", exception.message, false);
        }
    },

    /**
     * Format the callflow
     * @param {} flowname 
     * @returns {} 
     */
    FilenameFormatter: function (flowname) {
        try {
            var splitfilename = flowname.split('_');
            var FileInfo =
            {
                FlowName: splitfilename[0],
                CurrentUser: splitfilename[1],
                yymmdd: splitfilename[2],
                VersionMajor: splitfilename[3],
                VersionMinor: splitfilename[4],
                Currentstatus: splitfilename[5],

            };
            return FileInfo
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "FilenameFormatter", exception.message, false);
            return {};
        }
    },


    // ---------------------------------------------------------------------------------
    // Load Assembly Version
    // ---------------------------------------------------------------------------------
    LoadAssemblyVersion: function () {
        var status = false;
        $.ajax({
            url: window.ApplicationPath + "Application/GetAssemnblyVersion",
            type: 'POST',
            async: false,
            data: $('form').serialize(),
            dataType: 'json',
            success: function (result) {
                
                for (let i = 0; i < result.Assembly.length; i++) {
                    if (result.Assembly[i].Component === "InteractionWorkflow") {
                        $("#spnversion").text(result.Assembly[i].CurrentVersion);
                        try {
                            $("#IWVersion").html('<span>' + result.Assembly[i].CurrentVersion.split('.')[0] + "." + result.Assembly[i].CurrentVersion.split('.')[1] + '</span>' + " " +
                                result.InteractionWorkflowType.toUpperCase()
                                );
                        } catch (e) {
                        }
                    }

                    AddToFileVersionController({
                        Location: "ServerComponent",
                        FileName: result.Assembly[i].Component,
                        Version: result.Assembly[i].CurrentVersion
                    });

                }


                // license

                if (result.License.StatusCode !== "0") {
                    if (result.License.StatusCode === "-2") {
                        // still continue
                        $("#spnLicenseStatus").text(result.License.Status);
                        status = true;
                    } else {
                        var txt = '<i class="material-icons IW-License-Error-Icon">security</i> <span class="uk-text-danger IW-License-Error-Text">' + result.License.Status + '</span>';
                        $("#fileStatus").html(txt);
                        status = false;
                    }

                } else {
                    status = true;
                }

                //status = true;
            },
            //error: appevent.Log.OnAjaxError
        });

        return true;    //ReviewCodeLine      

        return status;
    },

    /**
     * Get the Callflow data
     * @param {} callflowname : name of the callflow to get the data
     * @returns {} callflow data.
     */
    GetCallflowData: function (callflowname) {
        try {
            $.ajax({
                url: window.ApplicationPath + "Application/GetDataDnisbased?dnis=" + callflowname,
                type: 'POST',
                async: false,
                data: $('form').serialize(),
                dataType: 'json',
                success: function (result) {
                    var jsonDataObj = $.parseJSON(result.JsonObject);
                    return jsonDataObj;
                }
            });
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetCallflowData", exception.message, false);
        }
    },


    /**
     * Is this a Order taking callflow ? 
     * @returns {} 
     * callflow : curret callflow
     */
    isOrderTakingCallflow: function (callflow) {

        var isOrdertaking = false;
        try {

            // If callflow is empty
            if ($.trim(callflow).length === 0) {
                // During callflow or DNIS/START ordertaking creation
                if ($("#hdnFlowType").val() === "ordertaking") isOrdertaking = true;
            } else {
                if (window.ApplicationPomConfiguration.jsonDataObj.Header.CallflowType.toLowerCase() === "ordertaking")
                    isOrdertaking = true;
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "ConfigureForOrderTaking", exception.message, false);
        }

        return isOrdertaking;
    },

    /*
        Load all the Session Variables.

    */
    LoadSessionVariables: function () {
        try {
            var $that = this;
            $.ajax({
                url: window.ApplicationPath + "OrderTake/GetSessionVariables",
                type: 'POST',
                async: true,
                //data: $('form').serialize(),
                dataType: 'json',
                success: function (result) {

                    var jsonDataObj = $.parseJSON(result); //jsonQ(jsonObj);
                    // update the Global object to current object
                    window.ApplicationPomConfiguration.SessionVariableObj = jsonDataObj;

                }
            });
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "LoadSessionVariables", exception.message, false);
        }
    },

    /*
     * Export kendo grid to . csv */
    DownloadCsvFile: function (gridID, FileName, isFiltered) {
        //  Mar 21, '18 : Vishal : Print either all which take from data() or filtered which is from view()

        var grid = $("#" + gridID).data("kendoGrid");
        var csv = '';
        fileName = FileName + ".csv" || 'download.csv';

        var data = null;
        //  If isFiltered is true, print only filtered results, otherwise all data
        if (isFiltered) {
            var dataSource = grid.dataSource;
            var filters = dataSource.filter();
            var allData = dataSource.data();
            var query = new kendo.data.Query(allData);
            var data = query.filter(filters).data;
        } else {
            data = grid.dataSource.data();
        }

        //add the header row
        for (var i = 0; i < grid.columns.length; i++) {
            if (grid.dataSource.options.fields[i].hidden) { //  To skip columns that are hidden
                continue;
            }
            var field = grid.columns[i].field;
            var title = grid.columns[i].title || field;

            //NO DATA
            if (!field) continue;

            title = title.replace(/"/g, '""');
            csv += '"' + title + '"';
            if (i < grid.columns.length - 1) {
                csv += ',';
            }
        }
        csv += '\n';

        //add each row of data
        for (var row in data) {
            for (var i = 0; i < grid.columns.length; i++) {
                if (grid.dataSource.options.fields[i].hidden == true) { //  To skip columns that are hidden
                    continue;
                }
                var fieldName = grid.columns[i].field;
                var template = grid.columns[i].template;
                var exportFormat = grid.columns[i].exportFormat;

                //VALIDATE COLUMN
                if (!fieldName) continue;
                var value = '';
                if (fieldName.indexOf('.') >= 0) {
                    var properties = fieldName.split('.');
                    var value = data[row] || '';
                    for (var j = 0; j < properties.length; j++) {
                        var prop = properties[j];
                        value = value[prop] || '';
                    }
                } else {
                    value = data[row][fieldName] || '';
                }
                if (value && template && exportFormat !== false) {
                    value = _.isFunction(template)
                        ? template(data[row])
                        : kendo.template(template)(data[row]);
                }
                value = value.toString().replace(/"/g, '""');
                csv += '"' + value + '"';
                if (i < grid.columns.length - 1) {
                    csv += ',';
                }
            }
            csv += '\n';
        }

        //EXPORT TO BROWSER
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' }); //Blob.js
        saveAs(blob, fileName); //FileSaver.js
    },
    /**
     *  * Vishal Pinto : May 23 '18 
     * Gets user type based on the flow operation.
     *  * If it's  checker operations like checkerDraft, it returns "CHECKER"
     *  * If it's  checker operations like draft, it returns "MAKER"
     */
    GetCurrentFlowRole: function (fileName) {
        try {
            var userRoles = $("#hdnApplicationSpecialUserType").val().split(',');
            fileName = fileName.toLowerCase();
            if (userRoles.length === 1)
                return window.ApplicationPomConfiguration.FileInfo.CurrentUserType;
            else {
                if (fileName.indexOf("checker") > 0 || fileName.indexOf("checkersaved") > 0)
                    return "CHECKER";
                else
                    return "MAKER";
            }
        } catch (e) {
            this.Log.LogDetails(this.Log.logType.Error, "LoadSessionVariables", e.message, false);
        }
    },

    /**
     * Close all kendo winows
     * @returns {} 
     */
    CloseAllKendoWindow: function () {
        try {
            if (WindowPopup !== undefined) WindowPopup.close();
            if (windowpopupwidget !== undefined) windowpopupwidget.close();
            if (windowpopupGlobalPhrase !== undefined) windowpopupGlobalPhrase.close();
        } catch (e) {
            this.Log.LogDetails(this.Log.logType.Error, "CloseAllKendoWindow", e.message, false);
        }
    },

    /**
     * Decode the encodedURL
     * @param {} encodedString 
     * @returns {} 
     */
    CustomDecodeURIComponent: function (encodedString) {

        var data = decodeURIComponent(encodedString);
        var replcad = data.replace(/"/g, "'"); //replace(/"/g, '"');//replace(/(['"])/g, "'\$1");
        return replcad;

    },
    CustomEncodeURIComponent: function (encodedString) {
        encodedString = encodedString.replace(/"/g, "'");
        var data = encodeURIComponent(encodedString);
        var replcad = data.replace(/'/g, "%27");
       
        return replcad;

    },

    /**
     * Get the Interaction Callflow Type.
     * This will return either chat or ivr
     * @param {} callflowName 
     * @returns {} 
     */
    GetInteractionWorkflowType: function (callflowName) {
        var callflowType = "ivr";
        try {
            $.ajax({
                url: window.ApplicationPath + "Application/GetDataDnisbased?dnis=" + callflowName,
                type: 'POST',
                async: false,
                dataType: 'json',
                success: function (result) {
                    var jsonDataObj = $.parseJSON(result.JsonObject);
                    callflowType = jsonDataObj.Header.CallflowType;
                    if (callflowType === undefined) callflowType = "ivr";

                },

            });
            
        } catch (e) {
            this.Log.LogDetails(this.Log.logType.Error, "GetInteractionWorkflowType", e.message, false);
        }

        return callflowType;
    },

    /**
     * Gets plain text from HTML
     * @param htmlString
     * @returns
     */
    GetPlainText: function (htmlString) {
        return $('<div>').html(htmlString)[0].innerText;
    },
}

/*
    Detects the key is number
*/
function isNumberKey(event) {
    var appUtilities = new AppUtilities();
    return appUtilities.isNumberKey(event);
}


/*
    Detects the key is DTMF
*/
function isDTMFKey(event) {
    var appUtilities = new AppUtilities();
    return appUtilities.isDTMFKey(event);
}

/**
 * Store all client side scripts to version manager
 * @param {} versionObj 
 *      Structure should be in
 *      {
 *          Location:ModelObj
 *          FileName : xxxx.js
 *          Version : 8.15
 *          LastModifiedDateTime : DateTime
 *          LastModifiedBy: name of the developer who modified this.
 *          Description : short description abt changes
 *      }
 * @returns {} 
 */
function AddToFileVersionController(versionObj) {
    var utils = new AppUtilities();
    try {
        // versionObj.Version = window.ApplicationUISettings.FileVersions.MajorVersion + "." + versionObj.Version;
        // check is this file is already exists ?
        for (let i = 0; i < window.ApplicationUISettings.FileVersions.Files.length; i++) {
            if (window.ApplicationUISettings.FileVersions.Files[i].Location === versionObj.Location
                && window.ApplicationUISettings.FileVersions.Files[i].FileName === versionObj.FileName) {
                window.ApplicationUISettings.FileVersions.Files.splice(i, 1);
                break;
            }
        }

        // lets push this item again to collection
        window.ApplicationUISettings.FileVersions.Files.push(versionObj);
    } catch (exception) {
        utils.Log.LogDetails(utils.Log.logType.Error, "AddToFileVersionController", exception.message, false);
    }
}

/**
 *  Converts a sentence to title case
 * */
$(document).ready(function () {
    String.prototype.toProperCase = function () {
        return this.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
    };
});