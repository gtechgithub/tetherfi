﻿/* -----------------------------------------------------------------------------------------------------------------
 * <copyright file Pom\Flow.js  company="Tetherfi Pte. Ltd.">
 *      Tetherfi™ 
 * </copyright>
 * <author>Prakash D'souza</author>
 * <CreatedOn> 09/01/2018  11:50 AM</CreatedOn>
 * <LastModified>09/01/2010  11:50 AM</LastModified>
 * <summary>
 *     Formats the node and Draw the call flow 
 * </summary>         
 * ---------------------------------------------------------------------------------------------------------------*/
var ApplicationPomConfiguration = {
    jsonDataObj: "",
    jsonData: "",
    EnableRemoteLogging: false
};
var GraphconfigSettings = {
    instance: null,
    DefaultNodePosition: "100:100"
};



$(document).ready(function () {
    /**
 * Define the Version
 * @returns {} 
 */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "Flow.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Ashwath",
        Description: "New commit."
    });

    var flowDiagram = new Flowdiagram();
    flowDiagram.Preview();
});


/*
    Define the class object
*/
var Flowdiagram = function () {
    // Define the Logger
    this.Log = new Logger();
};


/*
    in-herit current class object, add ore featues 

*/
Flowdiagram.prototype = {



    /*
        Save the connection points.
    */
    SavePomComponents: function () {
        let $that = this;
        try {

            $that.UpdateNodePosition();

            /**
             * Get parent cheild details
             */
            //var parentClildData = {
            //    CurrentNode:""
            //}
            var dataparser = new DataParser();
            var finalResult = [];
            var data = window.ApplicationPomConfiguration.jsonDataObj;
            for (let i = 0; i < data.length; i++) {
                let parentNodeId = data[i].Connection.ParentNode;
                let parent = null;
                if (parentNodeId !== "") {
                    parent = dataparser.GetData(data[i].Connection.ParentNode, "")[0];
                }

                let parentText = "";
                if (parent !== null) {
                    parentText = parent.Text;
                }
                finalResult.push({
                    "NextLinkedName": data[i].Text,
                    "CampaignName": parentText
                });
            }


            //var $that = this;
            var jsondata = {
                'JsonObject': JSON.stringify(finalResult)
            };

            $.ajax({
                type: "POST",
                data: JSON.stringify(jsondata),
                url: window.ApplicationPath + 'CampaignLinking/SaveCampaignLinks',
                contentType: 'application/json',
                dataType: "json",
                success: function (data) {
                    swal("Callflow saved.");
                    $that.SavePomConnectionToFile();
                },
                error: function () {
                    console.log('Failed to save');
                }
            });



        } catch (exception) {
            $that.Log.LogDetails($that.Log.logType.Error, "SavePomComponents", exception.message, false);
            return false;
        }


    },



    /*
        Save the connection points.
    */
    SavePomConnectionToFile: function () {
        var $that = this;
        var jsondata = {
            'jsontosave': JSON.stringify(window.ApplicationPomConfiguration.jsonDataObj)
        };
        try {
            $.ajax({
                type: "POST",
                data: JSON.stringify(jsondata),
                url: window.ApplicationPath + 'CampaignLinking/WriteCampaignLinkToFile',
                contentType: 'application/json',
                dataType: "json",
                success: function (data) {
                },
                error: function () {
                    console.log('Failed to save to file');
                }
            });
        } catch (exception) {
            $that.Log.LogDetails($that.Log.logType.Error, "SavePomConnectionToFile", exception.message, false);
            return false;
        }
    },


    /*
        Remove the connection points for single node
        and delete the block
    */
    ClearSingleConnection: function (source, removeblock) {
        try {

            window.GraphconfigSettings.instance.deleteEndpoint(source + "Bottom");
            window.GraphconfigSettings.instance.deleteEndpoint(source + "TopCenter");

            if (removeblock) {
                $("#" + source).remove();
            }

        } catch (exception) {
            console.log("[ClearSingleConnection] : " + exception.message);
        }
    },

    /**
     * Clear DOm Elements
     * @returns {} Nothing
     */
    ClearDOMFlow: function () {
        try {
            var dataparser = new DataParser();
            var data = dataparser.GetData("", "");

            $.each(data, function (key, value) {
                try {
                    window.GraphconfigSettings.instance.deleteEndpoint(value.Id);
                    $("#" + value.Id).remove();
                } catch (e) { }
            });



            // reset all the Connections
            window.GraphconfigSettings.instance.deleteEveryEndpoint();
        } catch (exception) {
            console.log("[ClearSingleConnection] : " + exception.message);
        }
    },

    /**
     * Clear call flow:, delete all the DOM obj from screen
     * @returns {} 
     */
    ClearFlow: function () {
        try {
            var dataparser = new DataParser();
            var data = dataparser.GetData("", "");

            $.each(data, function (key, value) {
                try {
                    window.GraphconfigSettings.instance.deleteEndpoint(value.Id);
                    $("#" + value.Id).remove();
                } catch (e) { }
            });

            // reset all the Connections
            window.GraphconfigSettings.instance.deleteEveryEndpoint();

        } catch (exception) {
            console.log("[ClearFlow] : " + exception.message);
        }
    },

    /*
        Re-establish all the connections again
        Call this method to re-set all the connections. Before this, need to call clear flow to clear all the DOM elements
    */
    ResetConnections: function () {
        try {
            ////;
            var $that = this;
            var dataprser = new DataParser();
            var data = dataprser.GetExisitingConnections("", "");
            for (var i = 0; i < data.length; i++) {
                if (data[i].source !== "") $that.buildConnections(data[i].source, data[i].destination);
            }
        } catch (exception) {
            console.log("[ResetConnections] : " + exception.message);
        }
    },

    /*
        Validate the connections
        Rules :
            1. Once source to destination set, it should not be reverse
            2. Duplicate conenctions same from source to destination twice
            3. Dnis to destination should be only one connection. no multiple connections fron dnis to destination allowed
    */

    isValidConnection: function (sourceId, destinationId, sourceData, DestinationData) {
        try {
            // 08/24/2017 : when user drag and drop to same node location
            if (sourceId === destinationId) {
                return "Invalid Connections. Source and destination nodes are the same.";
            }
            if (sourceData.Text === DestinationData.Text) {
                return "Invalid Connections. Source and destination nodes are the same.";
            }
            var dataparser = new DataParser();

            var parent = dataparser.GetParentConnection(sourceId);
            // 1. Once source to destination set, it should not be reverse
            if (parent)
                if (parent.length > 0 && parent[0].source === destinationId) {
                    return "You cannot set reverse connection";
                }

            // 2. Duplicate conenctions same from source to destination twice
            if (dataparser.GetExisitingConnections(sourceId, destinationId).length > 0) {
                return "Connection already set";
            }

            // 3. Dnis to destination should be only one connection. no multiple connections fron dnis to destination allowed
            if (sourceData.Type === "dnis") {
                var leg = new Legs();
                var dnisLegs = leg.GetChildrens(sourceData.Id)[0].Legs;
                if (dnisLegs[0].NextNodeId.length > 0) {
                    return "Multiple Connections from Dnis not allowed";
                }
            }


            return "";
        } catch (exception) {
            console.log("[isValidConnection] : " + exception.message);
            return false;
        }

    },

    /*
        Parse data to json object
    */
    ParseToJson: function (jsonDataObj) {
        try {
            window.ApplicationPomConfiguration.jsonData = jsonQ(jsonDataObj);
        } catch (err) {
            console.log(err.message);
        }
    },

    /*
     * Get exiting pom data from backend
     */
    GetData: function () {
        var randomPos = true; //should be false if the OCM version is 3.2.8.30 and above
        try {
            var $that = this;
            $.ajax({
                url: window.ApplicationPath + "CampaignLinking/Getdata",
                type: 'POST',
                async: false,
                dataType: 'json',
                success: function (result) {
                    if (result === "") {
                        // Lets log the error
                        return;
                    }

                    var jsonDataObj = $.parseJSON(result);
                    if (randomPos) {
                        for (i = 0; i < jsonDataObj.length; i++) {
                            if (jsonDataObj[i].Text === "") {
                                delete jsonDataObj[i];
                                break;
                            }
                            var a = Math.floor(Math.random() * (900 - 200) + 200);
                            var b = Math.floor(Math.random() * (700 - 200));
                            //if (b > 400) {
                            //    b = b - 200;
                            //}
                            var c = "" + a + ":" + b;
                            jsonDataObj[i].Position = c;
                        }
                    }
                    // update the Global object to current object
                    window.ApplicationPomConfiguration.jsonDataObj = jsonDataObj;


                    // Parse the data
                    $that.ParseToJson(jsonDataObj);


                }
            });
        } catch (exception) {
            console.log("[GetData] : " + exception.message);
        }
    },

    /**
     * Preview the Designer
     * @returns {} nothing.
     */
    Preview: function () {
        try {

            // initilse the current object 
            var $that = this;
            var dataParser = new DataParser();


            // Clear Exisitng flow, disconnetcs the connections and clear all the DOM elements from the canvas
            $that.ClearFlow();

            // Set the unique SessionId
            //var utils = new AppUtilities();

            // Get the data from server for current selected callflow, and set to global configvariables
            $that.GetData();

            //var data = window.ApplicationPomConfiguration.jsonDataObj;
            //if (data !== null) {
            //    utils.GetCursorPosition(data);
            //}

            // Since jsplum not yet ready. so re-build the jsplumb instance.
            if (window.GraphconfigSettings.instance === null) {
                var jsplumb = new jsPlumbSettings();
            }

            // Generate the Tree.
            $that.GenerateTree(false);
            // regenerate the conenction
            // since the flow of the data won't be in order, so we have to re-establish the connections
            $that.ResetConnections();
        } catch (exception) {
            console.log("[Preview] : " + exception.message);
        }
    },

    /*
        Add new node block in to the screen/canvas.
        this may be menu/module/option/Agent/conditional node
    */
    AddNewNode: function (node, setConnections) {
        try {
            // initilise the object variables 
            var $currentobj = this;
            var utils = new AppUtilities();


            // lets add this node to the collection
            // lets add this node to ApplicationConfigurationSettings.jsonDataObj
            utils.AddGenericNodetoCollection(node);

            // build the DOM object
            var domobj = $currentobj.buildDOM("", node);

            // build Connection Points
            $currentobj.buildConnectingPoints(domobj, node.Id);

            // set the connections
            if (setConnections) $currentobj.buildConnections(node.Connection.ParentNode, node.Id);

        } catch (exception) {
            console.log("[AddNewNode] : " + exception.message);
            // this.Log.LogDetails(this.Log.logType.Error, "AddNewNode", exception.message, false);
        }

    },

    /*
        Generate entire call flow Tree
    */
    GenerateTree: function (setconnections) {
        try {
            // initialise the object variables
            var $currentobj = this;
            var dataParser = new DataParser();

            // Get entire call flow data
            var data = dataParser.GetData("", "");

            // Iterate the data object one-by-one
            $.each(data, function (i, value) {
                // build the DOM object for this node
                var domobj = $currentobj.buildDOM("", value);

                // build the connection Points
                $currentobj.buildConnectingPoints(domobj, value.Id);

                // set connections
                if (setconnections) $currentobj.buildConnections(value.Connection.ParentNode, value.Id);

            });

            /*
        
        // Iterate all the nodes from here
        types.each(function (index, path, value) {
            // if (value.type.toLowerCase() !== "menu") {
            //console.log(value.name + '  ' + value.age);
            // lets generate Dom and connection
            var position = "bottom";

            // tab detection
            if (value.TabId === undefined || value.TabId === currentTabId) {
                var domobj = $currentobj.buildDOM(value.Type.toLowerCase(), value);
                $currentobj.buildConnectingPoints(domobj, value.Id);
                if (setconnections) $currentobj.buildConnections(value.Connection.ParentNode, value.Id);
            }
            // }
        });
        */
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GenerateTree", exception.message, false);
        }
    },


    /*
        Build DOM Object based on the elements passed.
        Based on the node type, we are setting node background-color,icon,text,tooltip ..etc.
        Node will be highlighted based on the user type
           For CHECKER : if MAKER changed the node content and saved
           ForMAKER    : If CHECKER Rejected the specific node
    */
    buildDOM: function (type, value) {
        try {
            // Initialize the Obj variables
            var apputils = new AppUtilities();

            var dataparser = new DataParser();

            var classname = '';
            var highlightclass = "";



            // initilse the temporary vaiables
            var texttoPrint = "",
                //icon = "home",
                icon = '<i class="material-icons md-24">home</i>',
                editfunction = "",
                deleteFunction = 'DeleteNode(' + apputils.AddSingleQuote(value.Id) + ')',
                dropableClass = "",
                refreshFunction = "";

            texttoPrint = $.trim(value.Text);
            icon = "highlight_off";
            icon = '<i onclick="' + deleteFunction + '" class="material-icons md-24"   style="color:red;cursor:pointer;"  data-uk-tooltip="{cls: \'help\',pos:\'top\'}" title=' +
                apputils.AddSingleQuote(texttoPrint) + '>' + icon + '</i>';
            editfunction = "EditQuestionSettings(" + apputils.AddSingleQuote(value.Id) + ")";
            classname = 'md-bg-blue-500';

            // Show View connections for entry point
            //if (isEditable)
            refreshIcon = '<i style="cursor:pointer" class="custom-md-icon material-icons md-24 uk-text-danger" data-uk-tooltip="{cls: ' +
                apputils.AddSingleQuote("help") + ',pos:' + apputils.AddSingleQuote("bottom") + '}"' +
                ' title="View Connections" onclick=' + refreshFunction + '>call_split</i>';

            // set the node Identity (id)
            var blkid = value.Id + "_cardblock";
            var titleid = value.Id + "_nodeTitle";
            var toggleid = value.Id + "_nodetoggler";

            var navigation = '';

            navigation = ' <div class="window ' + dropableClass + '" id="' + value.Id +
                '" style ="left:' + value.Position.split(':')[0] + 'px; top:' + value.Position.split(':')[1] + 'px; ">' +
                '<div class="cfwidget-node md-card md-card-hover md-card-overlay md-card uk-animation-slide-top ' + classname + '" id="' + blkid + '">' +
                '<div class="md-card-content uk-text-center">' +
                '<div class="md-card-overlay-wrap">' +
                '<div id="' + toggleid + '" class="md-card-widget-icon ' + highlightclass + '">' +
                icon +
                '</div>' +
                '<div class="md-card-widget-label">' +
                '<label class="uk-text-center node-label" id="' + titleid + '" data-uk-tooltip="{cls: ' +
                apputils.AddSingleQuote("help") + ',pos:' + apputils.AddSingleQuote("top") + '}" ' +
                'title="' + texttoPrint + '">' + texttoPrint + '</label>' +
                '</div>' +
                '</div>' +
                '</div>';
            // Append it to Canvas
            var div = $(navigation).appendTo('#canvas');

            window.GraphconfigSettings.instance.draggable(div, { containment: true });
            // Finally , return the DOM object for Connections
            return div;
        } catch (exception) {
            // console.log("[buildDOM] : " + exception.message);
            this.Log.LogDetails(this.Log.logType.Error, "buildDOM", exception.message, false);
        }
    },

    /**
     * Set the End points
     * @param {} destinationId DestinationId 
     * @param {} sourceAnchors SourceAnchor
     * @param {} targetAnchors Target Anchor
     * @returns {} Nothing
     */
    _addEndpoints: function (destinationId, sourceAnchors, targetAnchors) {

        // iterate the source anhors, basically it will be one anchor
        for (var i = 0; i < sourceAnchors.length; i++) {
            var sourceUuid = destinationId + sourceAnchors[i];
            var bt = sourceAnchors[i];
            // Its a 'Bottom' anchor,set the point at botton else set at TOP
            if (sourceAnchors[i] === "Bottom") bt = [0.5, 1, 1, 1];
            window.GraphconfigSettings.instance.addEndpoint(destinationId, window.GraphconfigSettings.endpointOptions, {
                anchor: bt, uuid: sourceUuid
            });
        }

    },

    /*
       Define the Connections to the elements
    */
    buildConnectingPoints: function (domobj, domid) {
        try {
            var $that = this;
            // _addEndpoints("Window4", ["TopCenter", "BottomCenter"], ["LeftMiddle", "RightMiddle"]);
            // Check for Dnis. If its a dnis, will not create a Top Anchor

            var dataparse = new DataParser();

            var data = dataparse.GetData(domid, "")[0];

            if (data === undefined) return;
            if (data === "") return;
            // when user creates a  nodes manually. there wont be any records in the json
            if (data.length === 0) return;

            // Dont create DNIS connector. In other cases, we will set Pointer to both TOP and BOTTOM
            $that._addEndpoints(domid, ["TopCenter"]);

            $that._addEndpoints(domid, ["Bottom"]);
        } catch (exception) {
            console.log("[buildConnectingPoints] : " + exception.message);
            // this.Log.LogDetails(this.Log.logType.Error, "buildConnectionPoints", exception.message, false);
        }

    },

    /*
        Establish the connection between two Elements
    */
    buildConnections: function (source, destination) {
        try {
            // Source and Destination should not be same
            if (source === destination) return;

            // 08/23/2017
            // since its a loop/iterate of all the nodes, and all the childs of the 'menu' will re-create the connection
            // have to avoid for duplicate connections
            var $that = this;
            var activeConnections = $that.GetActiveConnections();
            for (var c = 0; c < activeConnections.length; c++) {
                if (activeConnections[c].pageSourceId.toLowerCase() === source.toLowerCase() &&
                    activeConnections[c].pageTargetId.toLowerCase() === destination.toLowerCase()) {
                    return;
                }
            }

            // Initialsise the obj variable.
            var dataparse = new DataParser();
            var leg = new Legs();

            // Get all the childrens for the source element.
            var child = leg.GetChildrens(source)[0].Legs;

            // Destination/ current node
            var currennode = dataparse.GetData(destination, "")[0];

            // Is there any childrens and Parent node is Empty
            if (child.length > 0 && currennode.Connection.ParentNode === "") {
                // Set conenction points to both TOP and BOTTOM
                window.GraphconfigSettings.instance.connect({
                    uuids: [source + "Bottom", destination + "TopCenter"],
                    editable: true,
                    cssClass: "redLine"
                });

                // If there is childrens and parent is not Empty
            } else if (child.length > 0 && currennode.Connection.ParentNode !== "") {
                var label = "";
                var parent = dataparse.GetData(source, "")[0];

                label = "";
                //// Set both Pointer TOP and BOTTOM
                window.GraphconfigSettings.instance.connect({
                    uuids: [source + "Bottom", destination + "TopCenter"],
                    editable: true,
                    overlays: [
                        "Arrow",
                        ["Label", { label: label, location: 0.40, id: "myLabel" }]
                    ],

                });

            } else {
                window.GraphconfigSettings.instance.addEndpoint(domobj, {
                    uuid: domid,
                    anchor: "Top",
                    maxConnections: -1,

                }, endpointOptions);

            }
        } catch (exception) {
            console.log("[buildConnections] : " + exception.message);
            // this.Log.LogDetails(this.Log.logType.Error, "buildConnection", exception.message, false);
        }
    },

    /*
        define Droppable DOM. user will drag and drop over the card element dom.
        NOT USED
    */
    createDroppableElements: function (id, charttype) {
        try {
            var chartdroppableClass = charttype === "treechart" ? "Drag-n-Drop-hover-Tree-chart" : "Drag-n-Drop-hover-Org-chart";
            $(id).droppable({
                tolerance: 'pointer',
                tolerance: 'pointer',
                hoverClass: chartdroppableClass,
                activate: function (event, ui) {
                    $(this).addClass("over");
                },
                deactivate: function (event, ui) {
                    $(this).removeClass("over");
                },
                drop: function (event, ui) {
                    // Lets fill some data
                    $("#txtparentNode").val($(this).attr("id"));
                    $('#modelAddNewNode').modal('show');
                }
            });
        } catch (exception) {
            console.log("[createDroppableElements] : " + exception.message);
            // this.Log.LogDetails(this.Log.logType.Error, "createDroppableElements", exception.message, false);
        }
    },

    /*
        Get all the connections
    */
    GetActiveConnections: function () {
        var connections = [];
        try {
            $.each(window.GraphconfigSettings.instance.getConnections(), function (idx, connection) {
                connections.push({
                    connectionId: connection.Id,
                    pageSourceId: connection.sourceId,
                    pageTargetId: connection.targetId
                });
            });
        } catch (exception) {
            console.log("[GetActiveConnections] : " + exception.message);
            // this.Log.LogDetails(this.Log.logType.Error, "GetActiveConnections", exception.message, false);
        }
        return connections;
    },

    /**
     * Update the Current Node Position
     * @returns {} 
     */
    UpdateNodePosition: function () {
        try {
            var dataparser = new DataParser();

            var data = dataparser.GetData("", "");
            var utils = new AppUtilities();

            // Update only current Tab node positions
            $.each(data, function (key, value) {
                // get the position of the node/div
                var position = utils.GetElementPositinWithinContainer(value.Id);
                // update the position
                value.Position = position;

            });
            return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "IW TAB : UpdateNodePosition", exception.message, false);

        }
    },
};

/*
    Delete Node
*/
function DeleteNode(id) {
    var log = new Logger();
    try {
        var flow = new Flowdiagram();

        swal("Are you sure you want to delete this node?", {
            icon: "warning",
            buttons: {
                cancel: "Cancel",
                catch: {
                    text: "Yes",
                    value: "yes",
                }
            }
        }).then(function (value) {
            switch (value) {
                case "yes":
                    {
                        var dataparser = new DataParser();
                        if (dataparser.isDeletable(id)) {
                            if (!dataparser.RemoveNode(id)) {
                                swal("Unable to delete node. Please break all connections from the node and try again.");
                                //log.LogDetails(log.logType.Error,
                                //    "Delete Node", "Unable to delete node. Please break all connections from the node and try again.", true);
                                return;
                            }
                            // data is removed from  the flow. now remove from the screen
                            flow.ClearSingleConnection(id, true);
                            log.LogDetails(log.logType.Error, "Delete Node", "Node Deleted.", false);
                        } else {
                            swal("Unable to delete node. Please break all connections from the node and try again.");
                            //log.LogDetails(log.logType.Error,
                            //    "Delete Node", "Unable to delete node. Please break all connections from the node and try again.", true);
                        }
                    }
                    break;
            }
        });





        //UIkit.modal.confirm("Are you sure you want to delete this node?",
        //    function () {
        //        var dataparser = new DataParser();
        //        if (dataparser.isDeletable(id)) {
        //            if (!dataparser.RemoveNode(id)) {
        //                log.LogDetails(log.logType.Error,
        //                    "Delete Node", "Unable to delete node. Please break all connections from the node and try again.", true);
        //                return;
        //            }
        //            // data is removed from  the flow. now remove from the screen
        //            flow.ClearSingleConnection(id, true);
        //            log.LogDetails(log.logType.Error, "Delete Node", "Node Deleted.", false);
        //        } else {
        //            log.LogDetails(log.logType.Error,
        //                "Delete Node", "Unable to delete node. Please break all connections from the node and try again.", true);
        //        }

        //    }, { labels: { 'Ok': 'Yes', 'Cancel': 'No' } });


    } catch (exception) {
        console.log("[DeleteNode] : " + exception.message);
        // log.LogDetails(log.logType.Error, "DeleteNode", exception.message, false);
    }
};

