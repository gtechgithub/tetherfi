<?php
if ("download" == $_GET['type']) {
	
    $file = fopen("uploadedFiles\\publickeyconfig.properties","r");
	while(! feof($file))
	  {
	  echo fgets($file);
	  }
	fclose($file);

    exit;
} else {
	
if (move_uploaded_file($_FILES['file']['tmp_name'], "uploadedFiles\\publickeyconfig.properties")) {
		echo 'Success';
} else {
		echo 'Failed';
}
}
?>