﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "ocm.admin.js",
        Version: "3.2.9.1801",
        LastModifiedDateTime: "14-11-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "changes done for Module hierarchy"
    });
});
//-------------------------------------------------------------------------------------------------------------------
var gridId = "";
var gridData;
var UserName = "";
var TeamID = "";
var readFileAfterDelegate;
function CustomDeleteReason(e) {
    try {
        $("#ModifyReason1").val("")
        $("#modifyreasonwindow").show();
        e.preventDefault(); //prevent page scroll reset
        var tr = $(e.target).closest("tr"); //get the row for deletion
        gridData = this.dataItem(tr); //get the row data so it can be referred later
        var wdw = $("#myWindow").data("kendoWindow"); //get the Window widget's instance
        wdw.center().open();
        var path = window.location.pathname;
        var page = path.split("/")[1];
        gridId = e.delegateTarget.id;
    } catch (e) {
        console.log(e);
    }
}

function SupervisorRetagWindow(e) {
    try {
       
        $("#retagnewsupervisor").show();
        e.preventDefault(); //prevent page scroll reset
        var tr = $(e.target).closest("tr"); //get the row for deletion
        gridData = this.dataItem(tr); //get the row data so it can be referred later
       
        $("#retagnewsupervisortitle").html("<label>Choose new supervisor to retag supervisor/agent under team level: </label><span class='theme-color'> " + gridData.TeamName + "</span>");
        if (gridData.Profile == "Supervisor" && gridData.HasChild == true && $("#IsRetagSupervisor").val().toLowerCase() == "true") {
            UserName = gridData.UserName
            TeamID = gridData.TeamID
            var wdw = $("#retagnewsupervisorwindow").data("kendoWindow"); //get the Window widget's instance
            wdw.center().open();
            $("#retagnewsupervisorlist").data("kendoDropDownList").select(0);
            $("#retagnewsupervisorlist").data("kendoDropDownList").dataSource.read()
        }
        else {
            $("#ModifyReason1").val("")
            $("#modifyreasonwindow").show();
            var wdw = $("#myWindow").data("kendoWindow"); //get the Window widget's instance
            wdw.center().open();
        }
        var path = window.location.pathname;
        var page = path.split("/")[1];
        gridId = e.delegateTarget.id;
    } catch (e) {
        console.log(e);
    }
}
function getRetagSupervisorParam()
{
    return {
        id: UserName,
        teamid: TeamID,
        __RequestVerificationToken : $("#AntiForgeryToken").val() ,
    };
}

function CancelSupervisorRetag() {
    $("#retagnewsupervisorwindow").data("kendoWindow").close(); //get the Window widget's instance
}

function SupervisorRetagDeleteReason() {
    try {
        if ($("#retagnewsupervisorlist").data("kendoDropDownList").value() != "") {
            gridData.NewSupervisorID = $("#retagnewsupervisorlist").data("kendoDropDownList").value();
        }
        else {
            toaster("Please provide a valid Supervisor", "error");
            e.preventDefault();
        }
       
        $("#retagnewsupervisorwindow").data("kendoWindow").close(); //get the Window widget's instance
 
        $("#ModifyReason1").val("");
        $("#modifyreasonwindow").show();
       // e.preventDefault(); //prevent page scroll reset
        var wdw = $("#myWindow").data("kendoWindow"); //get the Window widget's instance
        wdw.center().open();
    } catch (e) {
        console.log(e);
    }
}

function DeleteRecord() {
    try {
        var grid = $("#" + gridId).data("kendoGrid");
        var modifyReason = $("#ModifyReason1").val();
        if ($.trim(modifyReason) == "") {
            toaster("Please enter the delete reason", "error");
            return;
        }
        if ($.trim(modifyReason).length >= 250) {
            toaster("Delete reason should be less than 250 characters", "error");
            return;
        }
        else {
            grid.dataSource.remove(gridData)
            gridData.ModifyReason = modifyReason;
            if (requestPrevent == 0) {
                $('#yesButton').hide();
                $.ajax({
                    url: "DeleteData",
                    type: 'POST',
                    sync: 'true',
                    datatype: 'json',
                    contentType: "application/json; charset=utf-8",
                    headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                    data: JSON.stringify(gridData), // Return a javaScript Error
                    success: function (result) {
                        requestPrevent = 0;
                        $('#yesButton').show();
                        message = result.Errors;
                        var y = message.hasOwnProperty("Success");
                        if (y == true) {
                            toaster(message.Success.errors[0], "success");
                            gridRefresh();
                        }
                        else
                            toaster(message.Failure.errors[0], "error");
                            gridRefresh();
                    }
                })
            }
            else {

            }
            requestPrevent = 1;
            //grid.dataSource.sync()
            $("#myWindow").data("kendoWindow").close(); //get the Window widget's instance
        }
    } catch (e) {
        console.log(e);
    }
}
function NoDeleteRecord() {
    $("#myWindow").data("kendoWindow").close(); //get the Window widget's instance
}


function buttonCloseClick() {

    $("#UserAccessGrid").css("display", "none");
    $("#UserId").val("");
}
function scrollTo() {
    try {
        $('html, body').animate({ scrollTop: $('#UserAccessGrid').offset().top }, 'slow');
    } catch (e) {

    }
    return false;
}

/*=============================================>>>>>
= Reusable Events =
===============================================>>>>>*/
/**
 * used to auto adjust the size of edit template in grid this is Center function
 */
jQuery.fn.center = function () {
    this.css("position", "center");
    this.css("top", "10%");
    this.css("left", "14.9%");
    //this.css("right", "14.9%");
    return this;
}


/**
 * on save modify reason
 * this is used by below module
 * Agentsetting
 * AgentTelephony
 * 
 */
function onSave(e) {
    //This method is in Validation.js in scripts
    modifyValid(e);
}
function empty() {
}
/**
 * Reusable edit event to hide modify reason 
 */
function genericEdit(e) {

    var height = $(window).width();
    heightper = (70 / 100 * height)
    $(".k-edit-form-container").width(heightper);
    $(".k-window").center();
    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }
}

function onOrgUnitBound(e) {
    $("#OrgUnit").val($("#LoggedInUsersTeam").val());
}
function bindingOrgUnit(e) {
    if ($("#ModuleHierachy").val().toLowerCase() == "true") {
        $("#OrgUnitGroup").show();

        if (e.model.isNew() == false) {
            if (e.model.OrgUnit !== null && e.model.OrgUnit !== '' && e.model.OrgUnit != 0) {
                $("#OrgUnit").val(e.model.OrgUnit);
            }
            else {
                $("#OrgUnit").val($("#LoggedInUsersTeam").val());
            }
        }
        else
        {
            $("#OrgUnit").val($("#LoggedInUsersTeam").val());
        }
    }
    else {
        $("#OrgUnitGroup").hide();
    }
}

//this gerneric fucntion will be called in admin pages with tab strip on select
function onSelect(e) {
    $("#" + formType).html('');
    var mystring = e.contentElement.id;
    mystring = mystring.replace('t', '');
    $("#dynamicSearchParam").val(mystring);
    $('#' + mystring).data('kendoGrid').dataSource.read();
    $('#' + mystring).data('kendoGrid').trigger("databound");
    //setGridHeight(0);
}

//this gerneric fucntion will be called in admin pages with tab strip on activate
function onActivate(e) {
    setTimeout(function () {
        setGridHeight(0);
    }, 100);
}

/**
 * 
 */
function clearAllFilter() {
    $("form.k-filter-menu button[type='reset']").trigger("click");
};

function attachClickHandler(e) {
    try {
        window.setTimeout(function () {
            var filename = e.files[0].name;
            $("#waveFileTag").val(filename);
            $(".k-upload-selected").click(function (e) {
                if (false) {
                    e.preventDefault();
                    return false;
                }
            });
        }, 1);
    } catch (e) {
        console.log(e);
    }
}


///Agent.js start 
function getRandomColor() {
    var letters = '0123456789ABCDE'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 15)];
    }
    return color;
}
var drawing = kendo.drawing;
var geometry = kendo.geometry;
function columnVisual(e) {
    return createColumn(e.rect, e.options.color);
}
function toggleHandler(e) {
    e.preventDefault();
    var visual = e.visual;
    var opacity = e.show ? 0.8 : 1;

    visual.opacity(opacity);
}
function createLegendItem(e) {
    var color = e.options.markers.background;
    var labelColor = e.options.labels.color;
    var rect = new geometry.Rect([0, 0], [120, 50]);
    var layout = new drawing.Layout(rect, {
        spacing: 5,
        alignItems: "center"
    });

    var overlay = drawing.Path.fromRect(rect, {
        fill: {
            color: "#fff",
            opacity: 0
        },
        stroke: {
            color: "none"
        },
        cursor: "pointer"
    });

    var column = createColumn(new geometry.Rect([0, 0], [15, 10]), color);
    var label = new drawing.Text(e.series.name, [0, 0], {
        fill: {
            color: labelColor
        }
    })

    layout.append(column, label);
    layout.reflow();

    var group = new drawing.Group().append(layout, overlay);

    return group;
}
function createColumn(rect, color) {
    var origin = rect.origin;
    var center = rect.center();
    var bottomRight = rect.bottomRight();
    var radiusX = rect.width() / 2;
    var radiusY = radiusX / 10;
    var gradient = new drawing.LinearGradient({
        stops: [{
            offset: 0,
            color: color
        }, {
            offset: 0.5,
            color: color,
            opacity: 0.9
        }, {
            offset: 0.5,
            color: color,
            opacity: 0.9
        }, {
            offset: 1,
            color: color
        }]
    });

    var path = new drawing.Path({
        fill: gradient,
        stroke: {
            color: color
        }
    }).moveTo(origin.x, origin.y)
        .lineTo(origin.x, bottomRight.y)
        .arc(180, 0, radiusX, radiusY, true)
        .lineTo(bottomRight.x, origin.y)
        .arc(0, 180, radiusX, radiusY);

    var topArcGeometry = new geometry.Arc([center.x, origin.y], {
        startAngle: 0,
        endAngle: 360,
        radiusX: radiusX,
        radiusY: radiusY
    });

    var topArc = new drawing.Arc(topArcGeometry, {
        fill: {
            color: color
        },
        stroke: {
            color: color
        }
    });
    var group = new drawing.Group();
    group.append(path, topArc);
    return group;
}
$(window).on("resize", function () {
    kendo.resize($("#tlkChart"));
});
function onSeriesClick(e) {
    console.log(kendo.format("Series click :: {0} ({1}): {2}",
        e.series.name, e.category, e.value));

    $("#dataToShow").html(kendo.format("Series click :: {0} ({1}): {2}",
        e.series.name, e.category, e.value));
    $('#myModal5').modal('show');
}
function onLegendItemClick(e) {
    setTotalLabel(e.sender, e.seriesIndex);
}
function setTotalLabel(chart, toggledSeriesIndex) {
    var series = chart.options.series;
    var lastSeries = {};
    var fields = [];

    for (var i = 0; i < series.length; i++) {
        var visible = series[i].visible;

        // We're about to toggle the visibility of the clicked series
        if (i === toggledSeriesIndex) {
            visible = !visible;
        }

        if (visible) {
            fields.push("dataItem." + series[i].field);
            lastSeries = series[i];
        }

        // Clean-up existing labels
        series[i].labels = {};
    }

    lastSeries.labels = {
        visible: true,
        template: "#=" + fields.join("+") + "#"
    };
}

function readFile(e, wrapper, validExt, calleeData) {

    var fileInfo = e.files[0];
    var raw = fileInfo.rawFile;
    var reader = new FileReader
    var extIndex = fileInfo.name.indexOf(".");
    var uploadedExt = fileInfo.name.substring(extIndex + 1, fileInfo.name.length);
    var result = true;
    //Need to refactor code for simplicity , committing due to time crunch
    reader.onloadend = function (evt) {
        var uploadedExtHeader;
        var expectedExtHeader;
      
        if (this.result.byteLength == 0) {
            toaster("Sorry, cannot upload empty file!", "error");
            removeSelectedFile(wrapper, fileInfo);
            return
        }
        if (uploadedExt === "csv" || uploadedExt === "txt") {
            expectedExtHeader = fileExtensionSignatures["exe"];
            uploadedExtHeader = new Uint8Array(this.result, 0, expectedExtHeader.length);
            for (var i = 0; i < uploadedExtHeader.byteLength; i++) {
                if (expectedExtHeader[i] == uploadedExtHeader[i]) {
                    removeSelectedFile(wrapper, fileInfo);
                    toaster("Please upload only " + validExt + " file!", "error");
                    result = false;
                    break;
                }
            }
        }
        else {
            expectedExtHeader = fileExtensionSignatures[uploadedExt];
            uploadedExtHeader = new Uint8Array(this.result, 0, expectedExtHeader.length); 
            for (var i = 0; i < uploadedExtHeader.byteLength; i++) {
                if (expectedExtHeader[i] != uploadedExtHeader[i]) {
                    removeSelectedFile(wrapper, fileInfo);
                    toaster("Please upload only " + validExt + " file!", "error");
                    result = false;
                    break;
                }
            }
        }
        if (readFileAfterDelegate)
            readFileAfterDelegate(result, fileInfo,calleeData);

    };
    reader.readAsArrayBuffer(raw);

    function removeSelectedFile(wrapper, fileInfo) {
        var selectedFile = wrapper.find(".k-file[data-uid='" + fileInfo.uid + "']");
        var status = wrapper.find(".k-upload-status")[0];
        selectedFile.parent()[0].remove();
        if (status)
            status.remove();
    }
}
//Agent.js end