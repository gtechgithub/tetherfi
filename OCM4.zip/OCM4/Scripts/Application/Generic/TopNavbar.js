﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
    */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "TopNavbar.js",
        Version: "3.2.9.1801",
        LastModifiedDateTime: "14-11-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: ""
    });
});



function UpdateTimeoutTime()
{
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/UpdateTimeoutTime',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data == true) {
                    console.log("Timeout updated.");
                }
                else {
                    console.log("Timeout updation error.");
                }
            }
        })
    } catch (e) {
    }
}

function GetUserReportList() {
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetUserReportList',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data != null) {
                    $("#NotificationCount").val(data.length);
                    $("#notificationCount").html(data.length);
                    $("#nav").empty();
                    var content = "";
                    data.forEach(function (item) {
                        content += "<a onclick='downloadreport(" + item.ID + "),remove(this),changeNotificationCount()'><div class='theme-color'><i class='fa fa-download fa-fw'></i> " + item.ReportName + "</div><span class='pull-left text-muted small' style='color:#000'>Generated On : " + moment(item.ReportGeneratedOn).format("DD/MM/YYYY, HH:mm:ss") + "</span></a><div class='divider'></div>";
                    });
                    content += "<li><div class='text-center link-block theme-color'><a href='" + window.ApplicationPath + "ReportDownload/Index'><strong>See all exported reports</strong><i class='fa fa-angle-right'></i></a></div></li>";
                    $("#nav").append("<li id='reports'>" + content + "</li>");
                }

                console.log("Notification Count: " + $("#NotificationCount").val());
                if ($("#NotificationCount").val() > 0 && $("#Client").val().toLowerCase() != "mbs") {
                    $("#notifications").removeClass("swing");
                    $("#notifications").addClass("swing");
                }
                else {
                    $("#notifications").removeClass("swing");
                }
            }
        })
    } catch (e) {
    }
}

function changeTheme(themename) {
    $("#themeul li").removeClass("fa fa-check fa-color");
    $("#" + themename + "themeli").addClass("fa fa-check fa-color");
    localStorage.setItem("ocmtheme", themename);
    setTheme(themename);
}

function changeFont(fontname) {
    $("#fontul li").removeClass("theme-color-background theme-text-color");
    $("#" + fontname + "fontli").addClass("theme-color-background theme-text-color");
    localStorage.setItem("ocmfont", fontname);
    setFont(fontname);
}

function openDropdown() {
    $("#profilelidropdown").addClass("open");
    $("#profiledropdown").attr("aria-expanded", "true");
}

function runTour() {
    ocmTour.run();
}

function downloadreport(iD) {
    post(window.ApplicationPath + 'ReportDownload/DownloadReport', { "iD": iD });
}

function changeNotificationCount() {
    $("#notificationCount").html((Number($("#notificationCount").text()) - 1).toString());
}

function post(path, params) {
    method = "post";
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    for (var key in params) {
        if (params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);
            form.appendChild(hiddenField);
        }
    }
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", "__RequestVerificationToken");
    hiddenField.setAttribute("value", $("#AntiForgeryToken").val());
    form.appendChild(hiddenField);

    document.body.appendChild(form);
    form.submit();
}

function remove(link) {
    link.parentNode.parentNode.removeChild(link.parentNode);
}