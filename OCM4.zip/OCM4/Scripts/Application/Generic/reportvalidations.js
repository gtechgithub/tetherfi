﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "reportvalidations.js",
        Version: "8.27",
        LastModifiedDateTime: "27-08-2018 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Version Changed."
    });
});

function onSelectExportAll() {
    try {

        if ($("#grid").data("kendoGrid").dataSource.total() != 0) {
            if ($("#grid").data("kendoGrid").dataSource.total() > parseInt($("#TotalExportToExcelLimit").val())) {
                toaster("Number of records being exported is greater than the export limit(" + $("#TotalExportToExcelLimit").val().toString() + ")", "error");
                return;
            }
            toaster("Report export is initiated... \n Notification will be sent once completed", "success");
            $("#isExportValue").val(true);
            $("#grid").data("kendoGrid").options.excel.allPages = true;
            $("#grid").data("kendoGrid").saveAsExcel();
            $("#grid").data("kendoGrid").options.excel.allPages = false;

            $("#exportAllToExcel").addClass("k-state-disabled");
            $("#exportAllToCsv").addClass("k-state-disabled");
            setTimeout(function () {
                $("#exportAllToExcel").removeClass("k-state-disabled");
                $("#exportAllToCsv").removeClass("k-state-disabled");
            }, 8000);
        }
        else {
            toaster("There is no record to export", "error");
        }
    }
    catch (e) {
        console.log(e);
    }
}


