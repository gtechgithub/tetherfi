﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "dynamicsearchmain.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Fixed Antiforgery issue in Advance search drop down"
    });
});

function GetComboParam() {
    return {
        reportType: $("#gridTypeValue").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function GetUcid() {
    return { ucid: $("#UCID").val() };
}

function GetFilterParam() {
    return {
        filterTypeValue: $("#filterTypeValue").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

//to add initial criteria on load
function AddInitialCriteria() {
    try {
        $("#clearAll").show();
        if ($("#searchForm").html().trim() == "") {
            idVal = new Array();
            id = id + 1;
            refId = refId + 1;
            var append = $("#searchForm");
            var template = $("#searchFormTemplate").html();
            var templateContent = template.replace(/_sc/g, id);
            $(templateContent).appendTo(append);
            setTimeout(function () {
                $("#" + id + "Form").removeClass("animated fadeIn");
            }, 500);
            idVal.push(id);
            $("#" + refId + "logicalRadioGroup").hide();
        }
    } catch (e) {
        console.log(e);
    }
}

//on change of text to search textbox
$(document).on("keyup", "input[class='k-textbox k-state-border-down']", function () {
    var inputID = this.id.toString().substring(4, this.id.length);
    if (inputID == "sTextToSearch" || inputID == "sMaskedTextToSearch")
        onSTextBoxChange(this);
    else
        onTextBoxChange(this);
});

$(document).on("keyup", "input[class='k-textbox']", function () {
    var inputID = this.id.toString().substring(4, this.id.length);
    if (inputID == "sTextToSearch" || inputID == "sMaskedTextToSearch")
        onSTextBoxChange(this);
    else
        onTextBoxChange(this);
});

function onTextBoxChange(e) {
    try {
        //while editing text box activate the logicalandor check buttons
        var inputID = e.id.toString().substring(0, 4);
        var button = $("#" + inputID + "AddButton").data("kendoButton");
        if (button != undefined) {
            if ($(e).val()) {
                button.enable(true);
            }
            else {
                button.enable(false);
            }
        }
       
    } catch (e) {
        console.log(e);
    }
}

//add button to display radio buttons
function AddButton(e) {
    try {
        //set an unique id for the add button
        var buttonID = this.element.attr("id");
        var generalID = buttonID.substring(0, 4);
        $("#" + generalID + "logicalRadioGroup").fadeIn();
    } catch (e) {
        console.log(e);
    }
}

//on change of checkbox to open advance search
$(document).on("change", "input[type='checkbox']", function () {
    try {
        if (!clearing) {
            if ($('#switch').is(':checked')) {
                switched = false;
                $("#showReportBtn").hide();
                $("#clearAllSearch").hide();
                $("#advanced").fadeIn();
                $("#showReportBtn").fadeIn();
                $("#clearAllSearch").fadeIn();
                $("#clearFilterBtnDiv").fadeIn();
                setReportType($("#reportname").val());
            }
            else {
                //if (switched)
                switched = true;
                ClearAll();
                $("#advanced").fadeOut(300);
                $("#showReportBtn").fadeOut(300);
                $("#showReportBtn").fadeIn(300);
                $("#clearAllSearch").fadeOut(300);
                $("#clearAllSearch").fadeIn(300);
                $("#clearFilterBtnDiv").fadeOut(300);
            }
        }
    } catch (e) {
        console.log(e);
    }
});

//on change of radio button
$(document).on("change", "input[type='radio']", function () {
    try {
        //after clicking on and/or another div(row) is created with a unique id
        var thisID = this.id.toString().substring(0, 4);
        var newID = parseInt(thisID) + 1;
        var inputID = this.id.toString().substring(4, this.id.length);

        if (inputID == "sRadioAND" || inputID == "sRadioOR") {
            var index = sAddedById.indexOf(parseInt(thisID));
            if (index == -1) {
                sAddedById.push(parseInt(thisID));
                //dynamicsearchapi.js
                SAddCriteria(thisID);
            }
            else if (sAllow) {
                if (thisID == sIdVal[sIdVal.length - 1]) {
                    sAddedById.push(parseInt(thisID));
                    SAddCriteria(thisID);
                }
            }
        }
        else {
            var index = addedById.indexOf(parseInt(thisID));
            if (index == -1) {
                addedById.push(parseInt(thisID));
                addCriteria(thisID);
            }
            else if (allow) {
                if (thisID == idVal[idVal.length - 1]) {
                    addedById.push(parseInt(thisID));
                    addCriteria(thisID);
                }
            }
        }
    } catch (e) {
        console.log(e);
    }
});

//clear advanced search
function clearAdvancedSearch() {
    try {
        if (switched)
            ClearAll();
        $("#advanced").fadeOut(300);
        $("#showReportBtn").fadeOut(300);
        $("#showReportBtn").fadeIn(300);
        $("#clearAllSearch").fadeOut(300);
        $("#clearAllSearch").fadeIn(300);
        $("#clearFilterBtnDiv").fadeOut(300);
        $('#switch').trigger("click");
    } catch (e) {
        console.log(e);
    }
}
//clear filter
function CloseButton(e) {
    try {
        var buttonId = $(e.event.target).closest(".k-button").attr("id");
        var ThisId = buttonId.substring(0, 4);
        var index = idVal.indexOf(parseInt(ThisId));
        var length = idVal.length;
        var lastVal = idVal[index];
        if (idVal.length > 1) {
            if (index > -1) {
                idVal.splice(index, 1);
                addedById.splice(index, 1);
                $("#" + ThisId + "Form").fadeOut();
                setTimeout(function () {
                    $("#" + ThisId + "Form").remove();
                }, 500);
                dynamicSearchFilterCount = dynamicSearchFilterCount - 1;
                length = idVal.length;
                var currId = idVal.length - 1;
                if (index <= length) {
                    $("#" + idVal[currId] + "RadioOR").removeAttr('checked');
                    $("#" + idVal[currId] + "RadioAND").removeAttr('checked');
                    $("#" + idVal[currId] + "logicalRadioGroup").hide();
                    $("#" + idVal[currId] + "AddButton").fadeIn();
                }
            }
        }
        else {
            $("#" + ThisId + "Form").addClass('animated shake');
            setTimeout(function () {
                $("#" + ThisId + "Form").removeClass('animated shake');
            }, 500);
            $("#" + ThisId + "logicalRadioGroup").hide();
            toaster("Cannot remove this filter!", "error");
        }
        if (addedById.length == 1 && idVal.length < 2) {
            var currId = idVal.length - 1;
            addedById = new Array();
        }
        else if (index == length) {
            allow = true;
        }
        else {
            allow = false;
        }
    } catch (e) {
        console.log(e);
    }
}

//clear all report filters
function ClearAll() {
    dynamicSearchFilterCount = 0;
    $("#searchForm").html('');
    AddInitialCriteria();
}

//clear all the search filters
function ClearAllSearch(showNotification) {
    try {
        if ($("#reportchannel").data("kendoDropDownList").value() != "" && $("#reportchannel").data("kendoDropDownList").value() != "Select Channel")//$("#reportname").data("kendoDropDownList").value() != "Select Report Name" && $("#reportname").data("kendoDropDownList").value() !="")
        {
            clearing = true;
            $("#reportchannel").data("kendoDropDownList").value("");
            $("#reportname").data("kendoDropDownList").value("");
            $("#quickSearchButton").css('display', 'none');
            $("#reporttype").data("kendoDropDownList").value("");
            $("#selectDateRange").fadeOut();
            $("#selectSingleDate").fadeOut();
            $('#singledatepicker').data("DateTimePicker").clear();
            $('#enddatepicker').data("DateTimePicker").clear();
            $('#startdatepicker').data("DateTimePicker").clear();
            //$("#singledate").data("kendoDateTimePicker").value(null);
            //$("#startdate").data("kendoDateTimePicker").value(null);
            //$("#enddate").data("kendoDateTimePicker").value(null);
            $("#advanceSearch").fadeOut();
            if ($('#switch').is(':checked')) {
                clearAdvancedSearch();
            }
            $("#reportname").data("kendoDropDownList").enable(false);
            $("#reporttype").data("kendoDropDownList").enable(false);
            clearing = false;
            if (showNotification) {
                toaster("Filters cleared successfully!", "success");
            }
        }
        else {
            if (showNotification) {
                toaster("Nothing to clear!", "error");
            }
        }
        onApplyQuickClear();
    } catch (e) {
        var err = new Error();
        console.log(err.stack);
        console.log(e);
        console.trace(e);
    }
}

//toast notification
function toaster(msg, type) {
    try {
        clearToast();
        var title = "";
        var shortCutFunction = type;
        toastr.options = {
            closeButton: true,
            debug: false,
            progressBar: true,
            positionClass: 'toast-top-center',
            onclick: null
        };
        toastr.options.showDuration = 400;
        toastr.options.hideDuration = 2000;
        toastr.options.timeOut = 4000;
        toastr.options.extendedTimeOut = 2000;
        toastr.options.showMethod = "fadeIn";
        toastr.options.hideMethod = "fadeOut";
        var $toast = toastr[shortCutFunction](msg, title);
    } catch (e) {
        console.log(e);
    }
}

//clear toast notification
function clearToast() {
    toastr.clear();
}

/**
 * Function used to determine the if its main grid or drill grid search
 * @param {string} type - Contains the type as main or drill.
 */
function DynamicSearch(type) {
    try {
        gridType = type;
        var reportnameval = $("#ControllerName").val().toLocaleLowerCase();
        if (type == "main") {
            if (reportnameval.indexOf("report") > 0) {
                $("#dynamicSearchParam").val("grid");
            }
            $("#gridTypeValue").val("" + reportnameval + type);
            $('#searchModel').modal('show');
            formType = "searchSForm";
            formTemplate = "searchSFormTemplate";
            AddSearch(1000, formType, formTemplate);
        }
        else if (type == "drill") {
            if (reportnameval.indexOf("report") > 0) {
                $("#dynamicSearchParam").val("drillGrid");
            }
            $("#gridTypeValue").val("" + reportnameval + type);
            formType = "searchDForm";
            formTemplate = "searchSFormTemplate";
            AddSearch(2000, formType, formTemplate);
        }
        else if (type == "drillView") {
            $("#gridTypeValue").val("" + reportnameval + type);
            $('#searchModel').modal('show');
            formType = "searchSForm";
            formTemplate = "searchSFormTemplate";
            AddSearch(3000, formType, formTemplate);
        }
        else {
            if (reportnameval.indexOf("report") > 0) {
                $("#dynamicSearchParam").val(type);
            }
            var number = 4000 + Math.floor(Math.random() * 4000);
            $("#gridTypeValue").val("" + reportnameval + type);
            formType = "searchDForm";
            formTemplate = "searchSFormTemplate";
            AddSearch(number, formType, formTemplate);
        }
    } catch (e) {
        console.log(e);
    }
}

function DynamicReportInnerSearch(type, formType) {
    try {
        var reportnameval = $("#ControllerName").val().toLocaleLowerCase();
        if (reportnameval.indexOf("report") > 0) {
            $("#dynamicSearchParam").val(type);
        }
        var number = 4000 + Math.floor(Math.random() * 4000);
        $("#gridTypeValue").val("" + reportnameval + type);

        formTemplate = "searchSFormTemplate";
        AddSearch(number, formType, formTemplate);
    }
    catch (e) {
        console.log(e);
    }
}
/**
 * on databound filters the grid and show message if no data is available.
 */
var databoundcount = 1;

function onDataBound(arg) {
    /// <summary>
    /// A generic function that performs certain functions like applying color when filtering grid, enable/disable grid auto resize and bind numbers to the
    /// </summary>
    /// <param name="arg">Contains the grids details</param>
    try {
        var gridName = arg.sender.element.closest('[data-role="grid"]').attr('id');
        var grid = $("#" + gridName).data("kendoGrid");
        //to avoid resize of grid when data source is cleared
        var filter = grid.dataSource.filter();
        addExtraHeightForGrid = ($("#" + gridName + " .k-grid-toolbar").height() == null || $("#" + gridName + " .k-grid-toolbar").height() == "" || $("#" + gridName + " .k-grid-toolbar").height() <= 0) ? 35 : 0;

        //Add theme-color class to the search icon if grid is filtered else show as default
        if (filter != undefined && filter != null && filter.filters.length > 0) {
            $('.clearSearch-link').addClass('theme-color');
            $('.fa-refresh').addClass('fa-spin');
        }
        else {
            $("a.clearSearch-link").removeClass("theme-color");
            $('.fa-refresh').removeClass('fa-spin');
        }

        //Enable/Disable Auto resize of columns in grid based on the global variable value
        if (gridName != "CallFlowGrid" && gridName != "MenuTraversalGrid") {
            if (enableDisableGridAutoResize == 0 && arg.sender.dataSource.data().length > 0) {
                var grid = $("#" + gridName).data("kendoGrid");

                for (var i = 0; i < grid.columns.length; i++) {
                    grid.autoFitColumn(i);
                }
            }
        }

        var pagesize = [];
        //Used for searching and set the grids datasource page number
        // $('#dynamicSearchParam').val(arg.sender.element[0].id)
        if (databoundcount == 1 && $("#ControllerName").val().toLowerCase().indexOf("report") > -1) {
            databoundcount = 0;
            var pagesizes = "5,10,20," + reportpagesize;
            //if ($("#" + gridName + " select[data-role=dropdownlist]").datasource != undefined)
            //{
            //    $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.data([]);
            //}
            $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.data([]);
            /*this is for kendo grid dynamic page size*/
            pagesize = pagesizes.split(',');
            for (i = 0; i < pagesize.length; i++) {
                if (pagesize[i].trim() !== "") {
                    $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.add({ text: pagesize[i], value: pagesize[i] })
                }
            }
            setGridHeight(0, gridName);
            var string = $("#jsonFilter").val();
            if (string != "") {
                var object = JSON.parse(string);
                var ds = $("#" + gridName).data("kendoGrid").dataSource;
                ds.filter([object]);
            }
            $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').select(1);
        }
        else {
          
                var pagesizes = "5,10,20," + adminpagesize;
                //if ($("#" + gridName + " select[data-role=dropdownlist]").datasource != undefined) {
                //    $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.data([]);
                //}
                $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.data([]);
                pagesize = pagesizes.split(',');
                for (i = 0; i < pagesize.length; i++) {
                    if (pagesize[i].trim() !== "") {
                        $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.add({ text: pagesize[i], value: pagesize[i] })
                    }
                }
                $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').select(1);
           
        }
        setGridHeight(0, gridName);
    } catch (e) {
        console.log(e);
    }
}

function OnMultiColumnGridDataBound(arg) {
    /// <summary>
    /// A generic function that performs certain functions like applying color when filtering grid, enable/disable grid auto resize and bind numbers to the
    /// </summary>
    /// <param name="arg">Contains the grids details</param>
    try {
        var gridName = arg.sender.element.closest('[data-role="grid"]').attr('id');
        var grid = $("#" + gridName).data("kendoGrid");
        //to avoid resize of grid when data source is cleared
        var filter = grid.dataSource.filter();
        addExtraHeightForGrid = ($("#" + gridName + " .k-grid-toolbar").height() == null || $("#" + gridName + " .k-grid-toolbar").height() == "" || $("#" + gridName + " .k-grid-toolbar").height() <= 0) ? 35 : 0;

        //Add theme-color class to the search icon if grid is filtered else show as default
        if (filter != undefined && filter != null && filter.filters.length > 0) {
            $('.clearSearch-link').addClass('theme-color');
            $('.fa-refresh').addClass('fa-spin');
        }
        else {
            $("a.clearSearch-link").removeClass("theme-color");
            $('.fa-refresh').removeClass('fa-spin');
        }

        //Enable/Disable Auto resize of columns in grid based on the global variable value
        if (gridName != "CallFlowGrid" && gridName != "MenuTraversalGrid") {
            if (enableDisableGridAutoResize == 0 && arg.sender.dataSource.data().length > 0) {
                var grid = $("#" + gridName).data("kendoGrid");

                FitAllColumns(grid, grid.columns);
            }
        }

        var pagesize = [];
        //Used for searching and set the grids datasource page number
        // $('#dynamicSearchParam').val(arg.sender.element[0].id)
        if (databoundcount == 1 && $("#ControllerName").val().toLowerCase().indexOf("report") > -1) {
            databoundcount = 0;
            var pagesizes = "5,10,20," + reportpagesize;
            $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.data([]);
            /*this is for kendo grid dynamic page size*/
            pagesize = pagesizes.split(',');
            for (i = 0; i < pagesize.length; i++) {
                if (pagesize[i].trim() !== "") {
                    $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.add({ text: pagesize[i], value: pagesize[i] })
                }
            }
            setGridHeight(0, gridName);
            var string = $("#jsonFilter").val();
            if (string != "") {
                var object = JSON.parse(string);
                var ds = $("#" + gridName).data("kendoGrid").dataSource;
                ds.filter([object]);
            }
            $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').select(1);
        }
        else {
            var pagesizes = "5,10,20," + adminpagesize;
            $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.data([]);
            pagesize = pagesizes.split(',');
            for (i = 0; i < pagesize.length; i++) {
                if (pagesize[i].trim() !== "") {
                    $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').dataSource.add({ text: pagesize[i], value: pagesize[i] })
                }
            }
            $("#" + gridName + " select[data-role=dropdownlist]").data('kendoDropDownList').select(1);
        }
        setGridHeight(0, gridName);
    } catch (e) {
        console.log(e);
    }
}

function FitAllColumns(grid, columns) {
    for (var i = 0; i < columns.length; i++) {
        if (columns[i].columns) {
            FitAllColumns(grid, columns[i].columns);
        }
        if (columns[i].field) {
            grid.autoFitColumn(columns[i].field);
        }
    }
}

//function getcolumnname(e) {
//    try {
//        console.log("Inside getcolumnName()");
//        var thisID = this.element.attr("id");
//        var controllerName = window.location.pathname.split("/")[1];
//        console.log("Controller Name is: " + controllerName);

//        if ($("#" + thisID).data("kendoComboBox").dataSource._data.length === 0) {
//            var columnsNames = "";
//            var columns = $("#" + $("#dynamicSearchParam").val()).data("kendoGrid").columns;
//            if (columns.length > 0) {
//                for (var i = 0; i < columns.length; i++) {
//                    var col = columns[i];
//                    if (col.title != undefined) {
//                        if (skipColumn(col.title) && col.hidden != true) {
//                            object123 = { "names": col.title, "values": col.field };
//                            $("#" + thisID).data("kendoComboBox").dataSource.add(object123);
//                        }
//                    }
//                }
//            }
//        }
//        else {
//            var columnsNames = "";
//            var columns = $("#" + $("#dynamicSearchParam").val()).data("kendoGrid").columns;
//            $("#" + thisID).data("kendoComboBox").setDataSource();
//            if (columns.length > 0) {
//                for (var i = 0; i < columns.length; i++) {
//                    var col = columns[i];
//                    if (col.title != undefined && col.hidden != true) {
//                        if (skipColumn(col.title)) {
//                            object123 = { "names": col.title, "values": col.field };
//                            $("#" + thisID).data("kendoComboBox").dataSource.add(object123);
//                        }
//                    }
//                }
//            }
//        }
//    } catch (e) {
//        console.log(e);
//    }
//}

function getcolumnname(e) {
    try {
        console.log("Inside getcolumnName()");
        var thisID = this.element.attr("id");
        var controllerName = window.location.pathname.split("/")[1];
        console.log("Controller Name is: " + controllerName);

        if ($("#" + thisID).data("kendoComboBox").dataSource._data.length === 0) {
            var columnsNames = "";
            var columns = $("#" + $("#dynamicSearchParam").val()).data("kendoGrid").columns;
            if (columns.length > 0) {
                for (var i = 0; i < columns.length; i++) {
                    var col = columns[i];
                    if (col.title != undefined) {
                        if (col.field == undefined) {
                            if (col.columns != undefined) {
                                for (var j = 0; j < col.columns.length; j++) {
                                    if (skipColumn(col.columns[j].title) && col.columns[j].hidden != true) {
                                        object123 = { "names": col.columns[j].title, "values": col.columns[j].field };
                                        $("#" + thisID).data("kendoComboBox").dataSource.add(object123);
                                    }
                                }
                            }
                        }
                        else {
                            if (skipColumn(col.title) && col.hidden != true) {
                                object123 = { "names": col.title, "values": col.field };
                                $("#" + thisID).data("kendoComboBox").dataSource.add(object123);
                            }
                        }
                    }
                }
            }
        }
        else {
            var columnsNames = "";
            var columns = $("#" + $("#dynamicSearchParam").val()).data("kendoGrid").columns;
            $("#" + thisID).data("kendoComboBox").setDataSource();
            if (columns.length > 0) {
                for (var i = 0; i < columns.length; i++) {
                    var col = columns[i];
                    if (col.title != undefined && col.hidden != true) {
                        if (col.field == undefined) {
                            if (col.columns != undefined) {
                                for (var j = 0; j < col.columns.length; j++) {
                                    if (skipColumn(col.columns[j].title)) {
                                        object123 = { "names": col.columns[j].title, "values": col.columns[j].field };
                                        $("#" + thisID).data("kendoComboBox").dataSource.add(object123);
                                    }
                                }
                            }
                        }
                        else {
                            if (skipColumn(col.title)) {
                                object123 = { "names": col.title, "values": col.field };
                                $("#" + thisID).data("kendoComboBox").dataSource.add(object123);
                            }
                        }
                    }
                }
            }
        }
    } catch (e) {
        console.log(e);
    }
}


//enter columns which have to be skipped here
function skipColumn(title) {
    try {
        var adminpagename = window.location.pathname.split("/")[1];
        if ((title == "Transfer Count" && $("#reportname").val() == "IvrCallTraceReport") || (title == "Intent" && $("#reportname").val() == "IvrCallTraceReport") || (title == "Transferred VDN" && $("#reportname").val() == "CallTransferReport") || (title == "Intent Skill" && $("#reportname").val() == "CallTransferReport") || (title == "Date Modified" && adminpagename == "LogfileData") || (title == "Id" && $("#reportname").val() == "AgentLoginLogoutReport")) {
            return false;
        }
        else
            return true;
    } catch (e) {
        console.log(e);
    }
}

function onColumnShowHide() {
    var gridName = arg.sender.element.closest('[data-role="grid"]').attr('id');
    var grid = $("#" + gridName).data("kendoGrid");
    for (var i = 0; i < grid.columns.length; i++) {
        grid.autoFitColumn(i);
    }
}