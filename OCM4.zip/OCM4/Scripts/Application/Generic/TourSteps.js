﻿$(function () {
    ocmTour.init();
});
ocmTour = {
    init: function () {

        // This tour guide is based on EnjoyHint plugin
        // for more info/documentation please check https://github.com/xbsoftware/enjoyhint
        $('#showOcmTour').click(function () {
            ocmTour.runOcmTour();
        })
    },

    runOcmTour: function () {
        // initialize instance
        var steps = new EnjoyHint({});

        // config
        var ocmGeneralTourSteps = [
            {
                'next .navbar-header': 'Welcome to OCM! Continue to take a brief tour...',
                'nextButton': { className: "myNext", text: "Yes" },
                'skipButton': { className: "mySkip", text: "No" }
            },
            {
                'next #lanid': 'This is your LAN ID',
                //'shape': 'circle',
                'nextButton': { className: "myNext", text: "Next" },
                'skipButton': { className: "mySkip", text: "Skip" }
            },
            {
                'click #OCMnotificationli': 'This is the Notification Area, click here to view Exported Reports',
                showSkip: false
                //'shape': 'circle',
                //'nextButton': { className: "myNext", text: "Next" },
                //'skipButton': { className: "mySkip", text: "Skip" }
            },
            {
                'next #nav': 'This is a list of all notifications i.e. Exported Report Excels',
                //'shape': 'circle',
                'nextButton': { className: "myNext", text: "Next" },
                'skipButton': { className: "mySkip", text: "Skip" }
            },
            {
                'next #OCMli': 'This is used to show which all OCM Admin Channels and Modules you have access to.',
                showSkip: false
                //'shape': 'circle',
                //'nextButton': { className: "myNext", text: "Next" },
                //'skipButton': { className: "mySkip", text: "Skip" }
            },
            //{
            //    'next #navTabs': 'This is a list of Channels available and below it are the list of Modules available for that Channel.',
            //    'shape': 'circle',
            //    'nextButton': { className: "myNext", text: "Next" },
            //    'skipButton': { className: "mySkip", text: "Skip" }
            //},
            //{
            //    'next #comboAdminList': 'Used to QuickSearch and access Modules.',
            //    'shape': 'circle',
            //    'nextButton': { className: "myNext", text: "Next" },
            //    'skipButton': { className: "mySkip", text: "Skip" }
            //},
            {
                'next #OCMReportsli': 'This is used to show which all OCM Reports you have access to.',
                showSkip: false
                //'shape': 'circle',
                //'nextButton': { className: "myNext", text: "Next" },
                //'skipButton': { className: "mySkip", text: "Skip" }
            }
    //,
    //{
    //    'key #mySearchButton': "Insert your search request and press 'Enter'",
    //    'keyCode': 13
    //},
    //{
    //    'click .btn': 'This button allows you to switch between the search results'
    //},
    //{
    //    'next .about': 'Check the list of all the features available',
    //    'shape': 'circle'
    //},
    //{
    //    'next .contact': 'Your feedback will be appreciated',
    //    'shape': 'circle',
    //    'radius': 70,
    //    'showSkip': false,
    //    'nextButton': { className: "myNext", text: "Got it!" }
    //}
        ];

        // set script config
        steps.set(ocmGeneralTourSteps);

        // run Enjoyhint script
        steps.run();
    }
};