$(document).ready(function () {
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "main.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Adhip",
        Description: "Removed extra fileversioning and changed tabresize method to pass correct parameters."
    });

    // Add body-small class if window less than 768px
    if ($(this).width() < 769) {
        $('body').addClass('body-small canvas-menu')
        $("body").removeClass("mini-navbar");
    } else {
        $('body').removeClass('body-small canvas-menu')
    }

    // MetsiMenu
    //$('#side-menu').metisMenu();

    // Collapse ibox function
    $('.collapse-link').click(function () {
        var ibox = $(this).closest('div.ibox');
        var button = $(this).find('i');
        var content = ibox.find('div.ibox-content');
        content.slideToggle(200);
        button.toggleClass('fa-chevron-up').toggleClass('fa-chevron-down');
        ibox.toggleClass('').toggleClass('border-bottom');
        setTimeout(function () {
            ibox.resize();
            ibox.find('[id^=map-]').resize();
        }, 50);
    });

    $("#showChart").click(function () {
        $('.close-link').trigger('click');
    });

    // Close ibox function
    $('.close-link').click(function () {
        var content = $(this).closest('div.ibox');
        content.remove();

        //$("#tlkChart").fadeOut();
        //setTimeout(function () {
        //    var chart = $("#chart").data("kendoChart");
        //    chart.refresh();
        //}, 200);

        //$("#tlkChart").fadeIn();
        //$("#gridtDiv").fadeOut();
        //$("#gridDiv").removeClass("animated fadeInRightBig");
        //$("#chartDiv").addClass("animated fadeInRightBig");
        //$("#chartDiv").css("display", "block");
        //$("#gridDiv").css("display", "none");
    });

    // Fullscreen ibox function
    $('.fullscreen-link').click(function () {
        var ibox = $(this).closest('div.ibox');
        var button = $(this).find('i');
        $('body').toggleClass('fullscreen-ibox-mode');
        button.toggleClass('fa-expand').toggleClass('fa-compress');
        ibox.toggleClass('fullscreen');
        setTimeout(function () {
            $(window).trigger('resize');
        }, 100);
    });

    // Close menu in canvas mode
    $('.close-canvas-menu').click(function () {
        $("body").toggleClass("mini-navbar");
        SmoothlyMenu();
    });

    // Run menu of canvas
    $('body.canvas-menu .sidebar-collapse').slimScroll({
        height: '100%',
        railOpacity: 0.9
    });

    // Initialize slimscroll for right sidebar
    $('.sidebar-container').slimScroll({
        height: '100%',
        railOpacity: 0.4,
        wheelStep: 10
    });

    // Open close small chat
    $('.open-small-chat').click(function () {
        $(this).children().toggleClass('fa-comments').toggleClass('fa-remove');
        $('.small-chat-box').toggleClass('active');
    });

    // Initialize slimscroll for small chat
    $('.small-chat-box .content').slimScroll({
        height: '234px',
        railOpacity: 0.4
    });

    // Small todo handler
    $('.check-link').click(function () {
        var button = $(this).find('i');
        var label = $(this).next('span');
        button.toggleClass('fa-check-square').toggleClass('fa-square-o');
        label.toggleClass('todo-completed');
        return false;
    });

    // Minimalize menu
    $('.navbar-minimalize').click(function () {
        if (OCMopened) {
            $('.OCM-sidebar-toggle').trigger('click');
        }
        if (OCMReportsopened) {
            $('.OCMReports-sidebar-toggle').trigger('click');
        }
        $("body").toggleClass("mini-navbar");
        SmoothlyMenu();
        //if ($(window).width() > 769) {
        //	$("#tlkChart").fadeOut();
        //	setTimeout(function(){
        //    var chart = $("#chart").data("kendoChart");
        //    chart.refresh();
        //	},300);
        //	$("#tlkChart").fadeIn(400);
        //}
    });

    // Tooltips demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    });

    // Move modal to body
    // Fix Bootstrap backdrop issu with animation.css
    $('.modal').appendTo("body");

    // Full height of sidebar
    function fix_height() {

        var windowHeight = $(window).height();
        var topNavBarHeight = $("#navbarheader").height();
        var footerHeight = $("#footer").height();

        $('#page-wrapper').css("min-height", windowHeight - topNavBarHeight - footerHeight + "px");
    }

    fix_height();

    // Fixed Sidebar
    $(window).bind("load", function () {
        if ($("body").hasClass('fixed-sidebar')) {
            $('.sidebar-collapse').slimScroll({
                height: '100%',
                railOpacity: 0.9
            });
        }
    });

    // Move right sidebar top after scroll
    $(window).scroll(function () {
        if ($(window).scrollTop() > 0 && !$('body').hasClass('fixed-nav')) {
            $('#right-sidebar').addClass('sidebar-top');
        } else {
            $('#right-sidebar').removeClass('sidebar-top');
        }
    });

    $(window).bind("load resize scroll", function () {
        if (!$("body").hasClass('body-small')) {
            //fix_height();
        }
    });

    $("[data-toggle=popover]")
        .popover();

    // Add slimscroll to element
    $('.full-height-scroll').slimscroll({
        height: '100%'
    });
    setTimeout(function () {
        setGridHeight(gridHeight);
    }, 300);
});

// Minimalize menu when screen is less than 768px
$(window).bind("resize", function () {
    if ($(this).width() < 769) {
        $('body').addClass('body-small canvas-menu')
        $("body").removeClass("mini-navbar");
        if ($("#OCM-sidebar").css('display') == 'block') {
            var leftNavigationWidth = 0;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCM-sidebar").width(sidebarWidth);
        }
        if ($("#OCMReports-sidebar").css('display') == 'block') {
            var leftNavigationWidth = 0;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCMReports-sidebar").width(sidebarWidth);
        }
    } else {
        $('body').removeClass('body-small canvas-menu')
        $("body").addClass("mini-navbar");
        if ($("#OCM-sidebar").css('display') == 'block') {
            var leftNavigationWidth = $("#leftSideNav").width() + 1;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCM-sidebar").width(sidebarWidth);
        }
        if ($("#OCMReports-sidebar").css('display') == 'block') {
            var leftNavigationWidth = $("#leftSideNav").width() + 1;
            var totalWindowWidth = $(window).width();
            var sidebarWidth = totalWindowWidth - leftNavigationWidth;
            $("#OCMReports-sidebar").width(sidebarWidth);
        }
    }
    setTimeout(function () {
        TabResize(0, "", true);
        setGridHeight(gridHeight);
    }, 300);
});

function setGridHeight(ext,id) {
    var totalheight = $(window).height();
    var footer = $("#footer").height();
    var navbar = $(".navbar").height();
    var gridId = id !== "" && id !== undefined ? "#" + id + " " : "";
    if (fullScreen !== true) {
        if (isGraph) {
            $("#graphTree").height(totalheight - footer - navbar - externalHeightForGrid + addExtraHeightForGrid - 98);
           
        }
        else {
            $(gridId + ".k-grid-content").height(totalheight - footer - navbar - externalHeightForGrid + addExtraHeightForGrid - 210 - ext - $(gridId + " .k-grid-header").height());
            console.log($(gridId + ".k-grid-content").height())
        }
    }
    else {
        if (isGraph) {
            $("#graphTree").height(totalheight - 78);
        }
        else {
            $(gridId + ".k-grid-content").height(totalheight - 48 - 142 + addExtraHeightForGrid - ext - $(gridId + " .k-grid-header").height());
        }
    }
}

// Local Storage functions
// Set proper body class and plugins based on user configuration
$(document).ready(function () {

    if (localStorageSupport) {
        var collapse = localStorage.getItem("collapse_menu");
        var fixedsidebar = localStorage.getItem("fixedsidebar");
        var fixednavbar = localStorage.getItem("fixednavbar");
        var boxedlayout = localStorage.getItem("boxedlayout");
        var fixedfooter = localStorage.getItem("fixedfooter");

        var body = $('body');

        if (fixedsidebar == 'on') {
            body.addClass('fixed-sidebar');
            $('.sidebar-collapse').slimScroll({
                height: '100%',
                railOpacity: 0.9
            });
        }

        if (collapse == 'on') {
            if (body.hasClass('fixed-sidebar')) {
                if (!body.hasClass('body-small')) {
                    body.addClass('mini-navbar');
                }
            } else {
                if (!body.hasClass('body-small')) {
                    body.addClass('mini-navbar');
                }
            }
        }

        if (fixednavbar == 'on') {
            $(".navbar-static-top").removeClass('navbar-static-top').addClass('navbar-fixed-top');
            body.addClass('fixed-nav');
        }

        if (boxedlayout == 'on') {
            body.addClass('boxed-layout');
        }

        if (fixedfooter == 'on') {
            $(".footer").addClass('fixed');
        }
    }
});

// check if browser support HTML5 local storage
function localStorageSupport() {
    return (('localStorage' in window) && window['localStorage'] !== null)
}

function SmoothlyMenu() {
    if (!$('body').hasClass('mini-navbar') || $('body').hasClass('body-small')) {
        // Hide menu in order to smoothly turn on when maximize menu
        $('#side-menu').hide();
        // For smoothly turn on menu
        setTimeout(
            function () {
                $('#side-menu').fadeIn(400);
            }, 200);
    } else if ($('body').hasClass('fixed-sidebar')) {
        $('#side-menu').hide();
        setTimeout(
            function () {
                $('#side-menu').fadeIn(400);
            }, 100);
    } else {
        // Remove all inline style from jquery fadeIn function to reset menu state
        $('#side-menu').removeAttr('style');
    }
}