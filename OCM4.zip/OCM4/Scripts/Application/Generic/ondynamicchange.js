﻿/**
 * 
 */
function onChange(arg) {
    try {
        var selectedData = $.map(this.select(), function (item) {
            return $(item).text();
        });
        $grid = arg.sender; //grid ref
        $cell = $grid.select(); // selected td
        $row = $cell.closest('tr'); //selected tr
        row_uid = $row.attr('data-uid'); //uid of selected row
        cell_index = $cell.index(); //cell index 0 based
        row_index = $row.index(); //row index 0 based
        dynamicGetData(selectedData);
    } catch (e) {
        console.log(e);
    }


}

/**
 * Gets the delected column row data
 */
function dynamicGetData(selectedData) {
    try {
        var reportnameval = $("#reportNameValue").val();

        if (reportnameval === "AgentInteractionReport") {
            var agentID = $grid.dataItem($row).AgentId; //selected row data
            var loginDateTime = $grid.dataItem($row).LoginDateTime; //selected row data
            var logoutDateTime = $grid.dataItem($row).LogoutDateTime; //selected row data
            var colName = $("#grid").find('th').eq(cell_index).text();//selected column name
            serverData = agentID + "," + loginDateTime + "," + logoutDateTime;
            $("#searchDForm").html('');
            set = false;
            var grid = $("#drillGrid").data("kendoGrid");
            grid.dataSource.data("");
            if (serverData != " ") {
                $("#innerGridValue").val(serverData);
                $("#DrillReportNameLbl").html("<h2>Agent Interaction Report</h2>Details of <span class='theme-color'>" + "AgentID" + "</span> : <span class='theme-color'>" + agentID + "</span>");
                grid.dataSource.read();
                $('#popupDrill').modal('show');
                if (openedDrillSearch) {
                    BackToSearch();
                }
                $("#DrillPopupFooter").hide();
                $("#searchDForm").hide();
            }
        }

        if (reportnameval === "EmailAgentPerformanceReport") {
            var agentID = $grid.dataItem($row).AgentID; //selected row data
            var agentName = $grid.dataItem($row).AgentName; //selected row data
            var colName = $("#grid").find('th').eq(cell_index).text();//selected column name
            serverData = agentID + "," + selectedData + "," + colName;

            var grid = $("#drillGrid").data("kendoGrid");
            grid.dataSource.data("");

            var skillGrid = $("#skillGrid").data("kendoGrid");
            skillGrid.dataSource.data("");
            if (colName == "Total Skills Assigned" && selectedData != 0) {
                $("#skillParam").val(agentID);
                $("#drillSkillInfo").html("<h2>Agent Performance Skill Report</h2>Skill Details of <span class='theme-color'>" + agentName + "</span>");
                skillGrid.dataSource.read();
                $('#popupSkillDrill').modal('show');
                $("#gridSearch").show();
                $("#PopupFooter").hide();
                $("#searchDForm").hide();
            }
            else if (!isNaN(selectedData) && selectedData != 0) {
                $("#innerGridValue").val(serverData);
                $("#DrillReportNameLbl").html("<h2>Agent Performance Detail Report</h2>Details of <span class='theme-color'>" + colName + "</span> : <span class='theme-color'>" + agentName + "</span>");
                grid.dataSource.read();

                $('#popupDrill').modal('show');
                if (openedDrillSearch) {
                    BackToSearch();
                }
                $("#gridDivSearch").show();
                $("#DrillPopupFooter").hide();
                $("#searchDDForm").hide();
            }
            if (selectedData == 0) {
                toaster("There are no records to popup", "info");
                return;
            }
            if (isNaN(selectedData)) {
                toaster("There are no records to popup", "info");
                return;
            }
        }
    } catch (e) {
        console.log(e);
    }
}

function initializeGridTooltip(gridName) {
    try {
        var grid = $("#" + gridName).data("kendoGrid");
        if (grid != undefined) {
            grid.thead.kendoTooltip({
                filter: "th",
                content: function (e) {
                    var target = e.target; // element for which the tooltip is shown
                    if ($(target).text().trim() != "") {
                        $(".k-tooltip-content").parent().css("visibility", "visible");
                        return $(target).text();
                    }
                    else {
                        $(".k-tooltip-content").parent().css("visibility", "hidden");
                    }
                }
            });
        }
    } catch (e) {
        console.log(e);
    }
}

function setTheme(themename) {
    /// <summary>
    /// Function to set the theme name for the href in the li tag in the _Layout.cshtml page
    /// </summary>
    /// <param name="themename">Contains the name of the theme</param>
    $("#kendoCustomLink").attr("href", ApplicationPath + "Content/kendocustom/" + themename + "theme/kendo.custom.css");
    $("#CommonLink").attr("href", ApplicationPath + "Content/kendocustom/" + themename + "theme/Common.css");
    $("#TopNavbarLink").attr("href", ApplicationPath + "Content/kendocustom/" + themename + "theme/TopNavBar.css");
    $("#FooterLink").attr("href", ApplicationPath + "Content/kendocustom/" + themename + "theme/Footer.css");
    $("#OCMSidebarLink").attr("href", ApplicationPath + "Content/kendocustom/" + themename + "theme/OCMSidebar.css");
    $("#OCMReportsSidebarLink").attr("href", ApplicationPath + "Content/kendocustom/" + themename + "theme/OCMReportsSidebar.css");
    $("#DashboardStylesLink").attr("href", ApplicationPath + "Content/kendocustom/" + themename + "theme/DashboardStyles.css");
}

function setFont(fontname) {
    /// <summary>
    /// Function to set the font name for the href in the li tag in the _Layout.cshtml page
    /// </summary>
    /// <param name="fontname">Contains the Name of the Font</param>
    $("#ocmFontLink").attr("href", ApplicationPath + "Content/Fonts/OCMFonts/" + fontname + "/" + fontname + ".css");
}

function clearBrowserStorage(){
    /// <summary>
    /// Function to clear Local and Session Storages of Browsers
    /// </summary>
    sessionStorage.clear();
    localStorage.clear();
}