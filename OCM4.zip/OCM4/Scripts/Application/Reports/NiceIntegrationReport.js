﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Reports",
        FileName: "NiceIntegrationReport.js",
        Version: "8.31",
        LastModifiedDateTime: "31-08-2018 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added progress bar and disabled push to nice button"
    });
});

//Global variables to store sessionid's and corresponding status
var gSession = new Array();
var gStatus = new Array();

function onConversationView(arg) {
    /// <summary>
    /// Function to get display the conversation view
    /// </summary>
    /// <param name="arg"></param>
    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_index = $row.index(); //row index 0 based
    var sessionID = $grid.dataItem($row).SessionID;
    serverData = sessionID;
    $("#chatInfoLabel").html("<h3>Interactions for Session : <span class='theme-color'>" + sessionID + "</span></h3>");
    var selectedData = drillServerCall(serverData);
    $("#searchDForm").hide();
}

$(function () {
    /// <summary>
    /// Function that gets triggered everytime a checkbox is checked and pushes sessionid and status to arrays based on status else it will remove it
    /// </summary>
    $('#grid').on('click', '.chkbx', function () {
        var checked = $(this).is(':checked');
        var data = $('#grid').data("kendoGrid").dataItem($(this).closest('tr'));
        var sessionID = data.SessionID;
        var status = data.NotPushed;
        if (checked == true) {
            if (status.toLowerCase() == "success") {
                toaster("Data has already been pushed to NICE", "error");
                $(this).attr('checked', false)
                return;
            }
            else {
                gSession.push(sessionID);
                gStatus.push(status)
            }
        }
        else {
            var sessionIndex = gSession.indexOf(sessionID);
            var statusIndex = gStatus.indexOf(status);
            if (sessionIndex > -1) {
                gSession.splice(sessionIndex, 1);
            }
            if (statusIndex > -1) {
                gStatus.splice(statusIndex, 1);
            }
        }
        console.log(gSession);
        console.log(gStatus);
    })
})

function drillServerCall(drillInputToServer) {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'NiceIntegrationReport/LoadInteractionsForSession',
        data: { sessionID: drillInputToServer, startDate: $("#startDateValue").val(), endDate: $("#endDateValue").val(), repType: $("#reportTypeValue").val(), singleDate: $("#singleDateValue").val() },
        dataType: "json",
        success: function (data) {
            if (data != null) {
                var chatdiv = "<div class='chat'>"
                $.each(data, function (key, value) {
                    if (data[key].Direction == "Out") {
                        if (data[key].InteractionDate == "")
                            chatdiv += "<div class='bubble agent'>" + data[key].InteractionText + "</div>"
                        else
                            chatdiv += "<div class= 'bubble agent'> <i class='fa fa-clock-o'></i><small> " + data[key].InteractionDate + " " + " </small><br> " + data[key].InteractionText + "</div>"
                    }
                    else {
                        if (data[key].InteractionDate == "")
                            chatdiv += "<div class='bubble customer'>" + data[key].InteractionText + "</div>"
                        else
                            chatdiv += "<div class= 'bubble customer'> <i class='fa fa-clock-o'></i><small> " + data[key].InteractionDate + " </small> <br> " + data[key].InteractionText + "</div>"
                    }
                }
                )
                chatdiv += "</div>"

                $("#dGrid").html("");
                $("#dGrid").html(chatdiv);
                if (data != null && data != "") {
                    $('#popupDrill').modal('show');
                    return;
                }
                else
                    toaster("There are no records to popup", "info");
                $('#popupDrill').modal('hide');
                return;
            }
        },
        error: function () {
            console.log('Failed to load');
        }
    });
}

function pushDataToNice(e) {
    var tr = $(e.target).closest("tr"); //get the row for deletion
    var data = this.dataItem(tr);
    if (data.NotPushed == "Success") {
        toaster("Data already has been pushed to NICE", "error");
        e.preventDefault();
        return;
    }
    else {
        $("#push-selected-data").addClass("k-state-disabled");
        $("#push-all-data").addClass("k-state-disabled");
        kendo.ui.progress($("#grid"), true);
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'NiceIntegrationReport/PushDatatoNice',
            data: { SessionID: data.SessionID, startDate: $("#startDateValue").val(), endDate: $("#endDateValue").val(), repType: $("#reportTypeValue").val(), CIF: data.CIF, Intent: data.Intent, Status: data.NotPushed, singleDate: $("#singleDateValue").val(), pushAllData: "false" }, // your data properties to be saved
            dataType: 'json',
            success: function (data) {
                if (data == "Data sent to NICE successfully") {
                    toaster("Data sent to NICE successfully", "success");
                }
                else if (data == "Unable to send data to NICE. Data Push Failed!") {
                    toaster("Unable to send data to NICE. Data Push Failed!", "error");
                }
                else if (data == "A few of the records were not updated successfully. Please check logs for more details.") {
                    toaster("A few of the records were not updated successfully. Please check logs for more details.", "error");
                }
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                $("#push-selected-data").removeClass("k-state-disabled");
                $("#push-all-data").removeClass("k-state-disabled");
                kendo.ui.progress($("#grid"), false);
            },
            error: function (data) {
                toaster("Some Error occurred", "error");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                $("#push-selected-data").removeClass("k-state-disabled");
                $("#push-all-data").removeClass("k-state-disabled");
                kendo.ui.progress($("#grid"), false);
            }
        });
    }
}

function pushAllDataToNice() {
    $("#push-selected-data").addClass("k-state-disabled");
    $("#push-all-data").addClass("k-state-disabled");
    kendo.ui.progress($("#grid"), true);
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'NICEIntegrationReport/PushDatatoNice',
        data: { SessionID: "", startDate: $("#startDateValue").val(), endDate: $("#endDateValue").val(), repType: $("#reportTypeValue").val(), CIF: "", Intent: "", Status: "", singleDate: $("#singleDateValue").val(), pushAllData: "true" }, // your data properties to be saved
        dataType: 'json',
        success: function (data) {
            if (data == "Data sent to NICE successfully") {
                toaster("Data sent to NICE successfully", "success");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
            }
            else if (data == "Unable to send data to NICE. Data Push Failed!") {
                toaster("Unable to send data to NICE. Data Push Failed!", "error");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
            }
            else if (data == "A few of the records were not updated successfully. Please check logs for more details.") {
                toaster("A few of the records were not updated successfully. Please check logs for more details.", "error");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
            }
            $("#push-selected-data").removeClass("k-state-disabled");
            $("#push-all-data").removeClass("k-state-disabled");
            kendo.ui.progress($("#grid"), false);
        },
        error: function (data) {
            toaster("Some Error occurred", "error");
            var grid = $("#grid").data("kendoGrid");
            grid.dataSource.read();
            $("#push-selected-data").removeClass("k-state-disabled");
            $("#push-all-data").removeClass("k-state-disabled");
            kendo.ui.progress($("#grid"), false);
        }
    });
}

function pushSelectedDataToNice() {
    /// <summary>
    /// Function to push only the checked boxes data to nice service
    /// </summary>
    var sessionId = gSession.join(",");
    var status = gStatus.join(",");

    if (sessionId.length > 0) {
        $("#push-selected-data").addClass("k-state-disabled");
        $("#push-all-data").addClass("k-state-disabled");
        kendo.ui.progress($("#grid"), true);
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'NiceIntegrationReport/PushDatatoNice',
            data: { SessionID: sessionId, startDate: $("#startDateValue").val(), endDate: $("#endDateValue").val(), repType: $("#reportTypeValue").val(), CIF: "", Intent: "", Status: status, singleDate: $("#singleDateValue").val(), pushAllData: "false" }, // your data properties to be saved
            dataType: 'json',
            success: function (data) {
                if (data == "Data sent to NICE successfully") {
                    toaster("Data sent to NICE successfully", "success");
                }
                else if (data == "Unable to send data to NICE. Data Push Failed!") {
                    toaster("Unable to send data to NICE. Data Push Failed!", "error");
                }
                else if (data == "A few of the records were not updated successfully. Please check logs for more details.") {
                    toaster("A few of the records were not updated successfully. Please check logs for more details.", "error");
                }
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                $("#push-selected-data").removeClass("k-state-disabled");
                $("#push-all-data").removeClass("k-state-disabled");
                kendo.ui.progress($("#grid"), false);
            },
            error: function (data) {
                toaster("Some Error occurred", "error");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                $("#push-selected-data").removeClass("k-state-disabled");
                $("#push-all-data").removeClass("k-state-disabled");
                kendo.ui.progress($("#grid"), false);
            }
        });
    }
    else {
        toaster("Select a checkbox", "error");
    }
}