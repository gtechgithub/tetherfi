﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Reports",
        FileName: "FeeWaiverTransactionReport.js",
        Version: "3.2.6.6",
        LastModifiedDateTime: "06-06-2019 08:30:00 AM",
        LastModifiedBy: "Adhip",
        Description: "Fixed invalid datetime being displayed in confirmation popup during PushAll for single date"
    });
});

//Global variables to store sessionid's and corresponding status
var rpaData = new Array();

function OnRPAGridDataBound(e) {
    try {
        rpaData = [];
        onDataBound(e);
    } catch (e) {
        console.log(e);
    }
}

function pushAllDataToRPA() {
    let startDate;
    let endDate;
    if ($("#reportTypeValue").val().toLowerCase() === "singledate") {
        startDate = moment($("#singleDateValue").val()).format("YYYYMMDD") + " 000000";
        endDate = moment($("#singleDateValue").val()).format("YYYYMMDD") + " 235959";
    }
    else {
        startDate = $("#startDateValue").val();
        endDate = $("#endDateValue").val();
    }
    startDate = startDate.substring(6, 8) + "-" + startDate.substring(4, 6) + "-" + startDate.substring(0, 4) + " " + startDate.substring(9, 11) + ":" + startDate.substring(11, 13) + ":" + startDate.substring(13, 15);
    endDate = endDate.substring(6, 8) + "-" + endDate.substring(4, 6) + "-" + endDate.substring(0, 4) + " " + endDate.substring(9, 11) + ":" + endDate.substring(11, 13) + ":" + endDate.substring(13, 15);
    swal("Push All - Confirmation Alert", "Confirm to push all data (success & failure) from " + startDate + " to " + endDate, {
        icon: "warning",
        buttons: {
            cancel: "Cancel",
            catch: {
                text: "Confirm",
                value: "yes"
            }
        }
    })
        .then(function (value) {
            switch (value) {
                case "yes":
                    ConfirmPushAllDataToRpa();
                    break;
            }
        });
}

function ConfirmPushAllDataToRpa() {
    try {
        ToggleUi(false, true);
        toaster("Request is sent and is being processed, please wait and do not refresh the page!", "success");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FeeWaiverTransactionReport/PushAllDatatoRPA',
            data: { startDate: $("#startDateValue").val(), endDate: $("#endDateValue").val(), repType: $("#reportTypeValue").val(), singleDate: $("#singleDateValue").val() }, // your data properties to be saved
            dataType: 'json',
            success: function (data) {
                console.log("Response after pushing all data to RPA \n\n" + data);
                var returnCode = JSON.parse(data).code;
                var returnMessage = JSON.parse(data).message;
                toaster(returnMessage + " (" + returnCode + ")", "info");
                ToggleUi(true, true);
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                rpaData = [];
            },
            error: function () {
                toaster("Some Error occurred", "error");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                ToggleUi(true, true);
                rpaData = [];
            }
        });
    } catch (e) {
        console.log(e);
    }
}

$(function () {
    /// <summary>
    /// Function that gets triggered everytime a checkbox is checked and pushes sessionid and status to arrays based on status else it will remove it
    /// </summary>
    $('#grid').on('click', '.chkbx', function () {
        var checked = $(this).is(':checked');
        var data = $('#grid').data("kendoGrid").dataItem($(this).closest('tr'));

        if (checked) {
            rpaData.push(data.MsgUID);
            console.log("Checked Data: \n\n" + rpaData);
        }
        else {
            if (rpaData.indexOf(data.MsgUID) > -1) {
                rpaData.splice(rpaData.indexOf(data.MsgUID), 1);
                console.log("Checked Data: \n\n" + rpaData);
            }
        }
    });
});

function pushSelectedDataToRPA() {
    /// <summary>
    /// Function to push only the checked boxes data to nice service
    /// </summary>
    var ucid = rpaData.join(",");

    if (ucid.length > 0) {
        ToggleUi(false, false);
        toaster("Request is sent and is being processed, please wait and do not refresh the page!", "success");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FeeWaiverTransactionReport/PushSelectedDatatoRPA',
            data: { data: ucid }, // your data properties to be saved
            dataType: 'json',
            success: function (data) {
                console.log("Response after pushing selected data to RPA \n\n" + data);
                var message = "Files are uploaded (1)";
                if (data.length > 0) {
                    for (i = 0; i < data.length; i++) {
                        if (JSON.parse(data[i]).code !== 1) {
                            message = "Some Files failed to upload!";
                            break;
                        }
                    }
                }
                toaster(message, "info");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                ToggleUi(true, false);
                rpaData = [];
            },
            error: function () {
                toaster("Some Error occurred", "error");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                ToggleUi(true, false);
                rpaData = [];
            }
        });
    }
    else {
        toaster("Select a checkbox", "error");
    }
}

function pushDATFileToRPA() {
    try {
        var reportType = $("#reportTypeValue").val();
        var singleDateValue = $("#singleDateValue").val();
        var startDateValue = $("#startDateValue").val();
        var endDateValue = $("#endDateValue").val();
        if (reportType === "SingleDate") {
            if (moment(singleDateValue).isSame(moment(), 'day')) {
                toaster("Cannot Generate EOD File for Today, check for a previous date!", "error");
                return;
            }
        }
        else {
            if (moment(startDateValue).isSame(moment(), 'day')) {
                toaster("Cannot Generate EOD File for Today, check for a previous date!", "error");
                return;
            }
            else if (moment(endDateValue).isSame(moment(), 'day')) {
                toaster("EOD File will not be generated for today!", "error");
                startDateValue = moment(startDateValue, "YYYYMMDD HHmmSS").format("YYYYMMDD") + " 000000";
                endDateValue = moment(endDateValue, "YYYYMMDD HHmmSS").subtract(1, "days").format("YYYYMMDD") + " 235959";
            }
            else {
                startDateValue = moment(startDateValue, "YYYYMMDD HHmmSS").format("YYYYMMDD") + " 000000";
                endDateValue = moment(endDateValue, "YYYYMMDD HHmmSS").format("YYYYMMDD") + " 235959";
            }
        }
        ToggleDatUi(false);
        toaster("Request is sent and is being processed, please wait and do not refresh the page!", "success");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FeeWaiverTransactionReport/PushDATFiletoRPA',
            data: { startDate: startDateValue, endDate: endDateValue, repType: $("#reportTypeValue").val(), singleDate: singleDateValue }, // your data properties to be saved
            dataType: 'json',
            success: function (data) {
                ToggleDatUi(true);
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                rpaData = [];
            },
            error: function () {
                toaster("Some Error occurred", "error");
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.read();
                ToggleDatUi(true);
                rpaData = [];
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function ToggleUi(isenable, isPushAll) {
    try {
        if (isenable) {
            isPushAll ? $("#push-all-data").removeClass("k-state-disabled") : $("#push-selected-data").removeClass("k-state-disabled");
            kendo.ui.progress($("#grid"), false);
        }
        else {
            isPushAll ? $("#push-all-data").addClass("k-state-disabled") : $("#push-selected-data").addClass("k-state-disabled");
            kendo.ui.progress($("#grid"), true);
        }
    } catch (e) {
        console.log(e);
    }
}

function ToggleDatUi(isenable) {
    if (isenable) {
        $("#push-dat-file").removeClass("k-state-disabled");
        kendo.ui.progress($("#grid"), false);
    }
    else {
        $("#push-dat-file").addClass("k-state-disabled");
        kendo.ui.progress($("#grid"), true);
    }
}