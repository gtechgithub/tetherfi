﻿//Function to store the selected DNIS in a hidden variable
function onDnisSelect(e) {
    if (e.dataItem.Value != " ") {
        //when a dnis is selected then we display generating tree message
        if ($("#selectedDnis").val() != "" && $("#selectedDnis").val() != 0) {
            $("#selectedDnis").val(e.dataItem.Value);
            $("#defaultMessage").css('display', 'none');
            $("#treeLoading").css('display', '');
            $("#noDnisData").css('display', 'none');
            $("#graphTree").css('display', 'none');
            var dnisDropdownlist = $("#SelectedDnis").data("kendoDropDownList");
            dnisDropdownlist.enable(false);
        }
        else {
            $("#selectedDnis").val(e.dataItem.Value);
            $("#defaultMessage").css('display', 'none');
            $("#graphTree").css('display', 'none');
            $("#treeLoading").css('display', '');
            $("#noDnisData").css('display', 'none');
            
            var dnisDropdownlist = $("#SelectedDnis").data("kendoDropDownList");
            dnisDropdownlist.enable(false);
        }
        generateTree();
    }
    else {
        var dnisDropdownlist = $("#SelectedDnis").data("kendoDropDownList");
        dnisDropdownlist.enable(true);
        $("#selectedDnis").val(0);
        $("#graphTree").css('display', 'none');
        $("#defaultMessage").css('display', '');
        $("#treeLoading").css('display', 'none');
        $("#noDnisData").css('display', 'none');
        $("#DnisReload").css('display', 'none');
    }
}

function onDnisReload() {
    if ($("#selectedDnis").val() != "" && ($("#selectedDnis").val() != 0)) {
        $("#defaultMessage").css('display', 'none');
        $("#treeLoading").css('display', '');
        $("#noDnisData").css('display', 'none');
        $("#graphTree").css('display', 'none');
        $("#DnisReload").css('display', 'none');
        var dnisDropdownlist = $("#SelectedDnis").data("kendoDropDownList");
        dnisDropdownlist.enable(false);
        generateTree();
    }
    else {
        toaster("Select a Hotline", "error");
    }
}

//On Load of the page Setting hidden variable value to 0
$(document).ready(function () {
    $("#selectedDnis").val(0);
})

//Function to check in given interval if hidden variable value is set
//setInterval(function () {
//    if ($("#selectedDnis").val() == 0) {
//        $("#graphTree").css('display', 'none');
//        $("#defaultMessage").css('display', '');
//    }
//    else {
//        $("#defaultMessage").css('display', 'none');
//        $("#graphTree").css('display', '');
//        generateTree();
//    }
//}, 20000);

function generateTree() {
    var startDate = $("#startDate").val();
    var endDate = $("#endDate").val();
    var repType = $("#repType").val();
    var singleDate=$("#singleDate").val();

    $.ajax({
        url: window.ApplicationPath + 'AnalysisCountGraphReport/GenerateTree',
        type: 'POST',
        data: { compositeKey: $("#selectedDnis").val(), startDate: startDate, endDate: endDate, repType: repType, singleDate: singleDate },
        dataType: 'json',
        success: function (result) {
            var dnisDropdownlist = $("#SelectedDnis").data("kendoDropDownList");
            dnisDropdownlist.enable(true);
            $("#DnisReload").css('display', '');
            //Remove Generating Tree Animation
            $("#treeLoading").css('display', 'none');
            if (result == "") {
                //If there is no data for the selected dnis then we display no data message
                $("#graphTree").css('display', 'none');
                $("#noDnisData").css('display', '');
            }
            else {
                $("#graphTree").css('display', '');
                $("#noDnisData").css('display', 'none');
            }
            //Create Org Chart
            var graphElement = document.getElementById("graphTree");
            var orgChart = new getOrgChart(graphElement, {
                //theme: "helen",
                levelSeparation: 70,
                gridView: true,
                enableEdit: false,
                enableSearch: false,
                //enableMove: false,
                enableDetailsView: false,
                scale: 0.35,
                expandToLevel: 1,
                color: "teal",
                dataSource: result
            });
        },
        error: function (result) {
            var dnisDropdownlist = $("#SelectedDnis").data("kendoDropDownList");
            dnisDropdownlist.enable(true);
            $("#graphTree").css('display', 'none');
            $("#defaultMessage").css('display', '');
            $("#treeLoading").css('display', 'none');
            $("#noDnisData").css('display', 'none');
            $("#DnisReload").css('display', '');
            console.log("Failed to Load Tree");
        }
    });
}