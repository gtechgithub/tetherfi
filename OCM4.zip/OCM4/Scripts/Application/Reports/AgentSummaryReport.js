﻿function onClickOfMainGrid(arg) {
    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_uid = $row.attr('data-uid'); //uid of selected row
    var cell_index = $cell.index(); //cell index 0 based
    var row_index = $row.index(); //row index 0 based
    var agentID = $grid.dataItem($row).AgentId;
    var agentName = $grid.dataItem($row).AgentName;
    var colName = $("#grid").find('th').eq(cell_index).text();//selected column name
    var menuGrid = $("#menuGrid").data("kendoGrid");
    var date;
    menuGrid.dataSource.data("");
    if (selectedData != 0) {
        $("#callBackParam").val(agentID);
        $("#mainMenuReportNameLbl").html("<h2>Agent Interaction Report</h2><h4>OCM Reports > Agent > Agent Summary Report > Agent Interaction Report <span id='date'></span></h4>Interaction Details of Agent: <span class='theme-color'>" + agentName);
        if ($("#reportTypeValue").val() == "DateRange") {
            var startDate = $("#startDateValue").val();
            var yy = startDate.substr(0, 4);
            var mm = startDate.substr(4, 2);
            var dd = startDate.substr(6, 2);
            var formattedStartDate = dd + "-" + mm + "-" + yy;

            var endDate = $("#endDateValue").val();
            var yy = endDate.substr(0, 4);
            var mm = endDate.substr(4, 2);
            var dd = endDate.substr(6, 2)
            var formattedEndDate = dd + "-" + mm + "-" + yy;

            date = " from " + formattedStartDate + " to " + formattedEndDate;
        }
        if ($("#reportTypeValue").val() == "SingleDate") {
            var singleDate = $("#singleDateValue").val();
            var yy = singleDate.substr(0, 4);
            var mm = singleDate.substr(4, 2);
            var dd = singleDate.substr(6, 2);
            var formattedSingleDate = dd + "-" + mm + "-" + yy;
            date = " on " + formattedSingleDate;
        }
        $("#date").html(date);
        menuGrid.dataSource.read();
        $('#popupMainDrill').modal('show');
        $("#sGrid").show();
        $("#DrillPopupFooter").hide();
        $("#searchDForm").hide();
    }
    if (selectedData == 0) {
        toaster("There are no records to popup", "info");
        return;
    }
}



function onChange(arg) {

    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_uid = $row.attr('data-uid'); //uid of selected row
    var cell_index = $cell.index(); //cell index 0 based
    var row_index = $row.index(); //row index 0 based
    var agentID = $grid.dataItem($row).AgentId; //selected row data
    var agentName = $grid.dataItem($row).AgentName;
    var loginDateTime = kendo.toString($grid.dataItem($row).LoginDateTime, $("#DateTimeFormat").val());
    //loginDateTime = parseInt(loginDateTime);
    var logoutDateTime = kendo.toString($grid.dataItem($row).LogoutDateTime, $("#DateTimeFormat").val());
    //loginDateTime = parseInt(logoutDateTime);
    var datetime;
    var drillgrid = $("#drillgridSummary").data("kendoGrid");
    drillgrid.dataSource.data("");
    $("#callBackParam").val(agentID);
    $("#loginDateTimeValue").val(kendo.toString($grid.dataItem($row).LoginDateTime, "yyyyMMdd HHmmss"));
    $("#logoutDateTimeValue").val(kendo.toString($grid.dataItem($row).LogoutDateTime, "yyyyMMdd HHmmss"));
    $("#DrillReportNameLbl").html("<h2>Agent Interaction Detailed Report</h2><h4>OCM Reports > Agent > Agent Summary Report > Agent Interaction Report > Agent Interaction Detailed Report <span id='datetime'></span></h4>Interaction Details of Agent: <span class='theme-color'>" + agentName);

    if ($("#reportTypeValue").val() == "DateRange") {
        var startDate = $("#startDateValue").val();
        var yy = startDate.substr(0, 4);
        var mm = startDate.substr(4, 2);
        var dd = startDate.substr(6, 2);
        var formattedStartDate = dd + "-" + mm + "-" + yy;

        var endDate = $("#endDateValue").val();
        var yy = endDate.substr(0, 4);
        var mm = endDate.substr(4, 2);
        var dd = endDate.substr(6, 2)
        var formattedEndDate = dd + "-" + mm + "-" + yy;

        datetime = " from " + loginDateTime + " to " + logoutDateTime;
    }
    if ($("#reportTypeValue").val() == "SingleDate") {
        var singleDate = $("#singleDateValue").val();
        var yy = singleDate.substr(0, 4);
        var mm = singleDate.substr(4, 2);
        var dd = singleDate.substr(6, 2);
        var formattedSingleDate = dd + "-" + mm + "-" + yy;
        //date = "on" + formattedSingleDate;
        datetime = " from " + loginDateTime + " to " + logoutDateTime;
    }
    var tempReportType = $("#reportTypeValue").val();
    $("#reportTypeValue").val("DateRange");
    $("#datetime").html(datetime);
    drillgrid.dataSource.filter({
        logic: "and",
        filters: [
            { field: "AgentId", operator: "contains", value: agentID }
            //{ field: "CreatedDateTime", operator: "isgreaterequal", value: loginDateTime },
            //{ field: "CreatedDateTime", operator: "islesserequal", value: logoutDateTime }
        ]
    });
    //drillgrid.dataSource.read();
    $("#reportTypeValue").val(tempReportType);
    $("#popupDrill").modal('show');
    $("#ssGrid").show();
    $("#PopupFooter").hide();
    $("#searchDDForm").hide();
}

function ondrillgridSummaryDataBound() {
    //var gridName = arg.sender.element.closest('[data-role="grid"]').attr('id');
    var grid = $("#drillgridSummary").data("kendoGrid");
    for (var i = 0; i < grid.columns.length; i++) {
        grid.autoFitColumn(i);
    }
}

function onmenuGridSummaryDataBound() {
    //var gridName = arg.sender.element.closest('[data-role="grid"]').attr('id');
    var grid = $("#menuGrid").data("kendoGrid");
    for (var i = 0; i < grid.columns.length; i++) {
        grid.autoFitColumn(i);
    }
}