﻿
function drawCallFlowConnections() {
    console.log("Inside drawCallFlowConnections");
    $("svg").remove();
    jsPlumb.ready(function () {
        var instance = jsPlumb.getInstance({ Container: "flowCanvas" });
        for (i = 1; i < count - 1; i++) {
            var node1 = "node-" + i;
            var nextnodecount = i + 1;
            var node2 = "node-" + nextnodecount;
            instance.connect({
                source: node1,
                target: node2,
                anchors: ["Right", "Left"],
                connector: ["Flowchart"],
                endpointStyle: { fill: "#73aec9", outlineStroke: "#73aec9", outlineWidth: 1 },
                paintStyle: { stroke: "#73aec9", strokeWidth: 2 },
                hoverPaintStyle: { stroke: "#73aec9" },
                overlays: [
                    "Arrow"
                ]
            });
        }
    });
}