﻿$(document).ready(function () {
    /**
        * Define the Version
        * @returns {}
        */
    AddToFileVersionController({
        Location: "Application\\Reports",
        FileName: "OCMReport.js",
        "Version": "3.2.7.8",
        LastModifiedDateTime: "08-07-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Cleared canvas and changed toaster confirmation to swal"
    });
});

function empty() {

}

function onSessionExport() {
    toaster("Report Export is Initiated... Notification will be sent once Completed", "success");
    $("#isExportValue").val(true);
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'OCMReport/DrillGridOneDataSecond',
        data: getReportParams(),
        dataType: "json",
        success: function (data) {
            $("#isExportValue").val(false);
        },
        error: function () {
            console.log('Failed to load');
        }
    });
}

function onFilterDateChange() {

}

function setFilterDate() {
    var intervalDropdownTime = $("#AgentSkillBcmsReportIntervalDropdown").val();
    var startTime = "00:00";
    var intLoopCount = 0;
    var addTime;
    var addParameter = '';
    $("#interval").data("kendoComboBox").dataSource.data([]);
    if (intervalDropdownTime.indexOf("h") > -1) {
        addParameter = 'hours';
        addTime = parseInt(intervalDropdownTime.split("h")[0]);
    }
    else if (intervalDropdownTime.indexOf("m") > -1) {
        addParameter = 'minutes';
        addTime = parseInt(intervalDropdownTime.split("m")[0]);
    }
    for (startTime; moment(startTime, 'HH:mm').isBefore(moment("23:59", 'HH:mm')) ; startTime = kendo.toString(moment(startTime, "HH:mm").add(addTime, addParameter)._d, "HH:mm")) {
        if (intLoopCount != 0 && startTime === "00:00") break;

        //if (startTime.startsWith("0")) startTime = startTime.substring(1);
        if (startTime.split(":")[1].startsWith("0") && startTime.split(":")[1] != "00") startTime = startTime.split(":")[0] + ":" + startTime.split(":")[1].substring(1);

        var toStartTime = kendo.toString(moment(startTime, "HH:mm").add(addTime, addParameter)._d, "HH:mm").toString();
        //if (toStartTime.startsWith("0")) toStartTime = toStartTime.substring(1);
        if (toStartTime.split(":")[1].startsWith("0") && toStartTime.split(":")[1] != "00") toStartTime = toStartTime.split(":")[0] + ":" + toStartTime.split(":")[1].substring(1);

        var endTime = startTime.toString() + "-" + kendo.toString(moment(startTime, "HH:mm").add(addTime, addParameter)._d, "HH:mm").toString();
        var endTime1 = endTime.split("-")[0];
        var endTime2 = endTime.split("-")[1];
        //if (endTime1.startsWith("0") && endTime1.split(":")[1] != "00") endTime1 = endTime1.substring(1);
        if (endTime1.split(":")[1].startsWith("0") && endTime1.split(":")[1] != "00") endTime1 = endTime1.split(":")[0] + ":" + endTime1.split(":")[1].substring(1);
        //if (endTime2.startsWith("0") && endTime2.split(":")[1] != "00") endTime2 = endTime2.substring(1);
        if (endTime2.split(":")[1].startsWith("0") && endTime2.split(":")[1] != "00") endTime2 = endTime2.split(":")[0] + ":" + endTime2.split(":")[1].substring(1);

        $("#interval").data("kendoComboBox").dataSource.add({ text: (startTime.toString() + "-" + toStartTime).trim(), value: endTime1 + "-" + endTime2.trim() });
        intLoopCount++;
    }
}

var audio;
var video;
var playlist;
var tracks;
var currentfile;

function loadPlaylist(sessionId) {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'OCMReport/GetWebRTCRecorderFileList',
        data: { "sessionId": sessionId },
        dataType: "json",
        success: function (data) {
            if (data != '') {
                //var samplejson = '{"sessionId" :12345,"conversations" : [{"conversationId" :121232,"start" : 232131,"recordings" : [{"user" : 132321,"start" : 23123,"filetype":"mp3","file" : "http://www.archive.org/download/bolero_69/Bolero.mp3"}]}]}';
                //var samplejson = '{"sessionId" :12345,"conversations" : [{"conversationId" :121232,"start" : 232131,"recordings" : [{"user" : 132321,"start" : 23123,"filetype":"audio","file" : "https://demo.tetherfi.com:55443/Tetherfi_HttpProxy/files/Recording.mp3"},{"user" : 132321,"start" : 23123,"filetype":"video","file" : "https://demo.tetherfi.com:55443/Tetherfi_HttpProxy/files/Recording.webm"}]}]}';
                var objData = JSON.parse(data);

                //var finalplaylist = "";
                $("#audio-video-playlist").html("");
                var t = $("#audio-video-playlist-template").html(), //template divs
                    e = $("#audio-video-playlist"), //to be appended before/after/to
                    n = Handlebars.compile(t); //initialize handlebars for the template divs
                for (var i = 0; i < objData.conversations.length; i++) {
                    for (var j = 0; j < objData.conversations[i].recordings.length; j++) {
                        if (objData.conversations[i].recordings[j].filetype == 'audio') {
                            var context = {
                                icon: "fas fa-music",
                                fileName: sessionId + '_' + objData.conversations[i].recordings[j].file.split('/').pop() + '_' + objData.conversations[i].recordings[j].user,
                                listId: sessionId + "_" + j,
                                function: "runAudio('" + objData.conversations[i].recordings[j].file + "','" + sessionId + "_" + j + "')",
                            }, //add context data
                                s = n(context); //execute the template with handlebar and context
                            //finalplaylist += '<li><a class="playlistcss aaudio" href=' + objData.conversations[i].recordings[j].file + '>' + sessionId + '_Recording' + i + '</a></li>'
                        }
                        else {
                            var context = {
                                icon: "fas fa-video",
                                fileName: sessionId + '_' + objData.conversations[i].recordings[j].file.split('/').pop() + '_' + objData.conversations[i].recordings[j].user,
                                listId: sessionId + "_" + j,
                                function: "runVideo('" + objData.conversations[i].recordings[j].file + "','" + sessionId + "_" + j + "')",
                            }, //add context data
                                s = n(context); //execute the template with handlebar and context
                            //finalplaylist += '<li><a class="playlistcss avideo" href=' + objData.conversations[i].recordings[j].file + '>' + sessionId + '_Recording' + i + '</a></li>'
                        }
                        e.append(s);
                    }
                }

                //$('#playlist').empty();
                //$("#playlist").append(finalplaylist);

                //initilize the player
                //initPlayer();
                quitAudioVideo();
                $("#audio").css('display', 'none');
                $("#video").css('display', 'none');
                var header = "Audio Video list for Session ID :"
                $("#drillplayerInfo").html("<h2 class='theme-color'>" + $("#reportHeader").val() + "</h2>" + header + "<span class='theme-color'>" + sessionId + "</span>");
                $('#popupplayer').modal('show');
            }
            else {
                toaster("There is no recording for this session to preview", "info");
            }
        },
        error: function () {
            toaster("Failed to load recording list", "info");
        }
    });
}

function PlayFile(currentfile) {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'OCMReport/GetRecordingFile',
        data: { "currentfile": currentfile },
        dataType: "json",
        success: function (data) {
            audio[0].src = data;
            audio.css('display', 'block');
            video.css('display', 'none');
            audio[0].load();
            audio[0].play();
        },
        error: function () {
            toaster("Failed to play the recording", "info");
        }
    });
}
function runAudio(currentfile, listId) {
    $('#audio-video-playlist li i.now-playing').addClass('hidden');
    $("#" + listId + " i.now-playing").removeClass('hidden');
    $("#video")[0].src = "";
    //$("#audio")[0].src = currentfile;
    console.log(currentfile);
    $("#audio")[0].src = window.ApplicationPath + 'OCMReport/GetRecordingFile?currentfile=' + encodeURI(currentfile);
    $("#audio").css('display', 'block');
    $("#video").css('display', 'none');
    $("#audio")[0].load();
    $("#audio")[0].play();

}
function runVideo(currentfile, listId) {
    $('#audio-video-playlist li i.now-playing').addClass('hidden');
    $("#" + listId + " i.now-playing").removeClass('hidden');
    $("#audio")[0].src = "";
    //$("#video")[0].src = currentfile;
    console.log(currentfile);
    $("#video")[0].src = window.ApplicationPath + 'OCMReport/GetRecordingFile?currentfile=' + encodeURI(currentfile);
    $("#video").height($("#player-content").height() - 10);
    $("#video").css('display', 'block');
    $("#audio").css('display', 'none');
    $("#video")[0].load();
    $("#video")[0].play();
}

function quitAudioVideo() {
    $("#video")[0].src = "";
    $("#audio")[0].src = "";
}
/**********************************************************************************Start of OCM Agent Scripting Report JS******************************************************************************************/

function OnAgentScriptingGridRowSelect(arg) {
    try {
        var selectedData = $.map(this.select(), function (item) {
            return $(item).text();
        });
        var $grid = arg.sender; //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var row_uid = $row.attr('data-uid'); //uid of selected row
        var cell_index = $cell.index(); //cell index 0 based
        var row_index = $row.index(); //row index 0 based

        var sessionId = $grid.dataItem($row).SessionId;
        $("#drillGridInputOne").val(sessionId);
        GetQuestionAnswer();

        $("#genericDrillModalPopupHeader").html("<h3 class='theme-color'>OCM Agent Scripting Report Details</h3><h3 style='display:inline;' class='theme-color'>Session ID: &nbsp;<h2 style='display:inline;'>" + sessionId + "</h2></h3>");
        $("#genericDrillModalPopup .modal-dialog").css("width", "400px");
        $("#genericDrillModalPopup").modal("show");
    } catch (e) {
        console.log(e);
    }
}

function GetQuestionAnswer() {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'OCMReport/DrillGridOneDataSecond',
        data: getReportParams(),
        dataType: "json",
        success: function (data) {
            console.log("Data Received: " + JSON.stringify(data));
            GenerateQuestionAnswerUI(data);
        },
        error: function () {
            console.log('Failed to load');
        }
    });
}

function GenerateQuestionAnswerUI(data) {
    try {
        var divData = "<div class='panel-group' id='agentScriptingAccordion' role='tablist' aria-multiselectable='true' style='overflow-y:auto;background-color: #fff;padding: 20px;border-radius:5px;word-break:break-word;max-height:480px;box-shadow: 0 1px 3px rgba(0,0,0,.12), 0 1px 2px rgba(0,0,0,.24);'>";
        if (data !== null && data.Data.length > 0) {
            for (i = 0; i < data.Data.length; i++) {
                var question = data.Data[i].Question;
                var answerList = data.Data[i].Answers === null || data.Data[i].Answers === "" ? null : data.Data[i].Answers.split('||');
                var answerDiv = "";

                //Checking if answer is not present
                if (answerList === null) {
                    answerDiv = "";
                }
                    //If Question has multiple answers
                else if (answerList.length > 1) {
                    answerDiv = "<ul>";
                    for (j = 0; j < answerList.length; j++) {
                        answerDiv += "<li style='margin-bottom: 5px;'>" + answerList[j] + "</li>";
                    }
                    //If Question 
                    if (data.Data[i].CustomAnswer === null || data.Data[i].CustomAnswer === "") {
                        answerDiv += "</ul>";
                    }
                }
                else {
                    if (data.Data[i].CustomAnswer === null || data.Data[i].CustomAnswer === "") {
                        answerDiv += answerList[0];
                    }
                    else {
                        answerDiv = "<ul><li style='margin-bottom: 5px;'>" + answerList[0] + "</li>";
                    }
                }

                if (data.Data[i].CustomAnswer !== null && data.Data[i].CustomAnswer !== "") {
                    //if (answerList === null || answerList === "") {
                    answerDiv += "<span >" + data.Data[i].CustomAnswer + "  </span>";
                    //}
                    //else {
                    //    answerDiv += "<li style='margin-bottom: 5px;'><span class='theme-color' style='font-weight:bold;'>" + data.Data[i].CustomAnswer.split("||")[0] + " - </span>" + data.Data[i].CustomAnswer.split("||")[1] + "</li></ul>";
                    //}
                }

                divData += "<div class='panel panel-default'><div style='cursor:pointer;' class='panel-heading' role='tab' data-toggle='collapse' data-parent='#agentScriptingAccordion' href='#collapse_" + (i + 1) + "' aria-expanded='true' aria-controls='collapse_" + (i + 1) + "'><h4 class='panel-title'><a role='button' class='theme-color'>Q" + (i + 1) + ") " + question + "</a></h4></div><div id='collapse_" + (i + 1) + "' class='panel-collapse collapse' role='tabpanel' aria-labelledby='headingOne'><div class='panel-body'>" + answerDiv + "</div></div></div>";
            }
        }
        else {
            divData += "<div style='text-align:center;'><h3 class='theme-color'> No Data to Display</h3></div>";
        }
        divData += "</div>";

        $("#genericDrillModalPopupBodyContent").html("");
        $("#genericDrillModalPopupBodyContent").html(divData);
    } catch (e) {
        console.log(e);
    }
}


/***********************************************************************************End of OCM Agent Scripting Report JS**********************************************************************************/

/********************************************************************************** Start of Fax Sent and Received Report JS *****************************************************************************/
//This method is called to preview original tiff image in Fax sent report and Fax received report
function previewTifFile(e) {
    console.log("previewTifFile");
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var validation = true;
    if (data.PageCount == "0") {
        toaster("There are no file to preview", "info");
        e.preventDefault();
        validation = false;
        return;
    }
    if (data.FileName == "" && data.FileName == null) {
        toaster("There are no file to preview", "info");
        e.preventDefault();
        validation = false;
        return;
    }
   
    var url;
    if (validation) {
        toaster("Please wait until previewing", "info");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'OCMReport/DownloadFileFromPath',
            data: { "path": data.FileName,"key":"preview", "jobId": "original" },
            dataType: "json",
            success: function (returneddata) {
                console.log(returneddata[0]);
                console.log(returneddata[1]);

                if (returneddata[0] == "" || returneddata[0] == false) {
                    console.log("Error while previewing");
                    toaster("Error while previewing", "error");
                    return;
                }
                else {
                    url = returneddata[0];
                    if (url != '') {
                        if (returneddata[1] != '') {
                            $('canvas').remove();
                            $('img').remove();
                            //get file name to be printed
                            var fileNameList = returneddata[1].split('\\');
                            var fileName = fileNameList[fileNameList.length - 1];

                        $(function () {
                            Tiff.initialize({ TOTAL_MEMORY: 16777216 * 10 });
                            var xhr = new XMLHttpRequest();
                            xhr.open('GET', url + fileName);
                            xhr.responseType = 'arraybuffer';

                            xhr.onload = function (e) {
                                var buffer = xhr.response;
                                var tiff = new Tiff({ buffer: buffer });
                                $('#pdfViewerDiv').show();
                                $("#closeIframe").show();
                                for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
                                    tiff.setDirectory(i);
                                    var j = i + 1;
                                    //create canvas out of tiff.js
                                    var canvas = tiff.toCanvas(),
                                        tempCanvas = document.createElement('canvas'),
                                        context = tempCanvas.getContext("2d"),
                                        img = document.createElement('img');
                                    tempCanvas.width = "1728";
                                    tempCanvas.height = "2200";
                                    context.drawImage(canvas, 0, 0, 1728, 2200);
                                    //assign data url to img source
                                    img.src = tempCanvas.toDataURL();
                                    //assign id for each img tag for print purpose
                                    img.id = "file_" + j + "_" + i;
                                    //give style for the img to view in window resize
                                    img.style.width = "100%";
                                    img.style.height = "100%";
                                    //append the img to the element
                                    $('#pdfViewerDiv').append(img);
                                    //delete tiff image from folder
                                    deleteTiffImage(returneddata[1]);
                                }
                            };
                            xhr.send();
                        });
                    }
                    else {
                        requestPrevent = 0;
                        message = returneddata.Errors;
                        toaster("File not found to preview", "error");
                    }
                    }
                    else {
                        requestPrevent = 0;
                        message = returneddata.Errors;
                        toaster("File not found to preview", "error");
                    }
                }
            },
            error: function (msg) {
                console.log(msg);
                toaster("There is an error in previewing the file", "error");
            },
        })
    }
}

//This method is called to preview annotated tiff image in Fax Received Report
function previewTifFileAnnotated(e) {
    console.log("previewTifFileAnnotated");
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var validation = true;
    if (data.PageCount == "0") {
        toaster("There are no file to preview", "info");
        e.preventDefault();
        validation = false;
        return;
    }
    if (data.AnnotatedFile == "" && data.AnnotatedFile == null) {
        toaster("There are no file to preview", "info");
        e.preventDefault();
        validation = false;
        return;
    }
    
    if (validation) {
        toaster("Please wait until previewing", "info");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'OCMReport/DownloadFileFromPath',
            data: { "path": data.AnnotatedFile, "key": "preview", "jobId": "annotated" },
            dataType: "json",
            success: function (returneddata) {
                console.log(returneddata[0]);
                console.log(returneddata[1]);

                if (returneddata[0] == "" || returneddata[0] == false) {
                    console.log("Error while previewing");
                    toaster("Error while previewing", "error");
                    return;
                }
                else {
                    url = returneddata[0];
                    if (url != '') {
                        if (returneddata[1] != '') {
                            $('canvas').remove();
                            $('img').remove();
                            //get file name to be printed
                            var fileNameList = returneddata[1].split('\\');
                            var fileName = fileNameList[fileNameList.length - 1];

                        $(function () {
                            Tiff.initialize({ TOTAL_MEMORY: 16777216 * 10 });
                            var xhr = new XMLHttpRequest();
                            xhr.open('GET', url + fileName);
                            xhr.responseType = 'arraybuffer';

                            xhr.onload = function (e) {
                                var buffer = xhr.response;
                                var tiff = new Tiff({ buffer: buffer });
                                $('#pdfViewerDiv').show();
                                $("#closeIframe").show();
                                for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
                                    tiff.setDirectory(i);
                                    var j = i + 1;
                                    //create canvas out of tiff.js
                                    var canvas = tiff.toCanvas(),
                                        tempCanvas = document.createElement('canvas'),
                                        context = tempCanvas.getContext("2d"),
                                        img = document.createElement('img');
                                    tempCanvas.width = "1728";
                                    tempCanvas.height = "2200";
                                    context.drawImage(canvas, 0, 0, 1728, 2200);
                                    //assign data url to img source
                                    img.src = tempCanvas.toDataURL();
                                    //assign id for each img tag for print purpose
                                    img.id = "file_" + j + "_" + i;
                                    //give style for the img to view in window resize
                                    img.style.width = "100%";
                                    img.style.height = "100%";
                                    //append the img to the element
                                    $('#pdfViewerDiv').append(img);
                                    //delete tiff image from folder
                                    deleteTiffImage(returneddata[1]);
                                }
                            };
                            xhr.send();
                        });
                    }
                    else {
                        requestPrevent = 0;
                        message = returneddata.Errors;
                        toaster("File not found to preview", "error");
                    }
                    }
                    else {
                        requestPrevent = 0;
                        message = returneddata.Errors;
                        toaster("File not found to preview", "error");
                    }
                }
            },
            error: function (msg) {
                console.log(msg);
                toaster("There is an error in previewing the file", "error");
            },
        })

    }
}

//this function is to print single tiff file
function print(e) {
    console.log("print");
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var validation = true;
    var fileids = "";

    if (data.PageCount == "0") {
        toaster("There are no file to print", "info");
        e.preventDefault();
        validation = false;
        return;
    }
    if (data.AnnotatedFile == "" && data.AnnotatedFile == null) {
        toaster("There are no file to print", "info");
        e.preventDefault();
        validation = false;
        return;
    }

    if (validation) {
        swal({
            title: "Are you sure you want to print ?",
            text: "Confirm to print",
            icon: "warning",
            buttons: {
                cancel: "Cancel",
                catch: {
                    text: "Yes",
                    value: "yes",
                }},
            dangerMode: false
        })
            .then(function (willPrint) {
                if (willPrint) {
                    //var c = confirm("Are you sure you want to print ?")
                    //if (c) {
                    toaster("Please Wait..!", "info");
                    $.ajax({
                        type: "POST",
                        url: window.ApplicationPath + 'OCMReport/DownloadFileFromPath',
                        data: { "path": data.AnnotatedFile, "key": "print", "jobId": data.JobID },
                        dataType: "json",
                        success: function (returneddata) {
                            console.log(returneddata[0]);
                            console.log("Files to be printed: " + returneddata[1]);

                            if (returneddata[0] == "" || returneddata[0] == false) {
                                console.log("Error while printing");
                                toaster("Error while printing", "error");
                                return;
                            }
                            else {

                                url = returneddata[0];
                                if (url != '') {
                                    if (returneddata[1] != '') {
                                        $('canvas').remove();
                                        $('img').remove();
                                        //get file name to be printed
                                        var fileNameList = returneddata[1].split('\\');
                                        var fileName = fileNameList[fileNameList.length - 1];

                                        $(function () {
                                            Tiff.initialize({ TOTAL_MEMORY: 16777216 * 10 });
                                            var xhr = new XMLHttpRequest();
                                            xhr.open('GET', url + fileName);
                                            xhr.responseType = 'arraybuffer';

                                            xhr.onload = function (e) {

                                                var buffer = xhr.response;
                                                var tiff = new Tiff({ buffer: buffer });

                                                for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
                                                    tiff.setDirectory(i);
                                                    var j = i + 1;
                                                    //create canvas out of tiff.js
                                                    var canvas = tiff.toCanvas(),
                                                        tempCanvas = document.createElement('canvas'),
                                                        context = tempCanvas.getContext("2d"),
                                                        img = document.createElement('img');
                                                    tempCanvas.width = "1728";
                                                    tempCanvas.height = "2200";
                                                    context.drawImage(canvas, 0, 0, 1728, 2200);
                                                    //assign data url to img source
                                                    img.src = tempCanvas.toDataURL();
                                                    //assign id for each img tag for print purpose
                                                    img.id = "file_" + j + "_" + i;
                                                    fileids = fileids + "#file_" + j + "_" + i + ",";
                                                    //give style for the img to view in window resize
                                                    img.style.width = "100%";
                                                    img.style.height = "100%";
                                                    //append the img to the element
                                                    $('#pdfViewerDiv').append(img);
                                                }

                                                //remove extra comma at the end
                                                fileids = fileids.slice(0, -1);
                                                //delete tiff image from folder
                                                deleteTiffImage(returneddata[1]);
                                                $("#gridDrillOne").data("kendoGrid").dataSource.read();
                                                //print the canvas
                                                $(fileids).printThis();
                                            };
                                            xhr.send();
                                        });
                                    }
                                    else {
                                        requestPrevent = 0;
                                        message = returneddata.Errors;
                                        toaster("File not found to print", "error");
                                    }
                                }
                                else {
                                    requestPrevent = 0;
                                    message = returneddata.Errors;
                                    toaster("File not found to print", "error");
                                }
                            }
                        },
                        error: function (msg) {
                            console.log(msg);
                            toaster("There is an error in printing the file", "error");
                        },
                    })
                }
                else {
                    console.log("User declined to print");
                }
            });
    }
}

//this function is called when one record is selected or deselected
function onFaxClick() {
    //check if no of selected checkbox reaches max bulk print count
    if ($("#checkFax:checked").length >= $('#MaxBulkPrintTiffCount').val()) {
        // disable remaining checkboxes
        $("#checkFax:not(:checked)").prop('disabled', true); 
    }
    else {
        //enable checkboxes if any checkbox is deselected
        $("#checkFax:not(:checked)").prop('disabled', false);
    }
}

//this function is used to get all selected tiff images path
function onDetailsChange() {
    var idsToSend = [];
    var jobidsToSend = [];

    var grid = $("#gridDrillOne").data("kendoGrid")
    var ds = grid.dataSource.view();

    for (var i = 0; i < ds.length; i++) {
        var row = grid.table.find("tr[data-uid='" + ds[i].uid + "']");
        var checkbox = $(row).find(".checkbox");

        if (checkbox.is(":checked")) {
            idsToSend.push(ds[i].AnnotatedFile);
            jobidsToSend.push(ds[i].JobID);
        }
    }
    $('#SelectedIdList').val(idsToSend);
    $('#SelectedJobIdList').val(jobidsToSend);
}

//this function to print bulk fax
function PrintBulkFax(e) {
    console.log("PrintBulkFax");

    //get files selected to print
    onDetailsChange()
    if ($('#SelectedIdList').val() == "") {
        toaster("Please select rows for bulk print", "error");
        return;
    }

    swal({
        title: "Are you sure you want to print ?",
        text: "Confirm to print",
        icon: "warning",
        buttons: {
            cancel: "Cancel",
            catch: {
                text: "Yes",
                value: "yes",
            }
        },
        dangerMode: false
    })
        .then(function (willPrint) {
            if (willPrint) {
                //var c = confirm("Are you sure you want to print ?")
                //if (c) {
                    toaster("Please Wait..!", "info");
                    $.ajax({
                        type: "POST",
                        url: window.ApplicationPath + 'OCMReport/DownloadFileFromPath',
                        data: { "path": $('#SelectedIdList').val(), "key": "print", "jobId": $('#SelectedJobIdList').val() },
                        dataType: "json",
                        success: function (returneddata) {
                            console.log(returneddata[0]);
                            console.log(returneddata[1]);

                            if (returneddata[0] == "" || returneddata[0] == false) {
                                console.log("Error while printing");
                                toaster("Error while printing", "error");
                                $('#SelectedIdList').val("");
                                return;
                            }
                            else {
                                url = returneddata[0];
                                if (url != '') {
                                    if (returneddata[1] != '') {

                                        var fileName = "", fileNameList = "";
                                        var filePathList = returneddata[1].split(',');
                                        var fileids = "";
                                        var imgcount = "";
                                        var fileCount = "";
                                        $('canvas').remove();
                                        $('img').remove();
                                        //var j = 1;
                                        for (var m = 0; m < filePathList.length; m++) {

                                            fileNameList = filePathList[m].split('\\');
                                            fileName = fileNameList[fileNameList.length - 1];

                                            $(function () {
                                                Tiff.initialize({ TOTAL_MEMORY: 16777216 * 10 });
                                                var xhr = new XMLHttpRequest();
                                                xhr.open('GET', url + fileName);
                                                xhr.responseType = 'arraybuffer';

                                                xhr.onload = function (e) {
                                                    var buffer = xhr.response;
                                                    var tiff = new Tiff({ buffer: buffer });

                                                    for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
                                                        tiff.setDirectory(i);
                                                        var j = i + 1;
                                                        //create canvas out of tiff.js
                                                        var canvas = tiff.toCanvas(),
                                                            tempCanvas = document.createElement('canvas'),
                                                            context = tempCanvas.getContext("2d"),
                                                            img = document.createElement('img');
                                                        tempCanvas.width = "1728";
                                                        tempCanvas.height = "2200";
                                                        context.drawImage(canvas, 0, 0, 1728, 2200);
                                                        //assign data url to img source
                                                        img.src = tempCanvas.toDataURL();
                                                        //assign id for each img tag for print purpose
                                                        img.id = "file_" + j + "_" + i;
                                                        fileids = fileids + "#file_" + j + "_" + i + ",";
                                                        //j++;
                                                        //give style for the img to view in window resize
                                                        img.style.width = "100%";
                                                        img.style.height = "100%";
                                                        //append the img to the element
                                                        $('#pdfViewerDiv').append(img);

                                                    }
                                                    //count the image to be printed
                                                    imgcount++;
                                                    //once the no of files to be printed is appended to the canvas print the page
                                                    if (m == imgcount) {
                                                        //remove extra comma at the end
                                                        fileids = fileids.slice(0, -1);
                                                        //delete tiff image from folder
                                                        deleteTiffImage(returneddata[1]);
                                                        $("#gridDrillOne").data("kendoGrid").dataSource.read();

                                                        $(fileids).printThis();
                                                    }
                                                };
                                                xhr.send();
                                            });
                                        }
                                    }
                                    else {
                                        //if there is no file 
                                        requestPrevent = 0;
                                        message = returneddata.Errors;
                                        toaster("File not found to print", "error");
                                    }
                                }
                                else {
                                    requestPrevent = 0;
                                    message = returneddata.Errors;
                                    toaster("File not found to print", "error");
                                }
                            }
                            $('#SelectedIdList').val("");
                            $('#SelectedJobIdList').val("");
                            fileids = "";
                        },
                        error: function (msg) {
                            console.log(msg);
                            toaster("There is an error in printing the file", "error");
                            $('#SelectedIdList').val("");
                            $('#SelectedJobIdList').val("");
                        },
                    })
                //}
            }
            else {
                console.log("User declined to print");
            }
        });
}

//this function is called when preview window is closed
function CloseFrame() {
    $("#pdfViewerDiv").hide();
    $('img').remove();
    $("#closeIframe").hide();
    $("#pdfPrintDiv").hide();
    $("#viewerIframe").hide();
}

//Delete file from folder after preview or print
function deleteTiffImage(tiffList)
{
    console.log("deleteTiffImage");
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'OCMReport/DeleteTiffImage',
        data: {"imageList": tiffList },
        dataType: "json",
        success: function (data) {
            if (data) {
                console.log('Tiff images are successfully deleted.');
            }
            else {
                console.log('Failed to delete tiff images');
            }
        },
        error: function () {
            console.log('Failed to delete tiff images');
        }
    });
}

/********************************************************************************** End of Fax Received Report JS *****************************************************************************/