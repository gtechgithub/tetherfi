﻿/* -----------------------------------------------------------------------------------------------------------------
 * <copyright file=InteractionWorkflow\DataParser.js  company="Tetherfi.">
 *      Tetherfi™ 
 * </copyright>
 * <author>Prakash D'souza</author>
 * <CreatedOn> 15/9/2017  6:50 PM</CreatedOn>
 * <LastModified>15/9/2017  6:51 PM</LastModified>
 * <summary>
 *      All major Data related stuffs here
 *  </summary>         
 * ---------------------------------------------------------------------------------------------------------------*/

var WindowPopup, windowpopupwidget, windowpopupGlobalPhrase;
var windowTitle = "";


$(document).ready(function () {
    /**GetData
     * Define the Version
     * @returns {} 
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "DataParser.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Prakash",
        Description: "new commit, has logic to process data."
    });
});


/*
    Define the class object
*/
var DataParser = function () {

    this.Log = new Logger();
}
/*
    in-herit current class object, add ore featues 

*/
DataParser.prototype = {

    /**
     * Check for any childrens for this node.
     * If there is any childrens, user has to break the connection of the each node and then try to delete 
     * Both incoming and out going connections should not be exists.
     *
     */
    isDeletable: function (id) {
        try {
            var $that = this;
            var outgoing = false;
            var incoming = false;
            var activeConnections = $that.GetActiveConnections();
            for (var i = 0; i < activeConnections.length; i++) {
                // is there any active connection for this node
                // incoming
                if (activeConnections[i].pageSourceId === id) {
                    incoming = true;
                }
                if (activeConnections[i].pageTargetId === id) {
                    outgoing = true;
                }
            }

            // is it a Dnis ?
            // will not allow to delete dnis
            var data = $that.GetData(id, "")[0];
            if (data.Type === "dnis") {
                this.Log.LogDetails(this.Log.logType.Error, "isDeletable", "Cannot delete Dnis node.", true);
                return false;
            }

            // Lets check the module lgs having any legs
            if (data.Type === "module") {
                // If there is any incoming connection for this module ?. If so. then need to break that connection first
                if (data.Connection.ParentNode !== "") {
                    this.Log.LogDetails(this.Log.logType.Error, "isDeletable", "Incoming connection found for this node", false);
                    return false;
                }

                // Lets check each legs and see
                for (var i = 0; i < data.Legs.length; i++) {
                    // check is there any furture legs are exsts for this node
                    var legdata = $that.GetData(data.Legs[i].NextNodeId, "")[0].Legs[0];
                    if (legdata.NextNodeId !== "") return false;
                }

                // lets allow to delete the 
                return true;
            }

            // In case of 'conditionalrule', and it contains only a 'Default' exit. and 'Default' doesn't have any children, then allow to delete
            if (data.Type === "conditionalrule") {

                // check the legs
                if (data.Legs.length === 1 && data.Legs[0].RuleName === "Default") {
                    // is this 'Default' having any kids?
                    var datalegChild = $that.GetData(data.Legs[0].Id, "")[0];
                    if (datalegChild.Legs.length > 0) {
                        // 1017-10-27 : If nextNodeId is Empty
                        if (datalegChild.Legs[0].NextNodeId !== "") {
                            this.Log.LogDetails(this.Log.logType.Error, "isDeletable", "Cannot delete Conditional node. Break the connections from 'Default' node", true);
                            return false;
                        } else {
                            return true;
                        }

                    } else {
                        // lets allow to delete the 
                        return true;
                    }
                }
                //this.Log.LogDetails(this.Log.logType.Error, "isDeletable", "Cannot delete Dnis node.", true);
                return false;
            }

            // both incoming and outgoing connection should not be there.
            if (incoming || outgoing) return false;
            else return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "isDeletable", exception.message, false);
        }
    },

    /*
        Get all the connections
    */
    GetActiveConnections: function () {
        try {
            var connections = [];
            $.each(window.GraphconfigSettings.instance.getConnections(), function (idx, connection) {
                connections.push({
                    connectionId: connection.Id,
                    pageSourceId: connection.sourceId,
                    pageTargetId: connection.targetId
                });
            });
            return connections;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetActiveConnections", exception.message, false);
            return [];
        }
    },

    GetHeader: function () {
        try {
            var data = ApplicationPomConfiguration.jsonDataObj.Header;

            return data;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetHeader", exception.message, false);
        }
    },

    /**
     * Get CallFlow level Comments
     * @returns {} 
     */
    GetFlowLevelComments: function () {
        try {
            if (ApplicationPomConfiguration.jsonDataObj.Comments === undefined) {
                ApplicationPomConfiguration.jsonDataObj.Comments = [];
            }
            var data = ApplicationPomConfiguration.jsonDataObj.Comments;

            return data;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetFlowLevelComments", exception.message, false);
        }
    },

    /**
    * Get CallFlow level Scheduler
    * @returns {} 
    */
    GetFlowLevelScheduler: function () {
        try {

            if (ApplicationPomConfiguration.jsonDataObj.Scheduler === undefined) {
                ApplicationPomConfiguration.jsonDataObj.Scheduler = [];
            }
            var data = ApplicationPomConfiguration.jsonDataObj.Scheduler;


            return data;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetFlowLevelScheduler", exception.message, false);
        }
    },

    /*
        Load data from the collection
    */
    GetData: function (id, type) {
        try {
            var apputils = new AppUtilities();
            var data = "";

            if (id === "" && type !== "") {
                data = Enumerable.From(ApplicationPomConfiguration.jsonDataObj).
                    Where("$.Type.toLowerCase() == " + apputils.AddSingleQuote(type.toLowerCase())).ToArray();
            } else if (id !== "" && type === "") {
                data = Enumerable.From(ApplicationPomConfiguration.jsonDataObj).
                    Where("$.Id.toLowerCase() == " + apputils.AddSingleQuote(id.toLowerCase())).ToArray();

            } else if (id !== "" && type !== "") {
                data = Enumerable.From(ApplicationPomConfiguration.jsonDataObj).
                    Where("$.Type.toLowerCase() == " + apputils.AddSingleQuote(type.toLowerCase()) +
                        " && $.Id.toLowerCase() == " + apputils.AddSingleQuote(id.toLowerCase())).ToArray();
            } else if (id === "" && type === "") {
                data = Enumerable.From(ApplicationPomConfiguration.jsonDataObj).ToArray();
            }


            return data;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetData", exception.message, false);
        }
    },

    /**
     * Get all the nodes inside specific tab
     * @param {} tabId Tab Id
     * @returns {} 
     */
    GetDataByTab: function (tabId) {
        var data = "";
        try {
            var apputils = new AppUtilities();
            if (tabId !== "") {
                data = Enumerable.From(ApplicationPomConfiguration.jsonDataObj).
                    Where("$.TabId.toLowerCase() == " + apputils.AddSingleQuote(tabId.toLowerCase())).ToArray();
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetDataByTab", exception.message, false);
        }

        return data;
    },

    /**
     * Load all the call flow level comments
     * @returns {} 
     */
    GetCallFlowLevelComments: function () {
        try {
            var comments = window.ApplicationPomConfiguration.jsonDataObj.Comments;
            // Get last comments only if
            if (comments.length > 0) {
                // latest comment first
                var utils = new AppUtilities();
                var latestComments = utils.sortResults(comments, 'InsertDateTime', false);
                return latestComments;
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "DataParser : GetCallFlowLevelComments", exception.message, false);
            return [];
        }
    },

    /**
     * Load all the call flow level comments
     * @returns {} 
     */
    GetCallFlowLevelCommentsById: function (id) {
        try {
            var apputils = new AppUtilities();

            var $that = this;
            var comments = $that.GetCallFlowLevelComments();

            var data = Enumerable.From(comments).
                Where("$.Id.toLowerCase() == " + apputils.AddSingleQuote(id.toLowerCase())).ToArray();

            return data;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "DataParser : GetCallFlowLevelComments", exception.message, false);
            return [];
        }
    },

    /**
     * Delete Comments
     * @param {} id  ID [optional] , if id is given, means delete specific comment
     * @returns {} none
     */
    DeleteCallflowlevelComments: function (id) {
        var deletestatus = false;
        try {
            if (id === "") {
                window.ApplicationPomConfiguration.jsonDataObj.Comments = [];
                deletestatus = true;
            } else {
                var comments = window.ApplicationPomConfiguration.jsonDataObj.Comments;
                for (var i = 0; i < comments.length; i++) {
                    if (comments[i].Id === id) {
                        comments.splice(i, 1);
                        deletestatus = true;
                        break;
                    }
                }
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "DataParser : GetCallFlowLevelComments", exception.message, false);

        }
        return deletestatus;
    },

    /*
        Update the Node position based on screen

    */

    UpdateNodePostion: function () {

        try {
            var $that = this;
            var data = $that.GetData("", "");
            var utils = new AppUtilities();

            $.each(data, function (key, value) {
                // get the position of the node/div
                var position = utils.GetElementPositinWithinContainer(value.Id);

                // update the position
                value.Position = position;

            });
            return true;


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "UpdateNodePostion", exception.message, false);
            return false;
        }
    },

    /*
        Get data by menu Id.
        Basically menu id should be unique within a call flow
    */
    IsDuplicateMenuId: function (menuid, currentId) {
        //
        try {
            var apputils = new AppUtilities();
            var data = "";

            data = Enumerable.From(ApplicationPomConfiguration.jsonDataObj).
                Where("$.Type.toLowerCase() == 'menu'" +
                    " && $.MenuElement.MenuId.toLowerCase() == " + apputils.AddSingleQuote(menuid)).ToArray();

            if (data.length === 0) return false;
            // is this the current record
            if (data.length === 1 && data[0].status === "") {
                if (data[0].Id === currentId) return false;
                else return true;
            }
            if (data.length > 1) return true;
            return data;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "IsDuplicateMenuId", exception.message, false);
            return true;
        }
    },

    /**
     * Gets all the childrens basd on parent given
     * @param {} source : source/parent nod id 
     * @returns {} 
     */

    GetChildrens: function (source) {
        try {
            //
            var $that = this;
            var data = $that.GetData("", "");
            var connections = [];

            $.each(data, function (key, value) {
                if (value.Connection.ParentNode.toLowerCase() === source.toLowerCase()) {
                    connections.push(value);
                }
            });

            return connections;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetChildrens", exception.message, false);
            return [];
        }
    },

    GetDeepChildren: function (result, sourceId) {
        try {
            //// item exists in a array 
            //var cnt = 0;
            //for (var k = 0; k < result.length; k++) {
            //    if (result[k].Id === sourceId) cnt++;
            //    if (cnt > 1)return false;
            //}
            //if (jQuery.inArray(sourceId, result) === 1) {
            //    return false;
            //};

            //  VP :Aug 29, '18 : Only copy nodes in the current tab. If exit point connects to an entry point in other tab, don't include
            var node = new DataParser().GetData(sourceId, "")[0];
            if (node.Type === "exitpoint") {
                if (node.Legs[0].TabId !== window.GraphconfigSettings.CurrentTabId) {
                    return false;
                }
            }

            var $that = this;
            //var data = $that.GetData();
            var legObj = new Legs();
            var legnodes = legObj.GetChildrens(sourceId)[0];

            for (var i = 0; i < legnodes.Legs.length; i++) {
                //for (var j = 0; j < legnodes.Legs[i].Legs.length; j++) {
                if (legnodes.Legs[i].NextNodeId !== "" && legnodes.Legs[i].NextNodeId !== undefined) {

                    // item exists in a array 
                    var found = false;
                    for (var k = 0; k < result.length; k++) {
                        if (result[k].Id === legnodes.Legs[i].NextNodeId) {
                            found = true;
                            break;
                        }
                    }
                    if (found) continue;
                    result.push({
                        Type: legnodes.Type,
                        Parent: sourceId,
                        Id: legnodes.Legs[i].NextNodeId
                    });
                    $that.GetDeepChildren(result, legnodes.Legs[i].NextNodeId);
                }
                //}
            }
            //$.each(legnodes, function(key, legnode) {
            //    $.each(legnodes.Legs, function (key1, leg) {
            //        if (leg.NextNodeId !== "") {
            //            result.push(leg.NextNodeId);
            //            $that.GetDeepChildren(result, leg.NextNodeId);
            //        }
            //    });


            //});
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetDeepChildren", exception.message, false);

        }

        return result;
    },


    //GetDeepChildern:function(source) {
    //    try {
    //        //
    //        var $that = this;
    //        var connections = [];

    //        var data = $that.GetChildrens(source);

    //        $.each(data, function (key, value) {
    //            connections.push(value);
    //            $.each($that.GetChildrens(value.Id), function (key1, value1) {
    //                connections.push(data);

    //            });

    //        });

    //        return connections;

    //    } catch (exception) {
    //        this.Log.LogDetails(this.Log.logType.Error, "GetChildrens", exception.message, false);
    //        return [];
    //    }
    //},

    /**
     * Get the next DTMF key 
     * @param {} sourceId  allways a menu
     * @returns {} nxt available dtmf
     * If the DTMF is reached to 9, it will set to *0 the nxt available DTMF
     */
    GetNextDTMF: function (sourceId) {

        var nxtdtmf = "0";
        try {
            var $that = this;
            // get childrens of this menu.
            var existingdtmflist = [];

            // Get existing dtmfs
            var leg = new Legs();
            ;
            /*
                var menuchild = $that.GetChildrens(sourceId);
                for (var i = 0; i < menuchild.length; i++) {
                    var dtmf = $("#" + menuchild[i].Id + '_dtmf').text();
                    if (parseInt(dtmf) >= 0) existingdtmflist.push(dtmf);
                }
            */
            var menuchild = leg.GetChildrens(sourceId)[0];
            for (var i = 0; i < menuchild.Legs.length; i++) {
                var dtmf = menuchild.Legs[i].Option;
                if (parseInt(dtmf) >= 0) existingdtmflist.push(dtmf);
            }
            // get next DTMF
            var max = 0;
            for (var i = 0; i < existingdtmflist.length; i++) {
                if (parseInt(existingdtmflist[i]) > max) max = parseInt(existingdtmflist[i]);
            }
            // If its a new and first connection, lets set it as 0
            //if (max === 0) nxtdtmf = 0;
            if (max >= 9) nxtdtmf = "*0";
            else nxtdtmf = max + 1;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetNextDTMF", exception.message, false);
        }
        // sending back as string
        return nxtdtmf.toString();
    },

    //GetParent:function(destination) {
    //    try {
    //        //
    //        var $that = this;
    //        var data = $that.GetData("", "");
    //        var connections = [];

    //        $.each(data, function (key, value) {
    //            if (value.Connection.ParentNode.toLowerCase() === source.toLowerCase()) {
    //                connections.push(value);
    //            }
    //        });

    //        return connections;

    //    } catch (exception) {
    //        this.Log.LogDetails(this.Log.logType.Error, "GetChildren", exception.message, false);
    //        return [];
    //    }
    //},

    /*
        Read all the connections that are existing in the json flow
        
    */
    GetExisitingConnections: function (source, destination) {
        try {
            //
            var $that = this;
            var data = $that.GetData("", "");
            var connections = [];

            // 08/01/2017 Lets take the parent/Source from Legs

            var legObj = new Legs();
            //var legs = legObj.GetCallFlowLegs();
            connections = legObj.LegConnections();


            //$.each(data, function(key, value) {
            //    var con = {
            //        source: value.Connection.ParentNode,
            //        // destination will be always the current node
            //        destination: value.Id
            //    };
            //    connections.push(con);
            //});

            // Get connections where source and destinations are same
            if (source !== "" && destination !== "") {
                var btnconnections = [];
                $.each(connections, function (key, value) {
                    if (value.source === source && value.destination === destination) {
                        var con = {
                            source: value.source,
                            // destination will be always the current node
                            destination: value.destination
                        };
                        btnconnections.push(con);
                    }
                });
                return btnconnections;
            }
            // Source and destination not given, return entire connection sets
            if (source === "" && destination === "") {
                return connections;
            }

            // get all the connections goes from source
            if (source !== "") {
                var sourceconnections = [];
                $.each(connections, function (key, value) {
                    if (value.source === source) {
                        var con = {
                            source: value.source,
                            // destination will be always the current node
                            destination: value.destination
                        };
                        connections.push(con);
                    }
                });
                return sourceconnections;
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetExisitingConnections", exception.message, false);
            return [];
        }
    },

    /*
        Get the Parent connecion ID based on child connection supplied.
        Only one parent for each node
    */
    GetParentConnection: function (child) {
        try {
            var $that = this;
            var data = $that.GetExisitingConnections("", "");
            var result = [];
            $.each(data, function (key, value) {
                if (value.destination === child) {
                    result.push(value);;
                }
            });

            return result;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetParentConnection", exception.message, false);
            return [];
        }
    },

    GetNextLeg: function (exsitinglegs) {
        var nxtleg = 0;
        try {


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetNextLeg", exception.message, false);
        }
        return nxtleg;
    },

    /*
        Break Connection between
        source      : source connection
        target : Target Connection 
    */
    BreakConnection: function (source, target) {
        try {
            // lets disconnectd the source [nextNodeId]
            source.Connection.NextNodeId = "";

            // remove parent from Target connection
            target.Connection.ParentNode = "";

            return true;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "BreakConnection", exception.message, false);
            return false;
        }

    },

    /*
        Delete Spcific node from the flow.
        Before deleting this node. there should not be any childrens. 
        Dont call this method directly
        
    */
    RemoveNode: function (id) {
        try {
            ;
            var $that = this;

            // initialse the audit trail obj.
            //var audittrial = new AuditTrial();

            if (!$that.isDeletable(id)) {
                return false;
            }


            // ready tp delete
            var data = window.ApplicationPomConfiguration.jsonDataObj;

            var currentData = $that.GetData(id, "")[0];
            var modulelegs = [];
            // is this a Module ?
            if (currentData.Type === "module") {
                modulelegs.push(id);
                for (var j = 0; j < currentData.Legs.length; j++) {
                    modulelegs.push(currentData.Legs[j].NextNodeId);
                }

                // get the removable indexes list
                var removeIndexList = [];
                for (var j = 0; j < modulelegs.length; j++) {
                    for (var i = 0; i < data.length; i++) {
                        if (modulelegs[j] === data[i].Id) {
                            removeIndexList.push(i);
                            break;
                        }
                    }
                }

                // lets make it index in descending oreder. so start delete rom end
                removeIndexList.sort(function (a, b) { return b - a });
                for (var i = 0; i < removeIndexList.length; i++) {

                    // update audit trial
                   // audittrial.AddToAudiTrialList("Delete", data[removeIndexList[i]].Type, JSON.stringify(data[removeIndexList[i]]), "", "node");
                    // lets remove the items
                    data.splice(removeIndexList[i], 1);
                }

                // Remove the Dom
                var flow = new Flowdiagram();
                for (var j = 0; j < modulelegs.length; j++) {
                    flow.ClearSingleConnection(modulelegs[j], true);
                }

                return true;

            }


            for (var i = 0; i < data.length; i++) {
                if (id === data[i].Id) {
                    // update audit trial
                   // audittrial.AddToAudiTrialList("Delete", data[i].Type, JSON.stringify(data[i]), "", "node");

                    data.splice(i, 1);
                }
            }

            return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "RemoveNode", exception.message, false);
            return false;
        }
    },

    /*
        Get direct data from the collection. this will not create any clone like From.Enumerable
    */
    GetDataDirect: function (id) {
        try {
            var data = window.ApplicationPomConfiguration.jsonDataObj;
            return data;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetDataDirect", exception.message, false);
            return [];
        }
    },


    /*
        Remove the node from the collection
        source      : source connection
        
    */
    RemoveExitNode: function (module, exitnode) {
        try {
            ;

            // relad the data and delete the exit node
            // will read direct data from the json here because GetData will internally create a copy
            var datatoDelete = window.ApplicationPomConfiguration.jsonDataObj;

            for (var j = 0; j < datatoDelete.length; j++) {

                if (datatoDelete[j].Id === exitnode.Id) {
                    datatoDelete.splice(j, 1);
                    break;
                }
            }

            //// Remove leg
            for (var i = 0; i < module.Legs.length; i++) {
                if (module.Legs[i].ExitNodeId === exitnode.Id) {
                    module.Legs.splice(i, 1);
                    break;
                }
            }


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "RemoveExitNode", exception.message, false);
            return false;
        }

    },


    /*
        Set connection between two nodes
        source      : Connection starts
        destination : Connections Ends
    */
    SetConntection: function (source, destination) {
        try {
            var utils = new AppUtilities();
           
            var $that = this;

            // source conenction
            var sourcedata = $that.GetData(source, "");

            // Destination Connection
            var destinationdata = $that.GetData(destination, "");

            // think that there will be only one destination there wont be duplicate id
            if (destinationdata.length === 1) {
                var childrens = $that.GetChildrens(source);
                if (childrens.length > 0) {
                    this.Log.LogDetails(this.Log.logType.Error, "SetConntection", "Should have only one Exit from " + sourcedata[0].Type + " node.", false);
                    return false;
                }
                sourcedata[0].Legs[0].NextNodeId = destinationdata[0].Id;

                sourcedata[0].Connection.NextNodeId = destination;
                // Update the source connection
                destinationdata[0].Connection.ParentNode = source;

                return true;
            } else {
                return false;
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "SetConntection", exception.message, false);
            return false;
        }
    },

    UpdateLegPhraseStatus: function (phrase, status) {
        //

        var legs = [];
        try {
            for (var i = 0; i < data; i++) {
                // var phrase
            }

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "UpdateLegPhraseStatus", exception.message, false);
            return [];
        }
    },

    GetLegs: function (source) {
        //
        try {
            var $that = this;
            // source conenction
            var sourcedata = $that.GetData(source, "");
            var menulegs = sourcedata[0].MenuElement.Legs;

            return menulegs;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetLegs", exception.message, false);
            return [];
        }
    },

    GetLegOption: function (source, optionid) {
        //
        try {
            var $that = this;
            // source conenction
            var sourcedata = $that.GetLegs(source);
            //var menulegs = sourcedata[0].MenuElement.Legs;

            var legs = [];
            // already exists this leg ?
            for (var i = 0; i < sourcedata.length; i++) {
                if (sourcedata[i].Id === optionid) {
                    legs.push(sourcedata[i]);
                }
            }

            return legs[0];

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetLegOption", exception.message, false);
            return [];
        }
    },

    /*
        Get Legs Phrases based on menu and option
    */
    GetLegsPhrases: function (source, optionid) {
        //
        try {
            var $that = this;
            // source conenction
            var legs = $that.GetLegOption(source, optionid);

            return legs.Phrases;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetLegsPhrases", exception.message, false);
            return [];
        }
    },


    AddPhraseLeg: function (sourceid, optionid, phrase) {
        try {
            //

            var $that = this;
            // source conenction
            var sourcedata = $that.GetData(sourceid, "");
            var menulegs = sourcedata[0].MenuElement.Legs;


            var legs = [];
            // already exists this leg ?
            for (var i = 0; i < menulegs.length; i++) {
                if (menulegs[i].Id === optionid) {
                    legs.push(menulegs[i]);
                }
            }
            legs[0].Phrases.push(phrase);


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "AddPhraseLeg", exception.message, false);
            return [];
        }
    },


    RemoveLegPhrase: function (sourceid, optionid, fileid) {
        try {
            var $that = this;


            var legs = $that.GetLegsPhrases(sourceid, optionid);
            for (var i = 0; i < legs.length; i++) {
                if (legs[i].Id === fileid) {
                    legs.splice(i, 1);
                }
            }
            //// source conenction
            //var sourcedata = $that.GetData(source, "");
            //var menulegs = sourcedata[0].MenuElement.Legs;

            //var legs = [];
            //// already exists this leg ?
            //for (var i = 0; i < menulegs.length; i++) {
            //    if (menulegs[i].Id === optionid) {
            //        legs.push(menulegs[i]);
            //    }
            //}

            //return legs;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "RemoveLegPhrase", exception.message, false);
            return [];
        }
    },


    /*
        To avoid the Pointer/refernce issue that we faced during currentphrase clear,
        Will create a clone of the object and push
    */
    ProcessApplicationCurrentPhraseList: function () {
        //
        try {
            var tmpphrases = {
                GreetingFile: { "Phrases": [] },
                InvalidPrompt1: { "Phrases": [] },
                InvalidPrompt2: { "Phrases": [] },
                NoInputPrompt1: { "Phrases": [] },
                NoInputPrompt2: { "Phrases": [] },
                MaxTries: { "Phrases": [] },
                AgentTransferAnnouncement: { "Phrases": [] },
                Announcement1: { "Phrases": [] },
                Announcement2: { "Phrases": [] },
                Announcement3: { "Phrases": [] },
                Announcement4: { "Phrases": [] },
                Announcement5: { "Phrases": [] },
                MenuPhrase: [],
                Rules: []

            };

            // Greetings
            if (window.ApplicationCurrentPhraseList.GreetingFile.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.GreetingFile.Phrases.slice(0), function (key, value) {
                    tmpphrases.GreetingFile.Phrases.push(value);
                });
            }
            // InvalidPrompt1
            if (window.ApplicationCurrentPhraseList.InvalidPrompt1.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.InvalidPrompt1.Phrases.slice(0), function (key, value) {
                    tmpphrases.InvalidPrompt1.Phrases.push(value);
                });
            }

            // InvalidPrompt2
            if (window.ApplicationCurrentPhraseList.InvalidPrompt2.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.InvalidPrompt2.Phrases.slice(0), function (key, value) {
                    tmpphrases.InvalidPrompt2.Phrases.push(value);
                });
            }
            // NoInputPrompt1
            if (window.ApplicationCurrentPhraseList.NoInputPrompt1.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.NoInputPrompt1.Phrases.slice(0), function (key, value) {
                    tmpphrases.NoInputPrompt1.Phrases.push(value);
                });
            }

            // NoInputPrompt2
            if (window.ApplicationCurrentPhraseList.NoInputPrompt2.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.NoInputPrompt2.Phrases.slice(0), function (key, value) {
                    tmpphrases.NoInputPrompt2.Phrases.push(value);
                });
            }

            // MenuPhrase
            if (window.ApplicationCurrentPhraseList.MenuPhrase.length !== undefined) {
                $.each(window.ApplicationCurrentPhraseList.MenuPhrase.slice(0), function (key, value) {
                    tmpphrases.MenuPhrase.push(value);
                });
            }

            // Rules
            if (window.ApplicationCurrentPhraseList.Rules.length !== undefined) {
                $.each(window.ApplicationCurrentPhraseList.Rules.slice(0), function (key, value) {
                    tmpphrases.Rules.push(value);
                });
            }

            // Max Tries
            if (window.ApplicationCurrentPhraseList.MaxTries.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.MaxTries.Phrases.slice(0), function (key, value) {
                    tmpphrases.MaxTries.Phrases.push(value);
                });
            }

            // Agent Transfer Announcement
            if (window.ApplicationCurrentPhraseList.AgentTransferAnnouncement.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.AgentTransferAnnouncement.Phrases.slice(0), function (key, value) {
                    tmpphrases.AgentTransferAnnouncement.Phrases.push(value);
                });
            }

            // Announcement 1
            if (window.ApplicationCurrentPhraseList.Announcement1.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.Announcement1.Phrases.slice(0), function (key, value) {
                    tmpphrases.Announcement1.Phrases.push(value);
                });
            }

            // Announcement 2
            if (window.ApplicationCurrentPhraseList.Announcement2.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.Announcement2.Phrases.slice(0), function (key, value) {
                    tmpphrases.Announcement2.Phrases.push(value);
                });
            }

            // Announcement 3
            if (window.ApplicationCurrentPhraseList.Announcement3.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.Announcement3.Phrases.slice(0), function (key, value) {
                    tmpphrases.Announcement3.Phrases.push(value);
                });
            }

            // Announcement 4
            if (window.ApplicationCurrentPhraseList.Announcement4.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.Announcement4.Phrases.slice(0), function (key, value) {
                    tmpphrases.Announcement4.Phrases.push(value);
                });
            }

            // Announcement 5 
            if (window.ApplicationCurrentPhraseList.Announcement5.Phrases.length > 0) {
                $.each(window.ApplicationCurrentPhraseList.Announcement5.Phrases.slice(0), function (key, value) {
                    tmpphrases.Announcement5.Phrases.push(value);
                });
            }
            return tmpphrases;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "ProcessApplicationCurrentPhraseList", exception.message, false);
        }
    },



    /*
        Generate the Data node based on type provided
        Will support following types
        dnins
        menu
        module
            exitnode
        agent
        multiskillagent

    */
    GenerateDataNode: function (data) {
        
        try {
            var utils = new AppUtilities();
            data = JSON.parse(JSON.stringify(data));
            data.Id = utils.generateUUID();
            return data;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GenerateDataNode", exception.message, false);
            return [];
        }
    },


    /*
        Add Flow Level Comments
        Keep pushing new comments to the flow level comment area.
    */
    AddCommentsToCallFlow: function (comment) {
        try {
            var $that = this;
            // Apr. 2, 2018 :- Vishal : Push comments only to JSON & not to callflow
            //var comments = $that.GetFlowLevelComments();
            //comments.push(comment);

            // Lets push the Comments to Json Storage
            var datacomment = {
                'Id': comment.Id,
                'InsertDateTime': comment.InsertDateTime,
                'UpdateDateTime': comment.UpdateDateTime,
                'User': comment.User,
                'UserType': comment.UserType,
                'UserAction': comment.Action,
                'Rejected': comment.Rejected,
                'Comments': comment.Comments
            }

            $.ajax({
                type: "POST",
                url: window.ApplicationPath + "Comment/UpdateComments?callflow=" + window.ApplicationPomConfiguration.FileInfo.FlowName,
                contentType: 'application/json',
                data: JSON.stringify(datacomment),
                dataType: 'json',
                async: true,
                success: function (response) {
                    if (response.StatusCode === "0") {
                        $that.Log.LogDetails($that.Log.logType.Success, "AddCommentsToCallFlow", "Comments successfully added to the json file", false);
                    }
                    else {
                        $that.Log.LogDetails($that.Log.logType.Error, "AddCommentsToCallFlow", "Failed to add comments to json files", false);
                    }
                },

            });

        } catch (exception) {
            $that.Log.LogDetails($that.Log.logType.Error, "AddCommentsToCallFlow", exception.message, false);
            return [];
        }
    },

    /*
        Add Flow Level Comments
        Keep pushing new comments to the flow level comment area.
    */
    AddSchedulerToCallFlow: function (schedule) {
        try {
            var $that = this;
            var schedulerdata = $that.GetFlowLevelScheduler();
            schedulerdata.push(schedule);
        } catch (exception) {
            $that.Log.LogDetails(this.Log.logType.Error, "AddSchedulerToCallFlow", exception.message, false);
            return [];
        }
    },

    //#region IW Tab

    /**
     * Get Tab deails. user can pass the Tab Id to get specific tab details
     * @param {} id : Auto generated tAb Id
     * @returns {} Tab array
     */
    GetTabs: function (id, tabname) {
        try {
            var apputils = new AppUtilities();
            var data = "";
            var tabs = ApplicationPomConfiguration.jsonDataObj.Tabs;

            if (id === "" && tabname === "") {
                data = tabs;
            } else if (id !== "" && tabname === "") {
                data = Enumerable.From(tabs).
                    Where("$.Id.toLowerCase() == " + apputils.AddSingleQuote(id.toLowerCase())).ToArray();
            } else if (id === "" && tabname !== "") {
                data = Enumerable.From(tabs).
                    Where("$.TabName.toLowerCase() == " + apputils.AddSingleQuote(tabname.toLowerCase())).ToArray();
            } else if (id === "" && tabname !== "") {
                data = Enumerable.From(tabs).
                    Where("$.Id.toLowerCase() == " + apputils.AddSingleQuote(id.toLowerCase()) +
                        " && $.TabName.toLowerCase() == " + apputils.AddSingleQuote(tabname.toLowerCase())).ToArray();
            }


            return data;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetTabs", exception.message, false);
            return [];
        }
    },

    /**
     * Add Tab details to Call flow
     * @param {} tab : An array of tab details
     * @returns {} true/false
     */
    AddTabToCallFow: function (tab) {

        try {

            var $that = this;
            var tabdata = $that.GetTabs("", "");
            tabdata.push(tab);
            return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "AddTabToCallFow", exception.message, false);
            return false;
        }

    },

    //#endregion region IW Tab

    //#region Remote Updates

    /**
     * Get the Remote Update Status
     * 
     * @param {} type 
     * @returns {} 
     */
    GetRemoteUpdateData: function (type) {
        try {
            var apputils = new AppUtilities();
            var data = "";
            var remoteupdates = ApplicationPomConfiguration.jsonDataObj.RemoteStatus;

            if (remoteupdates === undefined) {
                ApplicationPomConfiguration.jsonDataObj.RemoteStatus = [];
            }

            remoteupdates = ApplicationPomConfiguration.jsonDataObj.RemoteStatus;

            if (type === "") {
                data = remoteupdates;
            } else
                data = Enumerable.From(remoteupdates).
                    Where("$.Type.toLowerCase() == " + apputils.AddSingleQuote(type.toLowerCase())).ToArray();

            return data;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetRemoteUpdateData", exception.message, false);
            return [];
        }

    },


    /**
     * Add data ti Remote update
     * @param {} remoteupdate  :    Remote update data
     * @returns {} :true/false
     */
    AddRemoteUpdateToCallFlow: function (remoteupdate) {
        try {
            var $that = this;
            var remoteUpdatedata = $that.GetRemoteUpdateData("");
            if (remoteUpdatedata.length >= 0) {
                remoteUpdatedata.push(remoteupdate);
            } else {
                remoteUpdatedata[0].Id = remoteupdate.Id;
                remoteUpdatedata[0].InsertDateTime = remoteupdate.InsertDateTime;
                remoteUpdatedata[0].UpdateDateTime = remoteupdate.UpdateDateTime;
                remoteUpdatedata[0].UserType = remoteupdate.UserType;
                remoteUpdatedata[0].Type = remoteupdate.Type;
                remoteUpdatedata[0].Server = remoteupdate.Server;
                remoteUpdatedata[0].Comments = remoteupdate.Comments;
                remoteUpdatedata[0].OtherData = remoteupdate.OtherData;
            }
            return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "AddRemoteUpdateToCallFlow", exception.message, false);
            return false;
        }

    },

    /**
     * Remove Remote callflow notifications when sync is proper
     * @param {} type : edit/update/delete/approve
     * @returns {} 
     */
    RemoveRemoteUpdateToCallFlow: function (type, link) {
        try {

            var $that = this;
            var remoteupdates = ApplicationPomConfiguration.jsonDataObj.RemoteStatus;
            var len = remoteupdates.length;
            for (var i = len - 1; i >= 0; i--) {
                if (link !== "") {
                    if (remoteupdates[i].Type.toLowerCase() === type.toLowerCase() && remoteupdates[i].Server.toLowerCase() === link.toLowerCase()) {
                        remoteupdates.splice(i, 1);
                        return true;
                    }

                } else {
                    if (remoteupdates[i].Type.toLowerCase() === type.toLowerCase()) {
                        remoteupdates.splice(i, 1);
                    }
                }
            }

            return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "RemoveRemoteUpdateToCallFlow", exception.message, false);
            return false;
        }

    },
    //#endregion Remote Updates


    //#region Assignment

    /**
     * Get Assignment Data
     * @returns {} Assignment data
     */
    GetAssignmentData: function (id) {
        try {

            var data = GetData(id)[0];
            return data.AssignmentData;
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetAssignmentData", exception.message, false);
            return [];
        }
    },
    /**
     * Delete Callflow Sync Notifications
     * @param {} id  ID [optional] , if id is given, means delete specific notification
     * @returns {} none
     */
    DeleteCallflowSyncNotifications: function (id) {
        var deletestatus = false;
        try {
            if (id === "") {
                window.ApplicationPomConfiguration.jsonDataObj.RemoteStatus = [];      //  Clear all flow sync notifications
                window.ApplicationPomConfiguration.FailedSyncNotifications.IntentMaster = [];
                window.ApplicationPomConfiguration.FailedSyncNotifications.RuleMaster = [];
                window.ApplicationPomConfiguration.FailedSyncNotifications.GlobalConfigurations = [];
                window.ApplicationPomConfiguration.FailedSyncNotifications.GlobalPhrases = [];

                //  Update the JSON of master sync notifications
                var dp = new DataParser();
                dp.UpdateMasterSyncNotifications();
                deletestatus = true;
            } else {
                var notifications = window.ApplicationPomConfiguration.jsonDataObj.RemoteStatus;
                for (var i = 0; i < notifications.length; i++) {
                    if (notifications[i].Id === id) {
                        notifications.splice(i, 1);
                        deletestatus = true;
                        break;
                    }
                }
            }
            // update the callflow contents
            if (ApplicationPomConfiguration.FileInfo.Currentstatus === "SAVED") {
                var dnis = window.ApplicationPomConfiguration.currentdnis;
                var apputils = new AppUtilities();
                apputils.UpdateCallFlow(dnis);

                // Lets sync the callflow
                if (window.ApplicationPomConfiguration.EnableWebSync) {
                    var websync = new WebSyncElement();
                    websync.WebSyncMarkAsUpdate(dnis, dnis, jsondata);
                }
            }
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "DataParser : DeleteCallflowSyncNotifications", exception.message, false);

        }
        return deletestatus;
    },

    //#endregion Assignment

    //  #region Master Sync Notifications

    /*
        Load Master Sync Notifications.

    */
    LoadMasterSyncNotifications: function () {
        try {
            var $that = this;
            //var $that = this;
            $.ajax({
                url: window.ApplicationPath + "Application/GetMasterSyncNotifications",
                type: 'POST',
                async: true,
                dataType: 'json',
                success: function (result) {
                    // update the Global object to current object
                    window.ApplicationPomConfiguration.FailedSyncNotifications = $.parseJSON(result);

                    //  Show Sync notifications
                    new AppEvent().LoadSyncNotifications();
                }
            });
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "LoadModules", exception.message, false);
        }
    },

    /*
        Update Master Sync Notifications JSON.
    */
    UpdateMasterSyncNotifications: function () {
        try {
            var $that = this;
            var data = new FormData();
            data.append('jsondata', JSON.stringify(window.ApplicationPomConfiguration.FailedSyncNotifications));

            //  Update the JSON with the sync fail notifications
            $.ajax({
                type: "POST",
                url: window.ApplicationPath + "Application/UpdateMasterSyncNotifications",
                data: data,
                dataType: 'json',
                contentType: false,
                processData: false,
                async: true,
                success: function (response) {
                    if (response === "0") {
                        $that.Log.LogDetails($that.Log.logType.Success, "UpdateMasterSyncNotifications", "Master Sync Notifications updated successfully.", false);

                        // Lets sync the callflow
                        if (window.ApplicationPomConfiguration.EnableWebSync) {
                            var websync = new WebSyncElement();
                            websync.WebSyncMasterDataUpdate("failedSyncnotifications");
                        }
                    }
                    else
                        $that.Log.LogDetails($that.Log.logType.Error, "UpdateMasterSyncNotifications", "Master Sync Notifications update failed.", false);

                    //  Show Sync notifications
                    new AppEvent().LoadSyncNotifications();


                }
            });
        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "UpdateMasterSyncNotifications", exception.message, false);
        }
    }
    //  #endregion Master Sync Notifications
};