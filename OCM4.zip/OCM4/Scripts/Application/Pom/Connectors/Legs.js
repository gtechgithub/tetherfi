﻿/* -----------------------------------------------------------------------------------------------------------------
 * <copyright file=InteractionWorkflow\Legs.js  company="Tetherfi Pte. Ltd.">
 *      Tetherfi™ 
 * </copyright>
 * <author>Prakash D'souza</author>
 * <CreatedOn> 12/7/2017  12:34 AM</CreatedOn>
 * <LastModified>7/8/2017  1:21 PM</LastModified>
 * <summary>
 *      Class for to handle all the Legs related to Menu/Agent/Modulle/Conditional Node
 *  </summary>         
 * ---------------------------------------------------------------------------------------------------------------*/

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {} 
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "Legs.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Prakash",
        Description: "Version Changed."
    });
});


/*
    Define all the generic methods here...
*/
var Legs = function () {
    this.Log = new Logger();
}

Legs.prototype = {

    /**
     * Get All the legs based on Id and Type Provided
     * @param {} id  : Unique Identity
     * @param {} type  :menu/module/conditionalrule
     * @returns {} Legs
     */
    GetLegs: function (id, type) {

        var legs = [];
        try {
            var dataparser = new DataParser();

            var data = dataparser.GetData(id, type);
            $.each(data, function (key, value) {
                var leg = { Id: "", Type: "", Legs: [] };
                leg.Type = "";
                leg.Id = value.Id;
                leg.Legs.push(value.Legs);
                legs.push(leg);
            }); 

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetLegs", exception.message, false);

        }
        return legs;
    },

    /**
     * Format the Given Leg Deep array to proper array
     * @param {} legs  : An array of Legs
     * @returns {} : An array of Legs
     */
    GetFormattedLeg: function (legs) {

        var formattedLegs = [];
        try {

            $.each(legs, function (key, value) {
                //$.each(value, function (key1, legObj) {
                $.each(value.Legs, function (key2, leg) {
                    //;
                    var currentlegs = [];
                    for (var i = 0; i < leg.length; i++) {
                        currentlegs.push(leg[i]);

                    }
                    var tpleg = { Id: "", Type: "", TabId: "", Legs: [] };
                    tpleg.Type = value.Type;
                    tpleg.Id = value.Id;
                    tpleg.TabId = value.TabId;
                    tpleg.Legs = currentlegs;
                    formattedLegs.push(tpleg);

                });

                //});

            });

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetFormattedLeg", exception.message, false);

        }
        return formattedLegs;
    },

    /**
     * Get all the call Flow Legs
     * basically legs are only available for either Menu/Module/ConditionalRule
     * @returns {} 
     */
    GetCallFlowLegs: function () {


        var formattedLegs = [];
        try {
            var $that = this;
            var legs = [];

            legs.push($that.GetLegs("", ""));


            $.each(legs, function (key, value) {
                $.each(value, function (key1, legObj) {
                    $.each(legObj.Legs, function (key2, leg) {

                        if (leg !== undefined) {
                            var currentlegs = [];
                            for (var i = 0; i < leg.length; i++) {
                                //currentlegs.push(leg[i]);
                                // Since we are showing nxtid has Actual connected, so ignoring here
                                currentlegs.push(leg[i]);

                            }
                            var tpleg = { Id: "", Type: "", TabId: "", Legs: [] };
                            tpleg.Type = legObj.Type;
                            tpleg.Id = legObj.Id;
                            tpleg.TabId = "";
                            tpleg.Legs = currentlegs;
                            formattedLegs.push(tpleg);
                        }
                    });

                });

            });


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetCallFlowLegs", exception.message, false);

        }
        return formattedLegs;
    },

    /**
     * Get the Legs for Specific Source
     * @param {} source : source id
     * @returns {}  Legs/Childrens
     */
    GetChildrens: function (source) {
        // 
        var formattedLegs = [];
        try {
            var dataparser = new DataParser();
            var $that = this;


            var sourcedata = dataparser.GetData(source, "")[0];

            var legs = [];
            legs.push($that.GetLegs(source, ""));
            $.each(legs, function (key, value) {
                $.each(value, function (key1, legObj) {
                    $.each(legObj.Legs, function (key2, leg) {
                        var currentlegs = [];
                        for (var i = 0; i < leg.length; i++) {
                            currentlegs.push(leg[i]);
                        }
                        var tpleg = { Id: "", Type: "", TabId: "", Legs: [] };
                        tpleg.Type = legObj.Type;
                        tpleg.Id = legObj.Id;
                        tpleg.TabId = legObj.TabId;
                        tpleg.Legs = currentlegs;
                        formattedLegs.push(tpleg);
                    });

                });

            });


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetChildren", exception.message, false);

        }
        return formattedLegs;
    },


    /**
     * Get all the Leg connections. This method will return Source and destination in the form of array
     * @returns {} An connection array
     */
    LegConnections: function () {
        ;
        var connections = [];
        try {

            var $that = this;
            var legs = $that.GetCallFlowLegs();


            $.each(legs, function (key, value) {
                $.each(value.Legs, function (key, leg) {
                    var connector = {
                        source: value.Id,
                        destination: leg.NextNodeId
                    };
                    connections.push(connector);
                });

            });


        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "GetCallFlowLegs", exception.message, false);
        }
        return connections;
    },

    /*
    Current leg phrases
*/
    CurrentLegPhrase: function (menuoptionId) {
        try {
            // blobs
            var phraseblobs = window.ApplicationCurrentPhraseList.MenuPhrase;
            // create a  clone of existing menuoptions. this doen't include blob
            var clonedArray = window.ApplicationCurrentPhraseList.MenuPhrase.slice(0); //JSON.parse(JSON.stringify(window.ApplicationCurrentPhraseList.MenuPhrase));
            window.ApplicationCurrentPhraseList.MenuPhrase = clonedArray;


            var currentphrases = window.ApplicationCurrentPhraseList.MenuPhrase;

            var data = [];
            // lets take only to this menu option
            $.each(currentphrases, function (key, value) {
                var p = phraseblobs[key];
                if (menuoptionId === "") {
                    $.each(value.Phrases, function (key1, value1) {
                        value1.Blob = p.Phrases[key1].Blob;
                        data.push(value1);
                    });
                } else {
                    if (value.NextNodeId === menuoptionId) {
                        $.each(value.Phrases, function (key2, value2) {
                            value2.Blob = p.Phrases[key2].Blob;
                            data.push(value2);
                        });
                    }
                }
            });
            return data;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "CurrentLegPhrase", exception.message, false);
            return [];
        }
    },

    /*
        Current leg phrases
    */
    CurrentLegPhraseAdd: function (menuoptionId, phrase) {
        try {
            var currentphrases = window.ApplicationCurrentPhraseList.MenuPhrase;


            // lets take only to this menu option
            $.each(currentphrases, function (key, value) {
                if (value.NextNodeId === menuoptionId) {
                    value.Phrases.push(phrase);
                }
            });
            return true;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "CurrentLegPhraseAdd", exception.message, false);
            return false;
        }
    },

    /*
    Remove Current leg phrases
    */
    CurrentLegPhraseRemove: function (menuoptionId, file) {
        try {
            ;
            //var $that = this;
            //var currentphrases = $that.widgetCurrentLegPhrase(menuoptionId);
            //for (var i = 0; i < currentphrases.length; i++) {
            //    if (currentphrases[i].NextNodeId === file) {
            //        currentphrases.splice(i, 1);
            //        return true;
            //    }
            //}

            //var rtncollection = jQuery.grep(window.ApplicationCurrentPhraseList.MenuPhrase, function (value) {
            //    if (currentphrases[i].Id === menuoptionId) {
            //    return value.Id.toLowerCase() !== itemToRemove.toLowerCase();
            //});

            var currentphrases = window.ApplicationCurrentPhraseList.MenuPhrase;
            for (var i = 0; i < currentphrases.length; i++) {
                if (currentphrases[i].NextNodeId === menuoptionId) {
                    for (var j = 0; j < currentphrases[i].Phrases.length; j++) {
                        //if (currentphrases[i].Phrases[j].NextNodeId === file) {
                        if (currentphrases[i].Phrases[j].Id === file) {
                            currentphrases[i].Phrases.splice(j, 1);
                            return true;
                        }
                    }
                }
            }


            return false;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "CurrentLegPhraseRemove", exception.message, false);
            return false;
        }
    },

    /*
        Update the Legs
    */
    CurrentLegOptionUpdate: function (datatoupdate, editlist) {
        try {
            // 2018-07-19 : Check shuffling is enabled
            if (window.ApplicationConfigurationSettings.EnableOptionShuffling) {
                var clonedArray = jQuery.extend(true, [], datatoupdate);

                // Lets Check any nodes are missing in newly added/Edited list(Especially during PNC). then add if its missing and then shuffle 
                for (var j = 0; j < clonedArray.length; j++) {
                    var isExits = false;
                    for (var i = 0; i < editlist.length; i++) {
                        if (clonedArray[j].NextNodeId === editlist[i].NextNodeId) {
                            isExits = true;
                            break;
                        }
                    }
                    if (!isExits) {
                        editlist.push(clonedArray[j]);
                    }
                }

 
                for (var j = 0; j < datatoupdate.length; j++) {
                    datatoupdate[j].NextNodeId = editlist[j].NextNodeId;
                    datatoupdate[j].Option = editlist[j].Option;
                    datatoupdate[j].Tag = editlist[j].Tag;
                    datatoupdate[j].TextSynonyms = editlist[j].TextSynonyms;
                    datatoupdate[j].Enabled = editlist[j].Enabled;
                    

                    for (var i = 0; i < clonedArray.length; i++) {
                        if (clonedArray[i].NextNodeId === editlist[j].NextNodeId) {
                            datatoupdate[j].Rules = clonedArray[i].Rules;
                            datatoupdate[j].Phrases = clonedArray[i].Phrases;
                            datatoupdate[j].Name = clonedArray[i].Name;
                            break;
                        }
                    }
                }
            } else {

                for (var i = 0; i < editlist.length; i++) {
                    for (var j = 0; j < datatoupdate.length; j++) {
                        if (datatoupdate[j].NextNodeId === editlist[i].NextNodeId) {
                            datatoupdate[j].Option = editlist[i].Option;
                            datatoupdate[j].Tag = editlist[i].Tag;
                            datatoupdate[j].TextSynonyms = editlist[i].TextSynonyms;
                            datatoupdate[j].Enabled = editlist[i].Enabled;
                            break;
                        }
                    }
                }
            }

            return false;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "CurrentLegPhraseRemove", exception.message, false);
            return false;
        }
    },

    /*
        Update the Rules inside Leg
    */
    CurrentRuleLegOptionUpdate: function (datatoupdate, ruleobj) {
        try {
            ;
            for (var i = 0; i < ruleobj.length; i++) {
                for (var j = 0; j < datatoupdate.length; j++) {
                    if (ruleobj[i].MenuOptionId === datatoupdate[j].NextNodeId) {
                        if (datatoupdate[j].Rules === undefined) {
                            // lets create a new rule object
                            datatoupdate[j].Rules = "";


                        }
                        // lets push the rules to the Leg
                        // Lets update the exisitn data
                        datatoupdate[j].Rules = ruleobj[i];
                        break;
                    }
                }
            }


            return false;

        } catch (exception) {
            this.Log.LogDetails(this.Log.logType.Error, "CurrentLegPhraseRemove", exception.message, false);
            return false;
        }
    }
}