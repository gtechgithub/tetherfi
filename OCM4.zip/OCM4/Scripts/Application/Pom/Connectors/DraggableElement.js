﻿/* -----------------------------------------------------------------------------------------------------------------
* <copyright file=InteractionWorkflow\AnnouncementElement.js  company="Tetherfi Pte. Ltd.">
*      Tetherfi™ 
* </copyright>
* <author>Prakash D'souza</author>
* <CreatedOn> 29/8/2017  11:07 AM</CreatedOn>
* <LastModified>29/8/2017  7:03 PM</LastModified>
* <summary>
*      Clas object for Anouncement
*  </summary>         
* ---------------------------------------------------------------------------------------------------------------*/

$(document).ready(function () {
    /**
 * Define the Version
 * @returns {} 
 */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "DraggableElement.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Ashwath",
        Description: "Version Changed."
    });

    var draggableElement = new DraggableElement();
    // lets load the Pom Components
    draggableElement.LoadPomComponents();

});


/**
 * Define the Class object.
 * @returns {} 
 */
var DraggableElement = function () {

    // Define the Logger
    this.Log = new Logger();

    this.properties = {
        Id: "",
        Text: "",
        Type: "",
        Position: "",
        "Legs": [
            {
                "NextNodeId": "",
                "Text": ""
            }
        ],
        Connection: {
            ParentNode: "",
            DestinationNode: "",
            NextNodeId: ""
        }
    };
};




/**
 * Inherit the class Object
 */
DraggableElement.prototype = {

    LoadPomComponents: function () {
        var $that = this;
        try {
            $.ajax({
                type: "GET",
                url: window.ApplicationPath + 'CampaignLinking/GetCampaignList',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    $.each(data, function (index, element) {
                        var utils = new AppUtilities();
                        var id = utils.generateUUID();
                        $('.right-menu-slide').append('<a id=' + utils.AddSingleQuote(id) + '> <i class="material-icons">line_weight</i> ' + element.CampaignName + '</a>');
                        $that.createDroppablNodeElements(id, element.CampaignName);
                    });
                }
            });
        } catch (exception) {
            $that.Log.LogDetails($that.Log.logType.Error, "LoadPomComponents", exception.message, false);
            return false;
        }
    },

/*
    Draggable nodes.
*/
    createDroppablNodeElements: function (id, text) {
    var $that = this;


    try {
        var searchResultsRows = $("#" + id);

        searchResultsRows.draggable({ appendTo: "body" });
        searchResultsRows.draggable({
            create: function (event, ui) { }
        });

        searchResultsRows.css("cursor", "move").draggable("option", "helper", "clone").draggable({
            revert: "true",
            appendTo: 'body',
            cursor: "move",
            snap: "true",
            cursorAt: {
                top: 10,
                left: -5
            },
            helper: function (event) {

                var htmldata =
                    '<div class="cfwidget-node md-card md-card-hover md-card-overlay md-card md-bg-blue-grey-50" id="btnAnnouncementNode">      ' +
                    '   <div class="md-card-content uk-text-center">                                                                      ' +
                    '       <div class="md-card-overlay-wrap">                                                                            ' +
                    '           <div class="md-card-widget-icon">                                                                         ' +
                    '               <i class="material-icons md-24" style="color:red;">highlight_off</i>                                                               ' +
                    '           </div>                                                                                                    ' +
                    '           <div class="md-card-widget-label">                                                                        ' +
                    '               <label class="uk-text-center node-label">' + text + ' </label>                                        ' +
                    '           </div>                                                                                                    ' +
                    '                                                                                                                     ' +
                    '       </div>' +
                    '   </div>' +
                    '</div>';


                var dialog =
                    $('<div id="DragableWidget" style="z-index: 100;" class="draggedValue ui-widget-header ui-corner-all"></div>').appendTo('body');
                dialog.html(htmldata);

                return dialog;
            },
            start: function (event, ui) {
                //fade the grid
                $(this).parent().fadeTo('fast', 0.5);

            },
            stop: function (event, ui) {
                $(this).parent().fadeTo(0, 1);
                $that.DroppablNodeElements(event, text);
            }
        });

    } catch (exception) {
        this.Log.LogDetails(this.Log.logType.Error, "createDroppablNodeElements", exception.message, false);
    }

},

/*
    Drop the Node DOM element and create the node.
*/

DroppablNodeElements: function (event, text) {
    var $that = this;
    try {
        var utils = new AppUtilities();
        var dataparser = new DataParser();
        // get/Set the Div Positon to drop
        var position = utils.GetCursorPosition(event);
        var pos = position.Left + ":" + position.Top;
        //var pos = event.pageX + ":" + event.pageY; //utils.GetElementPositin("DragableWidget");
        $that.properties.Position = pos;
        $that.properties.Text = text;
        var data = dataparser.GenerateDataNode($that.properties);

        // Generate the Node and add to json colelction
        var flow = new Flowdiagram();
        flow.AddNewNode(data, true);

        // initialse the audit trail obj.
        // var audittrial = new AuditTrial();
        // update audit trial
        //// audittrial.AddToAudiTrialList("Create", "Announcement", "", JSON.stringify(data), "node");


    } catch (exception) {
        this.Log.LogDetails(this.Log.logType.Error, "DroppablNodeElements", exception.message, false);
    }
}
   
}
