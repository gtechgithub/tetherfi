/* -----------------------------------------------------------------------------------------------------------------
 * <copyright file=Tree\Initiliser.js  company="Tetherfi Pte. Ltd.">
 *      Tetherfi� Technologies
 * </copyright>
 * <author>Prakash D'souza</author>
 * <CreatedOn> 12/7/2017  12:34 AM</CreatedOn>
 * <LastModified>4/8/2017  10:18 PM</LastModified>
 * <summary>
 *      JSPlumb Initialiser object class, 
 *  </summary>         
 * ---------------------------------------------------------------------------------------------------------------*/

$(document).ready(function () {
    /**
* Define the Version
* @returns {} 
*/
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "Initiliser.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "14-01-2019 08:30:00 AM",
        LastModifiedBy: "Prakash",
        Description: "Intitiser of jsplumb and other custom properties."
    });
});


/**
 * Define the class Object
 * @returns {} 
 */
var jsPlumbSettings = function () {
    // call the below method during object construction
    this.init();
    this.batch();
};


/*
    in-herit, add more features
*/
jsPlumbSettings.prototype = {
    /*
    Define all local settings/ variables here

    */
    basicType: {
        connector: "StateMachine",
        paintStyle: { stroke: "red", strokeWidth: 2 },
        hoverPaintStyle: { stroke: "gray" },
        overlays: [
            "Arrow"
        ]
    },

    /*
        Initialise the the jsplumb onbject instance
    */
    init: function () {
        window.GraphconfigSettings.instance = jsPlumb.getInstance({
            // notice the 'curviness' argument to this Bezier curve.  the curves on this page are far smoother
            // than the curves on the first demo, which use the default curviness value.
            //Connector: ["Bezier", { curviness: 50 }],
            //DragOptions: { cursor: "pointer", zIndex: 2000 },
            //PaintStyle: { stroke: window.GraphconfigSettings.color, strokeWidth: 2 },
            //EndpointStyle: { radius: 9, fill: window.GraphconfigSettings.color },
            //HoverPaintStyle: { stroke: "#ec9f2e" },
            //EndpointHoverStyle: { fill: "#ec9f2e" },
            //Container: "canvas"

            //Endpoint: ["Dot", { radius: 2 }],
            //Connector: "StateMachine",
            //HoverPaintStyle: { stroke: "#1e8151", strokeWidth: 2 },
            ConnectionOverlays: [
                "Arrow",
                ["Label",
                    {
                        label: '', id: "dtmflabel",

                    }]
            ],
            Container: "canvas"
        });
    },

    batch: function () {
        // Define the Logger
        var log = new Logger();
        window.GraphconfigSettings.instance.registerConnectionType("basic", this.basicType);

        // suspend drawing and initialise.
        window.GraphconfigSettings.instance.batch(function () {

            var connectionbasedColor = "#ccc"; //"rgba(229,219,61,0.5)";
            window.GraphconfigSettings.endpointOptions = {
                paintStyle: { fill: connectionbasedColor, opacity: 0.2 },
                isSource: true,
                isTarget: true,
                endpoint: ["Dot", { radius: 10 }],
                //cssClass: "md-card uk-animation-slide-top",
                style: { fill: 'blue' },
                maxConnections: -1,
                connector: "Straight",
                // deleteEndpointsOnDetach:false,
                connectorStyle: { strokeWidth: 1, stroke: '#ccc' },
                //scope: "yellow", //this is really not working here.
                dropOptions: {
                    drop: function (e, ui) {
                        //alert('drop!');
                    }
                },
                overlays: [
                    [
                        "Label", {
                            location: [0.5, 1.5],
                            label: "Drag",
                            cssClass: "md-card uk-animation-slide-top",
                            visible: false
                        }
                    ]
                ]
            };

            /*
                    Define all the jsplumb events here. currently implemented below events
                    1. Connection moved
                    2.before drop
                    3.click
                
                */

            // When conenction moved from one node to another
            window.GraphconfigSettings.instance.bind("connectionMoved", function (params) {
                //alert("connection " + params.connection.id + " was moved");
            });

            // when connection Establish
            window.GraphconfigSettings.instance.bind("connection", function (info) {
            });

            // On mouse over.
            window.GraphconfigSettings.instance.bind("mouseover", function (connection) {
            });


            // Before drop the connection to destination
            // this event will trigger when source is droped to destination.
            window.GraphconfigSettings.instance.bind("beforeDrop", function (connection) {
               
                var dataparser = new DataParser();
                var flow = new Flowdiagram();

                // source connection
                var source = dataparser.GetData(connection.sourceId, "")[0];

                // destination/Target connection
                var target = dataparser.GetData(connection.targetId, "")[0];

                // is a valid connection 
                var validateconnectionStatus = flow.isValidConnection(connection.sourceId, connection.targetId, source, target);
                if (validateconnectionStatus !== "") {
                    log.LogDetails(log.logType.Error, "Connection", "Connection Failed. " + validateconnectionStatus, true);
                    return false;
                }
                var status = dataparser.SetConntection(connection.sourceId, connection.targetId);
                if (!status) {
                    log.LogDetails(log.logType.Error, "Connection", "Failed to establish connection between nodes", true);
                    // will cancel the connection
                    return false;
                }

                // initialse the audit trail obj.
                var audittrial = new AuditTrial();
                // update audit trial
                audittrial.AddToAudiTrialList("AddConnection", source.Type + "->" + target.Type, JSON.stringify(source), JSON.stringify(target), "node");

                // if its a menu will set the default dtmf to 0
                if (source.Type === "menu") {

                    // lets get the recently created a DTMF here
                    var nxtdtmf = "";
                    var legs = source.MenuElement.Legs;
                    for (var i = 0; i < legs.length; i++) {
                        if (legs[i].NextNodeId === connection.targetId) nxtdtmf = legs[i].Option;
                    }

                    // get the nxt available DTMF key for the menu connection
                    //var nxtdtmf = dataparser.GetNextDTMF(connection.sourceId);


                    // set the id for the label
                    var dtmflabelid = connection.sourceId + '_' + connection.targetId;
                    var label = '<a class="md-fab md-fab-danger md-fab-small-dtmf"><span id="' + dtmflabelid + '_dtmf">' + nxtdtmf + '</a>';
                    connection.connection._jsPlumb.overlays.dtmflabel.setLabel(label);
                }
                return connection.sourceId !== connection.targetId;
            });


            /**
             * On doublic of the Connection
             */
            window.GraphconfigSettings.instance.bind('dblclick', function (connection, e) {
                

                // 09/01/2017 : disabled below code to avoid double click loads old DTMF
                //connection.toggleType("basic");

                var conn = window.GraphconfigSettings.instance.getConnections({
                    //only one of source and target is needed, better if both setted
                    source: connection.sourceId,
                    target: connection.targetId
                });

                // define the classes
                var flow = new Flowdiagram();
                var dataparser = new DataParser();

                // source connection
                var source = dataparser.GetData(conn[0].sourceId, "")[0];

                // destination connection
                var target = dataparser.GetData(conn[0].targetId, "")[0];

                swal("Do you want to delete connections between '" + source.Text + "' and  '" + target.Text + "' ?", {
                    icon: "warning",
                    buttons: {
                        cancel: "Cancel",
                        catch: {
                            text: "Yes",
                            value: "yes",
                        }
                    }
                }).then(function (value) {
                    switch (value) {
                        case "yes":
                            {
                                if (!dataparser.BreakConnection(source, target)) {
                                    log.LogDetails(log.logType.Error, "BreakConnection", "Failed to break the connection between '" +
                                        source.Name + "' and  '" + target.Name + "'", true);
                                } else {
                                    // update the target parent
                                    target.Connection.ParentNode = "";
                                    window.GraphconfigSettings.instance.deleteConnection(conn[0]);

                                    // update the target parent
                                    target.Connection.ParentNode = "";
                                    //  clear the next node id of source
                                    source.Connection.NextNodeId = "";

                                    // Will break all the legs inside announcement
                                    for (i = 0; i < source.Legs.length; i++) {
                                        // delete specif Tarrget leg.
                                        if (source.Legs[i].NextNodeId === target.Id) {
                                            source.Legs[i].NextNodeId = "";
                                        }
                                    }
                                }
                            }
                            break;
                    }
                });

              
            });
        });
        jsPlumb.fire("interactionWokflowLoaded", window.GraphconfigSettings.instance);
    }
};

jsPlumb.ready(function () {

});