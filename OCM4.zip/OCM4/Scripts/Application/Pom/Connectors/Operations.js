﻿
$(document).ready(function () {
    $('.slide-toggle-wrap').on('click', function () {      
        $(this).toggleClass('active');
        $('.right-rswitch').toggleClass('show-sidebar');
        $('.right-menu-slide').animate({ width: 'toggle' }, 200);
    });

    /**
* Define the Version
* @returns {} 
*/
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "Operation.js",
        Version: "3.2.1.14",
        LastModifiedDateTime: "21-01-2019 08:30:00 AM",
        LastModifiedBy: "Ashwath",
        Description: "New Commit, has logic to interact with backend operations."
    });
});



/*
    Define the class object
*/
var Operations = function () {
    // Define the Logger
    this.Log = new Logger();
};


Operations.prototype = {

    /*
        Save the connection points.
    */
    SavePomComponents: function () {
        var flowDiagram = new Flowdiagram();

        let $that = this;
        try {

            flowDiagram.UpdateNodePosition();
      
            var dataparser = new DataParser();
            var finalResult = [];
            var data = window.ApplicationPomConfiguration.jsonDataObj;
            for (let i = 0; i < data.length; i++) {
                let nextNodeId = data[i].Legs[0].NextNodeId;
                let child = null;
                if (nextNodeId !== "") {
                    // child = data[i].Legs[0].Text;
                    for (var j = 0; j < data.length; j++) {
                        if (nextNodeId === data[j].Id) {
                            child = data[j].Text;
                        }
                    }
                }

                if (child !== null) {
                    finalResult.push({
                        "NextLinkedName": child,
                        "CampaignName": data[i].Text
                    });
                }
            }


            //var $that = this;
            var jsondata = {
                'JsonObject': JSON.stringify(finalResult)
            };

            $.ajax({
                type: "POST",
                data: JSON.stringify(jsondata),
                url: window.ApplicationPath + 'CampaignLinking/SaveCampaignLinks',
                contentType: 'application/json',
                dataType: "json",
                success: function (data) {
                    swal("Campaign connector flow saved successfully.");
                    $that.SavePomConnectionToFile();
                },
                error: function () {
                    console.log('Failed to save');
                }
            });



        } catch (exception) {
            $that.Log.LogDetails($that.Log.logType.Error, "SavePomComponents", exception.message, false);
            return false;
        }


    },

    /*
        Save the connection points.
    */
    SavePomConnectionToFile: function () {
        var $that = this;
        var jsondata = {
            'jsontosave': JSON.stringify(window.ApplicationPomConfiguration.jsonDataObj)
        };
        try {
            $.ajax({
                type: "POST",
                data: JSON.stringify(jsondata),
                url: window.ApplicationPath + 'CampaignLinking/WriteCampaignLinkToFile',
                contentType: 'application/json',
                dataType: "json",
                success: function (data) {
                },
                error: function () {
                    console.log('Failed to save to file');
                }
            });
        } catch (exception) {
            $that.Log.LogDetails($that.Log.logType.Error, "SavePomConnectionToFile", exception.message, false);
            return false;
        }
    }
};


/**
 *
 */
function callsave() {

    let $that = this;
    swal("Do you want to save this flow?", {
        icon: "warning",
        buttons: {
            cancel: "Cancel",
            catch: {
                text: "Yes",
                value: "yes",
            }
        }
    }).then(function (value) {
        switch (value) {
            case "yes":
                {
                    let obj = new Operations();
                    obj.SavePomComponents();
                }
                break;
        }
    });
}

function RevertCallflow() {

    swal("Do you want to undo/revert you callflow changes?", {
        icon: "warning",
        buttons: {
            cancel: "Cancel",
            catch: {
                text: "Yes",
                value: "yes",
            }
        }
    }).then(function (value) {
        switch (value) {
            case "yes":
                {
                    let obj = new Flowdiagram();
                    obj.Preview();
                }
                break;
        }
    });
}