﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "EmailRealTime.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
//Get Skill Names for BCMS
function getEmailRealtimeDashboardParam() {
    if ($("#emailbcmsSkills").val() != null) {
        return {
            skillvalues: $("#emailbcmsSkills").val(),
            tabValue: $("#selectedtabvalue").val(),
            __RequestVerificationToken: $("#AntiForgeryToken").val()
        }
    }
    else {
        return {
            skillvalues: '',
            tabValue: $("#selectedtabvalue").val(),
            __RequestVerificationToken: $("#AntiForgeryToken").val()
        }
    }
}

function getBcmsEmailParam() {
    return { tabValue: $("#selectedtabvalue").val() }
}

function onEmailRealTimeGridRequestEnd() {
    bcmsEmailRealTimeGridLock = false;
    setTimeout(function () {
        getEmailRealTimeGridData();
    }, realtimeoutTime)
}


setTimeout(function () {
    getEmailRealTimeGridData();
}, Number($("#realTimedashboardtimeouttime").val()))

function getEmailRealTimeGridData() {
    //var emaildnisvalue = $("#mailboxes").data("kendoMultiSelect").value();
    if (bcmsEmailRealTimeGridLock == false && $("#selectedtabvalue").val() == "emailrealtimequeue" && dashboardMasterLock == false) {
        //if (emaildnisvalue.length != 0) {
        bcmsEmailRealTimeGridLock = true;
        console.log("Calling BCMS Email Real Time Grid Datasource Read!");
        $("#emailRealTimeGrid").data("kendoGrid").dataSource.read();
        //}
    }
}


//Get all Dashboard data for BCMS
function getbcmsEmailDashboardData() {
    if ($("#selectedtabvalue").val() == "emailrealtimequeue" && bcmsEmailRealTimeLock == false && dashboardMasterLock == false) {
        // var obj = { "tabValue": "emailRealTime" };
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        bcmsEmailRealTimeLock = true;
        console.log("Calling BCMS Email Real Time Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetBcmsDashboardData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "tabValue": "emailrealtimequeue", "skillvalues": $("#emailbcmsSkills").val() },
            async: false,
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null) {
                        $("#bcmsEmailStaff").html(returneddata[0].Staff);
                        $("#bcmsEmailAvail").html(returneddata[0].Avail);
                        $("#bcmsEmailCiq").html(returneddata[0].CallsWaiting);
                        $("#bcmsEmailQWaitTime").html(returneddata[0].OldestCall);
                    }
                } catch (e) {
                    console.log(e);
                }
                bcmsEmailRealTimeLock = false;
                if ($("#selectedtabvalue").val() == "emailrealtimequeue" && bcmsEmailRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getbcmsEmailDashboardData();
                    }, realtimeoutTime)
                }
            },
            error: function () {
                console.log('Failed to load BCMS Dashboard data');
                bcmsEmailRealTimeLock = false;
                if ($("#selectedtabvalue").val() == "emailrealtimequeue" && bcmsEmailRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getbcmsEmailDashboardData();
                    }, realtimeoutTime)
                }
            }
        });
    }
}