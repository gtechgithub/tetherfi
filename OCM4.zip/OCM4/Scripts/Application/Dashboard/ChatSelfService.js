﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "ChatSelfService.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
function getChatselfserviceChartData() {
    if (chatselfserviceChartLock == false && chatselfservDashboardGenericChecks() && dashboardMasterLock == false) {
        chatselfserviceChartLock = true;
        console.log("Calling Chat Self-Service Dashboard Chart Datasource Read!");
        $("#chatselfserviceChart").data("kendoChart").dataSource.read();
    }
}

//Ajax call to get chatselfservice Dashboard data and append to div
function getChatselfserviceDashboardData() {
    if (chatselfservDashboardGenericChecks() && chatselfserviceLock == false && dashboardMasterLock == false) {
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        chatselfserviceLock = true;
        console.log("Calling Chat Self-Service Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetIvrDashData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: getDashboardParam(),
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null && chatselfservDashboardGenericChecks() && chatselfserviceLock == true && dashboardMasterLock == false) {
                        if (returneddata[0].TotalCalls != "") {
                            $("#totalchatselfservice").html(returneddata[0].TotalCalls);
                            animatingCounter("#totalchatselfservice");
                        }
                        else { $("#totalchatselfservice").html(0); }

                        if (returneddata[0].SelfServiceCalls != "") {
                            $("#selfservicedchat").html(returneddata[0].SelfServiceCalls);
                            animatingCounter("#selfservicedchat");
                        }
                        else { $("#selfservicedchat").html(0); }

                        if (returneddata[0].TransferredCalls != "") {
                            $("#transferredchatself").html(returneddata[0].TransferredCalls);
                            animatingCounter("#transferredchatself");
                        }
                        else { $("#transferredchatself").html(0); }

                        if (returneddata[0].AverageHandleTime != "") {
                            $("#chatselfserviceAHT").html(returneddata[0].AverageHandleTime);
                            $("#voiceAHTSec").css('display', 'inline-block');
                            animatingCounter("#chatselfserviceAHT");
                        }
                        else {
                            $("#chatselfserviceAHT").html(0);
                            $("#voiceAHTSec").css('display', 'none');
                        }

                        //if (returneddata[0].CallsinQueue != "") {
                        //    $("#ciq").html(returneddata[0].CallsinQueue);
                        //    animatingCounter("#ciq");
                        //}
                        //else { $("#ciq").html(0); }

                        if (returneddata[0].TotalTimeSpent != "") {
                            $("#chatselfservicetotalTimeSpent").html(returneddata[0].TotalTimeSpent);
                            $("#voiceTotalTimeSpentSec").css('display', 'inline-block');
                            animatingCounter("#chatselfservicetotalTimeSpent");
                         }
                        else {
                            $("#chatselfservicetotalTimeSpent").html(0);
                            $("#voiceTotalTimeSpentSec").css('display', 'inline-block');
                        }

                        if (returneddata[0].TotalCallbacks != "") {
                            $("#totalchatselfserviceCallbacks").html(returneddata[0].TotalCallbacks);
                            animatingCounter("#totalchatselfserviceCallbacks");
                        }
                        else { $("#totalchatselfserviceCallbacks").html(0); }

                        gauge1 = $("#chatselfservicemaxTimeSpentGauge").data("kendoRadialGauge").value(returneddata[0].MaxTimeSpent);
                        gauge2 = $("#chatselfserviceaverageTimeSpentGauge").data("kendoRadialGauge").value(returneddata[0].AverageTimeSpent);
                        if (returneddata[0].AverageTimeSpent != "") {
                            $("#chatselfserviceAvgTimeSpent").html(": " + returneddata[0].AverageTimeSpent + "(s)");
                        }
                        else { $("#chatselfserviceAvgTimeSpent").html(""); }
                        if (returneddata[0].MaxTimeSpent != "") {
                            $("#chatselfserviceMaxTimeSpent").html(": " + returneddata[0].MaxTimeSpent + "(s)");
                        }
                        else { $("#chatselfserviceMaxTimeSpent").html(""); }
                    }
                } catch (e) {
                    console.log(e);
                }

                //Setting lock as false since ajax request is complete
                chatselfserviceLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'chatselfservice'                  
                if (chatselfservDashboardGenericChecks() && chatselfserviceLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatselfserviceDashboardData();
                    }, timeoutTime);
                }
            },
            error: function () {
                console.log('Failed to load chatselfservice dashboard data');
                //Setting lock as false since ajax request is complete
                chatselfserviceLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'chatselfservice'                  
                if (chatselfservDashboardGenericChecks() && chatselfserviceLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatselfserviceDashboardData();
                    }, timeoutTime);
                }
            }
        });
    }
}

//Set the chart lock as false once the data request is complete
function onchatselfserviceChartRequestEnd() {
    kendo.ui.progress($("#chatselfserviceChart"), false);
    chatselfserviceChartLock = false;
    if (chatselfservDashboardGenericChecks() && chatselfserviceChartLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getChatselfserviceChartData();
        }, timeoutTime);
    }
}

function chatselfservDashboardGenericChecks() {
    var chatselfservicednisvalue = $("#chatselfservicednis").data("kendoMultiSelect").value();
    if ($("#selectedtabvalue").val() == "chatselfservice" && chatselfservicednisvalue.length != 0) {
        return 1;
    }
    else
        return 0;
}

