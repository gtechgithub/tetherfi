﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Sms.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
function getSmsChartData() {
    if (smsChartLock == false && smsDashboardGenericChecks() && dashboardMasterLock == false) {
        smsChartLock = true;
        console.log("Calling SMS Dashboard Chart Datasource Read!");
        $("#smsSummaryChart").data("kendoChart").dataSource.read();
    }
}

//Ajax call to get SMS Dashboard data and append to div
function getSmsDashboardData() {
    if (smsDashboardGenericChecks() && smsLock == false && dashboardMasterLock == false) {
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        smsLock == true;
        console.log("Calling SMS Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetSmsDashData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: getDashboardParam(),
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null && smsDashboardGenericChecks()) {
                        if (returneddata[0].SmsInQueue != "") {
                            $("#smsinQ").html(returneddata[0].SmsInQueue);
                            animatingCounter("#smsinQ");
                        }
                        else { $("#smsinQ").html(0) }

                        if (returneddata[0].SmsTransferred != "") {
                            $("#smsTransferred").html(returneddata[0].SmsTransferred);
                            animatingCounter("#smsTransferred");
                        }
                        else { $("#smsTransferred").html(0); }

                        if (returneddata[0].SmsConferenced != "") {
                            $("#smsConferenced").html(returneddata[0].SmsConferenced);
                            animatingCounter("#smsConferenced");
                        }
                        else { $("#smsConferenced").html(0); }

                        if (returneddata[0].SmsCount != "") {
                            $("#smsCount").html(returneddata[0].SmsCount);
                            animatingCounter("#smsCount");
                        }
                        else { $("#smsCount").html(0); }

                        if (returneddata[0].AverageHandleTime != "") {
                            $("#smsAHT").html(returneddata[0].AverageHandleTime);
                            $("#smsAHTSec").css('display', 'inline-block');
                            animatingCounter("#smsAHT");
                        }
                        else {
                            $("#smsAHT").html(0);
                            $("#smsSec").css('display', 'none');
                        }

                        if (returneddata[0].FirstCallResolution != "") {
                            if (returneddata[0].FirstCallResolution < 50) {
                                $("#smsFCR").html(returneddata[0].FirstCallResolution);
                                animatingCounter("#smsFCR")
                                $("#smspercent").css('display', 'inline-block');
                                $("#smsarrowdown").css('display', 'inline-block');
                                $("#smsarrowup").css('display', 'none');
                                $("#smsSetColor").attr('class', 'text-danger');
                            }
                            else if (returneddata[0].FirstCallResolution > 50) {
                                $("#smsFCR").html(returneddata[0].FirstCallResolution);
                                animatingCounter("#smsFCR")
                                $("#smspercent").css('display', 'inline-block');
                                $("#smsarrowdown").css('display', 'none');
                                $("#smsarrowup").css('display', 'inline-block');
                                $("#smsSetColor").attr('class', 'text-navy');
                            }
                        }
                        else {
                            $("#smspercent").css('display', 'none');
                            $("#smsFCR").html(0);
                            $("#smsarrowdown").css('display', 'none');
                            $("#smsarrowup").css('display', 'none');
                        }
                        gauge1 = $("#smsgauge1").data("kendoRadialGauge").value(returneddata[0].MaxHandleTime);
                        gauge2 = $("#smsgauge2").data("kendoRadialGauge").value(10);
                        $("#smsAvgTimeToReply").html(": " + "10" + "(s)");
                        if (returneddata[0].AverageTimeSpent != "") {
                            $("#smsAvgTimeToReply").html(": " + "10" + "(s)");
                        }
                        else { $("#smsAvgTimeToReply").html(""); }
                        if (returneddata[0].MaxTimeSpent != "") {
                            $("#smsMaxTimeToReply").html(": " + returneddata[0].MaxHandleTime + "(s)");
                        }
                        else { $("#smsMaxTimeToReply").html(""); }
                        //gauge1.redraw();
                        //gauge2.redraw();
                    }
                } catch (e) {
                    console.log(e);
                }

                //Setting lock as false since ajax request is complete
                smsLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'ivr'                  
                if (smsDashboardGenericChecks() && smsLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getSmsDashboardData();
                    }, timeoutTime)
                }
            },
            error: function () {
                console.log('Failed to load SMS dashboard data');
                //Setting lock as false since ajax request is complete
                smsLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'ivr'                  
                if (smsDashboardGenericChecks() && smsLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getSmsDashboardData();
                    }, timeoutTime)
                }
            }
        });
    }
}

//Set the chart lock as false once the data request is complete
function onSmsChartRequestEnd() {
    kendo.ui.progress($("#smsSummaryChart"), false);
    smsChartLock = false;
    if (smsDashboardGenericChecks() && smsChartLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getSmsChartData();
        }, timeoutTime)
    }
}

function smsDashboardGenericChecks() {
    var smsdnisvalue = $("#smsdnis").data("kendoMultiSelect").value();
    if (smsdnisvalue.length != 0 && $("#selectedtabvalue").val() == "sms") {
        return 1;
    }
    else
        return 0;
}