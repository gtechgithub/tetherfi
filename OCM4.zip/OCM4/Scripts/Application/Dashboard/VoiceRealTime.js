﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "VoiceRealTime.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
//Get Skill Names for BCMS
function getbcmsDashboardParam() {
    if ($("#bcmsSkills").val() != null) {
        return {
            skillvalues: $("#bcmsSkills").val(),
            tabValue: $("#selectedtabvalue").val(),
           __RequestVerificationToken: $("#AntiForgeryToken").val()
        }
    }
    else {
        return {
            skillvalues: '',
            tabValue: $("#selectedtabvalue").val(),
            __RequestVerificationToken: $("#AntiForgeryToken").val()
        }
    }
}

setTimeout(function () {
    getBcmsRealTimeGridData();
}, Number($("#realTimedashboardtimeouttime").val()))

function getBcmsRealTimeGridData() {
    //var emaildnisvalue = $("#mailboxes").data("kendoMultiSelect").value();
    if (bcmsRealTimeGridLock == false && $("#selectedtabvalue").val() == "bcmsrealtimequeue" && dashboardMasterLock == false) {
        //if (emaildnisvalue.length != 0) {
        bcmsRealTimeGridLock = true;
        console.log("Calling BCMS Voice Real Time Grid Datasource Read!");
        $("#bcmsgrid").data("kendoGrid").dataSource.read();
        //}
    }
}

//Get all Dashboard data for BCMS
function getbcmsDashboardData() {
    if ($("#selectedtabvalue").val() == "bcmsrealtimequeue" && bcmsRealTimeLock == false && dashboardMasterLock == false) {
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        bcmsRealTimeLock = true;
        console.log("Calling BCMS Voice Real Time Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetBcmsDashboardData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "tabValue": "bcmsrealtimequeue", "skillvalues": $("#bcmsSkills").val() },
            async: false,
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null) {
                        $("#bcmsStaff").html(returneddata[0].Staff);
                        $("#bcmsAvail").html(returneddata[0].Avail);
                        $("#bcmsciq").html(returneddata[0].CallsWaiting);
                        $("#bcmsInteractions").html(returneddata[0].ACD);
                        $("#bcmsacdInteractionsummary").html(returneddata[0].AcdCallsSummary);
                        $("#bcmsabandonedInteractions").html(returneddata[0].AbandCalls);
                        $("#bcmsactiveivrcalls").html(returneddata[0].IvrCalls);
                    }
                } catch (e) {
                    console.log(e);
                }
                bcmsRealTimeLock = false;
                if ($("#selectedtabvalue").val() == "bcmsrealtimequeue" && bcmsRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getbcmsDashboardData();
                    }, realtimeoutTime)
                }
            },
            error: function () {
                console.log('Failed to load BCMS Dashboard data');
                bcmsRealTimeLock = false;
                if ($("#selectedtabvalue").val() == "bcmsrealtimequeue" && bcmsRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getbcmsDashboardData();
                    }, realtimeoutTime)
                }
            }
        });
    }
}

function onBcmsRealTimeGridRequestEnd() {
    bcmsRealTimeGridLock = false;
    setTimeout(function () {
        getBcmsRealTimeGridData();
    }, realtimeoutTime)
}

function ColumnTrafficColor(value) {
    if (value != "") {
        value = parseInt(value);
        var columnTrafficColor = $("#columnTrafficColor").val().toLowerCase().split(',');
        var minRange = 0;
        var maxRange = 0;
        var color = "";
        var i;
        for (i = 0; i < columnTrafficColor.length; i++) {
            color = columnTrafficColor[i].split(':')[0].trim();
            maxRange = parseInt(columnTrafficColor[i].split(':')[1]);
            if ((value > minRange && value <= maxRange) || (value == 0)) {
                return "<div style='background-color:" + color + "'>" + value + "</div>";
            }
            minRange = parseInt(columnTrafficColor[i].split(':')[1]);
        }
        return value;
    }
    else {
        return value;
    }
}

$(document).ready(function () {
    var color = $("#voiceRealTimeDashboardColor").val().toLowerCase().split(',');
    var i;
    for (i = 0; i < color.length; i++) {
        $("#bcmsDashboardCount-"+i+"").addClass("bg-"+color[i].trim()+"");
    }
});

