﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "ChatRealTime.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------

//Get Skill Names for TReadTime
function getChatRealtimeDashboardParam() {
    if ($("#chatbcmsSkills").val() != null) {
        return {
            skillvalues: $("#chatbcmsSkills").val(),
            tabValue: $("#selectedtabvalue").val(),
            __RequestVerificationToken: $("#AntiForgeryToken").val()
        }
    }
    else {
        return {
            skillvalues: '',
            tabValue: $("#selectedtabvalue").val(),
            __RequestVerificationToken: $("#AntiForgeryToken").val()
        }
    }
}

function getBcmsChatParam(){
    return { tabValue: $("#selectedtabvalue").val() }
}

function onChatRealTimeGridRequestEnd() {
    bcmsChatRealTimeGridLock = false;
    setTimeout(function () {
        getChatRealTimeGridData();
    }, realtimeoutTime)
}


setTimeout(function () {
    getChatRealTimeGridData();
}, Number($("#realTimedashboardtimeouttime").val()))

function getChatRealTimeGridData() {
    //var emaildnisvalue = $("#mailboxes").data("kendoMultiSelect").value();
    if (bcmsChatRealTimeGridLock == false && $("#selectedtabvalue").val() == "chatrealtimequeue" && dashboardMasterLock == false) {
        //if (emaildnisvalue.length != 0) {
        bcmsChatRealTimeGridLock = true;
        console.log("Calling BCMS Chat Real Time Grid Datasource Read!");
        $("#chatRealTimeGrid").data("kendoGrid").dataSource.read();
        //}
    }
}


//Get all Dashboard data for BCMS
function getbcmsChatDashboardData() {
    if ($("#selectedtabvalue").val() == "chatrealtimequeue" && bcmsChatRealTimeLock == false && dashboardMasterLock == false) {
       // var obj = { "tabValue": "chatrealtimequeue" };
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        bcmsChatRealTimeLock = true;
        console.log("Calling BCMS Chat Real Time Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetBcmsDashboardData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "tabValue": "chatrealtimequeue", "skillvalues": $("#chatbcmsSkills").val() },
            async: false,
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null) {
                        $("#bcmsChatStaff").html(returneddata[0].Staff);
                        $("#bcmsChatAvail").html(returneddata[0].Avail);
                        $("#bcmsChatCiq").html(returneddata[0].CallsWaiting);
                        $("#bcmsChatInteractions").html(returneddata[0].ACD);
                        $("#bcmsChatAcdInteractionsummary").html(returneddata[0].AcdCallsSummary);
                        $("#bcmsChatAbandonedInteractions").html(returneddata[0].AbandCalls);
                    }
                } catch (e) {
                    console.log(e);
                }
                bcmsChatRealTimeLock = false;
                if ($("#selectedtabvalue").val() == "chatrealtimequeue" && bcmsChatRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getbcmsChatDashboardData();
                    }, realtimeoutTime)
                }
            },
            error: function () {
                console.log('Failed to load BCMS Dashboard data');
                bcmsChatRealTimeLock = false;
                if ($("#selectedtabvalue").val() == "chatrealtimequeue" && bcmsChatRealTimeLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getbcmsChatDashboardData();
                    }, realtimeoutTime)
                }
            }
        });
    }
}