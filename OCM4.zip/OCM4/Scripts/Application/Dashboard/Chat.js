﻿var chatDashboardArray = [];
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Dashboard\\",
        FileName: "Chat.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "08-09-2018 08:30:00 AM",
        LastModifiedBy: "Adhip",
        Description: "Dynamic Dashboard Data"
    });

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'Generic/GetJSONDashboardViewConfig',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify({ pagename: "ChatDashboard" }),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (returneddata) {
            console.log(returneddata);
            for (i = 0; i < 8; i++) {
                if (returneddata.Boxes[i].Visible == true) {
                    chatDashboardArray.push(returneddata.Boxes[i].PropertyName);
                    var t = $("#chatDivs").html(); //template divs
                    (i < 6) ? e = $("#chatData") : e = $("#chatData2"); //to be appended before/after/to
                    n = Handlebars.compile(t); //initialize handlebars for the template divs
                    context = {
                        propertyName: returneddata.Boxes[i].PropertyName,
                        defaultValue: returneddata.Boxes[i].Default,
                        Title: returneddata.Boxes[i].Title,
                        color: returneddata.Boxes[i].Color,
                        ionIcon: (returneddata.Boxes[i].Icon != "" && returneddata.Boxes[i].Icon != undefined && returneddata.Boxes[i].Icon != null) ? returneddata.Boxes[i].Icon : "",
                    }; //add context data
                    s = n(context); //execute the template with handlebar and context
                    e.append(s);
                    var allSubDataNotVisible = true; //Variable used to check if all subboxes are visible or not
                    if (returneddata.Boxes[i].SubBox.length > 0) {
                        for (j = 0; j < returneddata.Boxes[i].SubBox.length; j++) {
                            if (returneddata.Boxes[i].SubBox[j].Visible == true) {
                                chatDashboardArray.push(returneddata.Boxes[i].SubBox[j].PropertyName);
                                allSubDataNotVisible = false; //Some box is visible so we set to false
                                t = $("#subChatDivs").html(), //template divs
                                    e = $("#subCategory_" + returneddata.Boxes[i].PropertyName), //to be appended before/after/to
                                    n = Handlebars.compile(t), //initialize handlebars for the template divs
                                    context = {
                                        subPropertyId: returneddata.Boxes[i].SubBox[j].PropertyName,
                                        subPropertyDefaultValue: returneddata.Boxes[i].SubBox[j].Default,
                                        subPropertyName: returneddata.Boxes[i].SubBox[j].Title,
                                    }, //add context data
                                    s = n(context); //execute the template with handlebar and context
                                e.append(s);
                            }
                        }
                        if (allSubDataNotVisible == true) {
                            //If there is no subdata (visible) to be shown inside then we move the icon and delete the html
                            $("#subCategory_" + returneddata.Boxes[i].PropertyName).remove();
                            $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('left', 'unset');
                            $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('right', '10%');
                        }
                    }
                    else {
                        //If there is no subdata to be shown inside then we move the icon and delete the html
                        $("#subCategory_" + returneddata.Boxes[i].PropertyName).remove();
                        $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('left', 'unset');
                        $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('right', '10%');
                    }
                }
            }
            if ($("#chatData2").html().trim().length == 0) {
                //If there is no div to show under the bar chart increase the height of the bar chart
                $("#chatSummaryChart").css("height", "400px");
            }
        },
        error: function () {
            console.log('Failed to load Chat dashboard data');
        }
    });
});

function getChatChartData() {
    if (chatChartLock == false && $("#selectedtabvalue").val() == "chat" && dashboardMasterLock == false) {
        var chatdnisvalue = $("#skill").data("kendoMultiSelect");
        if (chatdnisvalue.value() == "" || chatdnisvalue.value() == null) {
            $("#chatdnisvalue").val("");
        }
        chatChartLock = true;
        console.log("Calling Chat Dashboard Chart Datasource Read!");
        var chatSelc = $("#ChatSelection").val();
        var grid = $("#chatSummaryChart").data("kendoChart");
        if ($("#chatdnisvalue").val() == "") {
            $("#ChatTitle").text('Top 10 Trending')
        }
        else {
            $("#ChatTitle").text('Top Trending')
        }
        if (chatSelc == '1') {
            grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatIntentChart"
            grid.dataSource.transport.type = "POST"
            grid.dataSource.read(getDashboardParam())
        }
        else {
            //$("#ChatTitle").text('Employees of chatSelc A ')
            grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatSkillChart"
            grid.dataSource.transport.type = "POST"
            grid.dataSource.read(getDashboardParam())
        }
    }
}

function getChatDashboardData() {
    //Checking if tab selected is chat
    if ($("#selectedtabvalue").val() == "chat" && chatLock == false && dashboardMasterLock == false) {
        //checking if chat ajax call is already made/not
        //Set Chatlock as true and make the ajax call

        var chatdnisvalue = $("#skill").data("kendoMultiSelect");
        if (chatdnisvalue.value() == "" || chatdnisvalue.value() == null) {
            $("#chatdnisvalue").val("");
        }
        chatLock == true;
        console.log("Calling Chat Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetChatDashData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: getDashboardParam(),
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null && $("#selectedtabvalue").val() == "chat" && dashboardMasterLock == false) {
                        for (i = 0; i < chatDashboardArray.length; i++) {
                            console.log(chatDashboardArray[i]);
                            $("#" + chatDashboardArray[i]).html(returneddata[0][chatDashboardArray[i]]);
                            if (chatDashboardArray[i].toLowerCase().indexOf("time") == -1) {
                                animatingCounter("#" + chatDashboardArray[i]);
                            }
                        }
                        //if (returneddata[0].isTransfered != "") {
                        //    $("#transferedChats").html(returneddata[0].isTransfered);
                        //    animatingCounter("#transferedChats");
                        //}
                        //else { $("#transferedChats").html(0); }

                        //if (returneddata[0].isConferenced != "") {
                        //    $("#chatsConferenced").html(returneddata[0].isConferenced);
                        //    animatingCounter("#chatsConferenced");
                        //}
                        //else { $("#chatsConferenced").html(0); }

                        //if (returneddata[0].ChatCount != "") {
                        //    $("#chatCount").html(returneddata[0].ChatCount);
                        //    animatingCounter("#chatCount");
                        //}
                        //else { $("#chatCount").html(0); }

                        //if (returneddata[0].AverageHandleTime != "") {
                        //    $("#chatAHT").html(returneddata[0].AverageHandleTime);
                        //    $("#chatAHTSec").css('display', 'inline-block');
                        //    animatingCounter("#chatAHT");
                        //}
                        //else {
                        //    $("#chatAHT").html(0);
                        //    $("#sec1").css('display', 'none');
                        //}

                        //if (returneddata[0].FirstCallResolution != "") {
                        //    if (returneddata[0].FirstCallResolution < 50) {
                        //        $("#chatFCR").html(returneddata[0].FirstCallResolution);
                        //        animatingCounter("#chatFCR");
                        //        $("#percent").css('display', 'inline-block');
                        //        $("#arrowdown").css('display', 'inline-block');
                        //        $("#arrowup").css('display', 'none');
                        //        $("#setColor").attr('class', 'text-danger');
                        //        $("#chatFcrStyle").addClass('bg-red');
                        //        $("#chatFcrStyle").removeClass('bg-green');
                        //    }
                        //    else if (returneddata[0].FirstCallResolution > 50) {
                        //        $("#chatFCR").html(returneddata[0].FirstCallResolution);
                        //        animatingCounter("#chatFCR");
                        //        $("#percent").css('display', 'inline-block');
                        //        $("#arrowdown").css('display', 'none');
                        //        $("#arrowup").css('display', 'inline-block');
                        //        $("#setColor").attr('class', 'text-navy');
                        //        $("#chatFcrStyle").removeClass('bg-red');
                        //        $("#chatFcrStyle").addClass('bg-green');
                        //    }
                        //}
                        //else {
                        //    $("#percent").css('display', 'none');
                        //    $("#chatFCR").html(0);
                        //    $("#arrowdown").css('display', 'none');
                        //    $("#arrowup").css('display', 'none');
                        //}
                        //if (returneddata[0].ChatCallback != "") {
                        //    $("#chatCallback").html(returneddata[0].ChatCallback);
                        //    animatingCounter("#chatCallback");
                        //}
                        //else { $("#chatCallback").html(0); }
                    }
                } catch (e) {
                    console.log(e);
                }

                //Setting lock as false so that the next ajax call can be made
                chatLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'chat'
                if ($("#selectedtabvalue").val() == "chat" && chatLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatDashboardData();
                    }, timeoutTime);
                }
            },
            error: function () {
                console.log('Failed to load Chat dashboard data');
                //Setting lock as false so that the next ajax call can be made
                chatLock = false;
                // Enable set Interval on error of the current ajax request if the selected tab is 'chat'
                if ($("#selectedtabvalue").val() == "chat" && chatLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatDashboardData();
                    }, timeoutTime);
                }
            }
        });
    }
}

//Set the chart lock as false once the data request is complete
function onChatChartRequestEnd() {
    chatChartLock = false;
    if ($("#selectedtabvalue").val() == "chat" && chatChartLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getChatChartData();
        }, timeoutTime);
    }
}

function onChatSelectionChange() {
    var chatSelc = $("#ChatSelection").val();
    var grid = $("#chatSummaryChart").data("kendoChart");

    if ($("#chatdnisvalue").val() == "") {
        $("#ChatTitle").text('Top 10 Trending')
    }
    else {
        $("#ChatTitle").text('Top Trending')
    }
    if (chatSelc == '1') {
        // $("#ChatTitle").text('Employees of chatSelc B ')
        grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatIntentChart"
        grid.dataSource.transport.type = "POST"
        grid.dataSource.read(getDashboardParam())
    }
    else {
        //$("#ChatTitle").text('Employees of chatSelc A ')
        grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatSkillChart"
        grid.dataSource.transport.type = "POST"
        grid.dataSource.read(getDashboardParam())
    }
}