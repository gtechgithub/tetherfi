﻿var chatbotDashboardArray = [];
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Dashboard\\",
        FileName: "Chatbot.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "31-01-2019 10:54:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Created"
    });
    $.ajax({
        
        type: "POST",
        url: window.ApplicationPath + 'Generic/GetJSONDashboardViewConfig',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify({ pagename: "ChatbotDashboard" }),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (returneddata) {
            console.log(returneddata);
            for (i = 0; i < 8; i++) {
                if (returneddata.Boxes[i].Visible == true) {
                    chatbotDashboardArray.push(returneddata.Boxes[i].PropertyName);
                    var t = $("#chatbotDivs").html(); //template divs
                    (i < 6) ? e = $("#chatbotData") : e = $("#chatbotData2"); //to be appended before/after/to
                    n = Handlebars.compile(t); //initialize handlebars for the template divs
                    context = {
                        propertyName: returneddata.Boxes[i].PropertyName,
                        defaultValue: returneddata.Boxes[i].Default,
                        Title: returneddata.Boxes[i].Title,
                        color: returneddata.Boxes[i].Color,
                        ionIcon: (returneddata.Boxes[i].Icon != "" && returneddata.Boxes[i].Icon != undefined && returneddata.Boxes[i].Icon != null) ? returneddata.Boxes[i].Icon : "",
                    }; //add context data
                    s = n(context); //execute the template with handlebar and context
                    e.append(s);
                    var allSubDataNotVisible = true; //Variable used to check if all subboxes are visible or not
                    if (returneddata.Boxes[i].SubBox.length > 0) {
                        for (j = 0; j < returneddata.Boxes[i].SubBox.length; j++) {
                            if (returneddata.Boxes[i].SubBox[j].Visible == true) {
                                chatbotDashboardArray.push(returneddata.Boxes[i].SubBox[j].PropertyName);
                                allSubDataNotVisible = false; //Some box is visible so we set to false
                                t = $("#subChatbotDivs").html(), //template divs
                                    e = $("#subCategory_" + returneddata.Boxes[i].PropertyName), //to be appended before/after/to
                                    n = Handlebars.compile(t), //initialize handlebars for the template divs
                                    context = {
                                        subPropertyId: returneddata.Boxes[i].SubBox[j].PropertyName,
                                        subPropertyDefaultValue: returneddata.Boxes[i].SubBox[j].Default,
                                        subPropertyName: returneddata.Boxes[i].SubBox[j].Title,
                                    }, //add context data
                                    s = n(context); //execute the template with handlebar and context
                                e.append(s);
                            }
                        }
                        if (allSubDataNotVisible == true) {
                            //If there is no subdata (visible) to be shown inside then we move the icon and delete the html
                            $("#subCategory_" + returneddata.Boxes[i].PropertyName).remove();
                            $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('left', 'unset');
                            $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('right', '10%');
                        }
                    }
                    else {
                        //If there is no subdata to be shown inside then we move the icon and delete the html
                        $("#subCategory_" + returneddata.Boxes[i].PropertyName).remove();
                        $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('left', 'unset');
                        $("#" + returneddata.Boxes[i].PropertyName + "-icon").css('right', '10%');
                    }
                }
            }
            if ($("#chatbotData2").html().trim().length == 0) {
                //If there is no div to show under the bar chart increase the height of the bar chart
                $("#chatbotSummaryChart").css("height", "400px");
            }
        },
        error: function () {
            console.log('Failed to load Chatbot dashboard data');
        }
    });
});

function getChatbotChartData() {
    if (chatbotChartLock == false && $("#selectedtabvalue").val() == "chatbot" && dashboardMasterLock == false) {
        var chatbotdnisvalue = $("#chatbotskill").data("kendoMultiSelect");
        if (chatbotdnisvalue.value() == "" || chatbotdnisvalue.value() == null) {
            $("#chatbotdnisvalue").val("");
        }
        chatbotChartLock = true;
        console.log("Calling Chatbot Dashboard Chart Datasource Read!");
        var chatbotSelc = $("#ChatbotSelection").val();
        var grid = $("#chatbotSummaryChart").data("kendoChart");
        if ($("#chatbotdnisvalue").val() == "") {
            $("#ChatbotTitle").text('Top 10 Trending')
        }
        else {
            $("#ChatbotTitle").text('Top Trending')
        }
        if (chatbotSelc == '1') {
            grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatbotIntentChart"
            grid.dataSource.read(getDashboardParam())
        }
        else {
            grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatbotSkillChart"
            grid.dataSource.read(getDashboardParam())
        }
    }
}

function getChatbotDashboardData() {
    //Checking if tab selected is chatbot
    if ($("#selectedtabvalue").val() == "chatbot" && chatbotLock == false && dashboardMasterLock == false) {
        //checking if chat ajax call is already made/not
        //Set Chatbotlock as true and make the ajax call

        var chatbotdnisvalue = $("#chatbotskill").data("kendoMultiSelect");
        if (chatbotdnisvalue.value() == "" || chatbotdnisvalue.value() == null) {
            $("#chatbotdnisvalue").val("");
        }
        chatbotLock == true;
        console.log("Calling Chatbot Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetChatbotDashData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: getDashboardParam(),
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null && $("#selectedtabvalue").val() == "chatbot" && dashboardMasterLock == false) {
                        for (i = 0; i < chatbotDashboardArray.length; i++) {
                            console.log(chatbotDashboardArray[i]);
                            $("#" + chatbotDashboardArray[i]).html(returneddata[0][chatbotDashboardArray[i]]);
                            if (chatbotDashboardArray[i].toLowerCase().indexOf("time") == -1) {
                                animatingCounter("#" + chatbotDashboardArray[i]);
                            }
                        }
                    }
                } catch (e) {
                    console.log(e);
                }

                //Setting lock as false so that the next ajax call can be made
                chatbotLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'chatbot'
                if ($("#selectedtabvalue").val() == "chatbot" && chatbotLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatbotDashboardData();
                    }, timeoutTime);
                }
            },
            error: function () {
                console.log('Failed to load Chatbot dashboard data');
                //Setting lock as false so that the next ajax call can be made
                chatbotLock = false;
                // Enable set Interval on error of the current ajax request if the selected tab is 'chatbot'
                if ($("#selectedtabvalue").val() == "chatbot" && chatbotLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatbotDashboardData();
                    }, timeoutTime);
                }
            }
        });
    }
}

//Set the chart lock as false once the data request is complete
function onChatbotChartRequestEnd() {
    chatbotChartLock = false;
    if ($("#selectedtabvalue").val() == "chatbot" && chatbotChartLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getChatbotChartData();
        }, timeoutTime);
    }
}

function onChatbotSelectionChange() {
    var chatbotSelc = $("#ChatbotSelection").val();
    var grid = $("#chatbotSummaryChart").data("kendoChart");

    if ($("#chatbotdnisvalue").val() == "") {
        $("#ChatbotTitle").text('Top 10 Trending')
    }
    else {
        $("#ChatbotTitle").text('Top Trending')
    }
    if (chatbotSelc == '1') {
        // $("#ChatTitle").text('Employees of chatSelc B ')
        grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatbotIntentChart"
        grid.dataSource.read(getDashboardParam())
    }
    else {
        //$("#ChatTitle").text('Employees of chatSelc A ')
        grid.dataSource.transport.options.read.url = window.ApplicationPath + "Dashboards/GetChatbotSkillChart"
        grid.dataSource.read(getDashboardParam())
    }
}