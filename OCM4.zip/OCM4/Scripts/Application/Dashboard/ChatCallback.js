﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "ChatCallback.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
function getChatCallbackGridData() {
    if (chatCallbackGridLock == false && $("#selectedtabvalue").val() == "chatcallback" && dashboardMasterLock == false) {
        chatCallbackGridLock = true;
        console.log("Calling Chat Callback Dashboard Grid Datasource Read!");
        $("#ChatCallbackGrid").data("kendoGrid").dataSource.read();
    }
}

function getChatCallbackChartData() {
    if (chatCallbackChartLock == false && $("#selectedtabvalue").val() == "chatcallback" && dashboardMasterLock == false) {
        chatCallbackChartLock = true;
        console.log("Calling Chat Callback Dashboard Chart Datasource Read!");
        $("#chatcallbackSummaryChart").data("kendoChart").dataSource.read();
    }
}

function getChatCallbackDashboardData() {
    if ($("#selectedtabvalue").val() == "chatcallback" && chatCallbackLock == false && dashboardMasterLock == false) {
        //checking if ajax call is already made/not 
        //Set lock as true and make the ajax call
        chatCallbackLock == true;
        console.log("Calling Chat Callback Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetChatCallbackDashboardData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: getDashboardParam(),
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null && $("#selectedtabvalue").val() == "chatcallback" && dashboardMasterLock == false) {
                        for (i = 0; i < returneddata.length; i++) {
                            if (returneddata[i].CallbackStatus == "AHT") {
                                if (returneddata[i].Value != "") {
                                    $("#chatCallbackAHT").html(returneddata[i].Value);
                                    animatingCounter("#chatCallbackAHT");
                                }
                                else {
                                    $("#chatCallbackAHT").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "ASSIGNED") {
                                if (returneddata[i].Value != "") {
                                    $("#chatassignedCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#chatassignedCallbacks");
                                }
                                else {
                                    $("#chatassignedCallbacks").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "CLOSED") {
                                if (returneddata[i].Value != "") {
                                    $("#chatclosedCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#chatclosedCallbacks");
                                }
                                else {
                                    $("#chatclosedCallbacks").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "DIAL") {
                                if (returneddata[i].Value != "") {
                                    $("#chatpendingCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#chatpendingCallbacks");
                                }
                                else {
                                    $("#chatpendingCallbacks").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "SLA") {
                                if (returneddata[i].Value != "") {
                                    $("#chatAvgSlaTime").html(returneddata[i].Value);
                                    animatingCounter("#chatAvgSlaTime");
                                }
                                else {
                                    $("#chatAvgSlaTime").html(0);
                                }
                            }
                            if (returneddata[i].CallbackStatus == "Total Callback") {
                                if (returneddata[i].Value != "") {
                                    $("#totalchatCallbacks").html(returneddata[i].Value);
                                    animatingCounter("#totalchatCallbacks");
                                }
                                else {
                                    $("#totalchatCallbacks").html(0);
                                }
                            }
                        }
                    }
                } catch (e) {
                    console.log(e);
                }
                chatCallbackLock = false;
                if ($("#selectedtabvalue").val() == "chatcallback" && chatCallbackLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatCallbackDashboardData();
                        //chatCallbackDashboardDataReload();
                    }, timeoutTime);
                }
            },
            error: function () {
                console.log('Failed to load Chat Callback dashboard data');
                chatCallbackLock = false;
                if ($("#selectedtabvalue").val() == "chatcallback" && chatCallbackLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getChatCallbackDashboardData();
                        //chatCallbackDashboardDataReload();
                    }, timeoutTime);
                }
            }
        });
    }
}

function onChatCallbackChartRequestEnd() {
    chatCallbackChartLock = false;
    if ($("#selectedtabvalue").val() == "chatcallback" && chatCallbackChartLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getChatCallbackChartData();
        }, timeoutTime);
    }
}

function onChatCallbackGridRequestEnd() {
    chatCallbackGridLock = false;
    if ($("#selectedtabvalue").val() == "chatcallback" && chatCallbackGridLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getChatCallbackGridData();
        }, timeoutTime);
    }
}