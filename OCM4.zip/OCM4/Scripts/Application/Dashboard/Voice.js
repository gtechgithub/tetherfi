﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var filename = "Voice.js";
var file_version = "3.2.8.30";
var changedBy = "Prathik"
//------------------------------------------------------------------------------------
function getIvrChartData() {
    if (ivrChartLock == false && ivrDashboardGenericChecks() && dashboardMasterLock == false) {
        ivrChartLock = true;
        console.log("Calling IVR Dashboard Chart Datasource Read!");
        $("#ivrChart").data("kendoChart").dataSource.read();
    }
}

//Ajax call to get IVR Dashboard data and append to div
function getIvrDashboardData() {
    if (ivrDashboardGenericChecks() && ivrLock == false && dashboardMasterLock == false) {
        //checking if ajax call is already made/not
        //Set lock as true and make the ajax call
        ivrLock = true;
        console.log("Calling IVR Dashboard Data Ajax Call!");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Dashboards/GetIvrDashData',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: getDashboardParam(),
            dataType: "json",
            success: function (returneddata) {
                try {
                    if (returneddata != null && ivrDashboardGenericChecks() && ivrLock == true && dashboardMasterLock == false) {
                        if (returneddata[0].TotalCalls != "") {
                            $("#totalivrcalls").html(returneddata[0].TotalCalls);
                            animatingCounter("#totalivrcalls");
                        }
                        else { $("#totalivrcalls").html(0); }

                        if (returneddata[0].SelfServiceCalls != "") {
                            $("#selfServicedCalls").html(returneddata[0].SelfServiceCalls);
                            animatingCounter("#selfServicedCalls");
                        }
                        else { $("#selfServicedCalls").html(0); }

                        if (returneddata[0].TransferredCalls != "") {
                            $("#transferredCalls").html(returneddata[0].TransferredCalls);
                            animatingCounter("#transferredCalls");
                        }
                        else { $("#transferredCalls").html(0); }

                        if (returneddata[0].AverageHandleTime != "") {
                            $("#ivrAHT").html(returneddata[0].AverageHandleTime);
                            $("#voiceAHTSec").css('display', 'inline-block');
                            animatingCounter("#ivrAHT");
                        }
                        else {
                            $("#ivrAHT").html(0);
                            $("#voiceAHTSec").css('display', 'none');
                        }

                        //if (returneddata[0].CallsinQueue != "") {
                        //    $("#ciq").html(returneddata[0].CallsinQueue);
                        //    animatingCounter("#ciq");
                        //}
                        //else { $("#ciq").html(0); }

                        if (returneddata[0].TotalTimeSpent != "") {
                            $("#totalTimeSpent").html(returneddata[0].TotalTimeSpent);
                            $("#voiceTotalTimeSpentSec").css('display', 'inline-block');
                            animatingCounter("#totalTimeSpent");
                         }
                        else {
                            $("#totalTimeSpent").html(0);
                            $("#voiceTotalTimeSpentSec").css('display', 'inline-block');
                        }

                        if (returneddata[0].TotalCallbacks != "") {
                            $("#totalIvrCallbacks").html(returneddata[0].TotalCallbacks);
                            animatingCounter("#totalIvrCallbacks");
                        }
                        else { $("#totalIvrCallbacks").html(0); }

                        gauge1 = $("#maxTimeSpentGauge").data("kendoRadialGauge").value(returneddata[0].MaxTimeSpent);
                        gauge2 = $("#averageTimeSpentGauge").data("kendoRadialGauge").value(returneddata[0].AverageTimeSpent);
                        if (returneddata[0].AverageTimeSpent != "") {
                            $("#ivrAvgTimeSpent").html(": " + returneddata[0].AverageTimeSpent + "(s)");
                        }
                        else { $("#ivrAvgTimeSpent").html(""); }
                        if (returneddata[0].MaxTimeSpent != "") {
                            $("#ivrMaxTimeSpent").html(": " + returneddata[0].MaxTimeSpent + "(s)");
                        }
                        else { $("#ivrMaxTimeSpent").html(""); }
                    }
                } catch (e) {
                    console.log(e);
                }

                //Setting lock as false since ajax request is complete
                ivrLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'ivr'                  
                if (ivrDashboardGenericChecks() && ivrLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getIvrDashboardData();
                    }, timeoutTime);
                }
            },
            error: function () {
                console.log('Failed to load Ivr dashboard data');
                //Setting lock as false since ajax request is complete
                ivrLock = false;
                // Enable set Interval on success of the current ajax request if the selected tab is 'ivr'                  
                if (ivrDashboardGenericChecks() && ivrLock == false && dashboardMasterLock == false) {
                    setTimeout(function () {
                        getIvrDashboardData();
                    }, timeoutTime);
                }
            }
        });
    }
}

//Set the chart lock as false once the data request is complete
function onIvrChartRequestEnd() {
    kendo.ui.progress($("#ivrChart"), false);
    ivrChartLock = false;
    if (ivrDashboardGenericChecks() && ivrChartLock == false && dashboardMasterLock == false) {
        setTimeout(function () {
            getIvrChartData();
        }, timeoutTime);
    }
}

function ivrDashboardGenericChecks() {
    var ivrdnisvalue = $("#ivrdnis").data("kendoMultiSelect").value();
    if ($("#selectedtabvalue").val() == "ivr" && ivrdnisvalue.length != 0) {
        return 1;
    }
    else
        return 0;
}

