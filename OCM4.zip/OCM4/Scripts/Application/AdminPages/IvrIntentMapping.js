﻿function onIvrIntentMappingEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#intentTalentLists").data("kendoDropDownList").readonly();
        $('#intentTalentList span').addClass('k-state-disabled');
        $("#prod").css('display', 'none');
        $("#seg").css('display', 'none');
        $("#lang").css('display', 'none');
        $("#intentList").css('display', 'none');
        $("#intentTalentLabel").html("Intent Talent");
    }
    if (e.model.isNew() == true) {
        $("#intentTalentList").css('display', 'none');
    }
}

function onIvrIntentMappingSave(e) {
    if (e.model.isNew() == true) {
        if (e.model.Product == "") {
            e.preventDefault();
            toaster("Provide a Product", "error");
            return;
        }
        if (e.model.Segment == "") {
            e.preventDefault();
            toaster("Provide a Segment", "error");
            return;
        }
        if (e.model.Language == "") {
            e.preventDefault();
            toaster("Provide a Language", "error");
            return;
        }
    }
    if (e.model.IntentTalent == "") {
        e.preventDefault();
        toaster("Provide an Intent Talent", "error");
        return;
    }
    if (e.model.isNew() == true) {
        intentMappingDuplicateCheck(e, e.model.Product, e.model.Segment, e.model.Language, e.model.IntentTalent);
    }
    if (e.model.VDN == "" || e.model.VDN == null) {
        e.preventDefault();
        toaster("Enter a VDN", "error");
        return;
    }
    if (e.model.VDN == "0") {
        toaster("Enter a VDN greater than 0", "error");
        e.preventDefault();
        return;
    }
    if (e.model.VDN.toString().length < 4) {
        e.preventDefault();
        toaster("VDN Length is less than 4", "error");
        return;
    }
    modifyValid(e);
}

function onIntentTalentFilter() {
    var value = this.value(),
    grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({});
        $("#vdnFilter").data("kendoDropDownList").value("");
        grid.dataSource.filter({ field: "IntentTalent", operator: "eq", value: value });
    }
    else {
        grid.dataSource.filter({});
    }
}

function onVdnFilter() {
    var value = this.value(),
    grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({});
        $("#intentTalentFilter").data("kendoDropDownList").value("");
        grid.dataSource.filter({ field: "Vdn", operator: "eq", value: value });
    }
    else {
        grid.dataSource.filter({});
    }
}

function onIvrIntentMappingRequestEnd(e) {
    genericRequest(e);
    $("#vdnFilter").data("kendoDropDownList").dataSource.read();
    $("#intentTalentFilter").data("kendoDropDownList").dataSource.read();
}

function intentMappingDuplicateCheck(e, product, segment, language, intentTalent) {
    var intent = "V";
    if (!(product == "" && product != null)) {
        intent += product;
    }
    var segmentSplit = segment.split('-');
    if (segmentSplit.length > 0) {
        intent += segmentSplit[0];
    }
    switch (language) {
        case "Cantonese":
            intent += "C";
            break;
        case "English":
            intent += "E";
            break;
        case "Mandarin":
            intent += "M";
            break;
    }
    intent += intentTalent;
    var currentTeamName = intent;
    var currentID = e.model.uid;
    var count = 0;
    var data = $("#grid").data("kendoGrid").dataSource._data;
    item = data.length;
    for (t in data) {
        if (isNaN(t)) {
            return;
        }
        if (data[t].IntentTalent.toString().toLowerCase() == currentTeamName.toString().toLowerCase()) {
            count++;
            if (count == 2) {
                e.preventDefault();
                toaster("Duplicate Record", "error");
                return;
            }
        }
        if (data[t].IntentTalent.toString().toLowerCase() == currentTeamName.toString().toLowerCase() &&
            data[t].uid != currentID) {
            e.preventDefault();
            toaster("Duplicate Record", "error");
            return;
        }
    }
}