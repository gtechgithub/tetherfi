﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "ReportScheduler.js",
        Version: "3.2.7.20",
        LastModifiedDateTime: "20-07-2019 09:49:00 PM",
        LastModifiedBy: "Shruthi",

    });
});
function onSchedulerEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="ReportName"]').attr("readonly", true);
        $(e.container).find('input[name="ServerID"]').attr("readonly", true);
    }
}

function onReportSchedulerSave(e) {
    e.model.InputStartDateTime = ($('#InputStartDateTime').val());
    e.model.InputEndDateTime = ($('#InputEndDateTime').val());
    e.model.StatusDateTime = kendo.toString(kendo.parseDate(e.model.StatusDateTime), "dd/MM/yyyy HH:mm:ss");
    e.model.LastExecutedDateTime = kendo.toString(kendo.parseDate(e.model.LastExecutedDateTime), "dd/MM/yyyy HH:mm:ss");

    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Status");
    fieldNames.push("Input Start Date");
    fieldNames.push("Input End Date");
    fieldNames.push("Frequency");
    fieldNames.push("WIP Timeout");
    fieldNames.push("Status DateTime");
    fieldNames.push("Last Executed DateTime");

    fieldValues.push(e.model.Status);
    fieldValues.push(e.model.InputStartDateTime);
    fieldValues.push(e.model.InputEndDateTime);
    fieldValues.push(e.model.Frequency);
    fieldValues.push(e.model.WIPTimeout);
    fieldValues.push(e.model.StatusDateTime);
    fieldValues.push(e.model.LastExecutedDateTime);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
   
    if (moment(e.model.InputStartDateTime, "DD/MM/YYYY HH:mm:ss", true).isValid() == false
        || moment(e.model.InputEndDateTime, "DD/MM/YYYY HH:mm:ss", true).isValid() == false
        || moment(e.model.StatusDateTime, "DD/MM/YYYY HH:mm:ss", true).isValid() == false
        || moment(e.model.LastExecutedDateTime, "DD/MM/YYYY HH:mm:ss", true).isValid() == false) {

        e.preventDefault()
        toaster("Date Time is not in proper format (dd/MM/yyyy HH:mm:ss)" , "error");
        return;
    }

    var validateStartDate = moment(e.model.InputStartDateTime, "DD/MM/YYYY HH:mm:ss");
    var validateEndDate = moment(e.model.InputEndDateTime, "DD/MM/YYYY HH:mm:ss");
    if (validateStartDate.isAfter(validateEndDate)) {

        e.preventDefault()
        toaster("Start Date is greater than End Date", "error");
        return;
    }
    modifyValid(e);
}




