﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "AgentSetting.js",
        Version: "3.2.9.1801",
        LastModifiedDateTime: "14-11-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Implemented re-tag supervisor if team or profile changed and supervisor is deleted"
    });
});

var previousAvayaLoginID = "";

var teamIdToBind = ""; //Store the Team ID which is to be bound
var teamNameToBind = ""; //Store the Team Name which is to be bound
var profileToBind = ""; //Store the Profile which is to be bound
var supervisorToBind = ""; //Store the Supervisor ID which is to be bound
var isRecordNew = false; //Used to track if the Record is a newly created record or it is a existing record being edited
var teamIdDataboundCounter = 0; //Used to keep track if all items are bound in the Team ID DropdownTree
var UserName = "";
var TeamID = "";
var Profile = "";
/**
 * This is on edit event of AgentSetting module
 */
function editAgentSetting(e) {
    previousAvayaLoginID = $("#AvayaLoginID").val();
    if (e.model.isNew() == true) {
        //By default we are not setting change event for validating profile so we bind it here
        $("#TeamID").data("kendoDropDownTree").bind("change", onProfilevalidation);
        $("#Profile").data("kendoDropDownList").bind("change", OnAgentSettingProfileChange);

        if ($("#AvayaLoginID").data("kendoNumericTextBox") !== undefined) {
            $("#AvayaLoginID").data("kendoNumericTextBox").bind("spin", onSpin);
        }
       
        //If new record set the isRecordNew to true and binding variables to blank
        isRecordNew = true;
        profileToBind = "";
        supervisorToBind = "";
        teamIdToBind = "";
        teamNameToBind = "";

        //Call read for TeamID and Profile to load their data in the components
        $("#TeamID").data("kendoDropDownTree").dataSource.read();
        $("#Profile").data("kendoDropDownList").dataSource.read();

        var channelmodel = jsonchannlecount;
        SetChannels(channelmodel);
        SetNumericTextBoxVisibility(channelmodel);
        var agentfeaturemodel = jsonagentfeature;
        SetFeature(agentfeaturemodel)

        //this method is in Validation.js
        Profilevalid();
        genericEdit(e);
    }
    else {
        //For edit we use databound events to bind model data to the components which is not required when adding a new record
        $("#TeamID").data("kendoDropDownTree").bind("dataBound", OnUserRoleMappingTeamIdDataBound);
        $("#SupervisorID").data("kendoDropDownList").bind("dataBound", OnUserRoleMappingSupervisorDataBound);
        $("#TeamID").data("kendoDropDownTree").unbind("change");

        Profilevalid();
        genericEdit(e);

        //If existing record set the isRecordNew to false and binding variables to the model value
        isRecordNew = false;
        teamIdToBind = e.model.TeamID;
        teamNameToBind = e.model.TeamName;
        profileToBind = e.model.Profile;
        supervisorToBind = e.model.SupervisorID;

        UserName = e.model.UserName;
        TeamID = e.model.TeamID;
        Profile = e.model.Profile;

        $("#TeamID").val(e.model.TeamID);
        $("#Profile").val(e.model.Profile);
        $("#SupervisorID").val(e.model.SupervisorID);
        $("#SupervisorID").data("kendoDropDownList").value(supervisorToBind);

        $(e.container).find('input[name="UserName"]').attr("readonly", true);
        if ($("#AvayaLoginID").data("kendoNumericTextBox") === undefined) {
            $("#AvayaLoginID").attr("readonly", true);
        }
        else {
            $("#AvayaLoginID").data("kendoNumericTextBox").enable(false);
        }
        SetChannels(e.model.AgentSettingChannelCount)
        SetNumericTextBoxVisibility(e.model.AgentSettingChannelCount);
        SetFeature(e.model.AgentFeature)
    }

    //onSupervisorChange(e);
}

function onSpin() {
    var AvayaLoginID = $("#AvayaLoginID").val();
    var MaxLoginID;
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (field[i].PropertyName == "AvayaLoginID") {
            MaxLoginID = jsonfields.GridColumns[i].Maxlength;
            break;
        }
    }

    if (AvayaLoginID.length > MaxLoginID) {
        var NewLoginID = $("#AvayaLoginID").data("kendoNumericTextBox");
        NewLoginID.value(AvayaLoginID - 1);
        return;
    }
}

function onProfilevalidation(e) {
    console.log("onProfilevalidation");
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/IsBottomMostTeam',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'teamid': $('#TeamID').val()
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                var dropdownlist = $("#Profile").data("kendoDropDownList");
                if (data != false) {
                    dropdownlist.enable(true);
                    // dropdownlist.select(0);
                    dropdownlist.select(2);
                    dropdownlist.enable(false);
                }
                else {
                    dropdownlist.enable(true);
                    dropdownlist.select(0);
                }
                $("#SupervisorID").data("kendoDropDownList").dataSource.read();
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

/**
 * This is on add new record whill create dynamic channels
 */
function getJsonAgentChannels() {
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'AgentSetting/GetJsonAgentChannels',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            dataType: "json",
            async: true,
            contentType: 'application/json',
            success: function (data) {
                return data;
            },
            error: function () {
                return "";
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

/* on changing the dropdown setting value to hidden fields */
function onSupervisorChange(e) {
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/GetTeamTreeWithOrgUnit',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'supervisor': $("#SupervisorID").val()
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data != null) {
                    $("#TeamID").kendoDropDownTree({
                        dataSource: {
                            schema: {
                                model: {
                                    children: "Items"
                                }
                            },
                            data: data
                        },
                        dataTextField: "Text",
                        dataValueField: "Id"
                    });

                    try {
                        if (e.model.TeamName !== "") {
                            $("#TeamID").data("kendoDropDownTree").text(e.model.TeamName);
                        }
                    } catch (e) { }
                }
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function filterSupervisor() {
    return {
        id: $("#UserName").val(),
        profile: $("#Profile").val(),
        teamid: $("#TeamID").val(),
        supervisor: $("#SupervisorID").val(), 
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

/**
 * this id for onsave event
 */
function onSaveAgentSetting(e) {
    var channelmodel = JSON.parse(JSON.stringify(jsonchannlecount));
    e.model.AgentSettingChannelCount = channelmodel;

    for (i = 0; i < channelmodel.length; i++) {
        if ($("#" + channelmodel[i].Channel).val() > 50 || $("#" + channelmodel[i].Channel).val().length > 2) {
            toaster("Tab Count should not exceed 50", "error");
            e.preventDefault();
            return false;
        }
        e.model.AgentSettingChannelCount[i].TabCount = $("#" + channelmodel[i].Channel).val();
        e.model.AgentSettingChannelCount[i].IsEnable = $("#" + channelmodel[i].Channel + channelmodel[i].Id).is(':checked');
    }

    var featuremodel = JSON.parse(JSON.stringify(jsonagentfeature));
    e.model.AgentFeature = featuremodel;

    for (i = 0; i < featuremodel.length; i++) {
        e.model.AgentFeature[i].IsEnable = $("#" + featuremodel[i].Feature).is(':checked');
    }

    e.model.TeamID = $("#TeamID").val();
    e.model.TeamName = $("#TeamID").data("kendoDropDownTree").text();
    e.model.Profile = $("#Profile").val();
    e.model.SupervisorName = $("#SupervisorID").data("kendoDropDownList").text();
    e.model.TextChatGreetingTemplateName = $("#TextChatGreetingTemplateID").data("kendoDropDownList").text()

    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {

        
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
    }
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
  
    if (e.model.TextChatGreetingTemplateID == null) {
        e.model.TextChatGreetingTemplateID = 0;
    }

    if (e.model.isNew() != true && e.model.HasChild == true && $("#IsRetagSupervisor").val().toLowerCase() == "true" && (TeamID != $("#TeamID").val() || Profile != $("#Profile").val())) {
        if ($("#retagagentsupervisorlist").css('display') == 'none') {
            $("#retagagentsupervisortitle").show();
            $("#retagagentsupervisorlabel").show();
            $("#retagagentsupervisorlist").show();
            $("#retagagentsupervisortitle").html("<label>Choose new supervisor to retag supervisor/agent under team level: </label><span class='theme-color'> " + teamNameToBind + "</span>");

            $("#retagagentsupervisordropdown").data("kendoDropDownList").select(0);
            $("#retagagentsupervisordropdown").data("kendoDropDownList").dataSource.read()
        }
        else {
            $("#retagagentsupervisortitle").hide();
            $("#retagagentsupervisorlabel").hide();
            $("#retagagentsupervisorlist").hide();
        }

        if ($("#retagagentsupervisordropdown").data("kendoDropDownList").value() != "") {
            e.model.NewSupervisorID = $("#retagagentsupervisordropdown").data("kendoDropDownList").value();
        }
        else {
            toaster("Please provide a valid Supervisor to retag supervisor/agent under team level: " + teamNameToBind, "error");
            e.preventDefault();
            return false;
        }
    }
    //this method is in Validation.js
    modifyValid(e);
}

function getRetagAgentSupervisorParam() {
    return {
        id: UserName,
        teamid: TeamID,
        __RequestVerificationToken: $("#AntiForgeryToken").val() 
    };
}

function SetNumericTextBoxVisibility(data) {
    try {
        for (i = 0; i < data.length; i++) {
            if (data[i].Visible == true) {
                NumericTextboxValidation(data[i].Channel + data[i].Id, data[i].Channel)
            }
        }
    } catch (e) {
        console.log(e);
    }
}

function NumericTextboxValidation(checkboxId, numericTextboxId) {
    try {
        if (document.getElementById(checkboxId).checked) {
            $("#" + numericTextboxId).data("kendoNumericTextBox").enable(true);
        } else {
            $("#" + numericTextboxId).data("kendoNumericTextBox").enable(false);
        }
    } catch (e) {
        console.log(e);
    }
}

//dynamical set channel count controls and values based on json configuration
function SetChannels(data) {
    try {
        $("#channel-content").html("");
        for (i = 0; i < data.length; i++) {
            if (data[i].Visible == true) {
                var t = $("#channel-template").html(), //template divs
                    e = $("#channel-content"), //to be appended before/after/to
                    n = Handlebars.compile(t), //initialize handlebars for the template divs
                    context = {
                        Id: data[i].Id,
                        Channel: data[i].Channel,
                        Display: data[i].Display,
                        BaseInteraction: data[i].BaseInteraction,
                        IsEnable: data[i].IsEnable,
                        TabCount: data[i].TabCount
                    }, //add context data
                    s = n(context); //execute the template with handlebar and context
                e.append(s);

                var viewModel = kendo.observable({
                    IsEnable: data[i].IsEnable
                });

                kendo.bind($("#" + data[i].Channel + data[i].Id), viewModel);

                $("#" + data[i].Channel).kendoNumericTextBox({
                    min: 0,
                    value: data[i].TabCount,
                    decimals: 0,
                    format: "#"
                });
            }
        }
    } catch (e) {
        console.log(e);
    }
}

//dynamical set feature control and values based on json configuration
function SetFeature(data) {
    try {
        $("#feature-content").html("");
        for (i = 0; i < data.length; i++) {
            if (data[i].Visible == true) {
                var t = $("#feature-template").html(), //template divs
                    e = $("#feature-content"), //to be appended before/after/to
                    n = Handlebars.compile(t), //initialize handlebars for the template divs
                    context = {
                        Feature: data[i].Feature,
                        FeatureDisplay: data[i].FeatureDisplay,
                        IsEnable: data[i].IsEnable,
                    }, //add context data
                    s = n(context); //execute the template with handlebar and context
                e.append(s);

                var viewModel = kendo.observable({
                    IsEnable: data[i].IsEnable
                });

                kendo.bind($("#" + data[i].Feature), viewModel);
            }
        }
    } catch (e) {
        console.log(e);
    }
}
// used to wait for the children to finish async export
var detailExportPromises = [];

// used to wait for the children to finish async export
var detailExportFeaturePromises = [];

//Used to check if the columns are changed from hidden to not hidden
var exportFlag = false;

function excelexport(e) {
    validateExportExcel(e);
    e.preventDefault();
    if (e.data.length > 0) {
        //var includedColumnList = ['IsManualInEnabled', 'IsTextChatAutoAnswer', 'IsTextChatAutoAcwEnabled', 'IsSecondTextChatAutoAnswer', 'IsHoldVoiceCallOnChatCall', 'IsVoiceAllAutoAcwEnabled', 'IsVoiceAcdAutoAnswerEnabled', 'IsVoiceAcdAutoAcwEnabled', 'IsCrmEnabled'];
        //if (exportFlag === false) { //Initially on click of grid export columns in list includedColumnList will be Hidden in grid so we unhide them
        //    for (i = 0; i < e.sender.columns.length; i++) {
        //        if (includedColumnList.indexOf(e.sender.columns[i].field) > -1) {
        //            //Make the column as Hidden:false
        //            e.sender.showColumn(i);
        //        }
        //    }
        //    //Set the flag to true to indicate that the hidden columns required to show in excel are not hidden
        //    exportFlag = true;
        //    //Again call the ExcelExport event of the grid so that it goes to the else part(below) where the actual export happens
        //    e.sender.saveAsExcel();
        //}
        //else {
            var workbook = e.workbook;
            detailExportPromises = [];

            var masterData = e.data;

            for (var rowIndex = 0; rowIndex < masterData.length; rowIndex++) {
                exportChildData(masterData[rowIndex].AvayaLoginID, rowIndex);
                exportChildFeatureData(masterData[rowIndex].AvayaLoginID, rowIndex);
            }

            $.when.apply(null, detailExportPromises)
                .then(function () {
                    // get the export results
                    var detailExports = $.makeArray(arguments);

                    // sort by masterRowIndex
                    detailExports.sort(function (a, b) {
                        return a.masterRowIndex - b.masterRowIndex;
                    });

                    // add an empty column
                    workbook.sheets[0].columns.unshift({
                        //width: 30
                    });

                    // prepend an empty cell to each row
                    for (var i = 0; i < workbook.sheets[0].rows.length; i++) {
                        workbook.sheets[0].rows[i].cells.unshift({});
                    }

                    
                    // merge the detail export sheet rows with the master sheet rows
                    // loop backwards so the masterRowIndex doesn't need to be updated
                    for (var i = detailExports.length  - 1; i >= 0; i-=2) {
                        var masterRowIndex = detailExports[i].masterRowIndex + 1; // compensate for the header row

                        var sheet = detailExports[i-1].sheet;

                        var sheet1 = detailExports[i].sheet1;

                        // prepend an empty cell to each row
                        for (var ci = 0; ci < sheet.rows.length; ci++) {
                            if (sheet.rows[ci].cells[0].value) {
                                sheet.rows[ci].cells.unshift({});
                                sheet.rows[ci].cells.unshift({});
                            }
                        }

                        // prepend an empty cell to each row
                        for (var ci = 0; ci < sheet1.rows.length; ci++) {
                            if (sheet1.rows[ci].cells[0].value) {
                                sheet1.rows[ci].cells.unshift({});
                                sheet1.rows[ci].cells.unshift({});
                            }
                        }

                        //Check if the subgrid has any data, usually the first row will be the headers, so we check if length is greater than 1, since the headers will be always present
                        if (sheet.rows.length > 1) {
                            // insert the detail sheet rows after the master row
                            [].splice.apply(workbook.sheets[0].rows, [masterRowIndex + 1, 0].concat(sheet.rows));
                        }

                        if (sheet1.rows.length > 1) {
                            // insert the detail sheet rows after the master row
                            [].splice.apply(workbook.sheets[0].rows, [masterRowIndex + 1, 0].concat(sheet1.rows));
                        }
                        //workbook.sheets[0].rows.unshift({});
                    }

                    // save the workbook
                    kendo.saveAs({
                        dataURI: new kendo.ooxml.Workbook(workbook).toDataURL(),
                        fileName: "Agent Settings.xlsx"
                    });
                    ////Hide the columns that were marked as Hidden:false to true so that they stay hidden in grid
                    //for (i = 0; i < e.sender.columns.length; i++) {
                    //    if (includedColumnList.indexOf(e.sender.columns[i].field) > -1) {
                    //        //Make the column as Hidden:true
                    //        e.sender.hideColumn(i);
                    //    }
                    //}
                    ////Export is done so setting the flag to false for the next time Export to Excel is clicked in grid
                    //exportFlag = false;
                });
        }
    //}
}

function exportChildData(contactID, rowIndex) {
    var deferred = $.Deferred();

    detailExportPromises.push(deferred);

    var arrayData = []; //Array containing objects of data
    for (i = 0; i < subGridData.length; i++) {
        //Find the agentid from the data
        if (subGridData[i].AgentId === contactID) {
            //Store the matching data in an object
            var testdata = {};
            testdata.Channel = subGridData[i].Channel;
            testdata.BaseInteraction = subGridData[i].BaseInteraction;
            testdata.IsEnable = subGridData[i].IsEnable;
            testdata.TabCount = subGridData[i].TabCount;
            //Push it in an array
            arrayData.push(testdata);
        }
    }
    //Create a temporary datasoure and pass the matched data
    var temporaryDataSource = new kendo.data.DataSource({
        data: arrayData
    });
    //Call read to get the data in the datasource
    temporaryDataSource.read();

    var exporter = new kendo.ExcelExporter({
        columns: [{
            field: "Channel",
        }, {
            field: "BaseInteraction"
        },
        {
            field: "IsEnable"
        },
        {
            field: "TabCount"
        }],
        //dataSource: a
        dataSource: temporaryDataSource
    });

    exporter.workbook().then(function (book, data) {
        deferred.resolve({
            masterRowIndex: rowIndex,
            sheet: book.sheets[0]
        });
    });

   
}


function exportChildFeatureData(contactID, rowIndex) {
    var deferred = $.Deferred();

    detailExportPromises.push(deferred);

    var arrayData = []; //Array containing objects of data
    for (i = 0; i < subGridFeatureData.length; i++) {
        //Find the agentid from the data
        if (subGridFeatureData[i].AgentId === contactID) {
            //Store the matching data in an object
            var testdata = {};
            testdata.FeatureDisplay = subGridFeatureData[i].FeatureDisplay;
            testdata.IsEnable = subGridFeatureData[i].IsEnable;
            //Push it in an array
            arrayData.push(testdata);
        }
    }
    //Create a temporary datasoure and pass the matched data
    var temporaryFeatureDataSource = new kendo.data.DataSource({
        data: arrayData
    });
    //Call read to get the data in the datasource
    temporaryFeatureDataSource.read();

    var exporter = new kendo.ExcelExporter({
        columns: [{
            field: "FeatureDisplay",
            title: "Features",
            width: 300
        },
        {
            field: "IsEnable"
        }],
        dataSource: temporaryFeatureDataSource
    });

    exporter.workbook().then(function (book, data) {
        deferred.resolve({
            masterRowIndex: rowIndex,
            sheet1: book.sheets[0]
        });
    });
}
/**
 * Method used to perform an action when all the data is bound to the dropdowntree
 * @param e
 */
function OnUserRoleMappingTeamIdDataBound(e) {
    try {
        var ddt = e.sender;
        var dataSource = ddt.dataSource;
        var node = e.node;

        if (!node) {
            var children = dataSource.data();

            children.forEach(function (item, index) {
                if (item.hasChildren) {
                    teamIdDataboundCounter++;
                }
            });
        } else {
            var children = ddt.treeview.dataItem(node).children.data();

            children.forEach(function (item, index) {
                if (item.hasChildren) {
                    teamIdDataboundCounter++;
                }
            });

            teamIdDataboundCounter--;
        }

        if (teamIdDataboundCounter === 0) {
            console.log("Team Tree Fully bound!");
            $("#SupervisorID").data("kendoDropDownList").dataSource.read();
            //In the case of edit we are not binding change event so we bind it here, in case of new record change event is already binded so below statements will not matter
            //For edit if we bind change event earlier in onUserRoleMappingEdit function then after setting the dropdownlist value, the onProfilevalidation event will be called which will clear it
            //So for the profile dropdownlist values to not be reset in the edit scenario we bind change event here
            $("#TeamID").data("kendoDropDownTree").bind("change", onProfilevalidation);
            $("#Profile").data("kendoDropDownList").bind("change", OnAgentSettingProfileChange);
        }
    } catch (e) {
        console.log(e);
    }
}

/**
 * Method used to perform an action when all the data is bound to the Supervisor dropdownlist
 * @param e
 */
function OnUserRoleMappingSupervisorDataBound(e) {
    try {
        console.log("onSupervisorDataBound");
        //Below Ajax call will be mainly used for edit scenario when binding data, after all 3 items data is bound in some cases profile will not be disabled so below ajax call is for that validation
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/IsBottomMostTeam',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'teamid': $('#TeamID').val()
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                var dropdownlist = $("#Profile").data("kendoDropDownList");
                if (data != false) {
                    dropdownlist.enable(true);
                    dropdownlist.enable(false);
                }
                else {
                    dropdownlist.enable(true);
                }
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function OnAgentSettingProfileChange() {
    $("#SupervisorID").data("kendoDropDownList").dataSource.read();
}

function OnAgentSettingCancel(e) {
    try {
        $("#TeamID").data("kendoDropDownTree").unbind("change");
    } catch (e) {
        console.log(e);
    }
}