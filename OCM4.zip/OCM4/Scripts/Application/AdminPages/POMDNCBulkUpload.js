﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
var stream = "Collections"; //TeleSales or Collections
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "POMDNCBulkUpload.js",
          Version: "3.2.9.18",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreeraj",
        Description: "Version Changed."
    });

    if (stream != "Telesales") {
        $("#cl").hide();
        //$("#ContactList").val('');
    }
});

var fileUpload = "";
function UploadData() {
    try {
        if (stream.toLowerCase() == "telesales") {
            if ($("#ContactList").val() == null || $("#ContactList").val() == "" || $("#ContactList").val() == undefined) {
                toaster("Please select the ContactList", "error");
                return;
            }
        }
        else {
            $("#ContactList").val('');
        }
        if (fileUpload == "" || fileUpload == null || fileUpload == undefined) {
            toaster("Please select the csv file", "error");
            return;
        }
        $("#ContactList").data("kendoDropDownList").enable(false);
        
        document.getElementById("upload").disabled = true;

        UploadDataAjax($("#ContactList").val(), fileUpload);
    }
    catch (e) {
        console.log("Exception in UploadData(): " + e);
    }
}

function attachClickHandler(e) {
    try {

        var controls = {
            "control1": $("#ContactList"),
            "control2": $('#FileNameTemp')
        }
        readFileAfterDelegate = setFileUploadValues;
        readFile(e, this.wrapper, "csv", controls);
    }
    catch (e) {
        console.log("Exception in attachClickHandler(): " + e);
    }
}

function setFileUploadValues(isValidFile, fileInfo, controls) {
    if (isValidFile) {
        if (stream.toLowerCase() == "telesales") {
            if (control.control1.data("kendoDropDownList").text() == "Select Contact List") {
                toaster("Please Select Contact List first & Re-Upload", "error");
            }
        }
        $("label[for='validation']").html("");
        controls.control2.removeAttr('value');
        controls.control2.val(fileInfo.name);
        fileUpload = fileInfo.name;
    }
}

function onCsvFileUpload(e) {
    try {
        if (stream.toLowerCase() == "telesales") {
            e.data = { codeID: $("#ContactList").data("kendoDropDownList").text(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
        }
        else {
            e.data = { codeID: '', module: $("#ControllerName").val() }; //sends the extra parameter to controller
        }
    }
    catch (e) {
        console.log("Exception in onCsvFileUpload(): " + e);
    }
}

function UploadDataAjax(contactList, fileUpload) {
    try {
        var loadingdiv = document.getElementById('loading');
        loadingdiv.style.display = "block";
        //$(".k-upload-selected").trigger("click");
        //$('#csvFile​').getKendoUpload().trigger('upload')
        $(".k-upload-selected").click();
    }
    catch (e) {
        console.log("Exception in UploadDataAjax(): " + e);
    }

}

function onComplete(e) {

    try {
        var loadingdiv = document.getElementById('loading');
        loadingdiv.style.display = "none";
        document.getElementById("upload").disabled = false;

        $("#ContactList").data("kendoDropDownList").enable(true);
        
        //document.getElementById("upload").disabled = false;

        var response = jQuery.parseJSON(e.XMLHttpRequest.responseText);
        if (e.XMLHttpRequest.response.toLowerCase() == "failure") {
            toaster("CSV has not been uploaded", "error");
            setTimeout(timer, 2000);
            //location.reload();
        }
        var text = response.Result;
        var flag = response.Flag;
        if (flag == "Success") {
            toaster(text, "success");
            setTimeout(timer, 2000);
            //location.reload();
        }
        else {
            toaster(text, "error");
            setTimeout(timer, 2000);
            //location.reload();
        }
    }
    catch (e) {
        console.log("Exception in onComplete(): " + e);
        toaster("File has not been uploaded. Please check...", "error");
        setTimeout(timer, 2000);
    }
}

function timer() {
    try {
        var contactList = $("#ContactList").data("kendoDropDownList");
        contactList.text(contactList.options.optionLabel);
        contactList.element.val("");
        contactList.selectedIndex = -1;

        $(".k-upload-files.k-reset").find("li").remove();
        fileUpload = null;
    }
    catch (e) {
        console.log("Exception in timer(): " + e);
    }
}