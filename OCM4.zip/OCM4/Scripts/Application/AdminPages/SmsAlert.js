﻿
// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "SmsAlert.js",
       Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Module hierarchy applied"
    });


});

/*********************************************************************************Start of Main Grid JS***********************************************************************************************/
/**
 * This is on edit event of SmsAlert module
 */
function editSmsAlert(e) {
    //this method is in Validation.js
    genericEdit(e);
    bindingOrgUnit(e);
   
}

function ValidateNumberAndTemplate() {
    if ($("#Number").val() == "0") {
        $("#Number").val("");
    }
    if ($("#TemplateId").val() == "0") {
        $("#TemplateId").val("");
    }
}


function filterSupervisor() {

    return {
        Suprevisorname: $("#Profile").val()
    };
}
/**
 * this is dropdown Event in for agent profile
 */
function onProfile(e) {
    //this method is in Validation.js
    // Profilevalid();
}

/**
 * this id for onsave event
 */
function onSaveSmsAlert(e) {
  //  ValidateNumberAndTemplate();
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }
    //this method is in Validation.js
    modifyValid(e);
    validateOrgUnit(e);
}

function onBulkUpdateClose(e) {
    $("#MakerComments").val("");
    $('#checkAllRow', grid.tbody).prop('checked', false);
    checkAll();
}



function categoriesChange(e) {
    var value = this.value()
    $('#TemplateIdStatus').val(value);
}

function onChangeSms(e) {
    $('#SelectedIdListSms').val(this.selectedKeyNames().join(", "));
}


function onCsvUpload(e) {
    if (e.XMLHttpRequest.response  == "") {
        $("#drillGrid").data("kendoGrid").dataSource.read();
        $('#drillGrid').data('kendoGrid').refresh();
        toaster("CSV has been Successfully uploaded", "success");
        $("#bulkUploadWindow").data("kendoWindow").center().close();
        CheckForMakerUpdate();
    }
    if (e.XMLHttpRequest.response == "Failure") {
        toaster("CSV has not been uploaded", "error");
        $(".k-upload-status").remove();
    }
    if (e.XMLHttpRequest.response == "NoData") {
        toaster("CSV either has some issues or no data to upload", "info");
        $(".k-upload-status").remove();
    }
}

function onCsvSelect(e)
{
    var wrapper = this.wrapper;
    var msg = "Please upload only csv file!";
    readFile(e, wrapper, msg);
}



function bulkUpload() {
    $("#bulkUploadWindow").data("kendoWindow").center().open();
}

function bulkUpdateTemplate() {
    var idsToSend = [];

    var grid = $("#drillGrid").data("kendoGrid")
    var ds = grid.dataSource.view();

    for (var i = 0; i < ds.length; i++) {
        var row = grid.table.find("tr[data-uid='" + ds[i].uid + "']");
        var checkbox = $(row).find(".checkbox");

        if (checkbox.is(":checked")) {
            idsToSend.push(ds[i].Id);
        }
    }
    $('#SelectedIdListSms').val(idsToSend.join(','));


    if ($('#TemplateIdStatus').val() == "") {
        toaster("Please Select Template", "error");
        return;
    }
    if ($('#SelectedIdListSms').val() == "") {
        toaster("Please Select rows for bulk update", "error");
        return;
    }
    $('bulkUpdateComments').val();
    $("#bulkUpdateWindow").data("kendoWindow").center().open();
}
function checkboxChange() {
    $('#checkAllRow', grid.tbody).prop('checked', false);
}

function checkAll() {
    var checked = $("#checkAllRow").is(":checked");
    $('.checkbox:not(:disabled)', grid.tbody).prop('checked', checked);
}

function SubmitBulkUpdateComment() {
    try {
        var bulkUpdateComment = $("#bulkUpdateComments").val();
        if (bulkUpdateComment.trim() === "") {
            toaster("Please provide Bulk Update comments!", "error");
            return;
        }
        else {
            var data = {};
            data.bulkUpdateComment = bulkUpdateComment;
            data.functionName = $("#ControllerName").val();

            $.ajax({
                type: "POST",
                url: 'BulkUpdateTemplate',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                data: { "TemplateId": $('#TemplateIdStatus').val(), "smsId": $('#SelectedIdListSms').val(), "comments": data.bulkUpdateComment },
                dataType: "json",
                cache: false,
                success: function (data) {
                    if (data == 1) {
                        toaster("Bulk Template Update Successful", "success")
                        $("#bulkUpdateWindow").data("kendoWindow").close();
                        $("#drillGrid").data("kendoGrid").dataSource.read();
                        $('#drillGrid').data('kendoGrid').refresh();
                        CheckForMakerUpdate();
                    }
                    else {
                        toaster("Bulk Template Update Failed", "error");
                        $("#bulkUpdateWindow").data("kendoWindow").close();
                        $("#drillGrid").data("kendoGrid").dataSource.read();
                        $('#drillGrid').data('kendoGrid').refresh();
                    }
                    checkAll();
                    //$('#SelectedIdListSms').val("");
                },
                error: function (data) {
                    console.log(data);
                    toaster("Bulk Template Update Failed", "error");
                    $("#bulkUpdateWindow").data("kendoWindow").close();
                }
            });
        }
        $("#bulkUpdateComments").val("");
    } catch (e) {
        console.log(e);
    }
}
