﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "VdnSurveyInfo.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});

function attachClickHandler(e) {

    $("#Ans1WaveFileTemp").val(e.files[0].name);
}

function attachClickHandler1(e)
{
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#Ans1WaveFileWavefileTag"),
        "control2": $("#Ans1WaveFileTemp")
    }
    readFile(e, this.wrapper, "wav", controls); 
}

function attachClickHandler2(e)
{
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#Ans2WaveFileWavefileTag"),
        "control2": $("#Ans2WaveFileTemp")
    }
    readFile(e, this.wrapper, "wav", controls); 
}
function attachClickHandler3(e)
{
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#Ans3WaveFileWavefileTag"),
        "control2": $("#Ans3WaveFileTemp")
    }
    readFile(e, this.wrapper, "wav", controls); 
}
function attachClickHandler4(e)
{
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#Ans4WaveFileWavefileTag"),
        "control2": $("#Ans4WaveFileTemp")
    }
    readFile(e, this.wrapper, "wav", controls); 
}
function attachClickHandler5(e)
{
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#Ans5WaveFileWavefileTag"),
        "control2": $("#Ans5WaveFileTemp")
    }
    readFile(e, this.wrapper, "wav", controls); 
}

function attachClickHandler6(e)
{
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#Ans6WaveFileWavefileTag"),
        "control2": $("#Ans6WaveFileTemp")
    }
    readFile(e, this.wrapper, "wav", controls); 
}
function setFileUploadValues(isValidFile, fileInfo, controls) {
    if (isValidFile) {
        controls.control1.html("");
        controls.control2.val(fileInfo.name);
    }
}

function onWavFileUpload1(e) {
    var surveyvdn1 = $("#SurveyVdn").val() + "FirstPrompt.wav"
    e.data = { functionality: $("#Functionality").val(), surveyVdn: surveyvdn1, module: $("#ControllerName").val() }; //sends the extra parameter to controller
}
function onWavFileUpload2(e) {
    var surveyvdn1 = $("#SurveyVdn").val() + "LastPrompt.wav"
    e.data = { functionality: $("#Functionality").val(), surveyVdn: surveyvdn1, module: $("#ControllerName").val() }; //sends the extra parameter to controller
}
function onWavFileUpload3(e) {
    var surveyvdn1 = $("#SurveyVdn").val() + "exceptionprompt.wav"
    e.data = { functionality: $("#Functionality").val(), surveyVdn: surveyvdn1, module: $("#ControllerName").val() }; //sends the extra parameter to controller
} function onWavFileUpload4(e) {
    var surveyvdn1 = $("#SurveyVdn").val() + "sorryprompt.wav"
    e.data = { functionality: $("#Functionality").val(), surveyVdn: surveyvdn1, module: $("#ControllerName").val() }; //sends the extra parameter to controller
} function onWavFileUpload5(e) {
    var surveyvdn1 = $("#SurveyVdn").val() + "noinputprompt.wav"
    e.data = { functionality: $("#Functionality").val(), surveyVdn: surveyvdn1, module: $("#ControllerName").val() }; //sends the extra parameter to controller
}
function onWavFileUpload6(e) {
    var surveyvdn1 = $("#SurveyVdn").val() + "invalidinputprompt.wav"
    e.data = { functionality: $("#Functionality").val(), surveyVdn: surveyvdn1, module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

function filtersurvey() {
    return {
        vdn: $("#vdnsurverytemp").val()
    };
}
/**
 * on edit of agent telephony validate for number,email,text;
 */
function editVdnSurveyInfo(e) {
    
    genericEdit(e);
    if (e.model.isNew() == false) {
       // $("#SurveyVdn").data('kendoTextBoxFor').readonly();
        $(e.container).find('input[name="SurveyVdn"]').attr("readonly", true);
        $("#vdnsurverytemp").val(e.model.SurveyVdn);
        $("#Ans1WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans1WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" >' + e.model.Ans1WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans2WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans2WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" >' + e.model.Ans2WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans3WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans3WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name">' + e.model.Ans3WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans4WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans4WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name">' + e.model.Ans4WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans5WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans5WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name">' + e.model.Ans5WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans6WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans6WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" >' + e.model.Ans6WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');

        
    }
    if (e.model.isNew() == true) {
        $("#waveFile").css("visibility", "hidden");
        $("#Ans1WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans2WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans3WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans4WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans5WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans6WaveFileWavefileTag").css("visibility", "hidden");
    }
}

/**
 * on select of dropdown in Agent telephony validate  number,email,text
 */
function onSaveVdnSurveyInfo(e) {
    var SurveyVdn = $("#SurveyVdn").val();
    var Language = $("#Language").val();
    var EmailId = $("#EmailId").val();

    if (SurveyVdn == "") {
        e.preventDefault();
        toaster("Please provide a valid SurveyVdn", "error");
        return;
    }
    if (Language == "") {
        e.preventDefault();
        toaster("Please provide a valid Language", "error");
        return;
    }
    if (EmailId == "") {
        e.preventDefault();
        toaster("Please provide a valid EmailId", "error");
        return;
    }

    if ($("#Ans1WaveFileTemp").val() !== "") {
        if ($("#Ans1WaveFileTemp").val().indexOf(".wav") > 0) {
            e.model.Ans1WavFile = $("#Ans1WaveFileTemp").val();
            e.model.Ans2WavFile = $("#Ans2WaveFileTemp").val();
            e.model.Ans3WavFile = $("#Ans3WaveFileTemp").val();
            e.model.Ans4WavFile = $("#Ans4WaveFileTemp").val();
            e.model.Ans5WavFile = $("#Ans5WaveFileTemp").val();
            e.model.Ans6WavFile = $("#Ans6WaveFileTemp").val();
            $(".k-upload-selected").trigger("click");
        }
        else {
            toaster("Please upload only wav file!", "error");
            e.preventDefault();
            return;
        }

    }
    else if (e.model.waveFileTag === "" || e.model.WaveFile === "") {
        toaster("Please upload a wav file!", "error");
        e.preventDefault();
        return;
    }
    if (e.model.waveFileTag !== "" && e.model.ModifyReason === null) {
        toaster("Please provide modify reason!", "error");
        e.preventDefault();
        return;
    }
    modifyValid(e);
}

function ViewGrid()
{
    if ($("#ChooseVdn").val() != "") {
        
        var grid = $("#gridUserAccessDetails").data("kendoGrid");
        var choosevdninfo = $("#ChooseVdn").val();
        grid.dataSource.data("");
        grid.dataSource.read();
        grid.dataSource.filter({
            logic: "and",
            filters: [
                { field: "SurveyVdn", operator: "eq", value: choosevdninfo }
            ]
        });
        $('#popupDrill').modal('show');
        $("#DrillPopupFooter").hide();
        $("#searchDFormTemplate").hide();
        $("#DrillReportNameLbl").html("<h2>CSO Survey Q & A</h2><span class='theme-color'>Survey Vdn</span> : <span class='theme-color'></span>" + $("#ChooseVdn").val())
    }
    else
    {
        toaster("Please Choose the Suvery vdn ", "error");
        return;
    }
  
}


function CreateQuestion()
{
    var oldsurveyvdn = $("#SurveyVdn").val();
    var newsurveyvdn = $("#ChooseVdn").val();
    kendo.confirm("Do you want to copy details of survey VDN  " + oldsurveyvdn + " to " + newsurveyvdn).then(function () {
    if ($("#SurveyVdn").val() != "" && $("#ChooseVdn").val() != "") {        
        $.ajax({
            type: 'POST',
            url: window.ApplicationPath + 'VdnSurveyInfo/CreateQuestion',     
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "oldvdn": oldsurveyvdn, "newvdn": newsurveyvdn },
            dataType: "json",
            success: function (response) {
                toaster("Details successfully copied ", "success");
                return;
            },
            error: function () {
                toaster("error in copying details ", "error");
                return;
            }
        });
    }
    else {
        toaster("Please Choose the Suvery vdn ", "error");
        return;
    }
    }, function () {
    });
}