﻿//Start of Javascript for AgentSkillEdit Page
function AgentSkillEdit(e) {
    var tr = $(e.target).closest("tr");
    var rowdata = this.dataItem(tr);
    var query = rowdata.ReportQuery;
    var reportName = rowdata.ReportName;
    $("#sqlQuery").val(query);
    $("#reportName").val(reportName);
    $("#reportName").attr("disabled", true);
    $("#saveQuery").hide();
    $("#updateQuery").show();

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'Supervisor/GetSkillEdit', //'@Url.Action("GetEditColumns", "DynamicReport")',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify({
            'query': query
        }),
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data != null) {
                var editColumns = $("#selectedColumns").data("kendoListBox");
                var dataSource = new kendo.data.DataSource({ data: data });
                editColumns.setDataSource(dataSource);
                editColumns.dataSource.read();
            }
        },
        error: function () {
            console.log('Failed to load');
        }
    });

    ClearAllJoins();
    tabChange();
}

function editSupervisor(e) {
    genericEdit(e);
}

function onSupervisorSave(e) {
    duplicateValidate(e, "Value", "Value");
    duplicateValidate(e, "Name", "Name");
    modifyValid(e);
}
