﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "CsoSurveyQa.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});

function attachClickHandler(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#waveFile"));
}

function attachClickHandler1(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans1WaveFileTemp"));
}

function attachClickHandler2(e) {
    
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans2WaveFileTemp"));
}
function attachClickHandler3(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans3WaveFileTemp"));
}
function attachClickHandler4(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans4WaveFileTemp"));
}
function attachClickHandler5(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans5WaveFileTemp")); 
}
function attachClickHandler6(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans6WaveFileTemp"));
}
function attachClickHandler7(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans7WaveFileTemp"));
}
function attachClickHandler8(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans8WaveFileTemp")); 
}
function attachClickHandler9(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans9WaveFileTemp"));
}
function attachClickHandler10(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#Ans10WaveFileTemp"));    
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validation']").html("");
        control.val(fileInfo.name);
    }
}

function onWavFileUpload(e) {
    e.data = { functionality: $("#Functionality").val(), Language: $("#Langauge").val(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

/**
 * on edit of agent telephony validate for number,email,text;
 */
function editCsoSurvey(e) {

    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#Langauge").data("kendoDropDownList").readonly();
        $("#SurveyVdn").data("kendoDropDownList").readonly();
        $("#QuestionNumber").data("kendoDropDownList").readonly();
        $("#WakeupWavefileTag").css("visibility", "visible");
        $("#WakeupWavefileTag").html('<ul class="k-upload-files k-reset">'+
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">'+
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">'+
          '<span class="k-file-name" title="' + e.model.QuestionWaveFile + '">' + e.model.QuestionWaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans1WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans1WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans1WavFile + '">' + e.model.Ans1WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans2WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans2WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans2WavFile + '">' + e.model.Ans2WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans3WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans3WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans3WavFile + '">' + e.model.Ans3WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans4WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans4WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans4WavFile + '">' + e.model.Ans4WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans5WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans5WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans5WavFile + '">' + e.model.Ans5WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans6WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans6WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans6WavFile + '">' + e.model.Ans6WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans7WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans7WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans7WavFile + '">' + e.model.Ans7WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans8WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans8WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans8WavFile + '">' + e.model.Ans8WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans9WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans9WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans9WavFile + '">' + e.model.Ans9WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#Ans10WaveFileWavefileTag").css("visibility", "visible");
        $("#Ans10WaveFileWavefileTag").html('<ul class="k-upload-files k-reset">' +
          '<li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper">' +
          '<span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper">' +
          '<span class="k-file-name" title="' + e.model.Ans10WavFile + '">' + e.model.Ans10WavFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');

        $("#waveFile").css("visibility", "visible");
        $("#waveFile").html(e.model.QuestionWaveFile);
    }
    if (e.model.isNew() == true) {
        $("#waveFile").css("visibility", "hidden");
        $("#Ans1WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans2WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans3WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans4WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans5WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans6WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans7WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans8WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans9WaveFileWavefileTag").css("visibility", "hidden");
        $("#Ans10WaveFileWavefileTag").css("visibility", "hidden");
    }
}

/**
 * on select of dropdown in Agent telephony validate  number,email,text
 */
function onSaveCsoSurvey(e) {
    //
    var QuestionNumber = $("#QuestionNumber").data("kendoDropDownList").value();
    var QuestionText = $("#QuestionText").val();
    var Langauge = $("#Langauge").data("kendoDropDownList").value();
    var Threshold = $("#Threshold").val();
    var Options = $("#Options").val();
    var SurveyVdn = $("#SurveyVdn").data("kendoDropDownList").value();
    var Status = $("#Status").data("kendoDropDownList").value();
    //var waveFileTag = $("#waveFileTag").val();

    if (QuestionNumber == "") {
        e.preventDefault();
        toaster("Please provide a valid Question Number", "error");
        return;
    }
    if (QuestionText == "") {
        e.preventDefault();
        toaster("Please provide a valid Ouestion Description", "error");
        return;
    }
    if (Langauge == "") {
        e.preventDefault();
        toaster("Please provide a valid Langauge", "error");
        return;
    }
    if (Threshold == "") {
        e.preventDefault();
        toaster("Please provide a valid Threshold", "error");
        return;
    }
    if (Options == "") {
        e.preventDefault();
        toaster("Please provide a valid Options", "error");
        return;
    }
    if (SurveyVdn == "") {
        e.preventDefault();
        toaster("Please provide a valid Survey Vdn", "error");
        return;
    }
    
    //if (waveFileTag == "") {
    //    e.preventDefault();
    //    toaster("Please provide a valid waveFile Tag", "error");
    //    return;
    //}

    if ($("#waveFile").val() !== "") {
        if ($("#waveFile").val().indexOf(".wav") > 0) {
            e.model.QuestionWaveFile = $("#waveFile").val();
            e.model.Ans1WavFile = $("#Ans1WaveFileTemp").val();
            e.model.Ans2WavFile = $("#Ans2WaveFileTemp").val();
            e.model.Ans3WavFile = $("#Ans3WaveFileTemp").val();
            e.model.Ans4WavFile = $("#Ans4WaveFileTemp").val();
            e.model.Ans5WavFile = $("#Ans5WaveFileTemp").val();
            e.model.Ans6WavFile = $("#Ans6WaveFileTemp").val();
            e.model.Ans7WavFile = $("#Ans7WaveFileTemp").val();
            e.model.Ans8WavFile = $("#Ans8WaveFileTemp").val();
            e.model.Ans9WavFile = $("#Ans9WaveFileTemp").val();
            e.model.Ans10WavFile = $("#Ans10WaveFileTemp").val();
            $(".k-upload-selected").trigger("click");
        }
        else {
            toaster("Please upload only wav file!", "error");
            e.preventDefault();
            return;
        }

    }
    else if (e.model.waveFileTag == "" || e.model.QuestionWaveFile == "") {
        toaster("Please upload a wav file!", "error");
        e.preventDefault();
        return;
    }
    if (Status == "") {
        e.preventDefault();
        toaster("Please provide a valid Status", "error");
        return;
    }
    if (e.model.waveFileTag !== "" && e.model.ModifyReason === null) {
        toaster("Please provide modify reason!", "error");
        e.preventDefault();
        return;
    }
    modifyValid(e);
}