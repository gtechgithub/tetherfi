﻿
// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "SmsResponseTemplate.js",
        Version: "3.2.7.24",
        LastModifiedDateTime: "24-07-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Applied Module hierarchy"
    });


});

/*********************************************************************************Start of Main Grid JS***********************************************************************************************/
function updateCount() {
    var cs = $('#Text').val().length;

    $('#msgText').text(cs);

    if (cs >= 161) {

        $("#msgText").css("color", "red");
    }
    else {
        $("#msgText").css("color", "green");
    }

}

function onSaveSmsResponseTemplate(e) {

    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("IcomTemplate");
    fieldNames.push("Value");

    fieldValues.push(e.model.IcomTemplate);
    fieldValues.push(e.model.Value);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "IcomTemplate", "icomTemplate")
    validateOrgUnit(e);
    modifyValid(e);
}

function onGridAddRow(e) {

    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }
    if (($('#Text').val().length) > 500) {
        toaster("Only 500 characters are allowed to SMS text", "error");
        e.preventDefault();
        return;
    }
    validateOrgUnit(e);
    modifyValid(e);
}

var editfieldNames = new Array();
var editfieldValues = new Array();

function onGridEditRow(e) {


    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }

    genericEdit(e);
    bindingOrgUnit(e);
    updateCount();
}

function CheckForDupplicate(e, obj) {

    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].Enable === 'Yes') {
            count++;
            if (obj[t].ID === e.model.ID) {
                count--;
            }

        }
    }

    if (count >= 1) {
        return false;
    }
    return true;
}