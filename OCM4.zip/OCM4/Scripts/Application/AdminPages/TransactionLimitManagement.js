﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "TransactionLimitManagement.js",
       Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreenitha",
        Description: "Added new js for Transaction Limit Management"
    });
});

function onTransactionLimitManagementEdit(e) {
    genericEdit(e);
    var dataSource = $("#Category").data("kendoDropDownList");
    if (e.model.isNew() == false) { //edit mode
        dataSource.readonly();
       // $(e.container).find('input[name="Category"]').attr("readonly", true);
    }
    else{
        dataSource.enable(true);
    }
}


function onTransactionLimitManagementSave(e) {
    if (e.model.Category == "" || e.model.Category == null) {
        toaster("Enter a Category", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Limit == "" || e.model.Limit == null) {
        toaster("Select a Maximum Amount Limit", "error");
        e.preventDefault();
        return;
    }
    modifyValid(e);
}
