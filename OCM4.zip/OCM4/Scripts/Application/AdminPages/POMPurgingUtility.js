﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------

// global variables 
var key = "Telesales"; //Telesales/Collections
var nric = "id_no";
var date = "date";
var isSpecificDropdown = false; //added this for TH Telesales on 20-Jun-2019. For SG Telesales and Collections need to show only specific dropdown values on selection of some attributes
//should be true for sg telesales and collections

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "POMPurgingUtility.js",
       Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreeraj",
        Description: "Version Changed."
    });
    if (key.toLowerCase() === "telesales") {
        $("#purge").kendoButton();

        $('#PurgeText1').attr("disabled", "disabled");

        $("#Attributes").on('change', function () {

            if ($("#Attributes").val().toLowerCase() === nric.toLowerCase()) {

                $("#Condition").data("kendoDropDownList").enable(true);
            }
            else {
                $("#Condition").data("kendoDropDownList").enable(true);
            }

            if ($("#Attributes").val().toLowerCase().includes(date)) {
                $("#datetimepicker").data("kendoDatePicker").enable();
                $('#PurgeText1').attr("disabled", "disabled");
            }
            else {
                $("#datetimepicker").data("kendoDatePicker").enable(false);
                $('#PurgeText1').removeAttr("disabled");
            }
        });
    }
    else {
        $("#purge").kendoButton();
        $('#PurgeText1').attr("disabled", "disabled");

        $("#Attributes").on('change', function () {

            if ($("#Attributes").val().toLowerCase() === "id") {

                $("#Condition").data("kendoDropDownList").enable(true);
            }
            else {
                $("#Condition").data("kendoDropDownList").enable(true);
            }
            if ($("#Attributes").val().toLowerCase() === date.toLowerCase()) {
                $("#datetimepicker").data("kendoDatePicker").enable();
                $('#PurgeText1').attr("disabled", "disabled");
            }
            else {
                $("#datetimepicker").data("kendoDatePicker").enable(false);
                $('#PurgeText1').removeAttr("disabled");
            }
        });
        $("#Condition").data("kendoDropDownList");
        $("#datetimepicker").data("kendoDatePicker");
    }

});

var attributes, condition, purgeText, contactList, dateTimePick;
function PurgeData() {
    try {
        if (key.toLowerCase() === "telesales") {
            if ($("#ContactList").val() === null || $("#ContactList").val() === "" || $("#ContactList").val() === undefined) {
                toaster("Please select the ContactList", "error");
                return;
            }
            if ($("#Attributes").val() === null || $("#Attributes").val() === "" || $("#Attributes").val() === undefined) {
                toaster("Please select the Attribute", "error");
                return;
            }
            if (isSpecificDropdown) {
                if ($("#Attributes").val().toLowerCase() === nric.toLowerCase()) {
                    if ($("#Condition").val() !== "Equals" && $("#Condition").val() !== "Not Equal to") {
                        toaster("Please select the valid Condition", "error");
                        return;
                    }
                }               
                if ($("#Attributes").val().toLowerCase() === "CAMP_ID".toLowerCase()) {
                    if ($("#Condition").val() !== "Equals" && $("#Condition").val() !== "Not Equal to") {
                        toaster("Please select the valid Condition", "error");
                        return;
                    }
                }
            }
            else {
                if ($("#Condition").val() === null || $("#Condition").val() === "" || $("#Condition").val() === undefined) {
                    toaster("Please select the valid Condition", "error");
                    return;
                }
            }
            if (($("#Attributes").val().toLowerCase().indexOf(date) <= -1)) {
                if ($("#PurgeText1").val() === null || $("#PurgeText1").val() === "" || $("#PurgeText1").val() === undefined) {
                    toaster("Please select the PurgeText", "error");
                    return;
                }
            }
            if (($("#Attributes").val().toLowerCase().includes(date))) {
                if ($("#datetimepicker").val() === null || $("#datetimepicker").val() === "" || $("#datetimepicker").val() === undefined) {
                    toaster("Please select the Date", "error");
                    return;
                }
                purgeText = $("#datetimepicker").val();
            }
            else {
                purgeText = $("#PurgeText1").val();
            }

            attributes = $("#Attributes").val();
            condition = $("#Condition").val();
            contactList = $("#ContactList").val();


            Purge(contactList, attributes, condition, purgeText);
        }
        else {
            if ($("#ContactList").val() === null || $("#ContactList").val() === "" || $("#ContactList").val() === undefined) {
                toaster("Please select the ContactList", "error");
                return;
            }
            if ($("#Attributes").val() === null || $("#Attributes").val() === "" || $("#Attributes").val() === undefined) {
                toaster("Please select the Attribute", "error");
                return;
            }
            if ($("#Attributes").val().toLowerCase() === "id") {
                if ($("#Condition").val() !== "Equals" && $("#Condition").val() !== "Not Equal to") {
                    toaster("Please select the valid Condition", "error");
                    return;
                }
            }
            if ($("#Condition").val() === null || $("#Condition").val() === "" || $("#Condition").val() === undefined) {
                toaster("Please select the Condition", "error");
                return;
            }

            if (($("#Attributes").val().toLowerCase() !== date.toLowerCase())) {
                if ($("#PurgeText1").val() === null || $("#PurgeText1").val() === "" || $("#PurgeText1").val() === undefined) {
                    toaster("Please select the PurgeText", "error");
                    return;
                }
            }
            if (($("#Attributes").val().toLowerCase() === date.toLowerCase())) {
                if ($("#datetimepicker").val() === null || $("#datetimepicker").val() === "" || $("#datetimepicker").val() === undefined) {
                    toaster("Please select the Date", "error");
                    return;
                }
                purgeText = $("#datetimepicker").val();
            }
            else {
                purgeText = $("#PurgeText1").val();
            }

            attributes = $("#Attributes").val();
            condition = $("#Condition").val();
            contactList = $("#ContactList").val();


            Purge(contactList, attributes, condition, purgeText);
        }
    }
    catch (e) {
        console.log("Exception in PurgeData(): " + e);
    }
}

function Purge(contactList, attributes, condition, purgeText) {
    try {
        var validation = true;
        var loadingdiv = document.getElementById('loading');
        loadingdiv.style.display = "block";
        if (validation) {
            $.ajax({
                type: "POST",
                url: window.ApplicationPath + 'POMPurgingUtility/PurgeUtilityData',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                data: { "contactList": contactList, "Attributes": attributes, "Condition": condition, "purgeText": purgeText },
                dataType: "json",
                success: function (returneddata) {

                    console.log(returneddata);
                    requestPrevent = 0;
                    message = returneddata.Errors;
                    var y = message.hasOwnProperty("Success");
                    if (y === true) {
                        loadingdiv.style.display = "none";
                        toaster(message.Success.errors[0], "success");
                        setTimeout(timer, 2000);
                    }
                    else {
                        loadingdiv.style.display = "none";
                        toaster(message.Failure.errors[0], "error");
                        setTimeout(timer, 2000);
                    }

                },
                error: function (returneddata) {
                    console.log(msg);
                    loadingdiv.style.display = "none";
                    toaster(msg.d, "error");
                    setTimeout(timer, 2000);
                }
            });
        }
    }
    catch (e) {
        console.log("Exception in Purge(): " + e);
    }
}
function timer() {
    try {
        var contactList = $("#ContactList").data("kendoDropDownList");
        contactList.text(contactList.options.optionLabel);
        contactList.element.val("");
        contactList.selectedIndex = -1;

        var attributes = $("#Attributes").data("kendoDropDownList");
        attributes.text(attributes.options.optionLabel);
        attributes.element.val("");
        attributes.selectedIndex = -1;

        var condition = $("#Condition").data("kendoDropDownList");
        condition.text(condition.options.optionLabel);
        condition.element.val("");
        condition.selectedIndex = -1;

        $("#PurgeText1").val("");

        $("#datetimepicker").val("");
    }
    catch (e) {
        console.log("Exception in timer(): " + e);
    }
}