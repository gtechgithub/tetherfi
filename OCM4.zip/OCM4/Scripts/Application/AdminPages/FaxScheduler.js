﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "FaxScheduler.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 12:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Version Changed."
    });
});

function onFaxSchedulerEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $(e.container).find('input[number="Number"]').attr("readonly", true);
        $("#tiffFileTag").css("visibility", "visible");
        $("#tiffFileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">tiff/pdf/jpeg</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.FileName + '">' + e.model.FileName + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#FileNameTemp").val(e.model.FileName);
        e.model.Number = e.model.Number.split(',');
        $("#sendNow")[0].checked = e.model.Scheduled.toLowerCase() == "no" ? false : true;

        $("#Template").data('kendoDropDownList').value(e.model.GlobalTemplate);
        e.model.Template = e.model.GlobalTemplate;
        $("#enableTemplate")[0].checked = e.model.EnableTemp.toLowerCase() == "no" ? false : true;
            
        var enable = document.getElementById('enableTemplate');
        if (enable.checked == true) {
            enable.checked = false;
        }
        if (enable.checked==false) {
            var dropdownlist = $("#Template").data("kendoDropDownList");
            var upload = $("#tiffFile").data("kendoUpload");
            dropdownlist.enable(true);
            upload.enable(false);
        }
        //$.each(e.model.Number, function (i, val) {
        //    // Append it to the select
        //    $("#txtfax").append(new Option(val, val, true, true)).trigger('change');
        //});

        $("#enableTemplate").change(function () {
            var dropdownlist = $("#Template").data("kendoDropDownList");
            var upload = $("#tiffFile").data("kendoUpload");
            if (this.checked) {
                dropdownlist.enable(false);
                upload.enable();
            } else {
                dropdownlist.enable();
                upload.enable(false);
            }
        });
    }
    onFrequency($("#Frequency").val());
}

function onFrequency(Frequency) {
    if (Frequency == "") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
    }
    if (Frequency == "Daily") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
    }
    if (Frequency == "Weekly") {
        $("#day").css('display', '');
        $("#date").css('display', 'none');
    }
    if (Frequency == "Monthly") {
        $("#day").css('display', 'none');
        $("#date").css('display', '');
    }
}
function onFrequencySelect(e) {
    if (e.dataItem.Value == "") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
    }
    if (e.dataItem.Value == "Daily") {
        $("#day").css('display', 'none');
        $("#date").css('display', 'none');
    }
    if (e.dataItem.Value == "Weekly") {
        $("#day").css('display', '');
        $("#date").css('display', 'none');
    }
    if (e.dataItem.Value == "Monthly") {
        $("#day").css('display', 'none');
        $("#date").css('display', '');
    }
}
function onDateSelect(e) {
    if (e.dataItem.Value == "29") {
        swal({ title: "Message", text: "The report will be scheduled on 28th of February (if it's not a leap year).\n And will be scheduled on 29th of every other month", type: "info" });
        toaster("The report will be scheduled on 28th of February (if it's not a leap year).\n And will be scheduled on 29th of every other month", "info");
    }
    if (e.dataItem.Value == "30") {
        swal({ title: "Message", text: "The report will be scheduled on the last day of February,\n and will be scheduled on 30th of every other month", type: "info" });
    }
    if (e.dataItem.Value == "31") {
        swal({ title: "Message", text: "The report will be scheduled on the last day of the month for months not containing 31 days", type: "info" });
    }
}

//This function is called when clicked on Update/Send/Create
function onFaxSchedulerSave(e) {
    e.model.Scheduled = $("#sendNow")[0].checked == false ? "No" : "Yes";
    e.model.Number = $("#Number").data("kendoMultiSelect").value();
    e.model.Time = $("#Time").val();
    e.model.EnableTemp = $("#enableTemplate")[0].checked == false ? "No" : "Yes";
    if (e.model.Number == "" || e.model.Number == undefined) {
        toaster("Please enter the Numbers", "error");
        e.preventDefault();
        return;
    }
    if (e.model.FaxLine == "" || e.model.FaxLine == null) {
        toaster("Please select the FaxLine", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Scheduled == "No") {
        if (e.model.Time == "" || e.model.Time == undefined) {
            toaster("Please notify when to send!", "error");
            e.preventDefault();
            return;
        }
    }
   
    var arrNum = e.model.Number;
    for (i = 0; i < arrNum.length; i++) {
        if (arrNum[i] == e.model.FaxLine) {
            toaster("One of your enterted fax number ("+ arrNum[i] +") is same as Faxline", "error");
            e.preventDefault();
            return;
        }
        if (isNaN(arrNum[i])) {
            toaster("Number ("+arrNum[i] +") cannot contain letters/special characters", "error");
            e.preventDefault();
            return;
        }
    }
    if (e.model.Frequency == "Daily") {
        if (moment(e.model.Time, "HH:mm", true).isValid() == false) {
            toaster("Select a Valid Daily Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.Time == "" || e.model.Time == null) {
            toaster("Select a Daily Time", "error");
            e.preventDefault();
            return;
        }
    }
    if (e.model.Frequency == "Weekly") {
        if (e.model.Day == "" || e.model.Day == null) {
            toaster("Select a Day", "error");
            e.preventDefault();
            return;
        }
        if (moment(e.model.Time, "HH:mm", true).isValid() == false) {
            toaster("Select a Valid Weekly Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.Time == "" || e.model.Time == null) {
            toaster("Select a Weekly Time", "error");
            e.preventDefault();
            return;
        }
    }
    if (e.model.Frequency == "Monthly") {
        if (e.model.Date == "" || e.model.Date == null) {
            toaster("Select a Monthly Date", "error");
            e.preventDefault();
            return;
        }
        if (moment(e.model.Time, "HH:mm", true).isValid() == false) {
            toaster("Select a Valid Monthly Time", "error");
            e.preventDefault();
            return;
        }
        if (e.model.Time == "" || e.model.Time == null) {
            toaster("Select a Monthly Time", "error");
            e.preventDefault();
            return;
        }
    }
    var ret = document.getElementById('enableTemplate').checked;

    e.model.FileName = $("#FileNameTemp").val();
    var file = e.model.FileName.split(".").pop();
    if (ret) {
        if (e.model.FileName == "" || e.model.FileName == undefined) {
            toaster("Please select file to send", "error");
            e.preventDefault();
            return;
        }
    }
    if (ret) {
        if (file != "pdf" && file != "jpg" && file != "jpeg" ) {
            toaster("Please select valid file to send", "error");
            e.preventDefault();
            return;
        }
    }
    e.model.GlobalTemplate = e.model.Template;
    if (!ret) {
        if (e.model.Template == "" || e.model.Template == null) {
            toaster("Please select Template to send", "error");
            e.preventDefault();
            return;
        }
    }
    for (var i in iCnt) {
        ;
        var fromid = document.getElementById('tb' + iCnt).value;
        var toid = document.getElementById('tbb' + icnt).value;
        //var splitfaxid = document.getElementById('txtFaxNumber' + iCnt).value;
    }
    e.model.Number = $("#Number").data("kendoMultiSelect").value().toString();
    $('#FileNameTemp').removeAttr('value');
    modifyValid(e);
}

function timepicker_change(e) {
    if (moment($("#Time").val(), "HH:mm", true).isValid() == false) {
        toaster("Select a Valid Time", "error");
        return;
    }
}

var fileUpload = "";
function attachClickHandler(e) {
    var validExt = "pdf/jpg/tif/jpeg";
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, validExt, $('#FileNameTemp'));
}



function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        fileUpload = "";
        $("label[for='validation']").html("");
        control.removeAttr('value');
        control.val(fileInfo.name);
        fileUpload = fileInfo.name;
    }
}

function onTiffFileUpload(e) {
    e.data = { functionality: $("#Functionality").val(), language: $("#Language").val(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

//below function will be called when clicked on Preview
function previewTifFile(e) {

    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var validation = true;
    if (data.PageCount == "0") {
        toaster("There are no file to priview", "info");
        e.preventDefault();
        validation = false;
    }
    if (data.FileName == "" && data.FileName == null) {
        toaster("There are no file to preview", "info");
        e.preventDefault();
        validation = false;
    }
    if (validation) {
        toaster("Please wait until previewing", "info");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FaxScheduler/DownloadFileFromPath',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "filename": data.FileName, "view": 'download' },
            dataType: "json",
            success: function (returneddata) {
                console.log(returneddata)

                if (returneddata.length > 0) {
                    $('#popupPreview').modal('show');
                    var div = "";
                    for (var i = 0; i < returneddata.length; i++) {
                        div += "<div id='" + returneddata[i] + "_" + i + "' class='col-lg-12'><img style='max-width:100%;' src='" + window.ApplicationPath + "FaxerImages/" + returneddata[i] + "'/></div>"
                    }
                    $("#tifPreview").html("");
                    $("#tifPreview").append(div);
                }
                else {
                    toaster("There is no file present to Preview!", "error");
                }
                requestPrevent = 0;
            },
            error: function (msg) {
                console.log(msg);
                toaster("There is an issue while previewing!!!", "error");
            },
        })
    }
}

//below function will be called when clicked on Preview (Eye image) on popup
function previewUploadedTifFile() {
    var validation = true;
    if (fileUpload == "" || fileUpload == null) {
        toaster("Please upload a file to preview", "info");
        validation = false;
    }
    if (validation) {
        toaster("Please wait until previewing", "info");
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'FaxScheduler/DownloadFileFromPath',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "filename": fileUpload, "view": 'upload' },
            dataType: "json",
            success: function (returneddata) {
                console.log(returneddata)

                if (returneddata.length > 0) {
                    $('#popupPreview1').modal('show');
                    var div = "";
                    for (var i = 0; i < returneddata.length; i++) {
                        div += "<div id='" + returneddata[i] + "_" + i + "' class='col-lg-12'><img style='max-width:100%;' src='" + window.ApplicationPath + "FaxerImages/" + returneddata[i] + "'/></div>"
                    }
                   
                    $("#tifPreview1").html("");
                    $("#tifPreview1").append(div);
                }
                else {
                    toaster("There is no file present to Preview!", "error");
                }
                requestPrevent = 0;
            },
            error: function (msg) {
                console.log(msg);
                toaster("There is an issue while previewing!!!", "error");
            },
        })
    }
}

function SplitFax(e) {
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var faxBoxId = data.ID;
    window.location = window.ApplicationPath + 'SplitFax' + '/Index?guid=' + faxBoxId;
}

function MergeFax(e) {
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var faxBoxId = data.ID;
    window.location = window.ApplicationPath + 'MergeFax' + '/Index?guid=' + faxBoxId;
}

function getAddressBookParam() {
    return {
        type: "addressbook",
        faxLine: $("#FaxLine").val(),
        adddressbookid: "",
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function getFaxSchedulerParam() {
    return {
        type: "recipient",
        faxLine: "",
        adddressbookid: $("#AddressBook").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function onChangeAddressBook()
{
    $("#Number").data("kendoMultiSelect").dataSource.read();
    $("#Number").data("kendoMultiSelect").bind("dataBound", onNumberDatabound);
}

function onNumberDatabound()
{
    var multiselect = $("#Number").data("kendoMultiSelect");
    var all = $.map(multiselect.dataSource.data(), function (dataItem) {
        return dataItem.Value;
    });
    multiselect.value(all);
    $("#Number").data("kendoMultiSelect").unbind("dataBound");

    //toaster message if number of recipient exceeded MaxNumberstoSend
    if (all.length > $("#MaxNumberstoSend").val())
    {
        toaster("Number of Recipients exceeded maximum number of Recipients", "info");
    }
}

//the actual data won't get synced to the server, but that's okay because when we save this new item on the update of the parent model, we presumably will grab that newly added item on the next read
function addNew(widgetId, value) {
    var widget = $("#" + widgetId).getKendoMultiSelect();
    var dataSource = widget.dataSource;
    if (!isNaN(value))
    {
        dataSource.add({
            Text: value,
            Value: value
        });

        dataSource.one("requestEnd", function (args) {
            if (args.type !== "create") {
                return;
            }

            var newValue = args.response[0].ProductID;

            dataSource.one("sync", function () {
                widget.value(widget.value().concat([newValue]));
            });
        });

        dataSource.sync();
        $("#Number").data("kendoMultiSelect").bind("dataBound", onNumberDatabound);
    }
       
}

