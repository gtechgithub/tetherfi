﻿$(document).ready(function () {
    /**
        * Define the Version
        * @returns {}
        */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrBranchManagement.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Applied Module hierarchy"
    });
});

var editfieldNames = new Array();
var editfieldValues = new Array();

function filterSubLine() {
    return {
        mainLines: $("#MainLines").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

//function onBranchWavFileUpload(e) {
//    e.data = { functionality: $("#ControllerName").val(), language: $("#Language").val() }; //sends the extra parameter to controller
//}
//function onAddWavFileUpload(e) {
//    e.data = { functionality: $("#ControllerName").val(), language: $("#Language").val() }; //sends the extra parameter to controller
//}

function onBranchWavFileUpload(e) {
    e.data = { waveFileTag: $("#BranchWavefile").val(), functionality: $("#ControllerName").val(), language: $("#Language").val() }; //sends the extra parameter to controller
}
function onAddWavFileUpload(e) {
    e.data = { waveFileTag: $("#AddressWavefile").val(), functionality: $("#ControllerName").val(), language: $("#Language").val() }; //sends the extra parameter to controller
}


function onWavFileRemove(e) {
    $("#waveFile").val("");
}

function onGridAddRow(e) {
    e.model.AddressText = $('#AddressText').val();
    e.model.BranchName = $('#BranchName').val();
    e.model.BranchWavefile = $("#BranchWavefile").val();
    e.model.AddressWavefile = $("#AddressWavefile").val();

    var fieldNames = new Array();
    var fieldValues = new Array();

    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].s == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }

    var currentModifyReason = e.model.ModifyReason;
    if (e.model.isNew() == false) {
        if ($.trim(currentModifyReason) == "" || $.trim(currentModifyReason) == null) {
            e.preventDefault();
            toaster("Please enter the modify reason", "error");
            return;
        }
    }
   
    if (e.model.BranchName != $("#BranchWavefile").val().replace(".wav", "")) {
        e.preventDefault();
        toaster("The Branch Name should be same as Branch Wav file name", "error");
        return;
    }
    if (e.model.AddressText != $("#AddressWavefile").val().replace(".wav", "")) {
        e.preventDefault();
        toaster("The Address text name should be same as Address Wav file name", "error");
        return;
    }
    if ($("#BranchWavefile").val().indexOf(".wav") > 0) {
        e.model.BranchWavefile = $("#BranchWavefile").val();
        $(".k-upload-selected").trigger("click");
    }
    else {
        toaster("Please upload only wav file!", "error");
        e.preventDefault();
        return;
    }
    if ($("#AddressWavefile").val().indexOf(".wav") > 0) {
        e.model.AddressWavefile = $("#AddressWavefile").val();
        $(".k-upload-selected").trigger("click");
    }
    else {
        toaster("Please upload only wav file!", "error");
        e.preventDefault();
        return;
    }
    validateOrgUnit(e);
}

function onGridEditRow(e) {
    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }
    genericEdit(e);
    bindingOrgUnit(e);
    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $("#BranchWavefileTag").css("visibility", "visible");
        $("#AddressWavefileTag").css("visibility", "visible");
        $("#BranchWavefileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.BranchWavefile + '">' + e.model.BranchWavefile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        $("#AddressWavefileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.AddressWavefile + '">' + e.model.AddressWavefile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
        $("#BranchWavefileTag").css("visibility", "hidden");
        $("#AddressWavefileTag").css("visibility", "hidden");
    }
}

function attachClickHandler(e) {
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#BranchWavefile"),
        "control2": $("#BranchName")
    }
    readFile(e, this.wrapper, "wav", controls);

  
}
function setFileUploadValues(isValidFile, fileInfo, controls) {
    if (isValidFile) {
        $("label[for='validation']").html("");
        controls.control1.val(fileInfo.name);
        var str = fileInfo.name
        str = str.replace(/.wav/g, "");
        controls.control2.val(str);
    }
}
 

function attachClickHandlerSecond(e) {
    readFileAfterDelegate = setFileUploadValues;
    var controls = {
        "control1": $("#AddressWavefile"),
        "control2": $("#AddressText")
    }
    readFile(e, this.wrapper, "wav", controls);
}