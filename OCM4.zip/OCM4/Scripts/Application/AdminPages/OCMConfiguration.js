﻿$(document).ready(function () {
    /**
    * Define the Version
    * @returns {}
    */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "OCMConfiguration.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreenitha",
        Description: "Added new js for OCM Configuration"
    });

    enableDisableGridAutoResize = 1;
    $('#channelGridpopup').hide();
    $('#channelDataGridpopup').hide();
    $('#adminModulesDataGridpopup').hide();
    $('#reportsDataGridpopup').hide();
    $('#dashboardDataGridpopup').hide();
    $('#popupDrill').hide();
    initializeGridTooltip('channelGrid');
    initializeGridTooltip('channelDataGrid');
    initializeGridTooltip('adminModulesDataGrid');
    //  TreeviewDataBind();

    $("#jsonTabstrip").kendoTabStrip({
        activate: onTabstripActivate,
        animation: {
            open: {
                effects: "fadeIn"
            }
        }
    });

});




var selectedNode = "";
var parentNode = "";
var subParentNode = "";
var selectedgridName = "";
function template() {
    kendo.template($("#message-template").html());
}

function TreeviewDataBind() {
    var FirstLevel = new kendo.data.HierarchicalDataSource({
        transport: {
            read: {
                data: "{ value : AccessConfiguration.json }",
                url: window.ApplicationPath + 'OCMConfiguration/GetTreeViewData/',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                dataType: "json"
            }
        },
        schema: {
            model: {
                hasChildren: "HasChildren",
                // children: "Items",
                Name: "Name"
            }
        }
    });
    var trVwScanOrg = $("#treeview").kendoTreeView({
        dataSource: FirstLevel,
        dataTextField: "Name"

    });
}

function treeItemSelect(e) {
 
    var dataItem = this.dataItem(e.node);
    var dataText = "type=" + dataItem.ModelType;
    var ds = e.sender.dataSource;

    ds.options.data.push(dataText);
}

function getTreeData() {

    return {
        value: $('#JsonDropdown').data("kendoDropDownList").value()
    };
}
function getData() {

    return {
        selectedNode: selectedNode,
        parentNode: subParentNode,
        modifyReason: $('#ModifyReason').val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}
function getNodeData(e) {
   
    return {
        selectedNode: selectedNode,
        parentNode: parentNode,
        modifyReason: $('#ModifyReason').val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}
function getReportColumnsData() {

    return {
        selectedNode: selectedNode,
        parentNode: parentNode,
        gridName: selectedgridName,
        modifyReason: $('#ModifyReason').val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}
function onAccessConfigurationSelect(e) {

    enableDisableGridAutoResize = 1;
    selectedNode = $('#treeview').data('kendoTreeView').dataItem(e.node).text;
    if (!(selectedNode.toLowerCase().indexOf("adminpages") >= 0 || selectedNode.toLowerCase().indexOf("reports") >= 0 || selectedNode.toLowerCase().indexOf("dashboards") >= 0 || selectedNode.toLowerCase().indexOf("otherapplications") >= 0)) {
        if (selectedNode.toLowerCase().indexOf(".") < 0) {
            parentNode = this.parent(this.parent(e.node)).data().id;
            subParentNode = this.parent(e.node).children()[0].textContent;
        }
        else {//json files
            parentNode = this.parent(e.node).data().id;
            subParentNode = "";
        }
        //parentNode = this.text(this.parent(e.node));

        //if (parentNode == "undefined") {
        //    parentNode = this.parent(e.node).data().id;
        //}
        $.ajax(
            {
                type: 'POST',
                url: window.ApplicationPath + 'OCMConfiguration/GetPreviewData/',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                dataType: 'json',
                async: false,
                data: { selectedNode: selectedNode, subParentNode: subParentNode, parentNode: parentNode },
                success: function (result) {
                   
                    if (result.length > 0) {
                        if (selectedNode.toLowerCase().indexOf("channeldata") >= 0) {// for channeldata
                            $('#channelGridpopup').hide();
                            $('#channelDataGridpopup').show();
                            $('#adminModulesDataGridpopup').hide();
                            $('#reportsDataGridpopup').hide();
                            $('#dashboardDataGridpopup').hide();
                           // enableDisableGridAutoResize = 0;
                            $('#selectedChannelDataModule').text(selectedNode);
                            $("#channelDataGrid").data("kendoGrid").dataSource.data(result);
                            //   generateGrid(result);
                        }
                        else if (selectedNode.toLowerCase().indexOf(".json") >= 0 && parentNode.toLowerCase().indexOf("admin modules") >= 0) {
                            $('#channelGridpopup').hide();
                            $('#channelDataGridpopup').hide();
                            $('#adminModulesDataGridpopup').show();
                            $('#reportsDataGridpopup').hide();
                            $('#dashboardDataGridpopup').hide();
                            //$("#adminModulesDataGrid").kendoGrid({
                            //    editable: true,
                            //    toolbar: ["create", "save", "cancel "],
                            //})
                            enableDisableGridAutoResize = 0;
                            $('#selectedAdminModule').text(selectedNode);
                            $("#adminModulesDataGrid").data("kendoGrid").dataSource.data(result);

                        }
                        else if (selectedNode.toLowerCase().indexOf(".json") >= 0 && parentNode.toLowerCase().indexOf("reports") >= 0) {
                           
                            $('#channelGridpopup').hide();
                            $('#channelDataGridpopup').hide();
                            $('#adminModulesDataGridpopup').hide();
                            $('#reportsDataGridpopup').show();
                            $('#dashboardDataGridpopup').hide();
                            $('#selectedReportModule').text(selectedNode);
                            $("#reportsDataGrid").data("kendoGrid").dataSource.data(result);
                        }
                        else if (selectedNode.toLowerCase().indexOf(".json") >= 0 && parentNode.toLowerCase().indexOf("dashboard") >= 0) {
                            
                            // var tbl = prettyPrint(result);
                            //$("#tabledatadiv").append(tbl);
                            $('#channelGridpopup').hide();
                            $('#channelDataGridpopup').hide();
                            $('#adminModulesDataGridpopup').hide();
                            $('#reportsDataGridpopup').hide();
                            $('#dashboardDataGridpopup').show();
                            $('#selectedDashboardModule').text(selectedNode);
                            $("#dashboardDataGrid").data("kendoGrid").dataSource.data(result);
                            //$("#tabledatadiv").kendoGrid({
                            //    //columns: [
                            //    //    { field: "flowName" },
                            //    //    { field: "userName" },
                            //    //    { field: "roleName" },
                            //    //    { field: "actions.importCallFlow", type: "boolean" },
                            //    //    { field: "actions.delete", type: "boolean" },
                            //    //    { field: "actions.edit", type: "boolean" },
                            //    //    { field: "actions.serialversionuid", type: "number" },
                            //    //    { field: "actions.realtimeView", type: "boolean" },
                            //    //    { field: "actions.build", type: "boolean" },
                            //    //    { field: "actions.add", type: "boolean" },
                            //    //    { field: "actions.copy", type: "boolean" },
                            //    //    { field: "actions.versionControl", type: "boolean" },

                            //    //],
                            //    toolbar: ["create", "save", "cancel"],
                            //    editable: true,
                            //    dataSource: {
                            //        data: result
                            //        //schema: {
                            //        //    parse: function (d) {
                            //        //        debugger;
                            //        //        for (var i = 0; i < d.length; i++) {
                            //        //            debugger;
                            //        //            if (d[i]) {
                            //        //                return d[i];
                            //        //            }
                            //        //        }
                            //        //        return [];
                            //        //    }
                            //        //}
                            //    },
                            //    columns: [{
                            //        field: "Title",
                            //        title: "Title"
                            //    }, {
                            //        field: "PropertyName",
                            //        title: "PropertyName"
                            //    }, {
                            //        field: "SubBox.Title",
                            //        title: "SubBox.Title",
                            //        width: "180px",
                            //        template: kendo.template($("#message-template").html())
                            //    } //template: "#=ddl.value#" }
                            //    ]
                            //}).data("kendoGrid");
                            // $("#tabledatadiv").data("kendoGrid").dataSource.data(result);
                        }
                        else {
                            //for channel
                            $('#channelGridpopup').show();
                            $('#channelDataGridpopup').hide();
                            $('#adminModulesDataGridpopup').hide();
                            $('#reportsDataGridpopup').hide();
                            $('#selectedModule').text(selectedNode);
                            $("#channelGrid").data("kendoGrid").dataSource.data(result);
                        }
                    }
                    else {
                        toaster("No records to display", "info");
                    }
                    // kendo.ui.progress($("#channelGrid"), false);
                },
                error: function (result) {
                    console.log("Error: " + result);
                    // kendo.ui.progress($("#channelGrid"), false);
                }
            });


        //kendo.ui.progress(progress, false);
    }
}


function onGridSave(e) {
    try {
     
        var fieldNames = new Array();
        var fieldValues = new Array();

        fieldNames.push("DisplayName");
        fieldNames.push("FunctionalityName");
        if (selectedNode.toLowerCase().indexOf("channeldata") >= 0) {// for channeldata
            fieldNames.push("Channel");
            fieldNames.push("Icon");
        }
        fieldNames.push("Included");

        fieldValues.push(e.model.DisplayName);
        fieldValues.push(e.model.FunctionalityName);
        if (selectedNode.toLowerCase().indexOf("channeldata") >= 0) {// for channeldata
            fieldValues.push(e.model.Channel);
            fieldValues.push(e.model.Icon);
        }
        fieldValues.push(e.model.Included);

        var result = validateBlankFields(fieldNames, fieldValues);

        if ($.trim(result) != "") {
            toaster("Please Provide " + result, "error");
            e.preventDefault();
            return false;
        }

        duplicateValidate(e, "FunctionalityName", "FunctionalityName")
        modifyValid(e);
    } catch (e) {
        console.log(e);
    }
}

function onGridEditRow(e) {

    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#FunctionalityName").prop("readonly", true);
    }
    if (e.model.isNew() == true) {
        $("#FunctionalityName").prop("readonly", false);
    }
}

function onAdminModulesGridSave(e) {
    try {
 
        var fieldNames = new Array();
        var fieldValues = new Array();

        fieldNames.push("Title");
        fieldNames.push("PropertyName");
        //fieldNames.push("Editable");
        //fieldNames.push("ColumnWidth");
        //fieldNames.push("ID");
        //fieldNames.push("FormGroup");
        //fieldNames.push("Hidden");
        //fieldNames.push("Width");
        //fieldNames.push("Encoded");
        //fieldNames.push("ClientTemplate");
        //fieldNames.push("DateFormat");
        //fieldNames.push("ConfigProperty");
        //fieldNames.push("Mandatory");
        //fieldNames.push("IncludeGrid");
        //fieldNames.push("FieldType");
        //fieldNames.push("FieldRows");
        //fieldNames.push("Maxlength");
        //fieldNames.push("OnKeyUpEvent");
        //fieldNames.push("OnMouseOutEvent");
        //fieldNames.push("IsDuplicateAllowed");


        fieldValues.push(e.model.Title);
        fieldValues.push(e.model.PropertyName);
        //fieldValues.push(e.model.Editable);
        //fieldValues.push(e.model.ColumnWidth);
        //fieldValues.push(e.model.ID);
        //fieldValues.push(e.model.FormGroup);
        //fieldValues.push(e.model.Hidden);
        //fieldValues.push(e.model.Width);
        //fieldValues.push(e.model.Encoded);
        //fieldValues.push(e.model.ClientTemplate);
        //fieldValues.push(e.model.DateFormat);
        //fieldValues.push(e.model.ConfigProperty);
        //fieldValues.push(e.model.Mandatory);
        //fieldValues.push(e.model.IncludeGrid);
        //fieldValues.push(e.model.FieldType);
        //fieldValues.push(e.model.FieldRows);
        //fieldValues.push(e.model.Maxlength);
        //fieldValues.push(e.model.OnKeyUpEvent);
        //fieldValues.push(e.model.OnMouseOutEvent);
        //fieldValues.push(e.model.IsDuplicateAllowed);

        var result = validateBlankFields(fieldNames, fieldValues);

        if ($.trim(result) != "") {
            toaster("Please Provide " + result, "error");
            e.preventDefault();
            return false;
        }

        duplicateValidate(e, "PropertyName", "PropertyName")
        modifyValid(e);
    } catch (e) {
        console.log(e);
    }
}

function onAdminModulesGridEditRow(e) {
 
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#PropertyName").prop("readonly", true);
    }
    if (e.model.isNew() == true) {
        $("#PropertyName").prop("readonly", false);
    }
}

function onJsonDropdownChange() {

    $("#treeview").data("kendoTreeView").dataSource.read();
    //$.ajax(
    //    {
    //        type: 'POST',
    //        url: window.ApplicationPath + 'OCMConfiguration/GetTreeViewData/',
    //        dataType: 'json',
    //        async: false,
    //        data: "",
    //        success: function (result) {
    //            debugger;
    //            //$("#treeview").kendoTreeView({
    //            //    dataSource: result
    //            //});
    //        },
    //        error: function (result) {
    //            console.log("Error: " + result);
    //        }
    //    });

}
function onDashBoardGridChange(e) {
    try {
      

        var $grid = e.sender; //grid ref
        var SubBox = $grid.dataItem(this.select()).SubBox;
        if (SubBox.length > 0) {
            var selectedData = $.map(this.select(), function (item) {
                return $(item).text();
            });
            console.log(selectedData);
            var $cell = $grid.select(); // selected td
            var $row = $cell.closest('tr'); //selected tr
            var row_uid = $row.attr('data-uid'); //uid of selected row
            var cell_index = $cell.index(); //cell index 0 based
            var row_index = $row.index(); //row index 0 based
            selectedgridName = $grid.dataItem($row).PropertyName; //selected row data
            console.log(selectedgridName);
            var colName = $("#dashboardDataGrid").find('th').eq(cell_index).text()//selected column name
            $("#searchDForm").html('');
            set = false;
            console.log(selectedgridName);
            var grid = $("#gridDashboardData").data("kendoGrid");
            // grid.dataSource.data("");
            externalHeightForGrid = 30;
            setGridHeight(20, "gridDashboardData");
            if (selectedData != null) {
              
                $("#gridDashboardData").data("kendoGrid").dataSource.data($grid.dataItem(this.select()).SubBox);
                $('#dashboardpopupDrill').modal('show');
                $("#DrillPopupFooter").hide();
                $("#searchDFormTemplate").hide();
                $("#DrillDashboardNameLbl").html("<h2>SubBox data for </h2><span class='theme-color'>Name</span> : <span class='theme-color'></span>" + selectedgridName);
            }
            if (selectedData === null) {
                toaster("There are no records to show", "info");
                return;
            }
        }
        else {
            toaster("There are no SubBox to show", "info");
            return;
        }
    } catch (e) {
        console.log(e);
    }
}

function onReportsGridChange(e) {
    try {
     

        var $grid = e.sender; //grid ref
        var columns = $grid.dataItem(this.select()).Columns;
        if (columns.length > 0) {
            var selectedData = $.map(this.select(), function (item) {
                return $(item).text();
            });
            console.log(selectedData);
            var $cell = $grid.select(); // selected td
            var $row = $cell.closest('tr'); //selected tr
            var row_uid = $row.attr('data-uid'); //uid of selected row
            var cell_index = $cell.index(); //cell index 0 based
            var row_index = $row.index(); //row index 0 based
            selectedgridName = $grid.dataItem($row).Name; //selected row data
            console.log(selectedgridName);
            var colName = $("#reportsDataGrid").find('th').eq(cell_index).text()//selected column name
            $("#searchDForm").html('');
            set = false;
            console.log(selectedgridName);
            var grid = $("#gridReportColumnsData").data("kendoGrid");
            // grid.dataSource.data("");
            externalHeightForGrid = 30;
            setGridHeight(20, "gridReportColumnsData");
            if (selectedData != null) {
             
                $("#gridReportColumnsData").data("kendoGrid").dataSource.data($grid.dataItem(this.select()).Columns);
                $('#popupDrill').modal('show');
                $("#DrillPopupFooter").hide();
                $("#searchDFormTemplate").hide();
                $("#DrillReportNameLbl").html("<h2>Column data for </h2><span class='theme-color'>Name</span> : <span class='theme-color'></span>" + selectedgridName);
            }
            if (selectedData === null) {
                toaster("There are no records to show", "info");
                return;
            }
        }
        else {
            toaster("There are no columns to show", "info");
            return;
        }
    } catch (e) {
        console.log(e);
    }
}

function OnSaveReportColumnsChanges(gridName) {
    try {
        var grid = $("#" + gridName).data("kendoGrid");
        var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

        if (dirtyItems.length > 0) {
            $('#popupDrill').modal('hide');
            $("#ModifyReasonUser").val("")
            $("#modifyreasonwindowforUser").show();
            var wdw = $("#myWindowUser").data("kendoWindow");
            wdw.center().open();
            gridNameTriggeredForSave = gridName; //Store the name of the grid for which save will be triggered
        }
        else {
            toaster("No rows has been changed", "info");
        }
    } catch (e) {
        console.log(e);
    }
}
$(".k-grid-cancel-changes").on('click', function (e) {
    try {
        var gridName = this.parentElement.parentElement.id;
        e.preventDefault();
        var grid = $("#" + gridName).data("kendoGrid");
        var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

        if (dirtyItems.length > 0) {
            return true;
        }
        else {
            toaster("No rows has been changed", "info");
        }
    } catch (e) {
        console.log(e);
    }
});


function saveChangeYes() {
    try {
        $('#modifyReason12').val($("#ModifyReasonUser").val());
        if ($.trim($('#modifyReason12').val()) == "") {
            toaster("Please enter the Modify Reason", "error");
            return;
        }
        else {
            $("#" + gridNameTriggeredForSave + " .k-grid-save-changes").trigger("click");
            $("#myWindowUser").data("kendoWindow").close();
            $('#grid').data('kendoGrid').dataSource.read();
        }
    } catch (e) {
        console.log(e);
    }
}
function onReportsGridSave(gridName, e) {
    try {
        //var gridName = this.parentElement.parentElement.id;
        e.preventDefault();
        var grid = $("#" + gridName).data("kendoGrid");
        var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

        if (dirtyItems.length > 0) {
            return true;
        }
        else {
            toaster("No rows has been changed", "info");
        }
    } catch (e) {
        console.log(e);
    }
}
function onReportsGridEditRow() {

}
function onReportColumnsSave(e) {
    duplicateValidate(e, "PropertyName", "PropertyName")
    modifyValid(e);
}

function showInfo() {
    try {
        $("#infoWindow").data("kendoWindow").open().center();
        onTabstripActivate();
    } catch (e) {
        console.log(e);
    }
}

function onTabstripActivate(e) {
    try {

        $('#AdminModulesInfo').html(JSON.stringify(adminModulesInfo, undefined, 2));
      
        if (e.item.innerText.toLowerCase() === "admin modules") {
           $('#AdminModulesInfo').html(JSON.stringify(adminModulesInfo, undefined, 2));
            $("#AdminModulesInfo").removeClass("hidden");
            $("#ReportsInfo").addClass("hidden");
            $("#DashboardsInfo").addClass("hidden");
            $("#AccessConfigurationInfo").addClass("hidden");
        }
        else if (e.item.innerText.toLowerCase() === "reports") {
            $('#ReportsInfo').html(JSON.stringify(reportInfo, undefined, 2));
            $("#AdminModulesInfo").addClass("hidden");
            $("#ReportsInfo").removeClass("hidden");
            $("#DashboardsInfo").addClass("hidden");
            $("#AccessConfigurationInfo").addClass("hidden");
        }
        else if (e.item.innerText.toLowerCase() === "dashboards") {
            $('#DashboardsInfo').html(JSON.stringify(dashboardInfo, undefined, 2));
            $("#AdminModulesInfo").addClass("hidden");
            $("#ReportsInfo").addClass("hidden");
            $("#DashboardsInfo").removeClass("hidden");
            $("#AccessConfigurationInfo").addClass("hidden");
        }
        else if (e.item.innerText.toLowerCase() === "access configuration") {
            $('#AccessConfigurationInfo').html(JSON.stringify(accessConfigurationInfo, undefined, 2));
            $("#AdminModulesInfo").addClass("hidden");
            $("#ReportsInfo").addClass("hidden");
            $("#DashboardsInfo").addClass("hidden");
            $("#AccessConfigurationInfo").removeClass("hidden");
        }
    } catch (e) {
        console.log(e);
    }
}

function RefreshApplication() {
    swal("Confirm to Refresh Application?", "", {
        text: "Note that after refresh, your session will be timed out and will be logged out !",
        icon: "warning",
        buttons: {
            catch: {
                text: "Refresh",
                value: "Refresh",
            },
            defeat: {
                text: "Cancel",
                value: "Cancel",
            }
        },
    })
        .then(function (value) {
           
            switch (value) {
                case "Refresh":
                    var url = window.ApplicationPath + 'OCMConfiguration/RefreshApplication';
                    $.ajax({
                        url: url,
                        type: "POST",
                        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                        success: function (result) {
                            if (result == true) {
                                toaster("Application Refreshed successfully", "success");
                                location.reload();
                            }
                            else {
                                toaster("Application Refresh failed", "error");
                            }
                        },
                        error: function (result) {
                            toaster("Application Refresh failed", "error");
                        }
                    })
                    break;

                case "Cancel":
                    break;
            }
        });
}


var reportInfo =
{

    "JsonVersioningDetails":

    {

        "FileName": "json file name e.g.: “OCMAgentInteractionReport.json",

        "Location": "Location where json is stored",

        "Version": "Latest version no of json file",

        "LastModifiedDateTime": "Last Modified Date Time",

        "LastModifiedBy": "Last Changed by user",

        "Description": "Latest changes done in json file",
    },

    "ReportName": "Report Name e.g.: Agent Interaction Report",

    "Grid":
        [

            {
                /*Main Grid*/
                "Name": "Main Grid Name",
                "ClientDetailTemplateId": "If grid has inner sub grid mention the id e.g.: Template",
                "ClientDetailTemplateColumn": "If grid has inner sub grid , mention the column name     based which sub grid data must fetch",
                "DetailReportName": "Report exports with detailed column of drill down",
                "DetailReportColumnNameOne": "Drilldown column name one e.g. AgentId",
                "DetailReportColumnNameTwo": "Drill down column name two",
                "DetailReportColumnNameThree": "Drill down column name three",
                "IsdetailReport": "detailed report true/false",
                "SummaryDataButton": "Main grid with header summary true/false",
                "Selectable": "grid selection cell/row/none",
                "Change": "on change event of grid",
                "DataBound": "Data Bound event of grid",
                "ColumnHide": "Column Hide event of grid",
                "ColumnShow": "Column show event of grid",
                "ExcelExport": "Export page event of grid",
                "DetailExpand": "Sub grid expansion event of grid",
                "Action": "Read action controller method",
                "Controller": "Controller name",
                "DataParameter": "Java script  method to pass parameter",
                "ServerOperation": "true/false",
                "GridAutoResize": "Grid Auto Resize 0/1 ",
                "PageSize": "Default grid page size. ",

                "Identity": [],             			       /* mention columns if grid as drill down report, on click of   mention column drill down grid will be show, e.g. AgentId or ALL*/
                "ReportAutoCompleteSearch": {                /*auto search dropdown*/
                    "Title": "Agent Name",
                    "PropertyName": "AgentName"
                },
            
                "Columns":
                    [
                        {
                            "Title": "Display name",
                            "PropertyName": "Property name same as table column name",
                            "IncludeInReport": "column included in report true/false ",
                            "IncludeInMenu": "column included in menu true/false ",
                            "Hidden": "Column not include in editor and grid true/false",
                            "ClientTemplate": "column client to template ",
                            "DataFormatType": "Used to format column data ",
                            "ColumnType": "Column Type ",
                            "ColumnGroup": [			       /* Column group to merge multiple columns */
                                {

                                    "Title": "Display name",
                                    "PropertyName": "Property name as per table column name",
                                    "IncludeInReport": "column included in report true/false ",
                                    "IncludeInMenu": "column included in menu true/false ",
                                    "Hidden": "Column not include in editor and grid true/false ",
                                    "ClientTemplate": "column client to template",
                                    "DataFormatType": "Used to format column data ",
                                    "ColumnType": "Column Type ",

                                },
                                {                                    
                                }
                            ]
                        }
                    ]
            }
        ]
}

var adminModulesInfo = {
    "JsonVersioningDetails": {                /* Json version details*/
        "FileName": "json file name e.g.: IvrIntroductoryMessageAnnouncement.json ",
        "Location": "Location where json is stored.",
        "Version": "Latest version no of json file",
        "LastModifiedDateTime": "Last Modified Date Time",
        "LastModifiedBy": "Last Changed by user",
        "Description": "Latest changes done in json file",
    },
    "Name": "Module Name. E.g.: “IvrIntroductoryMessageAnnouncement",
    "DisplayName": "Module Display Name. E.g. : “IVR Introductory Message Announcement",
    "FormGroup": "Form group in editor template",
    "MakerChecker": "Is Maker/Checker concept is enabled true/false",
    "ConfigKey": "Config keys required if any",
    "GridColumns": [
        {
            "Title": "Column Display Name",
            "PropertyName": "Property name same as table column name",
            "Editable": "Column can be editable true/false",
            "ColumnWidth": "Column width in editor template",
            "ID": "Unique Column ID to identify column",
            "FormGroup": "Form group in editor template",
            "Hidden": "Column not include in editor and grid true/false",
            "Width": "Column width in grid",
            "Encoded": "Column data encoded true/false",
            "ClientTemplate": "Template to format column data",
            "DateFormat": "Date column format. E.g. : '{0: dd/MM/yyyy HH:mm:ss}'",
            "ConfigProperty": "Config property if any",
            "Mandatory": "Column data is mandatory true/false",
            "IncludeGrid": "Column hidden in the grid true/false",
            "FieldType": "Column field type",
            "Maxlength": "Max length for the column data",
            "OnKeyUpEvent": "Key up event",
            "OnMouseOutEvent": "Mouse out event",
            "DropDownList": {                                /* Drop box list properties only if FieldType= DropDown*/
                "Action": "Controller method to fetch drop down values",
                "Controller": "Controller Name",
                "AutoBind": "Column auto bind true/false",
                "Event": "Event Name to be fired when dropdown value is changed",
                "DataParameter": "Parameter to be passed",
                "ServerOperation": "Server operation allowed true/false",
                "Enable": "ropdown Enabled true/false",
                "CascadeFrom": "Column Name to cascade from",
            },
            "DateTime": {                                        /* DateTime field properties only if FieldType="DateTime*/
                "MainId": "Column Main ID",
                "SubId": "Column Sub ID",
            },
            "WaveFile": {                                            /* Wave File properties only if FieldType=Upload*/
                "Id": "Unique ID used to save old file name in hidden field on Edit",
                "Name": "Unique Field Name",
                "SelectEventName": "Method to be fired when file is selected",
                "UploadEventName": "Method to upload file",
                "SaveAction": "Method to save file",
                "RemoveAction": "Method to be fired when file is removed",
                "SaveController": "Controller Name of Save Action",
                "RemoveController": "Controller Name of Remove Action",
                "DisplayTag": "ID used to show old file on Edit",
                "Validation": "Extension of upload file allowed eg: .wav"
            },
      "IsDuplicateAllowed": "Duplicate column value allowed true/false",
        },
        {}
  ]
}

var accessConfigurationInfo = {
    "JsonVersioningDetails": {                /* Json version details*/
        "FileName": "AccessConfiguration.json",
        "Location": "Location where json is stored.",
        "Version": "Latest version no of json file",
        "LastModifiedDateTime": "Last Modified Date Time",
        "LastModifiedBy": "Last Changed by user",
        "Description": "Latest changes done in json file",
    },
    "AdminPages": {
        "Channels": [
            {
                "DisplayName": "Display name of channel eg: TMAC",
                "FunctionalityName": "Functionality name of channel eg: TMAC",
                "Included": "Channel to be included in OCM, true/false"
            },
            {

            }
        ],
        "ChannelData": [
            {
                "DisplayName": "Display name of channel eg: OCM Configuration",
                "FunctionalityName": "Functionality name of channel eg: OCMConfiguration",
                "Channel": "Functionality name of channel for which channelData belongs to. eg: Home",
                "Icon": "Display icon of Channel data eg: fas fa-user-cog fa-2x",
                "Included": "ChannelData to be included in OCM under specified channel, true/false"
            },
            {

            }
        ],
        "CheckerChannelData": [
            {
                "DisplayName": "Display name of channel eg: Agent Setting Sync Checker",
                "FunctionalityName": "Functionality name of channel eg: AgentSettingSync",
                "Channel": "Functionality name of channel for which checkerChannelData belongs to. eg: TMAC",
                "Icon": "Display icon of Channel data eg: fas fa-user-cog fa-2x",
                "Included": "CheckerChannelData to be included in OCM under specified channel, true/false"
            },
            {

            }
        ]   
    },
    "Reports": {
        "Channels": [
            {
                "DisplayName": "Display name of channel eg: Agent",
                "FunctionalityName": "Functionality name of channel eg: Agent",
                "Included": "Channel to be included in OCM, true/false"
            },
            {

            }
        ],
        "ChannelData": [
            {
                "DisplayName": "Display name of channel eg: Agent Summary Report",
                "FunctionalityName": "Functionality name of channel eg: AgentSummaryReport",
                "Channel": "Functionality name of channel for which channelData belongs to. eg: Agent",
                "Icon": "Display icon of Channel data",
                "Included": "ChannelData to be included in OCM under specified channel, true/false"
            },
            {

            }
        ],
        "ReadOnlyChannelData": [
            {
                "DisplayName": "Display name of channel eg: Agent Interaction Report ReadOnly",
                "FunctionalityName": "Functionality name of channel eg: AgentInteractionReportReadOnly",
                "Channel": "Functionality name of channel for which ReadOnlyChannelData belongs to. eg: Agent",
                "Icon": "Display icon of Channel data",
                "Included": "ReadOnlyChannelData to be included in OCM under specified channel, true/false"
            },
            {

            }
        ]   
    },
    "Dashboards": {
        "Channels": [
            {
                "DisplayName": "Display name of channel eg: Agent",
                "FunctionalityName": "Functionality name of channel eg: Agent",
                "Included": "Channel to be included in OCM, true/false"
            },
            {

            }
        ],
        "ChannelData": [
            {
                "DisplayName": "Display name of channel eg: Chat Dashboard",
                "FunctionalityName": "Functionality name of channel eg: ChatDashboard",
                "Channel": "Functionality name of channel for which channelData belongs to. eg: Chat",
                "Icon": "Display icon of Channel data",
                "Included": "ChannelData to be included in OCM under specified channel, true/false"
            },
            {

            }
        ]
    },
    "OtherApplications": {
        "Channels": [
            {
                "DisplayName": "Display name of channel eg: TMAC",
                "FunctionalityName": "Functionality name of channel eg: TMAC",
                "Included": "Channel to be included in OCM, true/false"
            },
            {

            }
        ],
        "ChannelData": [
            {
                "DisplayName": "Display name of channel eg: Campaign Manager",
                "FunctionalityName": "Functionality name of channel eg: CampaignManager",
                "Channel": "Functionality name of channel for which channelData belongs to. eg: TMAC",
                "Icon": "Display icon of Channel data eg: fas fa-phone fa-2x",
                "Included": "ChannelData to be included in OCM under specified channel, true/false"
            },
            {

            }
        ]
    }
}

var dashboardInfo = {
    "JsonVersioningDetails": {                /* Json version details*/
        "FileName": "ChatDashboard.json",
        "Location": "Location where json is stored.",
        "Version": "Latest version no of json file",
        "LastModifiedDateTime": "Last Modified Date Time",
        "LastModifiedBy": "Last Changed by user",
        "Description": "Latest changes done in json file",
    },
    "Boxes": [
        {
            "Title": "Display title of the dashboard box, eg: Number of Chats",
            "PropertyName": "PropertyName of the dashboard box, eg: ChatCount",
            "Default": "Default of the dashboard box, eg: 0",
            "Color": "Display color of the dashboard box eg: bg-blue",
            "Icon": "Display icon of the dashboard box eg: ion-chatbubble",
            "Visible": "Visiblilty of dashboard box, true/false",
            "SubBox": [
                {
                    "Title": "Display title of the dashboard subbox, eg: Audio Escalated",
                    "PropertyName": "PropertyName of the dashboard subbox, eg: ChatToAudio",
                    "Default": "Default of the dashboard subbox, eg: 0",
                    "Visible": "Visiblilty of dashboard subbox, true/false"
                },
                {
                    
                }
            ]
        },
        {

        }
    ]
}
