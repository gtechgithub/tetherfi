﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "SocialMediaApplication.js",
        Version: "3.2.6.6",
        LastModifiedDateTime: "06-06-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: ""
    });
});

/**
 * Social Media Application pop up editor window
 */
function onSocialMediaApplicationEdit(e) {
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="Name"]').attr("readonly", true);
        $("#SocialMediaTypeId").data("kendoDropDownList").readonly();
    }
    genericEdit(e);
}

/**
 * Social Media Application create/update
 */
function onSocialMediaApplicationSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Name", "Social Media Type", "Active")
    fieldValues.push(e.model.Name, e.model.SocialMediaTypeId, e.model.Active);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "Name", "Name");
    modifyValid(e)
}
