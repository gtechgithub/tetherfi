﻿$(document).ready(function () {
    /**
        * Define the Version
        * @returns {}
        */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "PersonalizeIvr.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Org. Unit Implemented"
    });
});

var editfieldNames = new Array();
var editfieldValues = new Array();

function onStartPromptWavFileUpload(e) {
    e.data = { functionality: $("#ControllerName").val(), language: "English", module: $("#ControllerName").val() }; //sends the extra parameter to controller
}
function onEndPromptRegisteredWavFileUpload(e) {
    e.data = { functionality: $("#ControllerName").val(), language: "English", module: $("#ControllerName").val() }; //sends the extra parameter to controller
}
function onEndPromptCallingWavFileUpload(e) {
    e.data = { functionality: $("#ControllerName").val(), language: "English", module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

function onStartPromptWavFileRemove(e) {
        $("#StartPromptWaveFile").val("");
}
function onEndPromptRegisteredWavFileRemove(e) {
    $("#EndPromptRegisteredWaveFile").val("");
}
function onEndPromptCallingWavFileRemove(e) {
    $("#EndPromptCallingWaveFile").val("");
}

function CheckForDupplicate(e, obj) {
    e.model.VoicePromptID = $('#VoicePromptID').val();
    var currentVoicePromptID = e.model.VoicePromptID;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].VoicePromptID === currentVoicePromptID) {
            count++;
            if (count === 2) {
                return false;
            }
        }
    }
    return true;
}
function onGridAddRow(e) {
    e.model.StartPromptWaveFile = $("#StartPromptWaveFile").val();
    e.model.EndPromptRegisteredWaveFile = $("#EndPromptRegisteredWaveFile").val();
    e.model.EndPromptCallingWaveFile = $("#EndPromptCallingWaveFile").val();
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].s == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }


    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

    //if (CheckForDupplicate(e, this.dataSource.data()) === true) {
        //for startPromptWaveFile
    if ($("#StartPromptWaveFile").val() !== "") {
        if ($("#StartPromptWaveFile").val().indexOf(".wav") > 0) {
            e.model.StartPromptWaveFile = $("#StartPromptWaveFile").val();
                $(".k-upload-selected").trigger("click");
            }
            else {
                toaster("Please upload only wav file!", "error");
                e.preventDefault();
                return;
            }
        }
        else if (e.model.StartPromptWaveFileTag === "" || e.model.StartPromptWaveFile === "") {
            toaster("Please upload a wav file!", "error");
            e.preventDefault();
        }
        if (e.model.StartPromptWaveFileTag !== "" && e.model.ModifyReason === null) {
            toaster("Please provide modify reason!", "error");
            e.preventDefault();
        }


        //for EndPromptRegisteredWaveFile
        if ($("#EndPromptRegisteredWaveFile").val() !== "") {
            if ($("#EndPromptRegisteredWaveFile").val().indexOf(".wav") > 0) {
                e.model.EndPromptRegisteredWaveFile = $("#EndPromptRegisteredWaveFile").val();
                $(".k-upload-selected").trigger("click");
            }
            else {
                toaster("Please upload only wav file!", "error");
                e.preventDefault();
                return;
            }
        }
        else if (e.model.EndPromptRegisteredWaveFileTag === "" || e.model.EndPromptRegisteredWaveFile === "") {
            toaster("Please upload a wav file!", "error");
            e.preventDefault();
        }
        if (e.model.EndPromptRegisteredWaveFileTag !== "" && e.model.ModifyReason === null) {
            toaster("Please provide modify reason!", "error");
            e.preventDefault();
        }

        //for EndPromptCallingWaveFile
        if ($("#EndPromptCallingWaveFile").val() !== "") {
            if ($("#EndPromptCallingWaveFile").val().indexOf(".wav") > 0) {
                e.model.EndPromptCallingWaveFile = $("#EndPromptCallingWaveFile").val();
                $(".k-upload-selected").trigger("click");
            }
            else {
                toaster("Please upload only wav file!", "error");
                e.preventDefault();
                return;
            }
        }
        else if (e.model.EndPromptCallingWaveFileTag === "" || e.model.EndPromptCallingWaveFile === "") {
            toaster("Please upload a wav file!", "error");
            e.preventDefault();
        }
        if (e.model.EndPromptCallingWaveFileTag !== "" && e.model.ModifyReason === null) {
            toaster("Please provide modify reason!", "error");
            e.preventDefault();
        }

        if (($("#StartPromptWaveFile").val() == $("#EndPromptRegisteredWaveFile").val()) || ($("#StartPromptWaveFile").val() == $("#EndPromptCallingWaveFile").val())
            || ($("#EndPromptRegisteredWaveFile").val() == $("#EndPromptCallingWaveFile").val()))
        {
            toaster("Please choose different wav files!", "error");
            e.preventDefault();
        }
   // }
    validateOrgUnit(e);
}

function onGridEditRow(e) {
    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }

    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $('#VoicePromptID').attr("readonly",true);
        $("#StartPromptWaveFileTag").css("visibility", "visible");
        $("#StartPromptWaveFileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.StartPromptWaveFile + '">' + e.model.StartPromptWaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
       
        $("#EndPromptRegisteredWaveFileTag").css("visibility", "visible");
        $("#EndPromptRegisteredWaveFileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.EndPromptRegisteredWaveFile + '">' + e.model.EndPromptRegisteredWaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
       
        $("#EndPromptCallingWaveFileTag").css("visibility", "visible");
        $("#EndPromptCallingWaveFileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.EndPromptCallingWaveFile + '">' + e.model.EndPromptCallingWaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
        $("#StartPromptWaveFileTag").css("visibility", "hidden");
        $("#EndPromptRegisteredWaveFileTag").css("visibility", "hidden");
        $("#EndPromptCallingWaveFileTag").css("visibility", "hidden");
    }
    genericEdit(e);
    bindingOrgUnit(e);
}

function attachClickHandlerforStartPrompt(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#StartPromptWaveFile")); 
}

function attachClickHandlerforEndPromptRegistered(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#EndPromptRegisteredWaveFile")); 
}

function attachClickHandlerforEndPromptCalling(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#EndPromptCallingWaveFile")); 
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        control.val(fileInfo.name);
    }
}