﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "AgentSkillAssignment.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 03:45:00 PM",
        LastModifiedBy: "Bhagyashree",
        Description: "Removed the skill List from Grid and placed in the tab"
    });
});

//-----------------------------------------------------------------Start of JS from Index.cshtml------------------------------------------------------------------------------
function onSelect(e) {
    $("#" + formType).html('');
    var mystring = e.contentElement.id;
    mystring = mystring.replace('t', '');
    if (mystring !== 'addeditgrid') {
        $('.fa.fa-search').show();
        $('.fa.fa-refresh').show();
        $("#dynamicSearchParam").val(mystring);
        $("#" + $('#dynamicSearchParam').val()).data("kendoGrid").dataSource.read();
    }
    else {
        $('.fa.fa-search').hide();
        $('.fa.fa-refresh').hide();
    }
    TabResize(-15, "", true);
}

//Go's to Agent Setting module to edit/add new agent
function openAgentSetting() {
    window.location = window.ApplicationPath + 'AgentSetting' + '/Index';
}

function loadpartialview() {
    var agentID = $("#agentId").val();

    for (i = 0; i < jsonData.length; i++) {
        $("#" + jsonData[i].Channel.toLowerCase() + "Skill").data("kendoListBox").dataSource.data("");
        $("#selected" + jsonData[i].Channel.toLowerCase() + "Skill").data("kendoListBox").dataSource.data("");
        $("#" + jsonData[i].Channel.toLowerCase() + "SkillLevel").data("kendoListBox").dataSource.data("");
    }

    $('#popupDrill').modal('show');
    $("#DrillReportNameLbl").html("<h3>Agent Skill Assignment</h3><span class='theme-color'>Agent ID:</span> : <span class='theme-color'></span>" + agentID);
    var windowWidget = $("#popup");

    kendo.ui.progress(windowWidget, true);

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'AgentSkillAssignment/GetAgentSkillList',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify({
            'agentId': agentID
        }),
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data !== null) {
                for (i = 0; i < data.AllSkills.length; i++) {
                    let channelName = data.AllSkills[i].Channel.toLowerCase();
                    let skillName = data.AllSkills[i].SkillName;
                    let skillValue = data.AllSkills[i].SkillValue;
                    let skillExtension = data.AllSkills[i].SkillExtension;
                    $("#" + channelName + "Skill").data("kendoListBox").dataSource.add({ SkillName: skillName + " <" + skillExtension + ">", SkillValue: skillValue });
                }

                for (i = 0; i < data.AgentSkills.length; i++) {
                    let channelName = data.AgentSkills[i].Channel.toLowerCase();
                    let skillName = data.AgentSkills[i].SkillName;
                    let skillValue = data.AgentSkills[i].SkillValue;
                    let skillLevel = data.AgentSkills[i].SkillLevel;
                    let skillExtension = data.AgentSkills[i].SkillExtension;
                    $("#selected" + channelName + "Skill").data("kendoListBox").dataSource.add({ SkillName: skillName + " <" + skillExtension + ">", SkillValue: skillValue });
                    $("#" + channelName + "SkillLevel").data("kendoListBox").dataSource.add({ SkillName: skillName + " <" + skillExtension + ">", SkillLevel: skillLevel });
                }

                $("#DrillPopupFooter").hide();
                $("#searchDFormTemplate").hide();
                kendo.ui.progress(windowWidget, false);
            }
        },
        error: function () {
            console.log('Failed to load');
            kendo.ui.progress(windowWidget, false);
        }
    });
}

function onEditSkillTabstripActivate() {
    TabResize(100, "tabstrip_skilledit", true);
    var mainWidth = $("#tabstrip_skilledit .k-content.k-state-active").width();
    var subWidth = (mainWidth / 3) - 10;
    $("#tabstrip_skilledit .k-listbox").css("width", subWidth + "px");
    $("#tabstrip_skilledit label").css("width", subWidth + "px");
}

function onSkill(arg) {
    var tr = $(arg.target).closest("tr"); //get the row for deletion
    gridData = this.dataItem(tr);
    var agentID = gridData.AvayaLoginID;
    $("#agentId").val(agentID);
    console.log(agentID);
    loadpartialview();
}

function saveSkills() {
    var progress = $("#popup");

    kendo.ui.progress(progress, true);

    var channelDataObject = [];
    let i = 0;

    for (i = 0; i < jsonData.length; i++) {
        var selectedChannelListbox = $("#selected" + jsonData[i].Channel.toLowerCase() + "Skill").data("kendoListBox");
        var selectedChannelLevelListbox = $("#" + jsonData[i].Channel.toLowerCase() + "SkillLevel").data("kendoListBox");
        if (selectedChannelListbox.dataSource.data().length > 0) {
            for (j = 0; j < selectedChannelListbox.dataSource.data().length; j++) {
                var channelData = {};
                channelData.Channel = jsonData[i].Channel;
                channelData.SkillName = selectedChannelListbox.dataSource.data()[j].SkillName;
                channelData.SkillValue = selectedChannelListbox.dataSource.data()[j].SkillValue;
                channelData.SkillLevel = selectedChannelLevelListbox.dataSource.data()[j].SkillLevel;
                channelData.enable = 0;
                channelDataObject.push(channelData);
            }
        }
    }

    if (i <= 0) {
        toaster("At least one skill is required", "error");
        kendo.ui.progress(progress, false);
        return;
    }
    agentArray = new Array();
    var agentArray = new Array();
    var agentid = $("#agentId").val();
    agentArray[0] = agentid;
    kendo.ui.progress(progress, false);

    saveAgentSkill(agentArray, channelDataObject);
}

function saveAgentSkill(agentId, channelDataObject) {
    if (agentId == undefined)
        return;

    var progress = $("#popup");

    kendo.ui.progress(progress, true);

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'AgentSkillAssignment/SaveAgentSkills',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { agentId: agentId, channelskilldata: channelDataObject, isMultiSkill: false },
        dataType: 'json',
        success: function (msg) {
            try {
                let isSuccess = false;

                message = msg.Errors;
                // message = msg.saveresult;

                var y = message.hasOwnProperty("Success");
                if (y == true) {
                    for (var i = 0; i < message.Success.errors.length; i++) {
                        toaster(message.Success.errors[i], "success");
                        isSuccess = true;
                    }
                }

                var x = message.hasOwnProperty("Failure");

                if (x === true) {
                    for (var i = 0; i < message.Failure.errors.length; i++) {
                        let msgs = message.Failure.errors[i];
                        if (isSuccess)
                            setTimeout(function () {
                                toaster(msgs, "error");
                            }, 3500);
                        else
                            toaster(message.Failure.errors[i], "error");
                    }
                }
            } catch (e) {
                // toaster(msg, "error");
            }
            //clearskill();
            kendo.ui.progress(progress, false);
        },
        error: function (msg) {
            console.log(msg);
            toaster(msg.d, "error");
            kendo.ui.progress(progress, false);
        },
        timeout: 60000
    });
    var gridDrillOne = $("#grid").data("kendoGrid");
    gridDrillOne.dataSource.read();
    $('#popupDrill').modal('hide');
}
//-----------------------------------------------------------------End of JS from Index.cshtml------------------------------------------------------------------------------

//-----------------------------------------------------------------Start of JS from AddEdit.cshtml----------------------------------------------------------------------------
function LoadData(isUiLoaded) {
    if (isUiLoaded === false) {
        CreateDynamicSkillUi(true);
        $("#tabstrip_multi").kendoTabStrip({
            activate: OnSkillAssignmentActivate,
            contentLoad: OnSkillAssignmentActivate
        });
        TabResize(80, "tabstrip_multi", true);
        initializeGridTooltip('grid');
    }

    $("#AgentList").data("kendoListBox").dataSource.data("");
    $("#SelectedAgentList").data("kendoListBox").dataSource.data("");

    for (i = 0; i < jsonData.length; i++) {
        $("#" + jsonData[i].Channel.toLowerCase() + "MultiSkill").data("kendoListBox").dataSource.data("");
        $("#selected" + jsonData[i].Channel.toLowerCase() + "MultiSkill").data("kendoListBox").dataSource.data("");
        $("#" + jsonData[i].Channel.toLowerCase() + "MultiSkillLevel").data("kendoListBox").dataSource.data("");
    }

    $("#TeamID").data("kendoDropDownList").value("Select");
    $("#TeamID").data("kendoDropDownList").text("Select");

    var progress = $("#query-listboxmulti");

    kendo.ui.progress(progress, true);

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'AgentSkillAssignment/GetAgentName',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify(),
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data != null) {
                // Agent List
                var dataSource;
                var agentlist = $("#AgentList").data("kendoListBox");
                dataSource = new kendo.data.DataSource({ data: data });
                agentlist.setDataSource(dataSource);
                agentlist.dataSource.read();
            }
        },
        error: function () {
            console.log('Failed to load');
        }
    });

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'AgentSkillAssignment/GetSkillList',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify(),
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data !== null) {
                for (i = 0; i < data.AllSkills.length; i++) {
                    let channelName = data.AllSkills[i].Channel.toLowerCase();
                    let skillName = data.AllSkills[i].SkillName;
                    let skillValue = data.AllSkills[i].SkillValue;
                    let skillExtension = data.AllSkills[i].SkillExtension;
                    $("#" + channelName + "MultiSkill").data("kendoListBox").dataSource.add({ SkillName: skillName + " <" + skillExtension + ">", SkillValue: skillValue });
                }
                DynamicListboxWidth();

                kendo.ui.progress(progress, false);
            }
        },
        error: function () {
            console.log('Failed to load');
            kendo.ui.progress(progress, false);
            DynamicListboxWidth();
        }
    });
}

function OnSkillAssignmentActivate() {
    TabResize(80, "tabstrip_multi", true);
    DynamicListboxWidth();
}

function agentSkillChanged() {
    var select = document.getElementById("listAgentSkills");
    var select1 = document.getElementById("listSkillLevels");
    select1.selectedIndex = select.selectedIndex;
}

function saveMultiSkills() {
    var progress = $("#query-listboxmulti");

    kendo.ui.progress(progress, true);

    var channelDataObject = [];
    let i = 0;

    for (i = 0; i < jsonData.length; i++) {
        var selectedChannelListbox = $("#selected" + jsonData[i].Channel.toLowerCase() + "MultiSkill").data("kendoListBox");
        var selectedChannelLevelListbox = $("#" + jsonData[i].Channel.toLowerCase() + "MultiSkillLevel").data("kendoListBox");
        if (selectedChannelListbox.dataSource.data().length > 0) {
            for (j = 0; j < selectedChannelListbox.dataSource.data().length; j++) {
                var channelData = {};
                channelData.Channel = jsonData[i].Channel;
                channelData.SkillName = selectedChannelListbox.dataSource.data()[j].SkillName;
                channelData.SkillValue = selectedChannelListbox.dataSource.data()[j].SkillValue;
                channelData.SkillLevel = selectedChannelLevelListbox.dataSource.data()[j].SkillLevel;
                channelData.enable = 0;
                channelDataObject.push(channelData);
            }
        }
    }

    var agentArray = new Array();

    if (i <= 0) {
        toaster("At least one skill is required", "error");
        kendo.ui.progress(progress, false);
        return;
    }

    var listAgents = $("#SelectedAgentList").data("kendoListBox");
    if (listAgents.dataSource._data.length == 0) {
        toaster("At least one agent is required", "error");
        kendo.ui.progress(progress, false);
        return;
    }

    for (i = 0; i < listAgents.dataSource._data.length; i++) {
        agentArray[i] = listAgents.dataSource._data[i].AvayaLoginId;
    }

    kendo.ui.progress(progress, false);

    saveAgentMultiSkill(agentArray, channelDataObject);
}

function saveAgentMultiSkill(agentId, channelDataObject) {
    if (agentId == undefined)
        return;

    var progress = $("#query-listboxmulti");

    kendo.ui.progress(progress, true);

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'AgentSkillAssignment/SaveAgentSkills',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { agentId: agentId, channelskilldata: channelDataObject, isMultiSkill : true },
        dataType: 'json',
        success: function (msg) {
            try {
                let isSuccess = false;

                message = msg.Errors;

                var y = message.hasOwnProperty("Success");
                if (y === true) {
                    for (var i = 0; i < message.Success.errors.length; i++) {
                        toaster(message.Success.errors[i], "success");
                        isSuccess = true;
                    }
                }

                var x = message.hasOwnProperty("Failure");

                if (x == true) {
                    for (var i = 0; i < message.Failure.errors.length; i++) {
                        let msgs = message.Failure.errors[i];
                        if (isSuccess)
                            setTimeout(function () {
                                toaster(msgs, "error");
                            }, 3500);
                        else
                            toaster(message.Failure.errors[i], "error");
                    }
                }
            } catch (e) {
                console.log(e);
            }
            clearMultiskill();
            kendo.ui.progress(progress, false);
        },
        error: function (msg) {
            console.log(msg);
            toaster(msg.d, "error");
            kendo.ui.progress(progress, false);
        },
        timeout: 60000
    });
}

function clearMultiskill() {
    LoadData(true);
}

function DynamicListboxWidth() {
    try {
        var width = ($("#tabstrip_multi .k-content.k-state-active").width() / 3) - 10;
        $("#tabstrip_multi .k-listbox").css("width", width + "px");
        $("#tabstrip_multi label").css("width", width + "px");
    } catch (e) {
        console.log(e);
    }
}

function onDropdownChange(e) {
    $("#AgentList").data("kendoListBox").dataSource.data("");
    $("#SelectedAgentList").data("kendoListBox").dataSource.data("");

    var progress = $("#query-listboxmulti");

    kendo.ui.progress(progress, true);

    var id = $("#TeamID").val();
    if (id === "Select") {
        var selectid = { "Teamid": "" };
    }
    else {
        var selectid = { "Teamid": id };
        $.ajax({
            type: 'POST',
            url: window.ApplicationPath + "AgentSkillAssignment/GetAgentsByTeamID",
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify(selectid),
            type: 'POST',
            contentType: 'application/json; charset=utf-8',
            success: function (data) {
                // Variable data contains the data you get from the action method
                if (data != null) {
                    // Agent List
                    var dataSource;
                    var agentlist = $("#AgentList").data("kendoListBox");
                    dataSource = new kendo.data.DataSource({ data: data });
                    agentlist.setDataSource(dataSource);
                    agentlist.dataSource.read();
                }
                kendo.ui.progress(progress, false);
            },
            error: function () {
                console.log('Failed to load');
                kendo.ui.progress(progress, false);
            }
        });
    }
}
// used to wait for the children to finish async export
var detailExportPromises = [];
//Used to check if the columns are changed from hidden to not hidden
var exportFlag = false;

function excelexport(e) {
    validateExportExcel(e);
    e.preventDefault();
    if (e.data.length > 0) {
        //var includedColumnList = ['IsManualInEnabled', 'IsTextChatAutoAnswer', 'IsTextChatAutoAcwEnabled', 'IsSecondTextChatAutoAnswer', 'IsHoldVoiceCallOnChatCall', 'IsVoiceAllAutoAcwEnabled', 'IsVoiceAcdAutoAnswerEnabled', 'IsVoiceAcdAutoAcwEnabled', 'IsCrmEnabled'];
        //if (exportFlag === false) { //Initially on click of grid export columns in list includedColumnList will be Hidden in grid so we unhide them
        //    for (i = 0; i < e.sender.columns.length; i++) {
        //        if (includedColumnList.indexOf(e.sender.columns[i].field) > -1) {
        //            //Make the column as Hidden:false
        //            e.sender.showColumn(i);
        //        }
        //    }
        //    //Set the flag to true to indicate that the hidden columns required to show in excel are not hidden
        //    exportFlag = true;
        //    //Again call the ExcelExport event of the grid so that it goes to the else part(below) where the actual export happens
        //    e.sender.saveAsExcel();
        //}
        //else {
            var workbook = e.workbook;
            detailExportPromises = [];

            var masterData = e.data;

            for (var rowIndex = 0; rowIndex < masterData.length; rowIndex++) {
                exportChildData(masterData[rowIndex].AvayaLoginID, rowIndex);
                exportChildSkillData(masterData[rowIndex].AvayaLoginID, rowIndex);
            }

            $.when.apply(null, detailExportPromises)
                .then(function () {
                    // get the export results
                    var detailExports = $.makeArray(arguments);

                    // sort by masterRowIndex
                    detailExports.sort(function (a, b) {
                        return a.masterRowIndex - b.masterRowIndex;
                    });

                    // add an empty column
                    workbook.sheets[0].columns.unshift({
                        //width: 30
                    });

                    // prepend an empty cell to each row
                    for (var i = 0; i < workbook.sheets[0].rows.length; i++) {
                        workbook.sheets[0].rows[i].cells.unshift({});
                    }

                    // merge the detail export sheet rows with the master sheet rows
                    // loop backwards so the masterRowIndex doesn't need to be updated
                    for (var i = detailExports.length - 1; i >= 0; i-=2) {
                        var masterRowIndex = detailExports[i].masterRowIndex + 1; // compensate for the header row

                        var sheet = detailExports[i-1].sheet;

                        var sheet1 = detailExports[i].sheet1;

                        // prepend an empty cell to each row
                        for (var ci = 0; ci < sheet.rows.length; ci++) {
                            if (sheet.rows[ci].cells[0].value) {
                                sheet.rows[ci].cells.unshift({});
                                sheet.rows[ci].cells.unshift({});
                            }
                        }

                        for (var ci = 0; ci < sheet1.rows.length; ci++) {
                            if (sheet1.rows[ci].cells[0].value) {
                                sheet1.rows[ci].cells.unshift({});
                                sheet1.rows[ci].cells.unshift({});
                            }
                        }
                        //Check if the subgrid has any data, usually the first row will be the headers, so we check if length is greater than 1, since the headers will be always present
                        if (sheet.rows.length > 1) {
                            // insert the detail sheet rows after the master row
                            [].splice.apply(workbook.sheets[0].rows, [masterRowIndex + 1, 0].concat(sheet.rows));
                        }

                        if (sheet1.rows.length > 1) {
                            // insert the detail sheet rows after the master row
                            [].splice.apply(workbook.sheets[0].rows, [masterRowIndex + 1, 0].concat(sheet1.rows));
                        }
                        //workbook.sheets[0].rows.unshift({});
                    }

                    // save the workbook
                    kendo.saveAs({
                        dataURI: new kendo.ooxml.Workbook(workbook).toDataURL(),
                        fileName: "Agent Skill Assignment.xlsx"
                    });
                    ////Hide the columns that were marked as Hidden:false to true so that they stay hidden in grid
                    //for (i = 0; i < e.sender.columns.length; i++) {
                    //    if (includedColumnList.indexOf(e.sender.columns[i].field) > -1) {
                    //        //Make the column as Hidden:true
                    //        e.sender.hideColumn(i);
                    //    }
                    //}
                    ////Export is done so setting the flag to false for the next time Export to Excel is clicked in grid
                    //exportFlag = false;
                });
        }
    //}
}

function exportChildData(contactID, rowIndex) {
    var deferred = $.Deferred();

    detailExportPromises.push(deferred);

    var arrayData = []; //Array containing objects of data
    for (i = 0; i < subGridData.length; i++) {
        //Find the agentid from the data
        if (subGridData[i].AgentId === contactID) {
            //Store the matching data in an object
            var testdata = {};
            testdata.Channel = subGridData[i].Channel;
            testdata.BaseInteraction = subGridData[i].BaseInteraction;
            testdata.IsEnable = subGridData[i].IsEnable;
            testdata.TabCount = subGridData[i].TabCount;
            //Push it in an array
            arrayData.push(testdata);
        }
    }
    //Create a temporary datasoure and pass the matched data
    var temporaryDataSource = new kendo.data.DataSource({
        data: arrayData
    });
    //Call read to get the data in the datasource
    temporaryDataSource.read();

    var exporter = new kendo.ExcelExporter({
        columns: [{
            field: "Channel"
        }, {
            field: "BaseInteraction"
        },
        {
            field: "IsEnable"
        },
        {
            field: "TabCount"
        }],
        //dataSource: a
        dataSource: temporaryDataSource
    });

    exporter.workbook().then(function (book, data) {
        deferred.resolve({
            masterRowIndex: rowIndex,
            sheet: book.sheets[0]
        });
    });
}


function exportChildSkillData(contactID, rowIndex) {
    var deferred = $.Deferred();

    detailExportPromises.push(deferred);

    var arrayData = []; //Array containing objects of data
    for (i = 0; i < subGridSkillData.length; i++) {
        //Find the agentid from the data
        if (subGridSkillData[i].AgentId === contactID) {
            //Store the matching data in an object
            var testdata = {};
            testdata.SkillID = subGridSkillData[i].SkillID;
            testdata.SkillName = subGridSkillData[i].SkillName;
            //Push it in an array
            arrayData.push(testdata);
        }
    }
    //Create a temporary datasoure and pass the matched data
    var temporarySkillListDataSource = new kendo.data.DataSource({
        data: arrayData
    });
    //Call read to get the data in the datasource
    temporarySkillListDataSource.read();

    var exporter = new kendo.ExcelExporter({
        columns: [{
            field: "SkillID"
        },
        {
            field: "SkillName"
        }],
        dataSource: temporarySkillListDataSource
    });

    exporter.workbook().then(function (book, data) {
        deferred.resolve({
            masterRowIndex: rowIndex,
            sheet1: book.sheets[0]
        });
    });
}

//-----------------------------------------------------------------End of JS from AddEdit.cshtml------------------------------------------------------------------------------

function CreateDynamicSkillUi(isMultiSkill) {
    try {
        let liDiv = "";
        let liContentDiv = "";
        let i = 0;
        let firstVisibleLi = false;
        let channelName = "";

        //Creating tabstrip li in ul
        for (i = 0; i < jsonData.length; i++) {
            if (jsonData[i].Visible === true) {
                if (firstVisibleLi === false) {
                    liDiv += "<li class='k-state-active'>" + jsonData[i].Display + " Skills</li>";
                    firstVisibleLi = true;
                }
                else {
                    liDiv += "<li>" + jsonData[i].Display + " Skills</li>";
                }
            }
        }
        if (isMultiSkill) {
            $("#tabstrip_multi_ul").empty();
            $("#tabstrip_multi_ul").append(liDiv);
        }
        else {
            $("#tabstrip_skilledit_ul").empty();
            $("#tabstrip_skilledit_ul").append(liDiv);
        }

        i = 0;

        //Creating content for each li
        for (i = 0; i < jsonData.length; i++) {
            if (jsonData[i].Visible === true) {
                channelName = jsonData[i].Channel.toLowerCase();
                let multiSkillAppendName = "";
                isMultiSkill ? multiSkillAppendName = "Multi" : multiSkillAppendName = "";

                //Preparing Content Data to be appended
                liContentDiv = "<div class='" + multiSkillAppendName + "DivClass' id='" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "SkillContent' style='text-align:center;'>" +
                    "<label for='" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill' id= 'columns-label'> " + jsonData[i].Display + " Skills</label>" +
                    "<label for='selected" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill'>Selected " + jsonData[i].Display + " Skills</label>" +
                    "<label for='" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "SkillLevel'>Skill Level</label>" +
                    "<br />" +
                    "<select id='" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill'></select>" +
                    "<select id='selected" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill'></select>" +
                    "<select id='" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "SkillLevel'></select>" +
                    "</div>";

                //Appending Content Data
                if (i === 0) {
                    //When appending first div we clear already existing divs with class MultiDivClass and then append the first div after the ul
                    isMultiSkill ? $("#tabstrip_multi .MultiDivClass").remove() : $("#tabstrip_skilledit .DivClass").remove();
                    isMultiSkill ? $("#tabstrip_multi_ul").after(liContentDiv) : $("#tabstrip_skilledit_ul").after(liContentDiv);
                }
                else {
                    //All other divs except for the first div will be appended after 
                    $("#" + jsonData[i - 1].Channel.toLowerCase() + multiSkillAppendName + "SkillContent").after(liContentDiv);
                }


                //Initializing Listboxes
                //Skill Listbox
                $("#" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill").kendoListBox({
                    draggable: true,
                    selectable: "single",
                    dropSources: "",
                    connectWith: "",
                    dataTextField: "SkillName",
                    dataValueField: "SkillValue",
                    toolbar: {
                        position: "right",
                        tools: ["transferTo", "transferFrom"]
                    }
                });
                //Selected Skill Listbox
                $("#selected" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill").kendoListBox({
                    draggable: true,
                    selectable: "single",
                    dropSources: [jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill"],
                    connectWith: jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill",
                    dataTextField: "SkillName",
                    dataValueField: "SkillValue",
                    add: function (e) {
                        SetChannel(e, true);
                    },
                    remove: function (e) {
                        SetChannel(e, false);
                    }
                });
                $("#" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill").data("kendoListBox").options.dropSources = ["selected" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill"];
                $("#" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill").data("kendoListBox").options.connectWith = "selected" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "Skill";
                //Skill Level Listbox
                $("#" + jsonData[i].Channel.toLowerCase() + multiSkillAppendName + "SkillLevel").kendoListBox({
                    selectable: "single",
                    dataTextField: "SkillLevel",
                    dataValueField: "SkillName"
                }).data("kendoListBox");

                //Resizing Listboxes
                isMultiSkill ? DynamicListboxWidth() : onEditSkillTabstripActivate();
            }
        }
    } catch (e) {
        console.log(e);
    }
}

function UpdateTimeoutTime() {
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/ExtendSession',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data == true) {
                    console.log("Timeout updated.");
                }
            }
        })
    } catch (e) {
        console.log(e);
    }
}
function isInteger(x) {
    return (typeof x === 'number') && (x % 1 === 0);
}
function SetChannel(e, flag) {
    try {
        UpdateTimeoutTime();
        let isMultiSkill = e.sender.options.connectWith.split("Skill")[0].indexOf("Multi") > -1 ? true : false;
        let channel = isMultiSkill ? e.sender.options.connectWith.split("Skill")[0].split("Multi")[0] : e.sender.options.connectWith.split("Skill")[0];
        let removedItems = e.dataItems;
        let multiSkillAppendName = "";
        isMultiSkill ? multiSkillAppendName = "Multi" : multiSkillAppendName = "";
        let skilldata = $("#" + channel + multiSkillAppendName + "SkillLevel").data("kendoListBox");

        if (flag === true) {
            $('#popupDrill').css('display', 'none');
            swal({
                text: "Enter the Skill Level (Not more than " + maxAgentSkillLevel + ")",
                content:
                {
                    element: "input",
                    attributes: {
                        defaultValue: "1"
                    }
                },
                button: {
                    text: "OK",
                    closeModal: false
                }
            })
                .then(function (name) {
                    if (name === "")
                        name = $(".swal-content__input").val();
                    var skill = (isInteger(Number(name)) === false || name === null) ? "" : name;
                    if (skill.trim() === "" || skill.trim() === "0") {
                        swal.stopLoading();
                        swal.close();
                        SetChannel(e, flag);
                    }
                    if (skill.trim() !== "" && skill.trim() !== "0") {
                        if (parseInt(skill) > maxAgentSkillLevel || parseInt(skill) <= 0) {
                            swal.stopLoading();
                            swal.close();
                            skill = "";
                            SetChannel(e, flag);
                        }
                        else {
                            skilldata.dataSource.add({
                                SkillName: e.dataItems[0].SkillName,
                                done: false,
                                SkillLevel: parseInt(skill)
                            });
                            swal.stopLoading();
                            swal.close();
                            isMultiSkill === false ? $('#popupDrill').css('display', 'block') : "";
                        }
                    }
                });
        }
        else {
            var length = skilldata.dataSource._data.length;
            var item, i;
            var raw = skilldata.dataSource._data;
            for (i = length - 1; i >= 0; i--) {
                item = raw[i];
                if (e.dataItems[0].SkillName === skilldata.dataSource._data[i].SkillName) {
                    skilldata.dataSource.remove(item);
                }
            }
        }
    } catch (e) {
        console.log(e);
    }
}