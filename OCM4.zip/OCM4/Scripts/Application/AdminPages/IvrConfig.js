﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrConfig.js",
        Version: "3.2.9.1801",
        LastModifiedDateTime: "14-11-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Applied Module hierarchy"
    });
});

var editfieldNames = new Array();
var editfieldValues = new Array();

function editIvrConfig(e)
{
    var editjsonfield = jsonfields.GridColumns;
    for (i = 0; i < editjsonfield.length; i++) {
        if (editjsonfield[i].Hidden != true) {
            editfieldNames.push(editjsonfield[i].Title)
            editfieldValues.push(e.model[editjsonfield[i].PropertyName]);
        }
    }
    if (e.model.isNew() != true) {
        $("#Parameter").data("kendoDropDownList").enable(false);
    }
    
    genericEdit(e);
    bindingOrgUnit(e);
}

function onSaveIvrConfig(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
        else if (e.model.isNew() != true) { //check for duplicate on save old record while editing
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                if (field[i].Title == editfieldNames[i] & e.model[field[i].PropertyName] != editfieldValues[i]) {
                    duplicateValidate(e, field[i].PropertyName, field[i].Title);
                }
            }
        }
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    validateOrgUnit(e);
    modifyValid(e);
}