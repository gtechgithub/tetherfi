﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "UserManagement.js",
         Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreenitha",
        Description: "Changed id for export check boxes- fixed check box issue in grid"
    });

    initializeGridTooltip('grid');
    initializeGridTooltip('gridUserAccessDetails');
    initializeGridTooltip('gridAdminPagesCheckerAccessDetails');
    initializeGridTooltip('gridReportUserAccessDetails');
    initializeGridTooltip('gridDashboardAccessDetails');
    initializeGridTooltip('gridOtherApplicationsAccessDetails');
    enableDisableGridAutoResize = 1;
    //TabResize(0, "tabstrip", false);
    $("#tabstrip").kendoTabStrip({
        activate: onUserManagementTabstripActivate,
        animation: {
            open: {
                effects: "fadeIn"
            }
        }
    });
});

var gridNameTriggeredForSave = ""; //Used to store the name of the subGrid for which save will be triggered

/*********************************************************************************Start of Main Grid JS***********************************************************************************************/
function onUserManagementMainGridEdit(e) {
    var grid = $('#grid').data("kendoGrid");
    grid.clearSelection();
    genericEdit(e);
}

function onUserManagementMainGridSave(e) {
    try {
        var UserId = e.model.UserId;
        duplicateValidate(e, "UserId", "UserId")
        if (UserId == "") {
            toaster("Please provide User ID", "error");
            e.preventDefault();
            return;
        }

        if (UserId.indexOf("\"") >= 0) {
            toaster("Double quotes are not acceptable for username", "error");
            e.preventDefault();
            return;
        }

        if (UserId.indexOf("\\") < 1) {
            toaster("Please provide user domain ID", "error");
            e.preventDefault();
            return;
        }

        if (UserId == "reg1\\") {
            toaster("Please provide user ID", "error");
            e.preventDefault();
            return;
        }

        if (UserId.length <= UserId.indexOf("\\") + 1) {
            toaster("Please provide user ID", "error");
            e.preventDefault();
            return;
        }
        modifyValid(e);

    } catch (e) {
        console.log(e);
    }
}

function onUserManagementMainGridChange(arg) {
    try {
        var selectedData = $.map(this.select(), function (item) {
            return $(item).text();
        });
        console.log(selectedData);
        var $grid = arg.sender; //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var row_uid = $row.attr('data-uid'); //uid of selected row
        var cell_index = $cell.index(); //cell index 0 based
        var row_index = $row.index(); //row index 0 based
        var UserId = $grid.dataItem($row).UserId; //selected row data
        console.log(UserId);
        var colName = $("#grid").find('th').eq(cell_index).text()//selected column name
        $("#searchDForm").html('');
        set = false;
        console.log(UserId);
        $("#UserId").val(UserId);
        var grid = $("#gridUserAccessDetails").data("kendoGrid");
        grid.dataSource.data("");
        externalHeightForGrid = 30;
        setGridHeight(20, "gridUserAccessDetails");
        if (selectedData != null) {
            $("#isAdminPage").val(true);
            $("#isAdminPageChecker").val(false);
            $("#isReport").val(false);
            $("#isDashboard").val(false);
            $("#isOtherApplication").val(false);
            $("#gridUserAccessDetails").data("kendoGrid").dataSource.read();
            $('#popupDrill').modal('show');
            $("#DrillPopupFooter").hide();
            $("#searchDFormTemplate").hide();
            $("#DrillReportNameLbl").html("<h2>Page Based User Access</h2><span class='theme-color'>UserId</span> : <span class='theme-color'></span>" + UserId);
            $("#tabstrip").kendoTabStrip().data("kendoTabStrip").select(0);
            grid.dataSource.read();
        }
        if (selectedData === null) {
            toaster("There are no records to show", "info");
            return;
        }
    } catch (e) {
        console.log(e);
    }
}

function OnUserManagementMainGridDataBound(e) {
    try {
        externalHeightForGrid = 0;
        onDataBound(e);
    } catch (e) {
        console.log(e);
    }
}
/*********************************************************************************End Of Main Grid JS************************************************************************************************/

/*********************************************************************************Start Of Sub Grid JS************************************************************************************************/
//Function called whenever a checkbox is checked
//$(function () {
//    try {
//        $('#gridUserAccessDetails').on('click', '.chkbx', function () {
//            var checked = $(this).is(':checked');
//            var grid = $('#gridUserAccessDetails').data().kendoGrid;
//            var dataItem = grid.dataItem($(this).closest('tr'));
//            dataItem.set('Access', checked);
//        })
//    } catch (e) {
//        console.log(e);
//    }
//})

function onUserManagementTabstripActivate(e) {
    try {
        let gridName = "";
        console.log(e);
        if (e.item.innerText.toLowerCase() === "admin pages") {
            $("#isAdminPage").val(true);
            $("#isAdminPageChecker").val(false);
            $("#isReport").val(false);
            $("#isDashboard").val(false);
            $("#isOtherApplication").val(false);
            gridName = "gridUserAccessDetails";
            $("#" + gridName).data("kendoGrid").dataSource.read();
        }
        else if (e.item.innerText.toLowerCase() === "admin pages checker") {
            $("#isAdminPage").val(false);
            $("#isAdminPageChecker").val(true);
            $("#isReport").val(false);
            $("#isDashboard").val(false);
            $("#isOtherApplication").val(false);
            gridName = "gridAdminPagesCheckerAccessDetails";
            $("#" + gridName).data("kendoGrid").dataSource.read();
        }
        else if (e.item.innerText.toLowerCase() === "reports") {
            $("#isAdminPage").val(false);
            $("#isAdminPageChecker").val(false);
            $("#isReport").val(true);
            $("#isDashboard").val(false);
            $("#isOtherApplication").val(false);
            gridName = "gridReportUserAccessDetails";
            $("#" + gridName).data("kendoGrid").dataSource.read();
            //$("#gridReportUserAccessDetails").data("kendoGrid").dataSource.read();
        }
        else if (e.item.innerText.toLowerCase() === "dashboards") {
            $("#isAdminPage").val(false);
            $("#isAdminPageChecker").val(false);
            $("#isReport").val(false);
            $("#isDashboard").val(true);
            $("#isOtherApplication").val(false);
            gridName = "gridDashboardAccessDetails";
            $("#" + gridName).data("kendoGrid").dataSource.read();
            //$("#gridDashboardAccessDetails").data("kendoGrid").dataSource.read();
        }
        else if (e.item.innerText.toLowerCase() === "other applications") {
            $("#isAdminPage").val(false);
            $("#isAdminPageChecker").val(false);
            $("#isReport").val(false);
            $("#isDashboard").val(false);
            $("#isOtherApplication").val(true);
            gridName = "gridOtherApplicationsAccessDetails";
            $("#" + gridName).data("kendoGrid").dataSource.read();
            //$("#gridOtherApplicationsAccessDetails").data("kendoGrid").dataSource.read();
        }
       
        externalHeightForGrid = 30;
        setGridHeight(20, gridName);
        TabResize(20, "tabstrip", false);
    } catch (e) {
        console.log(e);
    }
}

//Function to check the checkboxes when loading data
function onUserManagementSubGridDatabound(e) {
    try {
        e.sender.items().each(function () {
            var dataItem = e.sender.dataItem(this);
            if (dataItem.Access != null && !dataItem.Access) {
                dataItem.AddAccess = dataItem.EditAccess = dataItem.DeleteAccess = dataItem.ExportAccess = false;
                $(this).find('input[id="checkAddAccess"]').attr("disabled", true);
                $(this).find('input[id="checkEditAccess"]').attr("disabled", true);
                $(this).find('input[id="checkDeleteAccess"]').attr("disabled", true);
                $(this).find('input[id="checkExportAccess"]').attr("disabled", true);
                $(this).find('input[id="checkReportExportAccess"]').attr("disabled", true);
            }
            if (dataItem.Access) {
                $(this).addClass("k-state-selected");
            }
            kendo.bind(this, dataItem);
        });
        
        onDataBound(e);
        externalHeightForGrid = 0;
        setGridHeight(20);
        //TabResize(100, "tabstrip", false);
        $("#checkAll")[0].checked = $("#checkAccess:checked").length === e.sender.dataSource.view().length;
        $("#checkAllAdminPagesChecker")[0].checked = $("#checkAdminPagesCheckerAccess:checked").length === e.sender.dataSource.view().length;
        $("#checkAllReport")[0].checked = $("#checkReportAccess:checked").length === e.sender.dataSource.view().length;
        $("#checkAllDashboard")[0].checked = $("#checkDashboardAccess:checked").length === e.sender.dataSource.view().length;
        $("#checkAllOtherApplications")[0].checked = $("#checkOtherApplicationsAccess:checked").length === e.sender.dataSource.view().length;

        $("#checkAllAddAccess")[0].disabled = $("#checkAddAccess:disabled").length > 0;
        $("#checkAllEditAccess")[0].disabled = $("#checkEditAccess:disabled").length > 0;
        $("#checkAllDeleteAccess")[0].disabled = $("#checkDeleteAccess:disabled").length > 0;
        $("#checkAllExportAccess")[0].disabled = $("#checkExportAccess:disabled").length > 0;
        $("#checkAllReportExportAccess")[0].disabled = $("#checkReportExportAccess:disabled").length > 0;

        $("#checkAllAddAccess")[0].checked = $("#checkAddAccess:checked").length == e.sender.dataSource.view().length;
        $("#checkAllEditAccess")[0].checked = $("#checkEditAccess:checked").length == e.sender.dataSource.view().length;
        $("#checkAllDeleteAccess")[0].checked = $("#checkDeleteAccess:checked").length == e.sender.dataSource.view().length;
        $("#checkAllExportAccess")[0].checked = $("#checkExportAccess:checked").length == e.sender.dataSource.view().length;
        $("#checkAllReportExportAccess")[0].checked = $("#checkReportExportAccess:checked").length == e.sender.dataSource.view().length;
    } catch (e) {
        console.log(e);
    }
}

var modifyReason = "";
function onUserManagementSubGridSave(e) {
    e.data = {
        value: $('#modifyReason12').val()
    };
    e.sender._data[0].ModifyReason = modifyReason;
}

function OnSaveSubGridAccessChanges(gridName) {
    try {
        var grid = $("#" + gridName).data("kendoGrid");
        var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

        if (dirtyItems.length > 0) {
            $('#popupDrill').modal('hide');
            $("#ModifyReasonUser").val("")
            $("#modifyreasonwindowforUser").show();
            var wdw = $("#myWindowUser").data("kendoWindow");
            wdw.center().open();
            gridNameTriggeredForSave = gridName; //Store the name of the grid for which save will be triggered
        }
        else {
            toaster("No rows has been changed", "info");
        }
    } catch (e) {
        console.log(e);
    }
}

$(".k-grid-cancel-changes").on('click', function (e) {
    try {
        var gridName = this.parentElement.parentElement.id;
        e.preventDefault();
        var grid = $("#" + gridName).data("kendoGrid");
        var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

        if (dirtyItems.length > 0) {
            return true;
        }
        else {
            toaster("No rows has been changed", "info");
        }
    } catch (e) {
        console.log(e);
    }
});

$('.k-grid-save-changes').hide();

function SyncSubGrid(e) {
    if (e.type == "update" || e.type == "delete" || e.type == "create") {
        e.sender.read();
        $('.k-grid-update').html('<span class="k-icon k-i-check"></span> Save');
    }
}

function SubGridGenericRequest(e) {
    try {
        var message = "";
        if (e.type === "update") {
            //$("#gridUserAccessDetails").data("kendoGrid").dataSource.read();
            //$("#gridReportUserAccessDetails").data("kendoGrid").dataSource.read();
            //$("#gridDashboardAccessDetails").data("kendoGrid").dataSource.read();
            //$("#gridOtherApplicationsAccessDetails").data("kendoGrid").dataSource.read();
            message = e.response.Errors;
            var y = message.hasOwnProperty("Success");
            if (y == true)
                toaster(message.Success.errors[0], "success");
            else
                toaster(message.Failure.errors[0], "error");
        }
    } catch (e) {
        console.log(e);
    }
}

//function SelectAllAccess(access) {
//    try {
//        var state = $(access).is(':checked');
//        var grid = $('#gridUserAccessDetails').data().kendoGrid;
//        $.each(grid.dataSource.view(), function () {
//            if (this['Access'] != state)
//                this.dirty = true;
//            this['Access'] = state;
//        });
//        grid.refresh();
//    } catch (e) {
//        console.log(e);
//    }
//}

//Modify Reason Window Methods
function saveChangeYes() {
    try {
        $('#modifyReason12').val($("#ModifyReasonUser").val());
        if ($.trim($('#modifyReason12').val()) == "") {
            toaster("Please enter the Modify Reason", "error");
            return;
        }
        else {
            $("#" + gridNameTriggeredForSave + " .k-grid-save-changes").trigger("click");
            $("#myWindowUser").data("kendoWindow").close();
            $('#grid').data('kendoGrid').dataSource.read();
        }
    } catch (e) {
        console.log(e);
    }
}

function saveChangeNo() {
    $("#myWindowUser").data("kendoWindow").close();
}

function checkAllAddAccess(ele, gridName) {
    try {
        var state = $(ele).is(':checked');
        var grid = $('#' + gridName).data().kendoGrid;
        $.each(grid.dataSource._pristineData, function () {
            $that = this;
            $.each(grid.dataSource.view(), function () {
                if (this.FunctionalityName == $that.FunctionalityName) {
                    this['AddAccess'] = state;
                    this.dirty = CheckIfDirty(this, $that);
                    return false;
                }
            });
        });
        grid.refresh();
    } catch (e) {
        console.log(e);
    }
}

function checkAllEditAccess(ele, gridName) {
    try {
        var state = $(ele).is(':checked');
        var grid = $('#' + gridName).data().kendoGrid;
        $.each(grid.dataSource._pristineData, function () {
            $that = this;
            $.each(grid.dataSource.view(), function () {
                if (this.FunctionalityName == $that.FunctionalityName) {
                    this['EditAccess'] = state;
                    this.dirty = CheckIfDirty(this, $that);
                    return false;
                }
            });
        });
        grid.refresh();
    } catch (e) {
        console.log(e);
    }
}

function checkAllDeleteAccess(ele, gridName) {
    try {
        var state = $(ele).is(':checked');
        var grid = $('#' + gridName).data().kendoGrid;
        $.each(grid.dataSource._pristineData, function () {
            $that = this;
            $.each(grid.dataSource.view(), function () {
                if (this.FunctionalityName == $that.FunctionalityName) {
                    this['DeleteAccess'] = state;
                    this.dirty = CheckIfDirty(this, $that);
                    return false;
                }
            });
        });
        grid.refresh();
    } catch (e) {
        console.log(e);
    }
}

function checkAllExportAccess(ele, gridName) {
    try {
        var state = $(ele).is(':checked');
        var grid = $('#' + gridName).data().kendoGrid;
        $.each(grid.dataSource._pristineData, function () {
            $that = this;
            $.each(grid.dataSource.view(), function () {
                if (this.FunctionalityName == $that.FunctionalityName) {
                    this['ExportAccess'] = state;
                    this.dirty = CheckIfDirty(this, $that);
                    return false;
                }
            });
        });
        grid.refresh();
    } catch (e) {
        console.log(e);
    }
}

function checkAll(ele, gridName) {
    try {
        var state = $(ele).is(':checked');
        var grid = $('#' + gridName).data().kendoGrid;
        $.each(grid.dataSource._pristineData, function () {
            $that = this;
            $.each(grid.dataSource.view(), function () {
                if (this.FunctionalityName == $that.FunctionalityName) {
                    if (state === false) {
                        //Change the state in the model for ADD,Edit,Delete,Export
                        this['AddAccess'] = state;
                        this['EditAccess'] = state;
                        this['DeleteAccess'] = state;
                        this['ExportAccess'] = state;
                    }
                    this['Access'] = state;
                    this.dirty = CheckIfDirty(this, $that);
                    return false;
                }
            });
        });
        grid.refresh();
    } catch (e) {
        console.log(e);
    }
}
/*********************************************************************************End Of Sub Grid JS************************************************************************************************/

function getData() {
    return {
        UserId: $("#UserId").val(),
        isAdminPage: $("#isAdminPage").val(),
        isAdminPageChecker: $("#isAdminPageChecker").val(),
        isReport: $("#isReport").val(),
        isDashboard: $("#isDashboard").val(),
        isOtherApplication: $("#isOtherApplication").val(),
        modifyReason: $('#modifyReason12').val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

/**
 * Function called when any single checkbox of View, Add, Edit, Delete, Export functionality is checked/unchecked
 * @param e contains the selected checkbox
 * @param type what is the type of access whose state is to be changed
 */
function ChangeAccess(e, type, gridName) {
    try {
        //After the checkbox state is changed store its changed state in variable
        var state = $(e).is(':checked');
        var grid = $("#" + gridName).data("kendoGrid");
        //Get all details of the grid row based on the location of the selected checkbox
        var gridData = grid.dataItem($(e).closest("tr"));
        $.each(grid.dataSource._pristineData, function () {
            //Find the old data of the grid to compare
            if (this.FunctionalityName == gridData.FunctionalityName) {

                if (gridName === "gridUserAccessDetails") {
                    if (state === false && type === 'Access') {
                        //Change the state in the model for ADD,Edit,Delete,Export
                        gridData['AddAccess'] = state;
                        gridData['EditAccess'] = state;
                        gridData['DeleteAccess'] = state;
                        gridData['ExportAccess'] = state;
                    }
                }
                if (gridName == "gridAdminPagesCheckerAccessDetails") {
                    gridData['AddAccess'] = false;
                    gridData['EditAccess'] = false;
                    gridData['DeleteAccess'] = false;
                    gridData['ExportAccess'] = false;
                }
                if (gridName == "gridReportUserAccessDetails") {
                    gridData['AddAccess'] = false;
                    gridData['EditAccess'] = false;
                    gridData['DeleteAccess'] = false;
                    if (state === false && type === 'Access') {
                        //Change the state in the model for ADD,Edit,Delete,Export

                        gridData['ExportAccess'] = state;
                    }
                }
                if (gridName == "gridDashboardAccessDetails") {
                    //Change the state in the model for ADD,Edit,Delete,Export
                    gridData['AddAccess'] = false;
                    gridData['EditAccess'] = false;
                    gridData['DeleteAccess'] = false;
                    gridData['ExportAccess'] = false;
                }
                if (gridName == "gridOtherApplicationsAccessDetails") {
                    //Change the state in the model for ADD,Edit,Delete,Export
                    gridData['AddAccess'] = false;
                    gridData['EditAccess'] = false;
                    gridData['DeleteAccess'] = false;
                    gridData['ExportAccess'] = false;
                }
                //Change the state in the model
                gridData[type] = state;
                //Compare if the initial(old) grid data access values with the current one, if same that means nothing is changed so dirty will be false else we set it to true
                gridData.dirty = CheckIfDirty(gridData, this);
                return false;
            }
        });
        grid.refresh();
        
    } catch (e) {
        console.log(e);
    }
}

/**
 * Check if View, Add, Edit, Delete, Export access type in both objects are same
 * @param element
 * @param gridData
 * @returns If both are not same then we return true, if they are same we return false
 */
function CheckIfDirty(element, gridData) {
    try {
        if (element.Access != gridData.Access || element.AddAccess != gridData.AddAccess || element.EditAccess != gridData.EditAccess || element.DeleteAccess != gridData.DeleteAccess || element.ExportAccess != gridData.ExportAccess) {
            return true;
        }
        else {
            return false;
        }
    } catch (e) {
        console.log(e);
    }
}

$("#popupDrill").on("hidden.bs.modal", function () {
    externalHeightForGrid = 0;
    setGridHeight(0, "grid");
});

//function checkAll(input) {
//    var grid = $("#grid").data("kendoGrid");
//    var items = grid.items();
//    items.each(function () {
//        var dataItem = grid.dataItem(this);
//        if (dataItem.Access != input.checked) {
//            dataItem.Access = input.checked;
//            dataItem.dirty = true;
//        }
//    })
//    grid.dataSource.sync();
//}