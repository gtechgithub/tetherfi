﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "DynamicReportDesigner.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Version Changed."
    });
});
//Start of Javascript for Index Page
function onReportSave(e) {
    duplicateValidate(e, "Value", "Value");
    duplicateValidate(e, "Name", "Name");
    modifyValid(e);
}

function onReportListEdit(e) {
    genericEdit(e);
}

function tabChange() {
    var tabstrip = $("#tabstrip").kendoTabStrip().data("kendoTabStrip");
    var myTab = tabstrip.tabGroup.children("li").eq(1);
    tabstrip.select(myTab);
    $("#grid").data("kendoGrid").dataSource.read();
}

function CreateReport() {
    tabChange();
    $("#reportName").val("");
    $("#reportName").attr("disabled", false);
    $("#tables").data("kendoDropDownList").dataSource.read();
    var listbox = $("#selectedColumns").data("kendoListBox");
    listbox.dataSource.data("");
    $("#saveQuery").show();
    $("#updateQuery").hide();
    $("#sqlQuery").val("");
    ClearAllJoins();
}

function CustomEdit(e) {
    var tr = $(e.target).closest("tr");
    var rowdata = this.dataItem(tr);
    var query = rowdata.ReportQuery;
    var reportName = rowdata.ReportName;
    $("#sqlQuery").val(query);
    $("#reportName").val(reportName);
    $("#reportName").attr("disabled", true);
    $("#saveQuery").hide();
    $("#updateQuery").show();

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'DynamicReportDesigner/GetEditColumns', //'@Url.Action("GetEditColumns", "DynamicReport")',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify({
            'query': query
        }),
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data != null) {
                var editColumns = $("#selectedColumns").data("kendoListBox");
                var dataSource = new kendo.data.DataSource({ data: data });
                editColumns.setDataSource(dataSource);
                editColumns.dataSource.read();
            }
        },
        error: function () {
            console.log('Failed to load');
        }
    });

    ClearAllJoins();
    tabChange();
}

//End of Javascript for Index Page
//---------------------------------------------------------
//Start of Javascript for AddEdit Page
var join = "";
var where = "";
var orderBy = "";
var rem = new Array();

function AddJoins() {
    var fromTable = $("#fromTable").val();
    var joinTable = $("#joinTable").val();
    var joinFromTable = $("#joinFromTables").val();
    var joinType = $("#joinType").val();
    var joinToTable = $("#joinToTables").val();
    var joinFromTableColumn = $("#joinFromTableColumns").val();
    var joinToTableColumn = $("#joinToTableColumns").val();


    rem.push(fromTable);
    rem.push(joinTable);
    rem = rem.filter(function (itm, i, rem) {
        return i == rem.indexOf(itm);
    });

    if (fromTable != "" && joinTable != "" && joinFromTable != "" && joinType != "" && joinToTable != "" && joinFromTableColumn != "" && joinToTableColumn != "") {
        if (join == "") {
            join += "FROM\r\n\t" + fromTable + "\r\n\t" + joinType + " " + joinTable + " ON " + joinFromTable + "." + joinFromTableColumn + " = " + joinToTable + "." + joinToTableColumn;
        }
        else {
            join += "\r\n\t" + joinType + " " + joinTable + " ON " + joinFromTable + "." + joinFromTableColumn + " = " + joinToTable + "." + joinToTableColumn;
        }
        if (rem.length > 0) {
            var tab = $("#joinToTables").data("kendoDropDownList").dataItems();
            var remainingTables = tab.filter(function (el) {
                return rem.indexOf(el) < 0;
            });
            
            Addwhereclause();
            //var whereclause = where != "" ? "\r\n\t" + where + ";" : ";";
            var whereclause = where != "" ? "\r\n\t" + where : "";
            AddOrderByClause();
            var orderByClause = orderBy != "" ? "\r\n\t" + orderBy + ";" : ";";
            remainingTables.length > 0 ? $("#joinQuery").val(join + ",\r\n\t" + remainingTables + whereclause + orderByClause) : $("#joinQuery").val(join + whereclause + orderByClause);
        }
        else {
            $("#joinQuery").val(join + ";");
        }
        $("#fromTable").data("kendoDropDownList").enable(false);
        resetJoin();
    }
    else {
        
        Addwhereclause();
        AddOrderByClause();
        if (where == "" && orderBy == "") {
            toaster("Select the table columns to join", "error");
        }
        else {
            var final = "";
            var text = "";
            var con = where + ";";
            if (join != "") {
                text = $("#joinQuery").val();
            }
            else {
                text = "FROM" + $("#sqlQuery").val().split("FROM")[1];
            }
            final = text;
            if (where != "") {
                //final = text.indexOf("WHERE") >= 0 ? text.split("WHERE")[0] + con : text.replace(";", con);
                final = text.indexOf("WHERE") >= 0 ? text.split("WHERE")[0] + con : (text.indexOf("ORDER BY") >= 0 ? text.split("ORDER BY")[0] + con + " ORDER BY " + text.split("ORDER BY")[1] : text.replace(";", con));
            }

            var orderByInQuery = text.indexOf("ORDER BY") >= 0 ? text.split("ORDER BY")[1] : "";
           
            if (orderBy != "") {
                var orderByClause = "\r\n\t" + orderBy + ";";
                final = final.indexOf("ORDER BY") >= 0 ? final.split("ORDER BY")[0] + orderByClause : final.replace(";", orderByClause);
               
                //final = final.replace(";", orderByClause);                
            }
            else if (orderByInQuery != "")
            {
                final = final.replace(";", orderByInQuery);
            }
            $("#joinQuery").val(final);
            resetJoin();
        }
    }
}

function AddOrderByClause() {
    var orderByTable = $("#orderByTables").val();
    var orderByColumn = $("#orderByColumns").val();
    if (orderByTable != "" && orderByColumn != "") {
       // var clause = orderByTable + "." + orderByColumn;
        var clause = orderByColumn;
        orderBy += orderBy == "" ? "   ORDER BY " + clause : ", " + clause;
    }
}

function Addwhereclause() {
    var lhsTable = $("#whereLHSTables").val();
    var lhsColumn = $("#whereLHSColumns").val();
    var condition = $("#whereCondition").val();
    var text = $("#whereText").val();
    var rhsTable = $("#whereRHSTables").val();
    var rhsColumn = $("#whereRHSColumns").val();
    var rhsValue = "";



    if (lhsTable != "" && lhsColumn != "" && condition != "") {
        var column = $("#whereLHSColumns").val().toUpperCase();
        if (!(column.indexOf("DATE") >= 0 || column.indexOf("TIME") >= 0 || column.indexOf("DATETIME") >= 0)) {
            if (condition != "Like" && condition != "Is NULL" && condition != "Is NOT NULL") {
                if (text == "" && rhsTable == "" && rhsColumn == "") {
                    toaster("Select the table columns/text to where clause", "error");
                }
                else {
                    rhsValue = text != "" ? "'" + text + "'" : rhsTable + "." + rhsColumn;
                }
            }
            else if (condition == "Like") {
                if (text == "") {
                    toaster("Enter table columns/text to where clause", "error");
                }
                rhsValue = text != "" ? "'" + text + "'" : rhsValue;
            }

            var clause = lhsTable + "." + lhsColumn + " " + condition + " " + rhsValue;
            where += where == "" ? "   WHERE " + clause : " \r\n\tAND " + clause;
        }

        else {
            var appendClause = "";
            if (column.indexOf("DATETIME") >= 0 || column.indexOf("ON") >= 0) { appendClause = condition.indexOf(">") >= 0 ? "ParameterFromDateTime" : condition.indexOf("<") >= 0 ? "ParameterToDateTime" : "ParameterDateTime"; }
            else if (column.indexOf("DATE") >= 0) { appendClause = condition.indexOf(">") >= 0 ? "DateFromParameter" : condition.indexOf("<") >= 0 ? "DateToParameter" : "DateParameter"; }
            else if (column.indexOf("TIME") >= 0) { appendClause = condition.indexOf(">") >= 0 ? "TimeFromParameter" : condition.indexOf("<") >= 0 ? "TimeToParameter" : "TimeParameter"; }
            var clause = lhsTable + "." + lhsColumn + " " + condition + " " + appendClause;
            where += where == "" ? "WHERE " + clause : " \r\n\tAND " + clause;
        }
        //var OrderByString = where.split("WHERE")[1].split(".")[1].split(" ")[0];
        //where += " ORDER BY "+ OrderByString;
    }
}

function getDateTimeColumnCondition() {
    var lhsTable = $("#whereLHSTables").val();
    var lhsColumn = $("#whereLHSColumns").val();
    var column = $("#whereLHSColumns").val().toUpperCase();
    if (column.indexOf("DATE") >= 0 || column.indexOf("TIME") >= 0 || column.indexOf("DATETIME") >= 0) {

        $("#RHSCondition").hide();
    }
    else {
        $("#RHSCondition").show();
    }
}

function getTableColumns() {
    var tableSelected = $("#tables").val();
    if (tableSelected != "") {
        $("#tableColumns").data("kendoListBox").dataSource.read({ tableSelected: tableSelected });
    }
    else {
        $("#tableColumns").val("");
    }
}

function getJoinFromTableColumns() {
    var tableSelected = $("#joinFromTables").val();
    $("#joinFromTableColumns").val("");
    if (tableSelected != "") {
        $("#joinFromTableColumns").data("kendoDropDownList").dataSource.read({ tableSelected: tableSelected });//, connString: connString });

    }
    else {
        $("#joinFromTableColumns").val("");
    }
}

function getJoinToTableColumns() {
    var tableSelected = $("#joinToTables").val();
    $("#joinToTableColumns").val("");
    if (tableSelected != "") {
        $("#joinToTableColumns").data("kendoDropDownList").dataSource.read({ tableSelected: tableSelected });
    }
    else {
        $("#joinToTableColumns").val("");
    }
}

function getWhereLHSTableColumns() {
    var tableSelected = $("#whereLHSTables").val();
    $("#whereLHSColumns").val("");
    if (tableSelected != "") {
        $("#whereLHSColumns").data("kendoDropDownList").dataSource.read({ tableSelected: tableSelected });

    }
    else {
        $("#whereLHSColumns").val("");
    }
}

function getWhereRHSTableColumns() {
    var tableSelected = $("#whereRHSTables").val();
    $("#whereRHSColumns").val("");
    if (tableSelected != "") {
        $("#whereRHSColumns").data("kendoDropDownList").dataSource.read({ tableSelected: tableSelected });

    }
    else {
        $("#whereRHSColumns").val("");
    }
}

function getOrderByTableColumns() {
    var tableSelected = $("#orderByTables").val();
    $("#orderByColumns").val("");
    if (tableSelected != "") {
        $("#orderByColumns").data("kendoDropDownList").dataSource.read({ tableSelected: tableSelected });

    }
    else {
        $("#orderByColumns").val("");
    }
}

function onJoin() {
    generateQuery();
}

function generateQuery() {
    if ($("#selectedColumns").data("kendoListBox").dataItems().length == 0) {
        toaster("Please select columns to generate query.", "error");
    }
    else {
        $("#joinwindow").data("kendoWindow").close();
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'DynamicReportDesigner/GetSqlStatement', // '@Url.Action("GetSqlStatement", "DynamicReport")',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'selectedColumns': $("#selectedColumns").data("kendoListBox").dataItems(),
                'joinQuery': $("#joinQuery").val() //join
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data != null) {
                    $("#sqlQuery").val(data);
                }
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    }
}

function CustomJoin(e) {
    if ($("#selectedColumns").data("kendoListBox").dataItems().length == 0) {
        toaster("Please select columns to Join Tables.", "error");
    }
    else {
        try {
            $("#customjoinwindow").show();
            e.preventDefault();
            var wdw = $("#joinwindow").data("kendoWindow");
            wdw.center().open();
            resetJoin();

        } catch (e) {
            console.log(e);
        }
    }
}

function ClearQuery() {
    $("#sqlQuery").val("");
    Clear();
}

function ClearAllJoins() {
    Clear();
    resetJoin();
}

function Clear() {
    join = "";
    where = "";
    orderBy = "";
    rem = [];
    $("#joinQuery").val("");
    $("#fromTable").data("kendoDropDownList").enable(true);
    $("#fromTable").val("").data("kendoDropDownList").text("");
}


function resetJoin() {
    
    $("#joinFromTables").val("").data("kendoDropDownList").text("");
    $("#joinToTables").val("").data("kendoDropDownList").text("");
    $("#joinTable").val("").data("kendoDropDownList").text("");
    $("#joinFromTableColumns").val("").data("kendoDropDownList").text("");
    $("#joinToTableColumns").val("").data("kendoDropDownList").text("");
    $("#joinType").data("kendoDropDownList").select(-1);
    $("#whereLHSTables").val("").data("kendoDropDownList").text("");
    $("#whereLHSColumns").val("").data("kendoDropDownList").text("");
    $("#whereCondition").data("kendoDropDownList").select(-1);
    $("#whereText").val("");
    $("#whereRHSTables").val("").data("kendoDropDownList").text("");
    $("#whereRHSColumns").val("").data("kendoDropDownList").text("");
    $("#orderByTables").val("").data("kendoDropDownList").text("");
    $("#orderByColumns").val("").data("kendoDropDownList").text("");

    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'DynamicReportDesigner/GetJoinTables',  // '@Url.Action("GetJoinTables", "DynamicReport")',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: JSON.stringify({ 'selectedColumns': $("#selectedColumns").data("kendoListBox").dataItems() }),
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data != null) {
                var fromdropdown = $("#joinFromTables").data("kendoDropDownList");
                var dataSource = new kendo.data.DataSource({ data: data });
                fromdropdown.setDataSource(dataSource);
                fromdropdown.dataSource.read();

                var todropdown = $("#joinToTables").data("kendoDropDownList");
                todropdown.setDataSource(dataSource);
                todropdown.dataSource.read();

                var fromtabledropdown = $("#fromTable").data("kendoDropDownList");
                fromtabledropdown.setDataSource(dataSource);
                fromtabledropdown.dataSource.read();

                var totabledropdown = $("#joinTable").data("kendoDropDownList");
                totabledropdown.setDataSource(dataSource);
                totabledropdown.dataSource.read();

                var whereLHStabledropdown = $("#whereLHSTables").data("kendoDropDownList");
                whereLHStabledropdown.setDataSource(dataSource);
                whereLHStabledropdown.dataSource.read();

                var whereRHStabledropdown = $("#whereRHSTables").data("kendoDropDownList");
                whereRHStabledropdown.setDataSource(dataSource);
                whereRHStabledropdown.dataSource.read();

                var orderBytabledropdown = $("#orderByTables").data("kendoDropDownList");
                orderBytabledropdown.setDataSource(dataSource);
                orderBytabledropdown.dataSource.read();
            }
        },
        error: function () {
            console.log('Failed to load');
        }
    });
}

function NoJoinTables() {
    join = "";
    where = "";
    $("#joinwindow").data("kendoWindow").close();
}

function SaveRecord(isEdit) {
    if ($("#sqlQuery").val() == "") {
        toaster("Please generate query to save.", "error");
    }
    else if ($("#reportName").val() == "") {
        toaster("Please enter Report Name to save.", "error");
    }
    else {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'DynamicReportDesigner/SaveReport',  // '@Url.Action("SaveReport", "DynamicReport")',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'reportName': $("#reportName").val(),
                'reportQuery': $("#sqlQuery").val(),
                'isEdit': isEdit
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (result) {
                if (result.Errors.Failure != null) {
                    var error = result.Errors.Failure.errors[0];
                    toaster(error, "error");
                }
                else {
                    var successmsg = result.Errors.Success.errors[0];
                    toaster(successmsg, "success");
                    $("#grid").data("kendoGrid").dataSource.read();
                }
            },
            error: function () {
                console.log('Failed to save');
            }
        });
    }
}

function OpenPreviewPopUp(e) {
    try {
        if ($("#sqlQuery").val() == "") {
            toaster("Please generate query to save.", "error");
        }
        else {
            $("#previewdata").show();
            e.preventDefault();
            var wdw = $("#resultwindow").data("kendoWindow");
            wdw.center().open();
            $("#ResultsGrid").empty();
            $.ajax({
                url: window.ApplicationPath + 'DynamicReportDesigner/GetPreviewData', //'@Url.Action("GetPreviewData", "DynamicReport")',
                type: "POST",
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                data: JSON.stringify({
                    'reportQuery': $("#sqlQuery").val()
                }),
                dataType: "json",
                contentType: 'application/json',
                success: function (data) {
                    if (data.Errors != "") {
                        $("#ResultsGrid").kendoGrid({
                            dataSource: {
                                data: ""
                            }
                        });
                        $("#ResultsGrid").find('.k-grid-content tbody').append('<tr class="kendo-data-row"><td style="text-align:center"><b>' + data.Errors + '</b></td></tr>');
                    }
                    else {
                        $("#ResultsGrid").kendoGrid({
                            resizable: true,
                            dataSource: {
                                data: data.Data,
                                pageSize: 10
                            }
                        });
                    }
                },
                error: function (ex) {
                    $("#resultwindow").data("kendoWindow").close();
                }
            });
        }
    }
    catch (e) {
        console.log(e);
    }
}
//End of Javascript for AddEdit Page