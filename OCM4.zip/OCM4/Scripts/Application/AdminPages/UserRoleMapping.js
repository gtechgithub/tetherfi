﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "UserRoleMapping.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Duplicate check"
    });
});

var teamIdToBind = ""; //Store the Team ID which is to be bound
var teamNameToBind = ""; //Store the Team Name which is to be bound
var profileToBind = ""; //Store the Profile which is to be bound
var supervisorToBind = ""; //Store the Supervisor ID which is to be bound
var isRecordNew = false; //Used to track if the Record is a newly created record or it is a existing record being edited
var teamIdDataboundCounter = 0; //Used to keep track if all items are bound in the Team ID DropdownTree
var UserName = "";
var TeamID = "";
var Profile = "";

/* Passing the search field to grid data reader */
function getTextToSearch() {
    return {
        textToSearch: $("#_TextToSearch").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

/* on edit key press have to show and hide the supervisor based on the profile and select the required radio */
function onUserRoleMappingEdit(arg) {
    $(".k-edit-form-container .k-state-disabled").addClass("k-grid-update").removeClass("k-state-disabled");
    if (arg.model.isNew() == true) {
        //By default we are not setting change event for validating profile so we bind it here
        $("#TeamID").data("kendoDropDownTree").bind("change", onProfilevalidation);
        $("#Profile").data("kendoDropDownList").bind("change", OnUserRoleMappingProfileChange);
        if ($("#AvayaLoginID").data("kendoNumericTextBox") !== undefined) {
            $("#AvayaLoginID").data("kendoNumericTextBox").bind("spin", onSpin);
        }
        $("#SupervisorID").val(arg.model.SupervisorID);
        //If new record set the isRecordNew to true and binding variables to blank
        isRecordNew = true;
        profileToBind = "";
        supervisorToBind = "";
        teamIdToBind = "";
        teamNameToBind = "";

        //Call read for TeamID and Profile to load their data in the components
        $("#TeamID").data("kendoDropDownTree").dataSource.read();
        $("#Profile").data("kendoDropDownList").dataSource.read();

        if (jsonfields.ConfigKey == "LDAP") {
            $(".k-edit-form-container .k-grid-update").addClass("k-state-disabled").removeClass("k-grid-update");
            $("#searchFields").show();
            $("#availableUsersGrid").hide();
            $("#editorFields").hide();
        }
        else {
            $("#searchFields").hide();
            $("#editorFields").show();
            if (arg.model.Profile == "Agent") {
                $("#supervisorCheck").show();
            }
        }
        Profilevalid();
        genericEdit(arg);
    }
    else if (arg.model.isNew() != true) {
        //For edit we use databound events to bind model data to the components which is not required when adding a new record
        $("#TeamID").data("kendoDropDownTree").bind("dataBound", OnUserRoleMappingTeamIdDataBound);
        $("#SupervisorID").data("kendoDropDownList").bind("dataBound", OnUserRoleMappingSupervisorDataBound);
        $("#TeamID").data("kendoDropDownTree").unbind("change");

        Profilevalid();
        genericEdit(arg);

        //If existing record set the isRecordNew to false and binding variables to the model value
        isRecordNew = false;
        teamIdToBind = arg.model.TeamID;
        teamNameToBind = arg.model.TeamName;
        profileToBind = arg.model.Profile;
        supervisorToBind = arg.model.SupervisorID;

        UserName = arg.model.UserName;
        TeamID = arg.model.TeamID;
        Profile = arg.model.Profile;

        $("#TeamID").val(arg.model.TeamID);
        $("#Profile").val(arg.model.Profile);
        $("#SupervisorID").val(arg.model.SupervisorID);
        $("#SupervisorID").data("kendoDropDownList").value(supervisorToBind);

        if (jsonfields.ConfigKey != "LDAP") {
            $("#Role").getKendoMultiSelect().value(arg.model.Role.split(','));
        }
        $("#searchFields").hide();
        $("#editorFields").show();
        $("#UserName").attr("readonly", true);
        if ($("#AvayaLoginID").data("kendoNumericTextBox") === undefined) {
            $("#AvayaLoginID").attr("readonly", true);
        }
        else {
            $("#AvayaLoginID").data("kendoNumericTextBox").enable(false);
        }
    }
}

function getRetagUserSupervisorParam() {
    return {
        id: UserName,
        teamid: TeamID,
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}
/* on each edit and delete operation have to reload the grid  */
function syncGrid(e) {
    if (e.type == "update" || e.type == "delete") {
        e.sender.read();
    }
}

function onSpin() {
    var AvayaLoginID = $("#AvayaLoginID").val();
    var MaxLoginID;
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (field[i].PropertyName == "AvayaLoginID") {
            MaxLoginID = jsonfields.GridColumns[i].Maxlength;
            break;
        }
    }

    if (AvayaLoginID.length > MaxLoginID) {
        var NewLoginID = $("#AvayaLoginID").data("kendoNumericTextBox");
        NewLoginID.value(AvayaLoginID - 1);
        return;
    }
}

function onProfilevalidation(e) {
    console.log("onProfilevalidation");
    try {
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/IsBottomMostTeam',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'teamid': $('#TeamID').val()
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                var dropdownlist = $("#Profile").data("kendoDropDownList");
                if (data != false) {
                    dropdownlist.enable(true);
                    //dropdownlist.select(0);
                    dropdownlist.select(2);
                    dropdownlist.enable(false);
                }
                else {
                    dropdownlist.enable(true);
                    dropdownlist.select(0);
                }
                $("#SupervisorID").data("kendoDropDownList").dataSource.read();
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function filterid() {
    return {
        id: $("#UserName").val(),
        profile: $("#Profile").val(),
        teamid: $("#TeamID").val(),
        supervisor: $("#SupervisorID").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}
/* on click on save button on edit page storing the hidden values to data model */
function onUserRoleMappingSave(e) {
    e.model.Profile = $("#Profile").val();
    e.model.TeamID = $("#TeamID").val();
    e.model.TeamName = $("#TeamID").data("kendoDropDownTree").text();
    e.model.SupervisorID = $("#SupervisorID").val();
    e.model.SupervisorName = $("#SupervisorID").data("kendoDropDownList").text();
    e.model.AvayaLoginID = $("#AvayaLoginID").val();
    e.model.FirstName = $("#FirstName").val();
    e.model.LastName = $("#LastName").val();
    e.model.UserName = $("#UserName").val();

    if (jsonfields.ConfigKey == "LDAP") {
        e.model.Role = $("#Role").val();
    }

    //var currentModifyReason = e.model.ModifyReason;
    //if (e.model.isNew() == false) {
    //    if ($.trim(currentModifyReason) == "" || $.trim(currentModifyReason) == null) {
    //        e.preventDefault();
    //        toaster("Please enter the modify reason", "error");
    //        return;
    //    }
    //    if ($("#Profile").val() == "Agent") {
    //        duplicateValidate(e, "AvayaLoginID", "AvayaLoginID");
    //    }
    //}

    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;
    //var title = "Avaya Login ID"
    //var isMandatory = false
    for (i = 0; i < field.length; i++) {
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
            //if (field[i].PropertyName == "AvayaLoginID") {
            //    title = field[i].Title;
            //    isMandatory = true;
            //}
        }
        if (e.model.isNew() == true) { //check for duplicate on save new record while creating
            if (field[i].Hidden != true & field[i].IsDuplicateAllowed == false) {
                duplicateValidate(e, field[i].PropertyName, field[i].Title);
            }
        }
    }

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    modifyValid(e);

    //if (isMandatory == true) {
    //    if (e.model.AvayaLoginID == "" && $("#Profile").val() == "Agent") {
    //        toaster("Please provide " + title, "error");
    //        e.preventDefault();
    //        return false;
    //    }
    //}
    if (e.model.isNew() != true && e.model.HasChild == true && $("#IsRetagSupervisor").val().toLowerCase() == "true" && (TeamID != $("#TeamID").val() || Profile != $("#Profile").val())) {
        if ($("#retagusersupervisorlist").css('display') == 'none') {
            $("#retagusersupervisortitle").show();
            $("#retagusersupervisorlabel").show();
            $("#retagusersupervisorlist").show();
            $("#retagusersupervisortitle").html("<label>Choose new supervisor to retag supervisor/agent under team level: </label><span class='theme-color'> " + teamNameToBind + "</span>");

            $("#retagusersupervisordropdown").data("kendoDropDownList").select(0);
            $("#retagusersupervisordropdown").data("kendoDropDownList").dataSource.read()
        }
        else {
            $("#retagusersupervisortitle").hide();
            $("#retagusersupervisorlabel").hide();
            $("#retagusersupervisorlist").hide();
        }

        if ($("#retagusersupervisordropdown").data("kendoDropDownList").value() != "") {
            e.model.NewSupervisorID = $("#retagusersupervisordropdown").data("kendoDropDownList").value();
        }
        else {
            toaster("Please provide a valid Supervisor to retag supervisor/agent under team level: " + teamNameToBind, "error");
            e.preventDefault();
            return false;
        }
    }
    console.log(e.model);
}

/* on selecting any data row from search grid following function will be called to populate the fields in create page  */
function onAvailableUsersChange(arg) {
    console.log(arg);
    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    console.log(selectedData);
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_uid = $row.attr('data-uid'); //uid of selected row
    var cell_index = $cell.index(); //cell index 0 based
    var row_index = $row.index(); //row index 0 based
    var UserName = $grid.dataItem($row).UserName; //selected row data
    console.log(UserName);
    var colName = $("#grid").find('th').eq(cell_index).text()//selected column name
    set = false;
    if (UserName != null) {
        $('#FirstName').val($grid.dataItem($row).FirstName);
        $('#LastName').val($grid.dataItem($row).LastName);
        $('#UserName').val($grid.dataItem($row).UserName);
        $('#Role').val($grid.dataItem($row).Role);
        $("#editorFields").show();
        $(".k-edit-form-container .k-state-disabled").addClass("k-grid-update").removeClass("k-state-disabled");
        //$('#popupSearchUsers').modal('hide');
        //$('#popupCreatePage').modal('show');
        //$("#CreatePageNameLbl").html("<h3>Create User</h3>");
    }
}

/* showing ldap search panel for creating users  */
function showCreatePopup() {
    $('#popupSearchUsers').modal('show');
    $("#SearchUsersPageNameLbl").html("<h3>Create User</h3>");
    $("#gridAvailableUsers").data("kendoGrid").dataSource.data({});
    $("#_TextToSearch").value(null);
}

/* closing the create panel */
function closeCreatePopup() {
    $('#popupSearchUsers').modal('hide');
    $("#availableUsersGrid").css('display', 'none');
    $("#_TextToSearch").val('');
}

/* on cancel button click on create panel search panel will be shown */
function cancelCreate() {
    $('#popupCreatePage').modal('hide');
    $('#popupSearchUsers').modal('show');
    $("#SearchUsersPageNameLbl").html("<h3>Create User Role Mapping Record</h3>");
}

/* on click of search button in search panel following method will be called to search the users from LDAP and populate the grid  */
function searchUsers() {
    $("#editorFields").hide();
    $(".k-edit-form-container .k-grid-update").addClass("k-state-disabled").removeClass("k-grid-update");
    if ($("#_TextToSearch").val() != '') {
        $("#availableUsersGrid").css('display', 'block');
        var grid = $("#gridAvailableUsers").data("kendoGrid");
        grid.dataSource.data("");
        grid.dataSource.read();
    }
    else {
        toaster("Please provide a user to search", "error");
        $("#availableUsersGrid").css('display', 'none');
    }
}

/**
 * Method used to perform an action when all the data is bound to the dropdowntree
 * @param e
 */
function OnUserRoleMappingTeamIdDataBound(e) {
    try {
        var ddt = e.sender;
        var dataSource = ddt.dataSource;
        var node = e.node;

        if (!node) {
            var children = dataSource.data();

            children.forEach(function (item, index) {
                if (item.hasChildren) {
                    teamIdDataboundCounter++;
                }
            });
        } else {
            var children = ddt.treeview.dataItem(node).children.data();

            children.forEach(function (item, index) {
                if (item.hasChildren) {
                    teamIdDataboundCounter++;
                }
            });

            teamIdDataboundCounter--;
        }

        if (teamIdDataboundCounter === 0) {
            console.log("Team Tree Fully bound!");
            $("#SupervisorID").data("kendoDropDownList").dataSource.read();
            //In the case of edit we are not binding change event so we bind it here, in case of new record change event is already binded so below statements will not matter
            //For edit if we bind change event earlier in onUserRoleMappingEdit function then after setting the dropdownlist value, the onProfilevalidation event will be called which will clear it
            //So for the profile dropdownlist values to not be reset in the edit scenario we bind change event here
            $("#TeamID").data("kendoDropDownTree").bind("change", onProfilevalidation);
            $("#Profile").data("kendoDropDownList").bind("change", OnUserRoleMappingProfileChange);
        }
    } catch (e) {
        console.log(e);
    }
}

/**
 * Method used to perform an action when all the data is bound to the Supervisor dropdownlist
 * @param e
 */
function OnUserRoleMappingSupervisorDataBound(e) {
    try {
        console.log("onSupervisorDataBound");
        //Below Ajax call will be mainly used for edit scenario when binding data, after all 3 items data is bound in some cases profile will not be disabled so below ajax call is for that validation
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'Generic/IsBottomMostTeam',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'teamid': $('#TeamID').val()
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                var dropdownlist = $("#Profile").data("kendoDropDownList");
                if (data != false) {
                    dropdownlist.enable(true);
                    dropdownlist.enable(false);
                }
                else {
                    dropdownlist.enable(true);
                }
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function OnUserRoleMappingProfileChange() {
    $("#SupervisorID").data("kendoDropDownList").dataSource.read();
}

function onUserRoleMappingCancel(e) {
    try {
        $("#TeamID").data("kendoDropDownTree").unbind("change");
    } catch (e) {
        console.log(e);
    }
}