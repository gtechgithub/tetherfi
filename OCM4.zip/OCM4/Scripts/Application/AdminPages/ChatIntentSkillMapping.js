﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "ChatIntentSkillMapping.js",
        Version: "11.8",
        LastModifiedDateTime: "31-08-2018 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Renamed module name"
    });
});
function onChatIntentMappingEdit(e) {
    genericEdit(e);
}


function onChatIntentMappingSave(e) {

    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields;

    for (i=0; i<field.length;i++)
    {
        if (field[i].Hidden != true & field[i].Mandatory== true)
        {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    modifyValid(e);
}
