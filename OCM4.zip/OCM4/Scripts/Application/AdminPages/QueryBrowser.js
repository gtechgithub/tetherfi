﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "QueryBrowser.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Included table name inside [] "
    });
});

function Bindgrid() {
    var progress = $("#popup");

    kendo.ui.progress(progress, true);
    try {
        if ($("#joinQuery").val() == "") {
            toaster("Please select table to generate query to preview.", "error");
        }
        else {
            //var patternMatchResult = $("#joinQuery").val().toLowerCase().match(/select\s*\*/g);
            //if (patternMatchResult.length > 1) {
            //    toaster("Cannot show more than one table", "error");
            //}
            //else {
            $('#grid').kendoGrid('destroy').empty();
            $("#grid").kendoGrid({
                height: 476,
                sortable: true,
                scrollable: true,
                groupable: true,
                columnMenu: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                resizable: true,
                reorderable: true,
                pageable: true,
                dataBound: onDataBound,
                excelExport: validateExportExcel,
            });
            kendo.ui.progress($("#grid"), true);
            if (QueryCheck($("#joinQuery").val())) {
                $.ajax(
                    {
                        type: 'POST',
                        url: window.ApplicationPath + 'QueryBrowser/GetPreviewData/',
                        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                        dataType: 'json',
                        async: false,
                        data: { reportQuery: $("#joinQuery").val() },
                        success: function (result) {
                            if (result != "") {
                                if (result.Data.length > 0) {
                                    $.each(result.Data, function (i, val) {
                                        for (o in val) {
                                            if (val[o] != null && val[o].toString().indexOf("/Date") != -1) {
                                                result.Data[i][o] = moment(val[o]).format("YYYY-MM-DD HH:mm:ss")
                                            };
                                        }
                                    });

                                    $("#grid").data("kendoGrid").dataSource.data(result.Data);
                                }
                                else if (result.Errors != "") {
                                    $("#grid").kendoGrid({
                                        noRecords: {
                                            template: result.Errors
                                        }
                                    });
                                }
                                else {
                                    toaster("No records to display", "info");
                                }
                                kendo.ui.progress($("#grid"), false);
                            }
                            else {
                                toaster("Successfully updated table.", "success");
                            }
                        },
                        error: function (result) {
                            console.log("Error: " + result);
                            kendo.ui.progress($("#grid"), false);
                        }
                    });
            }
            else {
                toaster("Cannot perform Update/Delete operations on Tables.", "error");
            }
        }
        kendo.ui.progress(progress, false);
    }
    catch (e) {
        console.log(e);
        kendo.ui.progress(progress, false);
    }

}

function onQueryBrowserSelect(e) {
    var progress = $("#popup");

    kendo.ui.progress(progress, true);

    if ($('#treeview').data('kendoTreeView').dataItem(e.node).text != "Tables") {
        var tableSelected = $('#treeview').data('kendoTreeView').dataItem(e.node).text;
        if (tableSelected != "") {
            $("#joinQuery").val("");
            $("#joinQuery").val("SELECT TOP 10 * FROM [" + tableSelected +"]");
        }
        else {
            $("#joinQuery").val("");
            toaster("Please select table to generate query to preview.", "error");
        }
        $('#grid').kendoGrid('destroy').empty();
        $("#grid").kendoGrid({
            height: 476,
            sortable: true,
            scrollable: true,
            groupable: true,
            columnMenu: true,
            pageable: {
                refresh: true,
                pageSizes: true,
                buttonCount: 5
            },
            resizable: true,
            reorderable: true,
            pageable: true,
            dataBound: onDataBound,
            excelExport: validateExportExcel,
        });
        kendo.ui.progress($("#grid"), true);
        if (QueryCheck($("#joinQuery").val())) {
            $.ajax(
                {
                    type: 'POST',
                    url: window.ApplicationPath + 'QueryBrowser/GetPreviewData/',
                    headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                    dataType: 'json',
                    async: false,
                    data: { reportQuery: $("#joinQuery").val() },
                    success: function (result) {
                        if (result != "") {
                            if (result.Data.length > 0) {
                                $.each(result.Data, function (i, val) {
                                    for (o in val) {
                                        if (val[o] != null && val[o].toString().indexOf("/Date") != -1) {
                                            result.Data[i][o] = moment(val[o]).format("YYYY-MM-DD HH:mm:ss")
                                        };
                                    }
                                });
                                $("#grid").data("kendoGrid").dataSource.data(result.Data);
                            }
                            else if (result.Errors != "") {
                                $("#grid").kendoGrid({
                                    noRecords: {
                                        template: result.Errors
                                    }
                                });
                            }
                            else {
                                toaster("No records to display", "info");
                            }                            
                            kendo.ui.progress($("#grid"), false);
                        }
                        else {
                            toaster("Successfully updated table.", "success");
                        }
                    },
                    error: function (result) {
                        console.log("Error: " + result);
                        kendo.ui.progress($("#grid"), false);
                    }
                });
        }
        else {
            toaster("Cannot perform Update/Delete operations on Tables.", "error");
        }
    }
    kendo.ui.progress(progress, false);
}

function QueryCheck(query) {
    if (query != "" && query.toLowerCase().indexOf('select') >= 0) {
        return true;
    }
    else {
        if (query != "" && isOperationsAllowedOnTables == true) {
            return true;
        }
        else {
            return false;
        }
    }
}