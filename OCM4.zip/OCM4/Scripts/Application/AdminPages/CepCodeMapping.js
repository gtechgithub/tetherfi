﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\Generic",
        FileName: "CepCodeMapping.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 08:30:00 AM",
        LastModifiedBy: "Prathik,Shruthi",
        Description: "Added duplicate check for CEP Event"
    });
});
function onCepCodeMappingeEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $("#EventType").attr("readonly", true);
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }
}

function onCepCodeMappingSave(e) {
    var cepEvent = $("#EventType").val();
    var description = $("#Description").val();
   // var productType = $("#ProductType").val();
    var bin = $("#Bin").val();
    var intent = $("#Intent").val();
    var transferFlag = $("#TransferStatus").data("kendoDropDownList").value();

    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("CEP Event", "Description", "BINS","Transfer flag");
    fieldValues.push(cepEvent, description, bin, transferFlag);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "EventType", "CEP Event");

    //if (cepEvent == "") {
    //    e.preventDefault();
    //    toaster("Please provide a valid CEP Event", "error");
    //    return;
    //}
    //if (description == "") {
    //    e.preventDefault();
    //    toaster("Please provide a valid description", "error");
    //    return;
    //}
    //if (productType == "") {
    //    e.preventDefault();
    //    toaster("Please provide a valid Product Code", "error");
    //    return;
    //}
    //if (bin == "") {
    //    e.preventDefault();
    //    toaster("Please provide a valid BINS", "error");
    //    return;
    //}
    //if (transferFlag == "") {
    //    e.preventDefault();
    //    toaster("Please select a transfer flag", "error");
    //    return;
    //}
    if (transferFlag == "Yes" && intent == "") {
        e.preventDefault();
        toaster("Please provide a valid Intent", "error");
        return;
    }
    modifyValid(e);
}