﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "CampaignUtilityHA.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreeraj",
        Description: "Version Changed."
    });
});
//------------------------------------------------------------------------------------


var refreshTime = 10000; //Refresh time, every these many seconds the grid refreshes
var isTime = 0; //should be 0 always
//StartCampaignJob
function onChangeCallback() {
    try {
        var idsToSend = [];

        var grid = $("#grid").data("kendoGrid")
        var ds = grid.dataSource.view();

        for (var i = 0; i < ds.length; i++) {
            var row = grid.table.find("tr[data-uid='" + ds[i].uid + "']");
            var checkbox = $(row).find(".checkbox");

            if (checkbox.is(":checked")) {
                idsToSend.push(ds[i].CampaignName);
            }
        }
        $('#SelectedCampaign').val(idsToSend);
    }
    catch (e) {
        console.log("Exception in onChangeCallback()StartCampaign: " + e);
    }
}

//StopCampaignJob
function onChangeCallbacks() {
    try {

        var idsToSend = [];

        var grid = $("#grid").data("kendoGrid")
        var ds = grid.dataSource.view();

        for (var i = 0; i < ds.length; i++) {
            var row = grid.table.find("tr[data-uid='" + ds[i].uid + "']");
            var checkbox = $(row).find(".checkbox");

            if (checkbox.is(":checked")) {
                idsToSend.push(ds[i].JobId);
            }
        }
        $('#SelectedCampaign').val(idsToSend);
    }
    catch (e) {
        console.log("Exception in onChangeCalbacks()StopCampaign: " + e);
    }
}

function StartCampaingn(e) {
    try {
        var tr = $(e.target).closest("tr"); //get the row
        var data = this.dataItem(tr); //get the row data so it can be referred later

        if (data.CampaignName == "") {
            toaster("Needs CampaignName to Start", "error");
            return;
        }
        if (data.ButtonFlag.toLowerCase() == "enable") {
            toaster("Campaign is already running!!", "info");
            return;
        }
        var grid = $("#grid").data("kendoGrid");

        $.ajax({
            type: 'POST',
            url: window.ApplicationPath + 'CampaignUtilityHA/ChangeStatusToStart',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "cList": data.CampaignName, "contactList": data.ContactListUsed, "CampaignName": data.CampaignName },
            success: function (returneddata) {
                if (returneddata == 1) {
                    toaster("Record Successfully Updated", "success");
                    grid.dataSource.read();
                    grid.clearSelection();
                    $('#SelectedIdListSms').val("");
                }
                else if (returneddata == 0) {
                    toaster("Record Not Updated", "error");
                    grid.dataSource.read();
                    grid.clearSelection();
                    $('#SelectedIdListSms').val("");
                }
                else {
                    toaster("Record Not Updated: " + returneddata, "error");
                    grid.dataSource.read();
                    grid.clearSelection();
                    $('#SelectedIdListSms').val("");
                }
            },
            error: function () {
                toaster("Some Error Occurred during the process", "error");
                grid.dataSource.read();
                grid.clearSelection();
                $('#SelectedIdListSms').val("");
            }
        });
    }
    catch (e) {
        console.log("Exception in StartCampaignJob(): " + e);
    }
}

function StopCampaign(e) {
    try {
        var grid = $("#grid").data("kendoGrid");

        var tr = $(e.target).closest("tr"); //get the row
        var data = this.dataItem(tr); //get the row data so it can be referred later

        if (data.JobId == "") {
            toaster("JobId is null, cannot stop the Campaign", "error");
            return;
        }
        if (data.ButtonFlag.toLowerCase() == "disable") {
            toaster("Campaign is already stopped!!", "info");
            return;
        }

        $.ajax({
            type: 'POST',
            url: window.ApplicationPath + 'CampaignUtilityHA/ChangeStatusToStop',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "cList": data.JobId, "contactList": data.ContactListUsed, "CampaignName": data.CampaignName },
            success: function (returneddata) {
                if (returneddata == 1) {
                    toaster("Record Successfully Updated", "success");
                    grid.dataSource.read();
                    grid.clearSelection();
                    $('#SelectedIdListSms').val("");
                }
                else if (returneddata == 0) {
                    toaster("Record Not Updated", "error");
                    grid.dataSource.read();
                    grid.clearSelection();
                    $('#SelectedIdListSms').val("");
                }
                else {
                    toaster("Record Not Updated: " + returneddata, "error");
                    grid.dataSource.read();
                    grid.clearSelection();
                    $('#SelectedIdListSms').val("");
                }
            },
            error: function () {
                toaster("Some Error Occurred during the process", "error");
                grid.dataSource.read();
                grid.clearSelection();
                $('#SelectedIdListSms').val("");
            }
        });
    }
    catch (e) {
        console.log("Exception in StopCampaignJob(): " + e);
    }
}

function refreshgrid() {
    try {
        $("#checkAllRow").val(false);
        ReloadMainGrid();
    }
    catch (e) {
        console.log("Exception in refreshGrid(): " + e);
    }
}
function ondataboundCallBack(e) {
    try {
        $("#checkAllRow")[0].checked = e.sender.items().find(":checked").length == e.sender.dataSource.view().length;
    }
    catch (e) {
        console.log("Exception in ondataboundCallBack(): " + e);
    }

}

function checkAll() {
    try {
        var checked = $("#checkAllRow").is(":checked");
        $('.checkbox:not(:disabled)', grid.tbody).prop('checked', checked);
    }
    catch (e) {
        console.log("Exception in checkAll(): " + e);
    }
}

function genericRequestCampaign(e) {
    try {
        $('.k-grid-update').css('display', 'inline-block');
        var message = "";
        requestPrevent = 0;

        if (isTime <= 0) {
            window.setInterval(function () {
                refreshGrid();
            }, refreshTime);
        }

        if (e.type === "read") {
            message = e.response.Errors;
            if (message == null) {
                //toaster("Grid updated Successfully", "success");
                console.log("Grid updated Successfully");
                return;
            }
            var y = message.hasOwnProperty("Success");
            if (y == true)
                toaster(message.Success.errors[0], "success");
            else
                toaster(message.Failure.errors[0], "error");
        }

        $("#grid").data("kendoGrid").dataSource.read();
    } catch (e) {
        console.log("Exception in genericRequestCampaign(): " + e);
    }
}

function refreshGrid() {
    $("#grid").data("kendoGrid").dataSource.read();
    isTime = isTime + 1;
}

$(document).ready(function () {
    initializeGridTooltip('grid');
    enableDisableGridAutoResize = 1;
});