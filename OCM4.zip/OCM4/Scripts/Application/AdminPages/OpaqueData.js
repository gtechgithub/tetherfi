﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "OpaqueData.js",
        Version: "11.15",
        LastModifiedDateTime: "29-10-2018 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: ""
    });
});





function onOpaqueDataEdit(e) {
   
    genericEdit(e);
}

function onOpaqueDataSave(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields.GridColumns;

    for (i = 0; i < field.length; i++) {
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "Key", "Key");
    modifyValid(e)
}
