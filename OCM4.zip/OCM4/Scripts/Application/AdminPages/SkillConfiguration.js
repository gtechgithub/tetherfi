﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "SkillConfiguration.js",
       Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: ""
    });
});


function editSkillConfiguration(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#SkillID").data("kendoNumericTextBox").readonly();
        $("#SkillExtension").data("kendoNumericTextBox").readonly();
        $("#Prioritylevel").data("kendoDropDownList").text(e.model.Priority);
        $("#Prioritylevel").data("kendoDropDownList").value(e.model.Prioritylevel);
    }
}

function onSaveSkillConfiguration(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    e.model.Prioritylevel = $("#Prioritylevel").val();
    e.model.Priority = $("#Prioritylevel").data("kendoDropDownList").text();

    fieldNames.push("SkillID");
    fieldNames.push("SkillName");
    fieldNames.push("SkillExtension");
    fieldNames.push("Enabled");
    fieldNames.push("Priority");

    fieldValues.push(e.model.SkillID);
    fieldValues.push(e.model.SkillName);
    fieldValues.push(e.model.SkillExtension);
    fieldValues.push(e.model.IsEnabled);
    fieldValues.push(e.model.Prioritylevel);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    // if (e.model.isNew() == true) {
    duplicateValidate(e, "SkillID", "SkillID");
    duplicateValidate(e, "SkillName", "SkillName");
    duplicateValidate(e, "SkillExtension", "SkillExtension");
    // }
    var SkillTimeOutTime = $("#SkillTimeOutTime").data("kendoTimePicker");
    var SLATime = $("#SLATime").data("kendoTimePicker");

    if ($("#SkillTimeOutTime").val() != null && $("#SkillTimeOutTime").val() != "") {
        e.model.SkillTimeOutTime = kendo.toString(SkillTimeOutTime.value(), "HH:mm:ss");
        if (e.model.SkillTimeOutTime == null || e.model.SkillTimeOutTime == "") {
            toaster("Enter SkillTimeOutTime", "error");
            e.preventDefault();
            return;
        }
    }
    if ($("#SLATime").val() != null && $("#SLATime").val() != "") {
        e.model.SLATime = kendo.toString(SLATime.value(), "HH:mm:ss");
        if (e.model.SLATime == null || e.model.SLATime == "") {
            toaster("Enter SLATime", "error");
            e.preventDefault();
            return;
        }
    }
    modifyValid(e);
}

function SyncCMData()
{
    swal({
        title: "Are you sure you want to sync skills from CM?",
        text: "Confirm to Sync Skills",
        icon: "warning",
        buttons: true,
        dangerMode: false,
    })
            .then(function (willSync) {
                if (willSync) {
                    kendo.ui.progress($("#grid"), true);
                    $.ajax({
                        type: "POST",
                        url: window.ApplicationPath + 'SkillConfiguration/SyncCMData',
                        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                        dataType: 'json',
                        success: function (data) {
                            //toaster need to be added here
                            if (data != null) {
                                if (data == 1)
                                    toaster("CM Skills Synced successfully", "success");
                                else
                                    toaster("Failed to sync CM Skills", "error");

                                var grid = $("#grid").data("kendoGrid");
                                grid.dataSource.read();
                                kendo.ui.progress($("#grid"), false);
                            }
                        },
                        error: function (data) {
                            toaster("Some Error occurred", "error");
                            var grid = $("#grid").data("kendoGrid");
                            grid.dataSource.read();
                            kendo.ui.progress($("#grid"), false);
                        }
                    });
                }
            });
}