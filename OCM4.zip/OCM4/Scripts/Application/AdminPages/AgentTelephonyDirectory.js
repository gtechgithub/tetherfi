﻿/**
 * on edit of agent telephony validate for number,email,text;
 */
function onEditTelephony(e) {
    genericEdit(e);
    var type = $("#Type").val();
    if (type == "Voice")
        $("#Value").attr("type", "number");
    if (type == "Email")
        $("#Value").attr("type", "email");
    if (type == "Investigation")
        $("#Value").attr("type", "text");

}

/**
 * on select od dropdown in Agent telephony validate  number,email,text
 */
function onselectEvent(e) {
    var type = $("#Type").val();
    if (type == "Voice")
        $("#Value").attr("type", "number");
    if (type == "Email")
        $("#Value").attr("type", "email");
    if (type == "Investigation")
        $("#Value").attr("type", "text");
}


/**
 * on select od dropdown in Agent telephony validate  number,email,text
 */
function onSaveTelephony(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("Name");
    fieldNames.push("Type");
    fieldNames.push("Value");
    fieldNames.push("TeamName");

    fieldValues.push(e.model.Name);
    fieldValues.push(e.model.Type);
    fieldValues.push(e.model.Value);
    fieldValues.push(e.model.TeamName);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    e.data = {
        teamId: $('#TeamName').val()
    }
    modifyValid(e);
}