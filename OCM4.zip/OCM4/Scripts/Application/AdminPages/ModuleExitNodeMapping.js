﻿
function onModuleExitNodeMappingEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $(e.container).find('input[name="ModuleName"]').attr("readonly", true);
        $(e.container).find('input[name="ExitNodes"]').attr("readonly", true);
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }

}

function onModuleExitNodeMappingSave(e) {
    if (e.model.ModuleName == "") {
        toaster("Enter Module Name", "error");
        e.preventDefault();
        return;
    }
    if (e.model.ExitNodes == "") {
        toaster("Enter Exit Nodes", "error");
        e.preventDefault();
        return;
    }
    modifyValid(e);
}

function onModuleFilter() {
    var value = this.value(),
    grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({ field: "ModuleName", operator: "eq", value: value });
    }
    else {
        grid.dataSource.filter({});
    }
}

function onModuleExitNodeMappingRequestEnd(e) {
    genericRequest(e);
    $("#module").data("kendoDropDownList").dataSource.read();
}