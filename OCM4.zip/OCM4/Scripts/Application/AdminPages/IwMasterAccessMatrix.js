﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IwMasterAccessMatrix.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "new module "
    });
});

function onGridDetailExpand(e) {
    var flowName = e.sender.dataItem(e.masterRow).flowName;

    $("#gridIWRoleAccessDetails_" + flowName).data("kendoGrid").dataSource.data([]);
    $("#gridIWRoleAccessDetails_" + flowName).data("kendoGrid").dataSource.add(e.sender.dataItem(e.masterRow));
}
function gridDataBound(e) {
    enableDisableGridAutoResize = 1;
    onDataBound(e);
}
function onIWMasterMatrixMainGridChange(arg) {
    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    console.log(selectedData);
    var $grid = arg.sender; //grid ref
    var $cell = $grid.select(); // selected td
    var $row = $cell.closest('tr'); //selected tr
    var row_uid = $row.attr('data-uid'); //uid of selected row
    var cell_index = $cell.index(); //cell index 0 based
    var row_index = $row.index(); //row index 0 based
    var RoleName = $grid.dataItem($row).RoleName; //selected row data
    var RoleType = $grid.dataItem($row).RoleType; //selected row data
    var colName = $("#grid").find('th').eq(cell_index).text()//selected column name
    $("#searchDForm").html('');
    set = false;
    console.log(RoleName);
    console.log(RoleType);
    $("#roleName").val(RoleName);
    $("#roleType").val(RoleType);

    if (selectedData != null) {
        try {
            $.ajax({
                type: "POST",
                url: window.ApplicationPath + 'IwMasterAccessMatrix/GetRoleBasedConfigMasterAccessMatrix',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                data: JSON.stringify({
                    'roleName': $('#roleName').val(),
                    'roleType': $('#roleType').val()
                }),
                async: false,
                dataType: "json",
                contentType: 'application/json',
                success: function (data) {

                    reset();

                    $('#IntentMaster').prop("checked", data.IntentMaster);
                    $('#RulesMaster').prop("checked", data.RulesMaster);
                    $('#GlobalConfigMaster').prop("checked", data.GlobalConfigMaster);
                    $('#GlobalPhrasesMaster').prop("checked", data.GlobalPhrasesMaster);
                    $('#ApproveGlobalPhrasesMaster').prop("checked", data.ApproveGlobalPhrasesMaster);
                    $('#HotKeysMaster').prop("checked", data.HotKeysMaster);
                    $('#AddNewIWCallFlow').prop("checked", data.AddNewIWCallFlow);
                    $('#AddNewOrderTake').prop("checked", data.AddNewOrderTake);
                    $('#AddNewSubFlow').prop("checked", data.AddNewSubFlow);
                    $('#SynonymMaster').prop("checked", data.SynonymMaster);

                    if ($('#roleType').val().toLowerCase() !== "maker") {
                        $("#AddNewIWCallFlow").attr("disabled", true);
                        $("#AddNewOrderTake").attr("disabled", true);
                        $("#AddNewSubFlow").attr("disabled", true);
                    }
                    else {
                        $("#AddNewIWCallFlow").attr("disabled", false);
                        $("#AddNewOrderTake").attr("disabled", false);
                        $("#AddNewSubFlow").attr("disabled", false);
                    }

                    if ($("#iw").data("kendoDropDownList").value() == "Voice") {
                        $("#SynonymMaster").attr("disabled", true);
                    }
                    else {
                        $("#GlobalConfigMaster").attr("disabled", true);
                        $("#GlobalPhrasesMaster").attr("disabled", true);
                        $("#ApproveGlobalPhrasesMaster").attr("disabled", true);
                        $("#HotKeysMaster").attr("disabled", true);
                        $("#AddNewOrderTake").attr("disabled", true);
                    }

                    $('#popupDrill').modal('show');
                    $('#autoCompleteTextbox').val("");
                    $("#DrillPopupFooter").hide();
                    $("#searchDFormTemplate").hide();
                    $("#DrillReportNameLbl").html("<h3 align='center'> IW Master Access Matrix</h3>");
                    $("#DrillReportNameSubLbl").html("<h4 align='center'> For Role: <span class='theme-color'>" + RoleName + "</span> & Role Type :<span class='theme-color'>" + RoleType + "</span> </h4>");
                },
                error: function () {
                    console.log('Failed to load');
                }
            });
        } catch (e) {
            console.log(e);
        }
    }
    if (selectedData == null) {
        toaster("There are no records to show", "info");
        return;
    }
}

function saveChange() {
    try {
        var currentModifyReason = $('#ModifyReason').val();
        var isSuccess = false;
        if ($.trim(currentModifyReason) == "" || $.trim(currentModifyReason) == null) {
            toaster("Please enter the modify reason", "error");
            e.preventDefault();
            return;
        }
        
        var details = {
            IntentMaster: $('#IntentMaster').is(":checked"),
            RulesMaster: $('#RulesMaster').is(":checked"),
            GlobalConfigMaster: $('#GlobalConfigMaster').is(":checked"),
            GlobalPhrasesMaster: $('#GlobalPhrasesMaster').is(":checked"),
            ApproveGlobalPhrasesMaster: $('#ApproveGlobalPhrasesMaster').is(":checked"),
            HotKeysMaster: $('#HotKeysMaster').is(":checked"),
            AddNewIWCallFlow: $('#AddNewIWCallFlow').is(":checked"),
            AddNewOrderTake: $('#AddNewOrderTake').is(":checked"),
            AddNewSubFlow: $('#AddNewSubFlow').is(":checked"),
            SynonymMaster: $('#SynonymMaster').is(":checked")
        }

        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'IwMasterAccessMatrix/WriteRoleBasedConfigMasterAccessMatrix',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: JSON.stringify({
                'roleName': $('#roleName').val(),
                'roleType': $('#roleType').val(),
                'detail': details,
                'modifyReason': $('#ModifyReason').val()
            }),
            async: false,
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {

                message = data.Errors;

                var y = message.hasOwnProperty("Success");

                if (y == true) {
                    for (var i = 0; i < message.Success.errors.length; i++) {
                        toaster(message.Success.errors[i], "success");
                        isSuccess = true;
                    }
                }

                var x = message.hasOwnProperty("Failure");

                if (x == true) {
                    for (var i = 0; i < message.Failure.errors.length; i++) {
                        let msgs = message.Failure.errors[i];
                        if (isSuccess)
                            setTimeout(function () {
                                toaster(msgs, "error");
                            }, 3500);
                        else
                            toaster(message.Failure.errors[i], "error");
                    }
                }
                cancelChange();
            },
            error: function () {
                console.log('Failed to load');
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function reset() {
    $('#IntentMaster').attr("disabled", false);
    $('#RulesMaster').attr("disabled", false);
    $('#GlobalConfigMaster').attr("disabled", false);
    $('#GlobalPhrasesMaster').attr("disabled", false);
    $('#ApproveGlobalPhrasesMaster').attr("disabled", false);
    $('#HotKeysMaster').attr("disabled", false);
    $('#AddNewIWCallFlow').attr("disabled", false);
    $('#AddNewOrderTake').attr("disabled", false);
    $('#AddNewSubFlow').attr("disabled", false);
    $('#SynonymMaster').attr("disabled", false);

    $('#IntentMaster').prop("checked", false);
    $('#RulesMaster').prop("checked", false);
    $('#GlobalConfigMaster').prop("checked", false);
    $('#GlobalPhrasesMaster').prop("checked", false);
    $('#ApproveGlobalPhrasesMaster').prop("checked", false);
    $('#HotKeysMaster').prop("checked", false);
    $('#AddNewIWCallFlow').prop("checked", false);
    $('#AddNewOrderTake').prop("checked", false);
    $('#AddNewSubFlow').prop("checked", false);
    $('#SynonymMaster').prop("checked", false);
}
function cancelChange() {
    reset();
    $('#ModifyReason').val('');
    $("#popupDrill").modal("hide");
}

function getParam() {
    return {
        modifyReason: $('#modifyReason').val(),
        roleName: $('#roleName').val(),
        roleType: $('#roleType').val(),
        iwappname: $('#iwappname').val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function iwchange() {
    $("#iwappname").val($("#iw").data("kendoDropDownList").value());
    $("#grid").data("kendoGrid").dataSource.read();
}
function onAutoCompleteSelectDrill(e) {
    var fieldValue = this.options.dataTextField;
    var filterValue = e.dataItem[fieldValue];
    if (e.sender._oldText == "") {
        $("#gridIWRoleAccessDetails").data("kendoGrid").dataSource.filter({});
    } else {
        $("#gridIWRoleAccessDetails").data("kendoGrid").dataSource.filter({ operator: "contains", field: this.options.dataTextField, value: filterValue });
    }
}

function onAutoCompleteChangeDrill(e) {
    if (e.sender._oldText == "") {
        $("#gridIWRoleAccessDetails").data("kendoGrid").dataSource.filter({});
    }
}



//Go's to Agent Setting module to edit/add new agent
function openRoleManagement() {
    window.location = window.ApplicationPath + 'RoleManagement' + '/Index';
}