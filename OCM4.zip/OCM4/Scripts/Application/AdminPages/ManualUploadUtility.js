﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "ManualUploadUtlity.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shruthi",
        Description: "Applied Module hierarchy"
    });
});

function onUploadUtilitySave(e) {
    try {
        e.model.UploadFileName = $("#FileNameTemp").val();
        e.model.ContactList = $("#ContactList").data("kendoDropDownList").text();
        if (e.model.ContactList == "") {
            toaster("Please select a contactList", "error");
            e.preventDefault();
            return;
        }
        if (e.model.UploadFileName == "") {
            toaster("Please select a Csv file", "error");
            e.preventDefault();
            return;
        }
        var values = e.model.UploadFileName.split('.')
        if (values[0] != e.model.ContactList) {
            toaster("Filename and ContactList should be same", "error");
            e.preventDefault();
            return;
        }
        validateOrgUnit(e);
        modifyValid(e);
    }
    catch (e) {
        console.log("Exception in onUploadUtilitySave(): " + ex);
    }
}

function uploadFiles(e) {
    try {
        var tr = $(e.target).closest("tr"); //get the row for Download
        var data = this.dataItem(tr);
        var loadingdiv = document.getElementById('loading');

        var rate_value;
        if (document.getElementById('append').checked) {
            rate_value = document.getElementById('append').value;
            rate_value = "Append";
        }
        if (document.getElementById('refresh').checked) {
            rate_value = document.getElementById('refresh').value;
            rate_value = "Refresh";
        }
        toaster("Please Wait ! Uploading file to POM Server", "info");
        loadingdiv.style.display = "block";
        $.ajax({
            type: "POST",
            url: window.ApplicationPath + 'POMManualUploadUtility/UploadFilePOM',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            data: { "path": data.UploadFilePath, "rate": rate_value, "contactList": data.ContactList, "key": data.UploadKey, "id": data.id, "uploadId": data.UploadId },
            success: function (returneddata) {
                requestPrevent = 0;
                message = returneddata.Errors;
                if (message.hasOwnProperty("Success") == true) {
                    loadingdiv.style.display = "none";
                    toaster(message.Success.errors[0], "success");
                    $("#checkerGrid").data("kendoGrid").dataSource.read();
                    $('#checkerGrid').data('kendoGrid').refresh();
                }
                else if (message.hasOwnProperty("Info") == true) {
                    loadingdiv.style.display = "none";
                    toaster("File has already been uploaded to POM Server", "info");
                    $("#checkerGrid").data("kendoGrid").dataSource.read();
                    $('#checkerGrid').data('kendoGrid').refresh();
                }
                else {
                    loadingdiv.style.display = "none";
                    toaster(message.Failure.errors[0], "error");
                    $("#checkerGrid").data("kendoGrid").dataSource.read();
                    $('#checkerGrid').data('kendoGrid').refresh();
                }
            },
            error: function (returneddata) {
                loadingdiv.style.display = "none";
                toaster(msg.d, "error");
                $("#checkerGrid").data("kendoGrid").dataSource.read();
                $('#checkerGrid').data('kendoGrid').refresh();
            }
        });
    }
    catch (e) {
        console.log("Exception in uploadFiles(): " + e);
    }
}

function attachClickHandler(e) {
    try {
        readFileAfterDelegate = setFileUploadValues;
        readFile(e, this.wrapper, "wav", $("#FileNameTemp")); 
    }
    catch (e) {
        console.log("Exception in attachClickHandler(): " + e);
    }
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validation']").html("");
        control.val(fileInfo.name);
    }
}

function onCsvUploadSuccess(e) {
    try {
        if (e.response == "success") {
            $("#grid").data("kendoGrid").dataSource.read();
            $('#grid').data('kendoGrid').refresh();
            toaster("CSV has been Successfully uploaded", "success");
        }
        if (e.response == "failure") {
            toaster("CSV has not been uploaded", "failure");
        }
        if (e.response == "nodata") {
            toaster("CSV either has some issues or no data to upload", "info");
        }
    }
    catch (e) {
        console.log("Exception in onCsvUploadSuccess(): " + e);
    }
}

function SendToCheckerApproval() {
    try {
        if ($('#TemplateIdStatus').val() == "") {
            toaster("Please Select Template", "error");
            return;
        }
        if ($('#SelectedIdListSms').val() == "") {
            toaster("Please Select rows for bulk update", "error");
            return;
        }
        kendo.prompt("Please, enter modify reason:", "").then(function (data) {
            $.ajax({
                type: "POST",
                url: 'SendToCheckerApproval',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                data: { "TemplateId": $('#TemplateIdStatus').val(), "id": $('#SelectedIdListSms').val(), "comments": data },
                dataType: "json",
                cache: false,
                success: function (data) {
                    if (data == 1) {
                        toaster("Sent data for Checker Approval", "success")
                        $("#grid").data("kendoGrid").dataSource.read();
                        $('#grid').data('kendoGrid').refresh();
                    }
                    else {
                        toaster("Sending failed for Checker Approval", "error");
                        $("#grid").data("kendoGrid").dataSource.read();
                        $('#grid').data('kendoGrid').refresh();
                    }

                },
                error: function (data) {
                    console.log(data);
                }
            });
        }, function () {
        })
    }
    catch (e) {
        console.log("Exception in SendToCheckerApproval(): " + e);
    }
}

function categoriesChange(e) {
    try {
        var value = this.value()
        $('#TemplateIdStatus').val(value);
    }
    catch (e) {
        console.log("Exception in categoriesChange(): " + e);
    }
}
var globalName;
function onIconFileUpload(e) {
    try {
        // $(".k-upload-action").hide();
        e.data = { codeID: $("#ContactList").data("kendoDropDownList").text(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
        globalName = e.files[0].name;
        $(".k-icon.k-i-close.k-i-cancel").hide();
        //$(".k-upload-action").toggle();
        //$(".k-i-cancel").hide();
        //$(".k-upload-action").hide();
        // $(".k-button.k-upload-action").toggle();
        //$(".k-i-cancel").toggle();
        //$(".k-button.k-upload-action").css("visibility", "hidden");
    }
    catch (e) {
        console.log("Exception in onIconFileUpload(): " + e);
    }
}

function onCsvRemove(e) {

}

//function onCancel(e) {
//    var fileName = e.files[0].name;
//    if (fileName !== "") {
//        $.ajax({
//            type: "POST",
//            url: window.ApplicationPath + 'POMManualUploadUtility/RemoveProcessingFile',
//            data: { "FileName": fileName },
//            dataType: "json",
//            cache: false,
//            success: function (data) {
//                if (data == true) {
//                    toaster("File removed!", "success")

//                }
//                else {
//                    toaster("File is under process", "error");

//                }

//            },
//            error: function (data) {
//                console.log(data);
//            }
//        });
//    }
//}

function onCsvUpload(e) {
    try {
        var response = jQuery.parseJSON(e.XMLHttpRequest.responseText);
        //$(".k-upload-action").toggle();
        //$(".k-i-cancel").show();
        //$(".k-upload-action").show();
        //$(".k-button.k-upload-action").toggle();
        //$(".k-button.k-upload-action").css("visibility", "visible");
        $(".k-icon.k-i-close.k-i-cancel").hide();
        if (response.Message != null) {
            if (response.Message.toLowerCase() == "deleted") {
                toaster("File has been deleted!", "info");
                $(".k-upload-files.k-reset").find("li").remove();
                $(".k-upload-status").remove();
                globalName = "";
                $('#FileNameTemp').removeAttr('value');
                //$(".k-upload-action").toggle();
                return;
            }
            else if (response.Message == "") {
                //$(".k-upload-action").toggle();
                toaster("CSV has been Successfully uploaded by Maker", "success");
            }
            else if (response.Message.toLowerCase() == "failure") {
                toaster("Invalid. CSV has not been uploaded", "error");
                $(".k-upload-files.k-reset").find("li").remove();
                $(".k-upload-status").remove();
                globalName = "";
                $('#FileNameTemp').removeAttr('value');
                //$(".k-upload-action").toggle();
            }
            else if (response.Message.toLowerCase() == "nodata") {
                toaster("Contact List and Filename are different", "error");
                $(".k-upload-files.k-reset").find("li").remove();
                $(".k-upload-status").remove();
                globalName = "";
                $('#FileNameTemp').removeAttr('value');
                //$(".k-upload-action").toggle();
            }
            else if (response.Message.toLowerCase() == "invalid") {
                toaster("Invalid Data! Cannot upload the file", "error");
                $(".k-upload-files.k-reset").find("li").remove();
                $(".k-upload-status").remove();
                globalName = "";
                $('#FileNameTemp').removeAttr('value');
                //$(".k-upload-action").toggle();
            }

            else if (response.Message.toLowerCase() == "pending") {
                toaster("Record cannot be created now. Uploading same contact list file is pending", "info");
                $(".k-upload-files.k-reset").find("li").remove();
                $(".k-upload-status").remove();
                globalName = "";
                $('#FileNameTemp').removeAttr('value');
                //$(".k-upload-action").toggle();
            }
            else if (response.Message.toLowerCase() == "rewrite") {
                toaster("Success. File re-written", "info");
            }

            else {
                var response = response.Message.toLowerCase();
                toaster("Upload Failed- Contact ID(s) failed are/is: " + response, "error");
                $(".k-upload-files.k-reset").find("li").remove();
                $(".k-upload-status").remove();
                globalName = "";
                $('#FileNameTemp').removeAttr('value');
                //$(".k-upload-action").toggle();
            }
        }
        else if (response.DuplicateCount > 0) {
            //var response = e.XMLHttpRequest.response;
            //$(".k-upload-action").show();
            toaster("Duplicate Count: " + response.DuplicateCount, "info");
        }

    }
    catch (e) {
        //$(".k-upload-action").show();
        console.log("Exception in onCsvUpload(): " + e);
    }
}

//Below method will download the csv file to local system, exclusively for POMManualUploadUtility module
function DownloadCSV(e) {
    try {
        var tr = $(e.target).closest("tr");
        var data = this.dataItem(tr);
        var upload = data.NewValues.split('<br/>')[3];
        var link = upload.split("UploadFilePath:")[1];
        window.open(link, 'Download');
        return link;
    }
    catch (e) {
        console.log("Exception in DownloadCSV(): " + e);
    }
}

function DownloadCSVChecker(e) {
    try {
        var tr = $(e.target).closest("tr");
        var data = this.dataItem(tr);
        var upload = data.UploadFilePath;

        window.open(upload, 'Download');
        return upload;
    }
    catch (e) {
        console.log("Exception in DownloadCSVChecker(): " + e);
    }
}

function onCancel(e) {

}