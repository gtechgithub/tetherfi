﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "TeamManagement.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreyas K R",
        Description: "Added Anti forgery header for onLevelDropdownChange"
    });
});
/** on edit fucntion to map the model to fields*/
function editTeam(e) {
    if (e.model.isNew() === true) {
        $("#hierarchy").show();
    }
    else {
        $("#hierarchy").hide();
        var kendoddl = $("<div class='form-group' style='padding: 15px;'><div class='col-lg-3'><label>Name*</label></div><div class='col-lg-7'><input id='Name' type='text' class='k-textbox' style='width: 100%;' /></div></div>");
        $("#teamlevel").append(kendoddl);
        $('#Name').val(e.model.Name);
        $("#levelId").val("0");
    }
    genericEdit(e);
}

/** on save fucntion to for validation,map field value to model*/
function onSaveTeam(e) {
    var fieldNames = [];
    var fieldValues = [];
    if (e.model.isNew() === true) {
        if ($("#LevelHierarchy").data("kendoDropDownList").value() === "") {
            toaster("Please Provide Level Hierarchy", "error");
            e.preventDefault();
            return false;
        }
        e.model.LevelHierarchy = $("#LevelHierarchy").data("kendoDropDownList").text()
        e.model.LevelHierarchyID = $("#LevelHierarchy").data("kendoDropDownList").value()
        e.model.ParentID = $("#parentId").val();
        e.model.Name = $("#Name").val();
        var globalvar = [];
        globalvar = jsonfields.AgentHierarchy;
        finaldata = [];

        GetTopMostParent(globalvar, $("#levelId").val(), finaldata);

        var field = finaldata.reverse();

        for (i = 0; i < field.length; i++) {
            fieldNames.push(field[i].LevelHierarchy);

            if (i != field.length - 1) {
                fieldValues.push($("#" + field[i].ID).data("kendoDropDownList").value());
            }
            else {
                fieldValues.push(e.model.Name);
            }
        }
    }
    else {
        e.model.Name = $("#Name").val();
        fieldNames.push("Name");
        fieldValues.push(e.model.Name);
    }
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) !== "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    duplicateValidate(e, "Name", "Name");
    modifyValid(e);
}

/** on drop down select this fucntion will be triggered and based on selection dynamically hierarchys are created*/
function onLevelDropdownChange(e) {
    if (e.item) {
        var dataItem = this.dataItem(e.item);
        var globalvar = [];
        globalvar = jsonfields.AgentHierarchy;
        finaldata = [];
        $("#parentId").val("0");
        $("#levelId").val(dataItem.ID);

        GetTopMostParent(globalvar, dataItem.ID, finaldata);

        finaldata.reverse();

        $("#teamlevel").html("");

        for (var i = 0; i < finaldata.length; i++) {
            if (finaldata[i].ID !== dataItem.ID) {
                var hierarchyfiled = $("<div class='form-group' style='padding: 15px;'><div class='col-lg-3'><label>" + finaldata[i].LevelHierarchy + "*</label></div><div class='col-lg-7'><input id=" + finaldata[i].ID + " value=1 style='width: 100%;' /></div></div>");

                $("#teamlevel").append(hierarchyfiled);

                if (i === 0) {
                    $("#" + finaldata[i].ID).kendoDropDownList({
                        optionLabel: "Select",
                        dataTextField: "Text",
                        dataValueField: "Value",
                        select: onSelectLevel,
                        dataSource: {
                            serverFiltering: true,
                            transport: {
                                read: {
                                    dataType: "json",
                                    type: "POST",
                                    contentType: "application/json; charset=utf-8",
                                    url: window.ApplicationPath + 'TeamManagement/GetLevelDropDown',
                                    headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() }
                                }
                            }
                        }
                    }).data("kendoDropDownList").enable(true);

                    $("#" + finaldata[i].ID).data("kendoDropDownList").select(0);
                }
                else {
                    $("#" + finaldata[i].ID).kendoDropDownList({
                        autoBind: false,
                       cascadeFrom: finaldata[i - 1].ID,
                        optionLabel: "Select",
                        dataTextField: "Text",
                        dataValueField: "Value",
                        select: onSelectLevel
                    }).data("kendoDropDownList").enable(false);
                }
            }
            else {
                var childfield = $("<div class='form-group' style='padding: 15px;'><div class='col-lg-3'><label>Name*</label></div><div class='col-lg-7'><input id='Name' type='text' class='k-textbox' style='width: 100%;' /></div></div>");

                $("#teamlevel").append(childfield);
            }
        }
        return false;
    } else {
        console.log("event :: select");
    }
}

/** to set data source dynamically to  hierachry dropdown on select of parent drop down*/
function onSelectLevel(e) {
    var dataItem = e.sender.element.context.id;
    var selectedId = this.dataItem(e.item);
    if (selectedId.Value != null) {
        $("#parentId").val(selectedId.Value);
        var globalvar = [];
        globalvar = jsonfields.AgentHierarchy;
        finaldata = [];
        GetNextChild(globalvar, dataItem, finaldata);

        $.ajax({
            url: window.ApplicationPath + 'TeamManagement/GetLevelDropDown',
            headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
            type: "POST",   
            data: JSON.stringify({
                'id': selectedId.Value
            }),
            dataType: "json",
            contentType: 'application/json',
            success: function (data) {
                if (data !== "") {
                    var dataSource = new kendo.data.DataSource({ data: data, serverFiltering: true });
                    var dropdownlist = $("#" + finaldata[0].ID).data("kendoDropDownList");
                    if (dropdownlist !== null) {
                        dropdownlist.setDataSource(dataSource);
                    }
                }
            },
            error: function (ex) {
                console.log(ex);
            }
        });
    } 
}

/** recursive function to get heirarchy tree top level to bottom level*/
function GetTopMostParent(data, currentId, finaldata) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].ID == currentId) {
            finaldata.push({
                ParentID: data[i].ParentID,
                ID: data[i].ID,
                LevelHierarchy: data[i].LevelHierarchy
            });
            if (currentId === 0) {
                return false;
            }
            GetTopMostParent(data, data[i].ParentID, finaldata);
        }
    }
}

/** fucntion to get parent next child by parentid*/
function GetNextChild(data, currentId, finaldata) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].ParentID == currentId) {
            finaldata.push({
                ParentID: data[i].ParentID,
                ID: data[i].ID,
                LevelHierarchy: data[i].LevelHierarchy
            });
            return false;
        }
    }
}