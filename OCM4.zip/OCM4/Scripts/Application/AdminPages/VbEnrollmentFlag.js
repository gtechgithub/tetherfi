﻿function val_alpha_num(e) {
    var keyCode = (e.which) ? e.which : e.keyCode
    if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122) && (keyCode < 48 || keyCode > 57) && keyCode != 32 || keyCode == 13)
        return false;
    return true;
}

function onDnisFilter(e) {
    var value = this.value(),
    grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({});
        grid.dataSource.filter({ field: "DNIS", operator: "eq", value: value });
    }
    else {
        grid.dataSource.filter({});
    }
}

function onVbEnrollmentFlagEdit(e) {
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $(e.container).find('input[name="DNIS"]').attr("readonly", true);
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }

}
function onVbEnrollmentFlagSave(e) {
    /// <summary>
    /// Function triggered when clicking Save Button
    /// </summary>
    /// <param name="e">e contains all the model data</param>
    /// <returns type="">false if validation does not happen</returns>
    duplicateValidate(e, "DNIS", "DNIS")
    var Dnis = $("#DNIS").val();
    var HotlineName = $("#HotlineName").val();
    var EnrollmentFlag = $("#EnrollmentFlag").data("kendoDropDownList").value();
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("DNIS");
    fieldNames.push("Hotline Name");
    fieldNames.push("Enrollment Flag");

    fieldValues.push(Dnis);
    fieldValues.push(HotlineName);
    fieldValues.push(EnrollmentFlag);
    
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    modifyValid(e);
}