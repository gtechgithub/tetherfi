﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "CMDataLink.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});

function onCMDataSyncSave() {
    try {
        var objectType = $("#option").data("kendoDropDownList").value();
        var currentModifyReason = $("#ModifyReason").val();

        var fieldNames = new Array();
        var fieldValues = new Array();

        fieldNames.push("Object Type");
        fieldNames.push("Modify Reason");

        fieldValues.push(objectType);
        fieldValues.push(currentModifyReason);

        var result = validateBlankFields(fieldNames, fieldValues);

        if ($.trim(result) != "") {
            toaster("Please Provide " + result, "error");
            e.preventDefault();
            return false;
        }
        swal({
            title: "Are you sure?",
            text: "Confirm to Save data",
            icon: "warning",
            buttons: true,
            dangerMode: false,
        })
            .then(function (willDelete) {
                if (willDelete) {
                    $("#syncButton").addClass("k-state-disabled");
                    $.ajax({
                        type: "POST",
                        url: window.ApplicationPath + 'CMDataLink/SyncData',
                        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                        data: { "changeType": objectType, "modifyReason": currentModifyReason },
                        dataType: "json",
                        success: function (msg) {
                            try {
                                requestPrevent = 0;
                                message = msg.Errors;
                                var y = message.hasOwnProperty("Success");
                                if (y == true) {
                                    toaster(message.Success.errors, "success");
                                    $("#option").data("kendoDropDownList").select(0);
                                    $("#ModifyReason").val("");
                                    $("#syncButton").removeClass("k-state-disabled");
                                }
                                else {

                                    toaster(message.Failure.errors, "error");
                                    $("#option").data("kendoDropDownList").select(0);
                                    $("#ModifyReason").val("");
                                    $("#syncButton").removeClass("k-state-disabled");
                                }
                            } catch (e) {
                                toaster(msg.d, "error");
                                $("#syncButton").removeClass("k-state-disabled");
                            }
                        },
                        error: function (msg) {
                            console.log(msg);
                            toaster(msg.d, "error");
                            kendo.ui.progress(progress, false);
                        },

                    });
                }
            });
    } catch (e) {
        console.log(e);
    }
}