﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "VIPListManagement.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning, Moved js function from index page to new js file"
    });
});

function onVIPListManagementEdit(e) {
    genericEdit(e);
    $("#CallerID").data("kendoNumericTextBox").bind("spin", onSpin);
}

function onSpin() {
    var CallerID = $("#CallerID").val();
    var MaxCallerID;
    var field = jsonfields;

    for (i = 0; i < field.length; i++) {
        if (field[i].PropertyName == "CallerID") {
            MaxCallerID = field[i].Maxlength;
            break;
        }
    }

    if (CallerID.length > MaxCallerID) {
        var NewCallerID = $("#CallerID").data("kendoNumericTextBox");
        NewCallerID.value(CallerID - 1);
        return;
    }
}
function onDownload() {
    try {
        post(window.ApplicationPath + 'VIPListManagement/Download');
      
    } catch (e) {
        console.log(e);
    }
}

function post(path) {
    method = "post";
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    document.body.appendChild(form);
    form.submit();
}

function onVIPListManagementSave(e) {

    var fieldNames = new Array();
    var fieldValues = new Array();
    var field = jsonfields;

    for (i = 0; i < field.length; i++) {
        if (field[i].Hidden != true & field[i].Mandatory == true) {
            fieldNames.push(field[i].Title)
            fieldValues.push(e.model[field[i].PropertyName]);
        }
    }
    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
        e.preventDefault();
        return false;
    }
    modifyValid(e);
}



function onBulkUpdateClose(e) {
    $("#MakerComments").val("");
    $('#checkAllRow', grid.tbody).prop('checked', false);
    checkAll();
}

function checkAll() {
    var checked = $("#checkAllRow").is(":checked");
    $('.checkbox:not(:disabled)', grid.tbody).prop('checked', checked);
}


function onCsvUpload(e) {
    if (e.XMLHttpRequest.response == "") {
        $("#grid").data("kendoGrid").dataSource.read();
        $('#grid').data('kendoGrid').refresh();
        toaster("CSV has been Successfully uploaded", "success");
        $("#bulkVipUploadWindow").data("kendoWindow").center().close();
    }
    if (e.XMLHttpRequest.response == "Failure") {
        toaster("CSV has not been uploaded", "error");
        $(".k-upload-status").remove();
    }
    if (e.XMLHttpRequest.response == "NoData") {
        toaster("CSV either has some issues or no data to upload", "info");
        $(".k-upload-status").remove();
    }
}

function onCsvSelect(e) {
    var wrapper = this.wrapper;
    var validExt = "csv";
    readFile(e, wrapper, validExt);
}

function bulkVipUpload() {
    $("#bulkVipUploadWindow").data("kendoWindow").center().open();
}


