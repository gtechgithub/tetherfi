﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "FaxDnis.js",
        Version: "3.2.7.20",
        LastModifiedDateTime: "20-7-2019 12:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Module hierarchy applied"
    });
});

function onFaxDnisEdit(e) {
    genericEdit(e);
    bindingOrgUnit(e);
    if (e.model.isNew() == false) {
        $("#ModifyReasonGroup").show();
        $(e.container).find('input[name="DNIS"]').attr("readonly", true);
        $(e.container).find('input[name="FaxLineName"]').attr("readonly", true);
        $(e.container).find('input[name="Prefix"]');
    }
    if (e.model.isNew() == true) {
        $("#ModifyReasonGroup").hide();
    }
}

//Below function is called when clicked on Save/Update
function onFaxDnisSave(e) {
    if (e.model.DNIS == "" || e.model.DNIS == null) {
        toaster("Please enter the Fax Line", "error");
        e.preventDefault();
        return;
    }
    //if (e.model.Prefix == "" || e.model.Prefix == null) {
    //    toaster("Please enter the Prefix", "error");
    //    e.preventDefault();
    //    return;
    //}
    if ((e.model.FaxLineName.replace(/ /g, '')) == "" || e.model.FaxLineName == null) {
        toaster("Please enter the Fax Line Name", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Description.replace(/ /g, '') == "") {
        toaster("Please enter the Description", "error");
        e.preventDefault();
        return;
    }
    if (e.model.Enabled == "" || e.model.Enabled == null) {
        toaster("Please select the Overall Status", "error");
        e.preventDefault();
        return;
    }
    if (e.model.SendEnabled == "" || e.model.SendEnabled == null) {
        toaster("Please select the Send Status", "error");
        e.preventDefault();
        return;
    }
    if (e.model.ReceiveEnabled == "" || e.model.ReceiveEnabled == null) {
        toaster("Please select the Receive Status", "error");
        e.preventDefault();
        return;
    }
    validateOrgUnit(e);
    modifyValid(e);
}

function openFaxAckList(e) {
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var dnis = data.DNIS;
    window.location = window.ApplicationPath + 'FaxAutoAckTemplates' + '/Index?DNIS=' + dnis;
}

function openFaxRouteList(e) {
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var dnis = data.DNIS;
    window.location = window.ApplicationPath + 'FaxRouteMap' + '/Index?DNIS=' + dnis;
}

function openFaxSenderList(e) {
    var tr = $(e.target).closest("tr"); //get the row
    var data = this.dataItem(tr); //get the row data so it can be referred later
    var dnis = data.DNIS;
    window.location = window.ApplicationPath + 'FaxSenders' + '/Index?DNIS=' + dnis;
}