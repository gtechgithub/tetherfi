﻿// ----------------------------------------------------------------------------------
// Register your Filename and version
// Whenever this file changed, Update the Version of the file.
// ----------------------------------------------------------------------------------

$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "DeskManager.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 PM",
        LastModifiedBy: "Shreenitha",
        Description: "Added new version"
    });

    initializeGridTooltip('grid');
    enableDisableGridAutoResize = 1;
});
var gridNameTriggeredForSave = ""; //Used to store the name of the subGrid for which save will be triggered

$('.k-grid-save-changes').hide();

function OnAddNew(gridName) {

    var grid = $("#" + gridName).data("kendoGrid");
    var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; e.TeamId = teamId; e.TeamName = teamName; });
}
function onEdit(e) {

    var model = e.model; // access edited/newly added model
    // model is observable object, use set method to trigger change event
    model.set("TeamName", teamName);
    model.set("TeamId", teamId);
    if (e.model.isNew() == true) {
        $('[name="TeamName"]').attr("readonly", true);
    }
}

function onSaveData(e) {
   
    var fieldNames = new Array();
    var fieldValues = new Array();

    //fieldNames.push("Team Id");
    //fieldNames.push("Team Name");
    fieldNames.push("Aux Code From");
    fieldNames.push("Aux Code To");
    fieldNames.push("Threshold");
    fieldNames.push("Delete");
    fieldNames.push("Allow Status Change");
    fieldNames.push("Allow Notification");

    //fieldValues.push(e.model.TeamId);
    //fieldValues.push(e.model.TeamName);
    fieldValues.push(e.AuxCodeFrom);
    fieldValues.push(e.AuxCodeTo);
    fieldValues.push(e.Threshold);
    fieldValues.push(e.IsDeleted);
    fieldValues.push(e.IsStatusChange);
    fieldValues.push(e.AllowNotification);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please Provide " + result, "error");
       // e.preventDefault();
        return false;
    }
    else {
        return true;
    }

}


function OnDeskManagerMainGridDataBound(e) {
    try {
        externalHeightForGrid = 0;
        onDataBound(e);
    } catch (e) {
        console.log(e);
    }
}
var teamId = "";
var teamName = "";
function onDeskManagerMainGridChange(arg) {

    try {
        var selectedData = $.map(this.select(), function (item) {
            return $(item).text();
        });
        console.log(selectedData);
        var $grid = arg.sender; //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var row_uid = $row.attr('data-uid'); //uid of selected row
        var cell_index = $cell.index(); //cell index 0 based
        var row_index = $row.index(); //row index 0 based
        var TeamId = $grid.dataItem($row).TeamId; //selected row data
        var TeamName = $grid.dataItem($row).TeamName; //selected row data
        console.log(TeamId);
        teamId = TeamId;
        teamName = TeamName
        var colName = $("#grid").find('th').eq(cell_index).text()//selected column name
        $("#searchDForm").html('');
        set = false;
        console.log(TeamId);
        $("#TeamId").val(TeamId);
        $("#TeamName").val(TeamName);
        var grid = $("#gridDetails").data("kendoGrid");
        grid.dataSource.data("");
        externalHeightForGrid = 30;
        setGridHeight(20, "gridDetails");
        if (selectedData != null) {
            $("#gridDetails").data("kendoGrid").dataSource.read();
            $('#popupDrill').modal('show');
            $("#DrillPopupFooter").hide();
            $("#searchDFormTemplate").hide();
            $("#DrillReportNameLbl").html("<h2>Desk Manager Threshold details</h2><span class='theme-color'>Team Name</span> : <span class='theme-color'></span>" + TeamName);
            grid.dataSource.read();
        }
        if (selectedData === null) {
            toaster("There are no records to show", "info");
            return;
        }
    } catch (e) {
        console.log(e);
    }
}

function OnSaveSubGridAccessChanges(gridName) {

    try {
        var grid = $("#" + gridName).data("kendoGrid");
        var dirtyItems = $.grep(grid._data, function (e) {
           
            return e.dirty === true;
        });

        if (dirtyItems.length > 0 || grid._data[0].TeamId != teamId) {   
            if (DataValidate() == true) {

                $('#popupDrill').modal('hide');
                $("#ModifyReasonUser").val("")
                $("#modifyreasonwindowforUser").show();
                var wdw = $("#myWindowUser").data("kendoWindow");
                wdw.center().open();
                gridNameTriggeredForSave = gridName; //Store the name of the grid for which save will be triggered
            }
        }
        else {
            toaster("No rows has been changed", "info");
        }
    } catch (e) {
        console.log(e);
    }
}


function DataValidate() {

    var grid = $("#gridDetails").data("kendoGrid");
    var data = grid.dataItems();
    var isValid = true;
    $.each(data, function (i, row) {
        if (onSaveData(row) == false) {
            isValid = false;
        }
    });
    return isValid;    
}

function getData() {

    return {
        teamId: teamId,
        teamName: teamName,
        modifyReason: modifyReason, //$('#ModifyReason12').val()
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

var modifyReason = "";
function onDeskManagerDetailsGridSave(e) {

    e.data = {
        value: $('#modifyReason12').val()
    };
    e.sender._data[0].ModifyReason = $('#modifyReason12').val(); //modifyReason;
}

function onDetailDataBound() {

    var msg = '@(ViewBag.Message)';
    $("#DrillDetailLbl").html("<span class='theme-color'>Showing previously editted data, as there is no threshold set for this team</span>");
}

function saveChangeYes() {
    try {
        $('#modifyReason12').val($("#ModifyReasonUser").val());
        if ($.trim($('#modifyReason12').val()) == "") {
            toaster("Please enter the Modify Reason", "error");
            return;
        }
        else {
            $("#" + gridNameTriggeredForSave + " .k-grid-save-changes").trigger("click");
            $("#myWindowUser").data("kendoWindow").close();
            $('#grid').data('kendoGrid').dataSource.read();
            modifyReason = $("#ModifyReasonUser").val();
        }
    } catch (e) {
        console.log(e);
    }
}

function DataSave(e) {

    var $that = this;
    var grid = $("#gridDetails").data("kendoGrid");
    var data = grid.dataItems();
    var selectedRowItem = $.extend({}, grid.dataItem(grid.select())); 
    selectedRowItem[this.element.attr('id')] = e.dataItem.Name;

    if (selectedRowItem.AuxCodeFrom == "On Call - Hold" && selectedRowItem.AuxCodeTo != "Un Hold") {
        grid.dataItem(grid.select()).set('AuxCodeTo', 'Un Hold'); 
        selectedRowItem.AuxCodeTo = "Un Hold"
    }
    if (selectedRowItem.AuxCodeFrom != "On Call - Hold" && selectedRowItem.AuxCodeTo == "Un Hold") {
        grid.dataItem(grid.select()).set('AuxCodeFrom', 'On Call - Hold');
        selectedRowItem.AuxCodeFrom = "On Call - Hold"
    }
  
    $.each(data, function (i, row) {
        if (selectedRowItem.AuxCodeFrom == row.AuxCodeFrom && selectedRowItem.AuxCodeTo == row.AuxCodeTo) {                 
            toaster("Please select different Aux code", "error");
            e.preventDefault();
            return;
        }
    });     
}


function saveChangeNo() {
    $("#myWindowUser").data("kendoWindow").close();
}