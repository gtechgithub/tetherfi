﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\AdminPages",
        FileName: "IvrCallbackManagement.js",
        Version: "3.2.9.1801",
        LastModifiedDateTime: "14-11-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Changes done to search with same start and end date"
    });

 });

function filtercall() {
    if ($('#start').val() == "") {
        toaster("Please select start date", "error")
        return;
    }
    if ($('#end').val() == "") {
        toaster("Please select start date", "error")
        return;
    }
    $("#grid").data("kendoGrid").dataSource.read();
}
function categoriesChange() {
    var value = this.value(),
         grid = $("#grid").data("kendoGrid");

    if (value) {
        grid.dataSource.filter({ field: "StatusOfCallback", operator: "eq", value: value });
    } else {
        grid.dataSource.filter({});
    }
}

function startChange() {
    var endPicker = $("#end").data("kendoDateTimePicker"),
        startDate = this.value();

    if (startDate) {
        startDate = new Date(startDate);
        //startDate.setDate(startDate.getDate() + 1);
        //startDate.setMinutes(startDate.getMinutes() + 30);
        endPicker.min(startDate);
    }
}

function endChange() {
    var startPicker = $("#start").data("kendoDateTimePicker"),
        endDate = this.value();

    if (endDate) {
        endDate = new Date(endDate);
        //endDate.setDate(endDate.getDate() - 1);
        //endDate.setMinutes(endDate.getMinutes() - 30);
        startPicker.max(endDate);
    }
}

function datevaluefetch()
{
    return {
        startdate: $("#start").val(),
        enddate: $("#end").val(),
        __RequestVerificationToken: $("#AntiForgeryToken").val()
    };
}

function clearFilters() {
    $("form.k-filter-menu button[type='reset']").trigger("click");
};

function onChangeCallback() {
    //$('#SelectedIdListSms').val(this.selectedKeyNames().join(", "));
    var idsToSend = [];

    var grid = $("#grid").data("kendoGrid")
    var ds = grid.dataSource.view();

    for (var i = 0; i < ds.length; i++) {
        var row = grid.table.find("tr[data-uid='" + ds[i].uid + "']");
        var checkbox = $(row).find(".checkbox");

        if (checkbox.is(":checked")) {
            idsToSend.push(ds[i].Srno);
        }
    }
    $('#SelectedIdListSms').val(idsToSend);
}
function ondataboundCallBack(e)
{
    $("#checkAllRow")[0].checked = e.sender.items().find(":checked").length == e.sender.dataSource.view().length;
    onDataBound(e);
}

function checkAll() {
    var checked = $("#checkAllRow").is(":checked");
    $('.checkbox:not(:disabled)', grid.tbody).prop('checked', checked);
}
function changeStatusToOpen() {
    onChangeCallback()
    if ($('#SelectedIdListSms').val() == "") {
        toaster("Please Select rows for bulk status update", "error");
        return;
    }

    var grid = $("#grid").data("kendoGrid");
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'IvrCallbackManagement/ChangeStatusToOpen',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { "id": $('#SelectedIdListSms').val()},
        success: function (returneddata) {
            if (returneddata == 0) {
                toaster("Record Successfully Updated", "success");
                grid.dataSource.read();
                grid.clearSelection();
                $('#SelectedIdListSms').val("");
            }
            else {
                toaster("Record Not Updated", "error");
                grid.dataSource.read();
                grid.clearSelection();
                $('#SelectedIdListSms').val("");
            }
        },
        error: function(){
            toaster("Some Error Occurred", "error");
            grid.dataSource.read();
            grid.clearSelection();
            $('#SelectedIdListSms').val("");
        }
    });
}

function refreshgrid() {
    $("#categories").data("kendoDropDownList").select(null)
    $("#checkAllRow").val(false);
    ReloadMainGrid()
}
function changeStatusToClose() {
    onChangeCallback()
    if ($('#SelectedIdListSms').val() == "") {
        toaster("Please Select rows for bulk status update", "error");
        return;
    }

    var grid = $("#grid").data("kendoGrid");
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'IvrCallbackManagement/ChangeStatusToClose',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        data: { "id": $('#SelectedIdListSms').val()},
        success: function (returneddata) {
            if (returneddata == 0) {
                toaster("Record Successfully Updated", "success");
                grid.dataSource.read();
                grid.clearSelection();
                $('#SelectedIdListSms').val("");

            }
            else {
                toaster("Record Not Updated", "error");
                grid.dataSource.read();
                grid.clearSelection();
                $('#SelectedIdListSms').val("");
            }
        },
        error: function () {
            toaster("Some Error Occurred", "error");
            grid.dataSource.read();
            grid.clearSelection();
            $('#SelectedIdListSms').val("");
        }
    });
}