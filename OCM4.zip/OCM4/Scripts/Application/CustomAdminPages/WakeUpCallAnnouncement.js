﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "WakeUpCallAnnouncement.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});

function attachClickHandler(e) { 
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#waveFile")); 
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validation']").html("");
        control.val(fileInfo.name);
    }
}

function onWavFileUpload(e) {
    e.data = { functionality: $("#Functionality").val(), language: $("#Language").val(), module: $("#ControllerName").val() }; //sends the extra parameter to controller
}

/**
 * on edit of agent telephony validate for number,email,text;
 */
function editWakeUpCallAnnouncement(e) {
   
    genericEdit(e);
    if (e.model.isNew() == false) {
        $("#WakeupWavefileTag").css("visibility", "visible");
        $("#WakeupWavefileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.WaveFile + '">' + e.model.WaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');
        
        $("#waveFile").css("visibility", "visible");
        $("#waveFile").html(e.model.WaveFile);
    }
    if (e.model.isNew() == true) {
        $("#waveFile").css("visibility", "hidden");
        $("#WakeupWavefileTag").css("visibility", "hidden");
    }
}

/**
 * on select of dropdown in Agent telephony validate  number,email,text
 */
function onSaveWakeUpCallAnnouncement(e) {
    var description = $("#Description").val();
    if ($("#waveFile").val() !== "") {
        if ($("#waveFile").val().indexOf(".wav") > 0) {
            e.model.WaveFile = $("#waveFile").val();
            $(".k-upload-selected").trigger("click");
        }
        else {
            toaster("Please upload only wav file!", "error");
            e.preventDefault();
            return;
        }

    }
    else if (e.model.waveFileTag === "" || e.model.WaveFile === "") {
        toaster("Please upload a wav file!", "error");
        e.preventDefault();
        return;
    }
    if (e.model.waveFileTag !== "" && e.model.ModifyReason === null) {
        toaster("Please provide modify reason!", "error");
        e.preventDefault();
        return;
    }
    if (description == "") {
        e.preventDefault();
        toaster("Please provide a valid Description", "error");
        return;
    }
    modifyValid(e);
}