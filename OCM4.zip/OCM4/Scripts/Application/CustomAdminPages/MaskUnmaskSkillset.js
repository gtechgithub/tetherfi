﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "MaskUnmaskSkillset.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Replaced Helpline ID with Helpline Name in Skillset page"
    });
});

    var gridNameTriggeredForSave = ""; //Used to store the name of the subGrid for which save will be triggered


    function checkAll(ele, gridName) {
        try {
            var state = $(ele).is(':checked');
            var grid = $('#' + gridName).data().kendoGrid;
            $.each(grid.dataSource._pristineData, function () {
                $that = this;
                $.each(grid.dataSource.view(), function () {
                    if (this.Skill == $that.Skill) {
                        this['Mask'] = state;
                        this.dirty = CheckIfDirty(this, $that);
                        return false;
                    }
                });
            });
            grid.refresh();
        } catch (e) {
            console.log(e);
        }
    }

    function maskSkill(e, type, gridName) {
        try {
            //After the checkbox state is changed store its changed state in variable
            var state = $(e).is(':checked');
            var grid = $("#" + gridName).data("kendoGrid");
            //Get all details of the grid row based on the location of the selected checkbox
            var gridData = grid.dataItem($(e).closest("tr"));

            $.each(grid.dataSource._pristineData, function () {
                //Find the old data of the grid to compare
                if (this.Skill == gridData.Skill) {
            //Change the state in the model
                    gridData[type] = state;
                    gridData.dirty = CheckIfDirty(gridData, this);
                    return false;
                }
            });
            grid.refresh();
        } catch (e) {
            console.log(e);
        }
    }

    function getData() {
        return {
            HelpLineID: $("#HelpLineID").val(),
            modifyReason: $('#modifyReason12').val(),
            __RequestVerificationToken: $("#AntiForgeryToken").val()
        };
    }

    function SubGridGenericRequest(e) {
        try {
            var message = "";
            if (e.type === "update") {
                message = e.response.Errors;
                var y = message.hasOwnProperty("Success");
                if (y == true)
                    toaster(message.Success.errors[0], "success");
                else
                    toaster(message.Failure.errors[0], "error");
            }
        } catch (e) {
            console.log(e);
        }
    }

    function onMaskUnmasSkillsetkChange(arg) {
        try {
            var tr = $(arg.target).closest("tr"); //get the row for edit
            gridData = this.dataItem(tr);
            var HelpLineID = gridData.HelpLineID;
            var HelpLine = gridData.HelpLine;
            console.log(HelpLineID);

            //start of helpline filter
            var isEditable = false;
            var userHotlines = $("#userHotlines").val();
            var userhotlinesarray = userHotlines.split(',');
            for (var i = 0; i < userhotlinesarray.length; i++) {
                if (userhotlinesarray[i] != HelpLineID) continue;
                isEditable = true;
                break;
            }
            if (isEditable == false)
            {
                toaster("You cannot edit this record.", "error");
                arg.preventDefault();
                return;
            }
            //end of helpline filter

            $("#searchDForm").html('');
            set = false;
            $("#HelpLineID").val(HelpLineID);
            var grid = $("#gridSkillsetDetails").data("kendoGrid");
            grid.dataSource.data("");
            externalHeightForGrid = 30;
            setGridHeight(20, "gridSkillsetDetails");
            var windowWidget = $("#popup");

            kendo.ui.progress(windowWidget, true);

            $.ajax({
                type: "POST",
                url: window.ApplicationPath + 'MaskUnmaskSkillset/GetGridSkillData',
                headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
                data: JSON.stringify({
                    'HelpLineID': HelpLineID
                }),
                dataType: "json",
                contentType: 'application/json',
                success: function (data) {
                    if (data !== null) {
                        $('#popupDrill').modal('show');
                        $("#DrillPopupFooter").hide();
                        $("#searchDFormTemplate").hide();
                        $("#DrillReportNameLbl").html("<h2>Mask/Unmask Skillset in Phonebook</h2><span class='theme-color'>Helpline Name</span> : <span class='theme-color'></span>" + HelpLine);
                        grid.dataSource.read();
                        kendo.ui.progress(windowWidget, false);
                    }
                    else
                    {
                        toaster("There are no records to show", "info");
                        kendo.ui.progress(windowWidget, false);
                        return;
                    }
                },
                error: function () {
                    console.log('Failed to load');
                    kendo.ui.progress(windowWidget, false);
                }
            });
        } catch (e) {
            console.log(e);
        }
    }

    function OnSaveSubGridSkillChanges(gridName) {
        try {
            var grid = $("#" + gridName).data("kendoGrid");
            var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

            if (dirtyItems.length > 0) {
                $('#popupDrill').modal('hide');
                $("#ModifyReasonUser").val("")
                $("#modifyreasonwindowforUser").show();
                var wdw = $("#myWindowUser").data("kendoWindow");
                wdw.center().open();
                gridNameTriggeredForSave = gridName; //Store the name of the grid for which save will be triggered
            }
            else {
                toaster("No rows has been changed", "info");
            }
        } catch (e) {
            console.log(e);
        }
    }

    $(".k-grid-cancel-changes").on('click', function (e) {
        try {
            var gridName = this.parentElement.parentElement.id;
            e.preventDefault();
            var grid = $("#" + gridName).data("kendoGrid");
            var dirtyItems = $.grep(grid._data, function (e) { return e.dirty === true; });

            if (dirtyItems.length > 0) {
                return true;
            }
            else {
                toaster("No rows has been changed", "info");
            }
        } catch (e) {
            console.log(e);
        }
    });

    $('.k-grid-save-changes').hide();

    function SyncSubGrid(e) {
        if (e.type == "update" || e.type == "delete" || e.type == "create") {
            e.sender.read();
            $('.k-grid-update').html('<span class="k-icon k-i-check"></span> Save');
        }
    }

    var modifyReason = "";
    function onMaskUnmaskSkillsetSubGridSave(e) {
        e.data = {
            value: $('#modifyReason12').val()
        };
        e.sender._data[0].ModifyReason = modifyReason;
    }

    //Function to check the checkboxes when loading data
    function onMaskUnmaskSkillsetSubGridDatabound(e) {
        try {
            e.sender.items().each(function () {
                var dataItem = e.sender.dataItem(this);

                if (dataItem.Mask) {
                    $(this).addClass("k-state-selected");
                }
                kendo.bind(this, dataItem);
            });

            onDataBound(e);
            externalHeightForGrid = 0;
            setGridHeight(20);
            $("#checkAll")[0].checked = $("#checkSkill:checked").length === e.sender.dataSource.view().length;

        } catch (e) {
            console.log(e);
        }
    }

    //Modify Reason Window Methods
    function saveChangeYes() {
        try {
            $('#modifyReason12').val($("#ModifyReasonUser").val());
            if ($.trim($('#modifyReason12').val()) == "") {
                toaster("Please enter the Modify Reason", "error");
                return;
            }
            else {
                $("#" + gridNameTriggeredForSave + " .k-grid-save-changes").trigger("click");
                $("#myWindowUser").data("kendoWindow").close();
                $('#grid').data('kendoGrid').dataSource.read();
            }
        } catch (e) {
            console.log(e);
        }
    }

    function saveChangeNo() {
        $("#myWindowUser").data("kendoWindow").close();
    }

function CheckIfDirty(element, gridData) {
    try {
        if (element.Mask != gridData.Mask) {
            return true;
        }
        else {
            return false;
        }
    } catch (e) {
        console.log(e);
    }
}