﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "DexCRMLinks.js",
        Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});



function editDexCrmLink(e) {
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="Intent"]').attr("readonly", true);
    }
    genericEdit(e);
}
function onSaveDexCrmLink(e) {
    var intent = $("#Intent").val();
    var popUpURL = $("#PopUpURL").val();
    var appendWithPatronID = $("#AppendWithPatronID").data("kendoDropDownList").value();
    var enablePaiza = $("#EnablePaiza").data("kendoDropDownList").value();
    var enableFIT = $("#EnableFIT").data("kendoDropDownList").value();
    var enableExpress = $("#EnableExpress").data("kendoDropDownList").value();
    if (intent == "") {
        e.preventDefault();
        toaster("Please provide a valid Intent", "error");
        return;
    }
    if (popUpURL == "") {
        e.preventDefault();
        toaster("Please provide a valid PopUp URL", "error");
        return;
    }
    if (appendWithPatronID == "") {
        e.preventDefault();
        toaster("Please provide a valid Append With PatronID", "error");
        return;
    }
    if (enablePaiza == "") {
        e.preventDefault();
        toaster("Please provide a valid Enable Paiza", "error");
        return;
    }
    if (enableFIT == "") {
        e.preventDefault();
        toaster("Please provide a valid Enable FIT", "error");
        return;
    }
    if (enableExpress == "") {
        e.preventDefault();
        toaster("Please provide a valid Enable Express", "error");
        return;
    }
    duplicateValidate(e, "Intent", "Intent")
    modifyValid(e);
}

function ReloadData() {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'DexCRMLinks/ReloadData',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data) {
                toaster("Data Reloaded Successfully", "success");
            }
        },
        error: function () {
            toaster("Failed to Reload Data", "error");
            console.log('Failed to Reload Data');
        }
    });
}