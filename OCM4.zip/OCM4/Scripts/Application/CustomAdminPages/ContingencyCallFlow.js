﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "ContingencyCallFlow.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 00:00:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Disable Editable checkbox before hide"
    });
});

function onBeforeEditCallflow(e) {
    var isSuperAdmin = $("#isSuperAdmin").val();
    if (e.model.Editable == "False" && isSuperAdmin == "False")
    {   
        toaster("You cannot edit this record.", "error");
        e.preventDefault();
    }
}

function editContingencyCallFlow(e) { 
    if (e.model.isNew() == false) {
        var helplineid = e.model.HelpLineID;
        $("#Description").data("kendoDropDownList").enable(false);
        $("#HelpLine").data("kendoDropDownList").value(helplineid);
        $("#HelpLine").data("kendoDropDownList").enable(false);
        if (e.model.Editable.toLowerCase() == "false")
            $('#editable').prop("checked", false);
        else
            $('#editable').prop("checked", true);
        $("#chkeditable").hide();
    }
    else {
        $("#Description").data("kendoDropDownList").enable(true);
        $("#HelpLine").data("kendoDropDownList").enable(true);
        $('#editable').prop("checked", true);
        $("#chkeditable").show();
    }
    genericEdit(e);
}

function CheckForDupplicateCallflow(e, obj) {
    var helpLineID = e.model.HelpLineID;
    var description = e.model.Description;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].HelpLineID == helpLineID && obj[t].Description == description) {
            count++;
            if (count === 2) {
                return false;
            }   
        }
    }
    return true;
}

function onSaveContingencyCallFlow(e) {
    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("HelpLine","Description","Status")
    fieldValues.push(e.model.HelpLine,e.model.Description,e.model.Status);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

    if (CheckForDupplicateCallflow(e, this.dataSource.data()) === false) {
        toaster("Duplicate Call Flow for same HelpLine.", "error");
        e.preventDefault();
        return;
    }

    modifyValid(e);

    e.model.HelpLineID = $("#HelpLine").data("kendoDropDownList").value();
    e.model.HelpLine = $("#HelpLine").data("kendoDropDownList").text();
    if (document.getElementById('editable').checked) {
        e.model.Editable = "True";
    }
    else {
        e.model.Editable = "False";
    }
}
