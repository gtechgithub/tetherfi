﻿$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "ContingencyWaveFileUpload.js",
        Version: "3.2.9.18",
        LastModifiedDateTime: "18-09-2019 08:30:00 AM",
        LastModifiedBy: "Shruthi",
        Description: "Disable Editable checkbox before hide"
    });
});

function onBeforeEditWaveFile(e) {
    var isSuperAdmin = $("#isSuperAdmin").val();
    if (e.model.Editable == "False" && isSuperAdmin == "False") {
        toaster("You cannot edit this record.", "error");
        e.preventDefault();
    }
}

function editContingencyWaveFileUpload(e)
{
    genericEdit(e);
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="ReferenceWaveFileName"]').attr("readonly", true);
        var helplineid = e.model.HelpLineID;
        $("#Description").data("kendoDropDownList").enable(false);
        $("#HelpLine").data("kendoDropDownList").value(helplineid);
        $("#HelpLine").data("kendoDropDownList").enable(false);
        if (e.model.Editable.toLowerCase() == "false")
            $('#editable').prop("checked", false);
        else
            $('#editable').prop("checked", true);
        $("#chkeditable").hide();

        $("#ContingencyWavefileTag").css("visibility", "visible");
        $("#ContingencyWavefileTag").html('<ul class="k-upload-files k-reset"><li class="k-file" <span class="k-progress"></span><span class="k-file-extension-wrapper"><span class="k-file-extension">wav</span><span class="k-file-state"></span></span><span class="k-file-name-size-wrapper"><span class="k-file-name" title="' + e.model.WaveFile + '">' + e.model.WaveFile + '</span></span><strong class="k-upload-status"></strong></li></ul>');

        $("#waveFile").css("visibility", "visible");
        $("#waveFile").html(e.model.WaveFile);
    }
    if (e.model.isNew() == true) {
        $("#waveFile").css("visibility", "hidden");
        $("#ContingencyWavefileTag").css("visibility", "hidden");
        $("#Description").data("kendoDropDownList").enable(true);
        $("#HelpLine").data("kendoDropDownList").enable(true);
        $('#editable').prop("checked", true);
        $("#chkeditable").show();
    } 
}

function CheckForDupplicate(e, obj) {
    var helpLineID = e.model.HelpLineID;
    var description = e.model.Description;
    var language = e.model.Language;
    var count = 0;
    var data = obj;
    for (t in obj) {
        if (obj[t].HelpLineID == helpLineID && obj[t].Description == description && obj[t].Language == language) {
            count++;
            if (count === 2) {
                return false;
            }
        }
    }
    return true;
}

function onSaveContingencyWaveFileUpload(e)
{
    e.model.HelpLineID = $("#HelpLine").data("kendoDropDownList").value();
    e.model.HelpLine = $("#HelpLine").data("kendoDropDownList").text();
    if (document.getElementById('editable').checked) {
        e.model.Editable = "True";
    }
    else {
        e.model.Editable = "False";
    }

    var fieldNames = new Array();
    var fieldValues = new Array();

    fieldNames.push("HelpLine", "Description","Language","Reference Wave File Name")
    fieldValues.push(e.model.HelpLineID, e.model.Description,e.model.Language, e.model.ReferenceWaveFileName);

    var result = validateBlankFields(fieldNames, fieldValues);

    if ($.trim(result) != "") {
        toaster("Please provide input for " + result, "error");
        e.preventDefault();
        return false;
    }

    if (CheckForDupplicate(e, this.dataSource.data()) === false) {
        toaster("Duplicate Wave file for same HelpLine.", "error");
        e.preventDefault();
        return;
    }

    if ($("#waveFile").val() !== "") {
        if ($("#waveFile").val().indexOf(".wav") > 0) {
            e.model.WaveFile = $("#waveFile").val();
            $(".k-upload-selected").trigger("click");
        }
        else {
            toaster("Please upload only wav file!", "error");
            e.preventDefault();
            return;
        }

    }
    else if (e.model.waveFileTag === "" || e.model.WaveFile === "") {
        toaster("Please upload a wav file!", "error");
        e.preventDefault();
        return;
    }
    if (e.model.waveFileTag !== "" && e.model.ModifyReason === null) {
        toaster("Please provide modify reason!", "error");
        e.preventDefault();
        return;
    }
    modifyValid(e);
}

function attachClickHandler(e) {
    readFileAfterDelegate = setFileUploadValues;
    readFile(e, this.wrapper, "wav", $("#waveFile"));
}

function setFileUploadValues(isValidFile, fileInfo, control) {
    if (isValidFile) {
        $("label[for='validation']").html("");
        control.val(fileInfo.name);
    }
}

function onWavFileUpload(e) {
    e.data = { helpline: $("#HelpLine").data("kendoDropDownList").text(), language: $("#Language").val() }; //sends the extra parameter to controller
}

function onWavFileRemove(e) {
    $("#waveFileName").val("")
}

function onChange(arg) {
    var selectedData = $.map(this.select(), function (item) {
        return $(item).text();
    });
    var str = String(selectedData[0].match(/.wav/g));
    if (str == ".wav") {
        var $grid = arg.sender; //grid ref
        var $cell = $grid.select(); // selected td
        var $row = $cell.closest('tr'); //selected tr
        var url = $grid.dataItem($row).WaveFile;
        if (url == "") {
            toaster("There is no Wav File to Play", "error");
            return;
        }
        else {
            var link = url;
        }
    }
    else {
        toaster("Select a Wav File", "info");
        return;
    }
}