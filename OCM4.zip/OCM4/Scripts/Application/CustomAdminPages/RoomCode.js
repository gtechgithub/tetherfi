﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "RoomCode.js",
        Version: "3.1.8.26",
        LastModifiedDateTime: "26-08-2018 00:00:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});
/**
 * on edit of agent telephony validate for number,email,text;
 */
function editRoomCode(e) {
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="RoomCode"]').attr("readonly", true);
    }
    genericEdit(e);

}

/**
 * on select of dropdown in Agent telephony validate  number,email,text
 */
function onSaveRoomCode(e) {
    duplicateValidate(e, "RoomCode", "RoomCode")
    modifyValid(e);
}
