﻿
$(document).ready(function () {
    /**
     * Define the Version
     * @returns {}
     */
    AddToFileVersionController({
        Location: "Application\\CustomAdminPages",
        FileName: "SRCTier.js",
         Version: "3.2.8.30",
        LastModifiedDateTime: "30-08-2019 08:30:00 AM",
        LastModifiedBy: "Prathik",
        Description: "Added versioning"
    });
});


function editSRCTier(e) {
    if (e.model.isNew() == false) {
        $(e.container).find('input[name="Code"]').attr("readonly", true);
    }
    genericEdit(e);

}
function onSaveSRCTier(e) {
    var code = $("#Code").val();
    var name = $("#Name").val();
    var description = $("#Description").val();
    if (code == "") {
        e.preventDefault();
        toaster("Please provide a valid Code", "error");
        return;
    }
    if (name == "") {
        e.preventDefault();
        toaster("Please provide a valid Name", "error");
        return;
    }
    if (description == "") {
        e.preventDefault();
        toaster("Please provide a valid Description", "error");
        return;
    }
    duplicateValidate(e, "Code", "Code")
    modifyValid(e);
}

function ReloadData() {
    $.ajax({
        type: "POST",
        url: window.ApplicationPath + 'SRCTier/ReloadData',
        headers: { "__RequestVerificationToken": $("#AntiForgeryToken").val() },
        dataType: "json",
        contentType: 'application/json',
        success: function (data) {
            if (data) {
                toaster("Data Reloaded Successfully", "success");
            }
        },
        error: function () {
            toaster("Failed to Reload Data", "error");
            console.log('Failed to Reload Data');
        }
    });
}
